# LFTR Marine Intelligence Globe

Clean installer README for the current GFS / RTOFS marine-globe build.


## Current visual patch: Bait continuous XYZ particle cloud

This package changes the default Bait-3D renderer from prism/cube clusters to one viewport-local particle cloud driven by the bait probability scalar field:

```text
B(lat, lon, depth_m) -> bait probability 0..1

Backend:
  OceanTruth / RTOFS / bathymetry / chlorophyll build the scalar field
  /gfs/api/bait-3d-volume emits thresholded field_samples

Frontend:
  static/js/layers/bait-3d.js maps field_samples into jittered XYZ particles
  50% probability is the alpha threshold
  higher probability = brighter / larger / more glow
  true depth is preserved in metadata; visual depth is scaled for Google Maps 3D
```

The older adaptive-lite cluster and full cube glyph renderers remain available as debug/alternate modes:

```js
window.GFS_BAIT_FIELD_RENDER_MODE = 'particle-cloud' // default
window.GFS_BAIT_FIELD_RENDER_MODE = 'adaptive-lite'  // old implicit cluster/prism renderer
window.GFS_BAIT_FIELD_RENDER_MODE = 'full-cubes'     // true cube glyph debug renderer
```

Useful browser flags before module load:

```js
window.GFS_BAIT_FIELD_THRESHOLD = 0.50
window.GFS_BAIT_FIELD_PARTICLE_MAX = 2200
window.GFS_BAIT_FIELD_PARTICLE_ALPHA_FULL_AT = 0.88
window.GFS_BAIT_FIELD_PARTICLE_CORE_SHELL = '1'
```

Verify the patch locally after the service is running:

```bash
bash scripts/check_bait_particle_cloud_field.sh
```


## Current visual patch: Google-floor math cutout, no visual bathymetry tiling

This package changes the ocean cutout renderer so the browser no longer draws tiled bathymetry floors by default.  The cutout now renders one viewport-local mathematical Google-altitude floor that can be zoomed through cleanly.

Key behavior:

```text
Ocean cutout visual:
  one mathematical Google-floor mask over the active viewport
  no tiled ETOPO/bathymetry floor cells by default
  no grid/rim/cell construction helpers by default
  rendered floor altitude stays in the shallow under-sea Google mask band

Ocean math/data:
  bathymetry tile endpoint remains available
  landmask / water fraction / ocean-connected gating remain server-side
  OceanTruth, bait scoring, boats, and depth metadata can still use bathymetry
```

Useful browser flags before module load:

```js
window.GFS_OCEAN_CUTOUT_SINGLE_FLOOR = '1'                 // default
window.GFS_OCEAN_CUTOUT_FLOOR_MASK_MODE = '1'             // default
window.GFS_OCEAN_CUTOUT_RENDER_BATHYMETRY_TILES = '0'     // default visual policy
window.GFS_OCEAN_CUTOUT_RENDER_BATHYMETRY_TILES = '1'     // debug: restore old visual tile floor
```

Verify the patch locally:

```bash
bash scripts/check_ocean_cutout_google_floor_math.sh
```

## Current pass: Unified Ocean Truth Interpolator

This pass introduces one marine source-of-truth contract for the ocean systems:

```text
OceanTruth.sample(lon, lat, depth_m, time)
```

The important rule is:

```text
voxels are not the source of truth
voxels / samples are temporary extraction anchors
```

RTOFS, bathymetry, atmosphere, and chlorophyll feed a continuous marine field. Bait, boats, and ocean cutout should consume that shared field instead of inventing separate viewports or square domains.

## What uses OceanTruth now

```text
Bait:
  /gfs/api/bait-3d-volume now prefers OceanTruth
  chlorophyll late-injects as a score booster
  the Bait pill renders one thresholded scalar-field particle cloud underwater, not surface bait or discrete schools

Boats:
  boater renderer can fetch /gfs/api/ocean-truth when scene-frame boater points are missing/warming/small
  boat points come from the same ocean-connected bathymetry + RTOFS surface sample domain

Ocean:
  bathymetry mask remains ocean-connected only
  known inland below-sea-level basins stay rejected

Clouds:
  clouds stay outside OceanTruth for now because clouds are atmospheric and not ocean-landmasked
```

## Chlorophyll policy

Chlorophyll is allowed to be slow.

```text
initial render:
  bathymetry + RTOFS + atmosphere truth renders immediately

late render:
  chlorophyll warms in the background
  cached chlorophyll is reused for 8 hours
  when ready, it only raises/nudges bait probability
  it must not blank bait or force a full scene reset
```

## Install

```bash
cd ~/broadcast
unzip -o GFSBroadcast_UnifiedOceanTruthInterpolatorPass.zip -d /tmp/lftr_unified_ocean_truth
cd /tmp/lftr_unified_ocean_truth/broadcast
bash deploy/install.sh
sudo systemctl restart broadcast
```

## Verify

```bash
cd ~/broadcast
source venv/bin/activate
bash scripts/check_unified_ocean_truth_interpolator.sh
```

Good signs:

```text
schema = lftr_ocean_truth_interpolator_v1
truth_is_not_voxels = true
sample_count > 0
ocean_truth.enabled = true
chlorophyll.status = loading OR ready
cloud_count > 0
boats_points > 0 once RTOFS surface cache is warm
```

## Useful browser console checks

```js
({
  bait3d: window.__gfsBait3dStats,
  field: window.__gfsBaitFieldStats,
  volume: window.__gfsBait3dVolume && {
    ok: window.__gfsBait3dVolume.ok,
    source: window.__gfsBait3dVolume.source,
    ocean_truth: window.__gfsBait3dVolume.ocean_truth,
    shape: window.__gfsBait3dVolume.shape,
    field_sample_count: window.__gfsBait3dVolume.field_sample_count,
    policy: window.__gfsBait3dVolume.field_render_policy
  },
  boats: window.__gfsBoatsRenderState?.lastStats,
  fieldNodes: document.querySelectorAll('[data-bait-renderer="bait-probability-scalar-field"]').length
})
```

## Bathymetry cache

The installer preserves existing bathymetry cache directories. If the SoCal cache is empty, seed/rebuild once:

```bash
cd ~/broadcast
source venv/bin/activate
bash scripts/seed_bathymetry_socal_cache.sh
python3 scripts/build_bathymetry_4deg_cache.py --bbox=-125,32,-117,38 --grid 32 --force || true
```

The build may print a NetCDF cleanup segmentation fault after files are written. If the API reports tile files and water cells, the cache itself is usable.

## Native RTOFS 3D trilinear pass

This pass moves the ocean truth implementation closer to the intended math model:

```text
RTOFS native 3D field
  temperature(lon,lat,depth,time)
  salinity(lon,lat,depth,time)
  u(lon,lat,depth,time)
  v(lon,lat,depth,time)

OceanTruth.sample(lon, lat, depth_m, time)
```

Surface is now treated as the same sampler at `depth_m=0`, not as a separate concept:

```text
surface = OceanTruth.sample(lon, lat, 0, time)
bait    = OceanTruth.sample(lon, lat, chosen_bait_depth_m, time)
```

Request handlers still do not open NetCDF directly. Warm the native 3D cache first, or let the bait endpoint spawn it with `warm=1`:

```bash
cd ~/broadcast
source venv/bin/activate
python3 scripts/warm_rtofs_3d_truth_cache.py --bbox=-125,32,-117,38
bash scripts/check_ocean_truth_3d_trilinear.sh
```

Good signs after the warmer completes:

```text
rtofs_3d.ok = true
rtofs_3d.status = ready
rtofs_3d.field_shape = [z, y, x]
first_sample.sample_method = rtofs_native_3d_trilinear
first_sample.bait_depth_m > 0
first_sample.bait_sample.sample_method = rtofs_native_3d_trilinear
```

## Subsurface bait visual-depth pass

This pass fixes two issues found during the first native-3D run:

1. RTOFS regional 3DZ HVR files may expose `Latitude`/`Longitude` as 2-D curvilinear Y/X grids. The warmer now accepts those files and builds compact local mean axes for the native `[z,y,x]` field cache instead of rejecting them as `missing_or_not_1d`.
2. Bait depths of 30-60 m are real but visually tiny on a 3D globe, so they can look surface-attached. The frontend now keeps true depth in `data-bait-true-depth-m`, renders the school at an exaggerated negative visual altitude, and draws optional faint depth stems from the surface to the school.

Default visual-depth controls:

```js
window.GFS_BAIT_3D_VISUAL_DEPTH_SCALE = 14
window.GFS_BAIT_3D_MIN_VISUAL_DEPTH_M = 90
window.GFS_BAIT_3D_MAX_VISUAL_DEPTH_M = 1400
window.GFS_BAIT_3D_SHOW_DEPTH_STEMS = 1
window.GFS_BAIT_3D_REPLACES_SURFACE_BAIT = 1
```

The legacy surface bait renderer is skipped while bait-3D is active, so the visible bait bodies should now come from the subsurface bait renderer rather than flat scene-frame polygons.


## Bait scalar-field mode

The Bait pill now renders field mode only: a thresholded subsurface bait-probability scalar field.  It does not draw legacy surface bait or discrete school bodies when `bait-3d` is active.

Endpoint contract:

```bash
/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=0,5,10,20,35,50,75,100,150,200&threshold=0.48&max_field_points=2200&max_clouds=0&mode=field
```

The payload includes `field_samples[]` above threshold, each with lon/lat/depth/probability and optional OceanTruth variables.  The frontend renders transparent underwater cell patches with this ramp:

`pastel yellow -> neon yellow -> pastel green -> neon green`

Check:

```bash
bash scripts/check_bait_scalar_field_mode.sh
```

## Bait scalar field contoured cubes

The Bait pill now uses field mode only for the global /gfs viewport.  It renders thresholded bait-probability samples as underwater contoured cube cells, not discrete bait schools.  Default depth bins are about 10 ft near the surface so adjacent cells read as a connected 3D scalar field.  Probability controls the pastel yellow → neon yellow → pastel green → neon green ramp, with transparency concentrated near the threshold and glow/outline emphasis on hotter cubes.

Useful browser knobs:

```js
window.GFS_BAIT_FIELD_THRESHOLD = 0.55       // raise to show less field
window.GFS_BAIT_FIELD_MAX_RENDERED = 12000  // raise cautiously on strong clients
window.GFS_BAIT_FIELD_MAX_DOM_NODES = 26000 // hard DOM safety budget
window.GFS_BAIT_FIELD_CUBE_STEP_FT = 10     // vertical cube bin target
```

Diagnostics:

```bash
bash scripts/check_bait_contoured_cube_field.sh
```

## Bait field true cube glyph no-sheet patch

The Bait pill now defaults to field mode rendered as thresholded cube glyphs instead of wide source-cell surface/depth sheets.

Key browser knobs:

```js
window.GFS_BAIT_FIELD_NO_SURFACE_SHEETS = '1';  // default
window.GFS_BAIT_FIELD_DRAW_TOP_FACE = '0';      // default: avoid sheet look
window.GFS_BAIT_FIELD_DRAW_ALL_SIDES = '1';     // default
window.GFS_BAIT_FIELD_CUBE_HORIZONTAL_FT = 10;  // true logical cube edge
window.GFS_BAIT_FIELD_CUBE_VISUAL_HORIZONTAL_SCALE = 80; // readable visual glyph
window.GFS_BAIT_FIELD_MAX_RENDERED = 12000;
window.GFS_BAIT_FIELD_MAX_DOM_NODES = 26000;
```

Run:

```bash
bash scripts/check_bait_true_cube_glyphs_no_sheets.sh
```

## 2026-06-13 bait adaptive-lite field renderer

This pass keeps the visual style of the glowing bait scalar field, but makes the global viewport lighter.

### Stanza 1 — Bait owns bait

The Bait pill now owns the bait probability field renderer.  When bait-3d field mode is active, the scene-frame request no longer asks for legacy flat bait, and the field/current fallback no longer creates synthetic bait from current points.

### Stanza 2 — Boats own boats

The Boats pill now owns boat hydration.  If boats are missing from the combined scene-frame, the marine supplement requests `boats` only, and the field/current fallback creates `boater` only.

### Stanza 3 — Keep the look, reduce the DOM

Default bait rendering is now `adaptive-lite`: hot depth cells are aggregated into glowing contour anchors.  The palette and style remain pastel yellow → neon yellow → pastel green → neon green, with outlines and glow, but it no longer draws every 10 ft cube by default.

Override in the browser before loading `/gfs` if full cube mode is needed:

```js
window.GFS_BAIT_FIELD_RENDER_MODE = "full-cubes";
window.GFS_BAIT_FIELD_MAX_RENDERED = 12000;
window.GFS_BAIT_FIELD_MAX_DOM_NODES = 26000;
```

Useful default knobs:

```js
window.GFS_BAIT_FIELD_LITE_MAX_ANCHORS = 950;
window.GFS_BAIT_FIELD_MAX_DOM_NODES = 6200;
window.GFS_BAIT_FIELD_THRESHOLD = 0.50;
```

### Stanza 4 — Wider /gfs viewport

The clean-spine `/gfs` layout now uses a compact title/status area and gives the globe the full remaining screen height.

### Check

```bash
bash scripts/check_bait_adaptive_lite_pills_viewport.sh
```

#!/usr/bin/env python3
"""Build LFTR 4-degree bathymetry tiles from NOAA/NCEI ETOPO 2022.

Viewport/local build:
  python3 scripts/build_bathymetry_4deg_cache.py --bbox=-125,32,-117,38 --grid 16

Whole-world resumable cache build:
  python3 scripts/build_bathymetry_4deg_cache.py --world --grid 16 --missing-only

Chunked world build, useful on a server shell:
  python3 scripts/build_bathymetry_4deg_cache.py --world --grid 16 --missing-only --start-index 0 --max-build 250

Runtime /gfs/api/bathymetry-tiles is cache-first. This builder is the tool that
fills the world cache ahead of camera moves.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from server.gfs.bathymetry_tiles import (  # noqa: E402
    DEFAULT_TILE_DEG,
    _open_etopo_dataset,
    _tile_path,
    build_tile_from_source,
    cache_inventory,
    tiles_for_bbox,
    world_tiles,
)


def parse_bbox(raw: str | None):
    if not raw:
        return {"west": -125.0, "south": 32.0, "east": -117.0, "north": 38.0}
    parts = [float(x.strip()) for x in raw.split(",")[:4]]
    if len(parts) != 4:
        raise ValueError("bbox must be west,south,east,north")
    return {"west": parts[0], "south": parts[1], "east": parts[2], "north": parts[3]}


def tile_exists(tile: dict, tile_deg: float) -> bool:
    return _tile_path(ROOT, str(tile.get("tile_id")), float(tile.get("tile_deg") or tile_deg)).exists()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bbox", default="-125,32,-117,38", help="west,south,east,north")
    ap.add_argument("--world", action="store_true", help="enumerate the full 4-degree world tile grid")
    ap.add_argument("--tile-deg", type=float, default=DEFAULT_TILE_DEG)
    ap.add_argument("--grid", type=int, default=16, help="render depth grid per tile, e.g. 8, 16, or 32")
    ap.add_argument("--limit", type=int, default=60, help="bbox tile enumeration cap; ignored for --world")
    ap.add_argument("--start-index", type=int, default=0, help="start index for chunked/resumable world builds")
    ap.add_argument("--max-build", type=int, default=0, help="maximum tiles to build this run; 0 means all selected")
    ap.add_argument("--missing-only", action="store_true", help="skip tiles already present in the cache")
    ap.add_argument("--force", action="store_true", help="overwrite existing tiles, including lower-grid cache files")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if args.world:
        bbox = {"west": -180.0, "south": -90.0, "east": 180.0, "north": 90.0}
        tiles = world_tiles(tile_deg=args.tile_deg, limit=10000)
    else:
        bbox = parse_bbox(args.bbox)
        tiles = tiles_for_bbox(bbox, tile_deg=args.tile_deg, limit=args.limit)

    start = max(0, int(args.start_index or 0))
    selected = tiles[start:]
    if args.max_build and args.max_build > 0:
        selected = selected[: args.max_build]

    skipped_existing = []
    to_build = []
    for tile in selected:
        exists = tile_exists(tile, args.tile_deg)
        if exists and (args.missing_only or not args.force):
            skipped_existing.append(tile)
            continue
        to_build.append(tile)

    print(json.dumps({
        "ok": True,
        "action": "build_bathymetry_4deg_cache",
        "mode": "world" if args.world else "bbox",
        "bbox": bbox,
        "tile_deg": args.tile_deg,
        "grid": args.grid,
        "total_tile_count": len(tiles),
        "selected_tile_count": len(selected),
        "build_tile_count": len(to_build),
        "skipped_existing_count": len(skipped_existing),
        "start_index": start,
        "max_build": args.max_build,
        "tiles": to_build[:25],
        "cache": cache_inventory(ROOT, args.tile_deg),
    }, indent=2))
    if args.dry_run or not to_build:
        return 0

    ds, url = _open_etopo_dataset()
    print(f"OPENED_SOURCE {url}")
    built = []
    errors = []
    try:
        for i, tile in enumerate(to_build, 1):
            print(f"BUILD {i}/{len(to_build)} {tile['tile_id']} bbox={tile['bbox']}", flush=True)
            try:
                out = build_tile_from_source(ROOT, tile, render_grid=args.grid, dataset=ds)
                built.append({
                    "tile_id": out.get("tile_id"),
                    "path": out.get("cache", {}).get("path"),
                    "depth_mean_m": out.get("depth_mean_m"),
                    "depth_max_m": out.get("depth_max_m"),
                    "water_fraction": out.get("water_fraction"),
                    "grid": out.get("render_grid", {}).get("rows"),
                    "water_cells": out.get("cutaway_mask", {}).get("water_render_cells"),
                    "land_cells": out.get("cutaway_mask", {}).get("land_render_cells"),
                })
            except Exception as exc:
                errors.append({"tile_id": tile.get("tile_id"), "error": str(exc)})
                print(f"ERROR {tile.get('tile_id')} {exc}", flush=True)
    finally:
        try:
            ds.close()
        except Exception:
            pass
    print(json.dumps({
        "ok": not errors,
        "built_count": len(built),
        "error_count": len(errors),
        "built": built,
        "errors": errors[:25],
        "cache": cache_inventory(ROOT, args.tile_deg),
    }, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$(pwd)}"
if [[ ! -f "$ROOT/static/js/layers/bait-3d.js" ]]; then
  echo "Run from broadcast root or pass broadcast root path" >&2
  exit 2
fi
BAIT="$ROOT/static/js/layers/bait-3d.js"
INDEX="$ROOT/static/js/index.js"

grep -q "FIELD_PARTICLE_BODY_LENGTH_IN.*|| 4" "$BAIT"
grep -q "FIELD_PARTICLE_BODY_WORLD_M" "$BAIT"
grep -q "data-bait-body-scale-policy.*no-body-scale_glow-only" "$BAIT"
grep -q "body not scaled, glow only" "$BAIT"
grep -q "FIELD_PARTICLE_GLOW_MIN_PX" "$BAIT"
grep -q "FIELD_PARTICLE_GLOW_MAX_PX" "$BAIT"
grep -q "sizePreserved = false" "$BAIT"
grep -q "20260615-bait-4in-glow-only-v12" "$INDEX"

if grep -q "const sizePx = FIELD_PARTICLE_SIZE_MIN" "$BAIT"; then
  echo "FAILED: bait body is still probability-scaled with sizePx" >&2
  exit 1
fi

echo "OK: bait cedar-plug ellipse body is fixed 4in/no body scale; glow halo carries visibility; cache bust is v12."

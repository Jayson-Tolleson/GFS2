#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== syntax =="
python3 -m compileall -q server scripts
node --check static/js/index.js >/dev/null
node --check static/js/layers/bait-3d.js >/dev/null

echo "== bait adaptive-lite renderer contract =="
grep -n "bait_probability_scalar_field_adaptive_lite_glow_contours_v4" static/js/layers/bait-3d.js
grep -n "FIELD_LITE_MAX_ANCHORS" static/js/layers/bait-3d.js | head -3
grep -n "renderScalarFieldLite" static/js/layers/bait-3d.js

echo "== pill separation contract =="
grep -n "filter((name) => !shouldSkipLegacyBaitRender(name))" static/js/index.js
grep -n "neededMarineSupplementLayers" static/js/index.js
grep -n "field_current_boats_only" static/js/index.js
if grep -n "field_current_rtofs_ocean_points_bait_fallback\|render_flattened_bait_beacons_from_ocean_points" static/js/index.js; then
  echo "legacy bait fallback still present" >&2
  exit 1
fi

echo "== wide viewport css contract =="
grep -n "20260613 wide-viewport" static/gfs.css
grep -n "min-height:calc(100vh - 68px)" static/gfs.css

echo "== optional live bait endpoint sample =="
if command -v curl >/dev/null && command -v jq >/dev/null; then
  curl -fsS --max-time 12 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&grid=10&max_clouds=0&max_cells=120&threshold=0.50&max_field_points=400&chlorophyll=warm&truth=1&warm=0&mode=field&render=cubes" \
    | jq '{ok, source, field_sample_count, cloud_count, shape, policy:.field_render_policy, first:(.field_samples[0] // null)}' || true
else
  echo "curl/jq not available; skipped live endpoint"
fi

echo "OK bait adaptive-lite/pill/viewport contract present"

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
from pathlib import Path
idx = Path('static/js/index.js').read_text()
boats = Path('static/js/gfs/boats.js').read_text()
bait = Path('server/gfs/bait_scalar_field.py').read_text()
assert 'GFS_ENABLE_FRONTEND_BOAT_FIELD_FALLBACK' in idx, 'frontend boat field fallback gate missing'
assert 'frontend field/current boat fabrication disabled' in idx, 'field/current no-fabrication policy missing'
assert 'if (!boatPayloadSstReady(payload)) return [];' in boats, 'boats still render from non-ready payload arrays'
assert 'available: Boolean(hasCurrentSignal)' in boats, 'current signal availability marker missing'
assert 'FIELD_EXTRACTION_FLOOR = 0.05' in bait, 'bait extraction floor not lowered'
assert '_samples_from_full_field_payload' in bait and 'full_field_low_floor_extraction' in bait, 'bait recovery extraction missing'
print('OK regression gates: no frontend synthetic boats; bait scalar cloud recovers from full field while keeping 0.80 display threshold')
PY

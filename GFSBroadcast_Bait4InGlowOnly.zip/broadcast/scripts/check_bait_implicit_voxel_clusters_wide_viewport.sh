#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo '== implicit voxel cluster bait renderer =='
grep -n "implicit voxel clusters\|FIELD_IMPLICIT_CLUSTER_ENABLED\|requestBboxForField\|GFS_SCENE_VIEWPORT_PAD" static/js/layers/bait-3d.js static/js/index.js | sed -n '1,120p'
echo
echo '== wide viewport frame wiring =='
grep -n 'data-app="gfs-clean-spine"\|20260614-bait-implicit-clusters-wide-viewport-v5' static/gfs.html templates/index.html static/gfs.css | sed -n '1,120p'

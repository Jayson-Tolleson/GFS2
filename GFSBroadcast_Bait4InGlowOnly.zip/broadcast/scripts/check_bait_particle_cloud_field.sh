#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BBOX="${BBOX:--125,32,-117,38}"
THRESHOLD="${THRESHOLD:-0.50}"
MAX_FIELD_POINTS="${MAX_FIELD_POINTS:-2800}"
DEPTHS="${DEPTHS:-0,3.048,6.096,9.144,12.192,15.24,18.288,21.336,24.384,27.432,30.48,36.576,45.72,60.96,76.2,91.44,121.92,152.4,200}"

echo "== frontend bait particle-cloud syntax =="
node --check static/js/layers/bait-3d.js

echo

echo "== bait continuous XYZ particle-cloud endpoint contract =="
curl -sS "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=${BBOX}&depths=${DEPTHS}&grid=20&max_clouds=0&max_cells=1200&threshold=${THRESHOLD}&max_field_points=${MAX_FIELD_POINTS}&chlorophyll=warm&truth=1&warm=1&mode=field&render=particle_cloud" \
| jq '{
  ok,
  schema,
  source,
  shape,
  count,
  field_sample_count,
  field_render_policy,
  continuous_field,
  math_contract,
  probability: {
    min: ([.field_samples[]?.probability] | min // null),
    max: ([.field_samples[]?.probability] | max // null),
    avg: (([.field_samples[]?.probability] | add) / ([.field_samples[]?.probability] | length) // null)
  },
  depths: {
    min: ([.field_samples[]?.depth_m] | min // null),
    max: ([.field_samples[]?.depth_m] | max // null),
    unique_count: ([.field_samples[]?.depth_m] | unique | length)
  },
  first: (.field_samples[0] // null)
}'

echo

echo "== frontend particle-cloud renderer contract =="
grep -RInE --exclude-dir=__pycache__ \
  "particle-cloud|bait-scalar-field-particle-cloud|FIELD_PARTICLE_CLOUD_ENABLED|probabilityAlpha|particle_alpha_threshold|20260614-bait-particle-cloud-field-v6" \
  static/js/layers/bait-3d.js templates/index.html server/gfs/bait_volume.py server/gfs/routes.py \
| sed -n '1,180p'

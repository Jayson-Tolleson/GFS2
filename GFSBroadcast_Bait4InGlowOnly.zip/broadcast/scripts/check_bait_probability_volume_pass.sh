#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "== syntax =="
python3 -m py_compile server/gfs/bait_volume.py server/gfs/routes.py server/gfs/rtofs_source.py
node --check static/js/index.js
node --check static/js/layers/bait-3d.js
node --check static/js/layers/ocean-glass.js

echo "== contracts =="
grep -q "data-layer=\"ocean-glass\"" templates/index.html && { echo "Ocean Cutout is still a clickable pill"; exit 1; } || true
grep -q "Ocean Cutout: Standard" templates/index.html
grep -q "bait-3d" static/js/index.js
grep -q "__gfsBait3dStats" static/js/layers/bait-3d.js
grep -q "@bp.get(\"/gfs/api/bait-3d-volume\")" server/gfs/routes.py

echo "== live endpoint if server is running =="
if curl -fsS --max-time 3 "http://127.0.0.1:8000/gfs/api/status" >/dev/null 2>&1; then
  curl -sS --max-time 20 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=0,5,10,20,35,50,75,100&grid=16&max_clouds=12" \
    | jq '{ok,source,shape,cloud_count,depths_m,rtofs_surface:{ok,status,count},rtofs_3d:{status,selected_candidate},math_contract}'
else
  echo "server not running; skipped live curl"
fi

echo "PASS bait probability volume pass"

#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"
fail=0
need(){ grep -R "$1" -n "$2" >/dev/null || { echo "MISSING: $1 in $2" >&2; fail=1; }; }
need "/gfs/api/bait-field-cloud" server/gfs/routes.py
need "FIELD_RENDER_MODE = String(window.GFS_BAIT_FIELD_RENDER_MODE || 'particle-cloud')" static/js/layers/bait-3d.js
need "bait-scalar-field-cedar-plug-ellipse-point-cloud" static/js/layers/bait-3d.js
need "silver_top_white_bottom_black_outline_cedar_plug_eye" static/js/layers/bait-3d.js
need "data-bait-alpha-threshold" static/js/layers/bait-3d.js
need "hardClearLegacyBaitDom" static/js/index.js
need "bait-scalar-cloud-no-fake-boats-v11" static/js/index.js
need "bait-scalar-cloud-no-fake-boats-v11" templates/index.html
if grep -R "const MODULE_VERSION = '20260614-google-floor-math-cutout-v8'" -n static/js/index.js >/dev/null; then
  echo "OLD MODULE_VERSION still present" >&2
  fail=1
fi
if (( fail )); then
  exit 1
fi
cat <<'OK'
OK bait scalar cloud browser contract:
- /gfs uses cache-busted v11 clean spine
- layer modules import with v11, so stale yellow-square bait-3d is not reused
- bait-3d defaults to /gfs/api/bait-field-cloud particle-cloud mode
- cedar-plug ellipse sprites are the rendered particles
- legacy yellow surface bait DOM is hard-cleared when bait-3d is active
OK

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

fail(){ echo "FAIL: $*" >&2; exit 1; }

python3 -m py_compile \
  server/gfs/bait_volume.py \
  server/gfs/bait_scalar_field.py \
  server/gfs/bait_cloud_sampler.py \
  server/gfs/harbor_water_mask.py \
  server/gfs/routes.py

node --check static/js/layers/bait-3d.js >/dev/null

grep -q '/gfs/api/bait-field-cloud' server/gfs/routes.py || fail 'missing bait-field-cloud route'
grep -q 'threshold=0.80' server/gfs/bait_scalar_field.py || fail 'missing default 80% scalar field threshold'
grep -q 'viewport_top20_quantile' server/gfs/bait_scalar_field.py || fail 'missing top-20 calibration contract'
grep -q 'harbor_water_valid' server/gfs/bait_volume.py || fail 'bait volume does not use harbor-safe water validity'
grep -q 'min_water_fraction: float = 0.08' server/gfs/bait_volume.py || fail 'harbor/coastal water fraction default not relaxed'
grep -q 'cedar_plug_eye_silver_top_white_bottom_black_outline' static/js/layers/bait-3d.js || fail 'cedar-plug ellipse sprite style missing'
grep -q 'FIELD_THRESHOLD = Number(window.GFS_BAIT_FIELD_THRESHOLD || 0.80)' static/js/layers/bait-3d.js || fail 'frontend default threshold is not 80%'
grep -q 'FIELD_PARTICLE_CORE_SHELL.*0' static/js/layers/bait-3d.js || fail 'core shell should be off by default for pure point cloud mass'

echo 'OK bait scalar field cloud contract: /gfs/api/bait-field-cloud, harbor water preserved, 80% top-field threshold, cedar-plug ellipse sprites.'

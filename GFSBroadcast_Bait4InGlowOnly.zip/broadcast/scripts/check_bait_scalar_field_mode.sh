#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BBOX="${BBOX:--125,32,-117,38}"
THRESHOLD="${THRESHOLD:-0.50}"
MAX_FIELD_POINTS="${MAX_FIELD_POINTS:-7200}"
DEPTHS="${DEPTHS:-0,3.048,6.096,9.144,12.192,15.24,18.288,21.336,24.384,27.432,30.48,36.576,45.72,60.96,76.2,91.44,121.92,152.4,200}"

echo "== bait scalar field endpoint =="
curl -sS "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=${BBOX}&depths=${DEPTHS}&grid=18&max_clouds=0&max_cells=1800&threshold=${THRESHOLD}&max_field_points=${MAX_FIELD_POINTS}&chlorophyll=warm&truth=1&warm=1&mode=field" \
| jq '{
  ok,
  schema,
  source,
  shape,
  count,
  field_sample_count,
  field_render_policy,
  render_expectation: "contoured cubes + outline lines + glow particles",
  rtofs_3d: {ok:.rtofs_3d.ok,status:.rtofs_3d.status,field_shape:.rtofs_3d.field_shape},
  ocean_truth: {enabled:.ocean_truth.enabled,sample_count:.ocean_truth.sample_count,chlorophyll:.ocean_truth.chlorophyll.status},
  probability: {
    min: ([.field_samples[]?.probability] | min // null),
    max: ([.field_samples[]?.probability] | max // null),
    avg: (([.field_samples[]?.probability] | add) / ([.field_samples[]?.probability] | length) // null)
  },
  depths: {
    min: ([.field_samples[]?.depth_m] | min // null),
    max: ([.field_samples[]?.depth_m] | max // null),
    unique: ([.field_samples[]?.depth_m] | unique)
  },
  first: (.field_samples[0] // null)
}'

echo

echo "== frontend scalar-field renderer contract =="
grep -RIn --exclude-dir=__pycache__ \
  "bait-probability-contoured-cubes\|glow-particle\|pastel yellow\|FIELD_THRESHOLD\|max_field_points\|field_samples" \
  static/js/layers/bait-3d.js server/gfs/bait_volume.py server/gfs/routes.py \
| head -120

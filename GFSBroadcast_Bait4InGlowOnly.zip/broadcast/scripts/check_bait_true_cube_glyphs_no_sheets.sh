#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== syntax =="
python3 -m py_compile server/gfs/bait_volume.py server/gfs/ocean_truth.py server/gfs/rtofs_3d_truth.py 2>/dev/null || true
node --check static/js/layers/bait-3d.js
node --check static/js/index.js

echo
 echo "== bait cube renderer contract =="
grep -RIn --exclude-dir=__pycache__ \
  "true_cube_glyphs_v3_no_sheets\|FIELD_NO_SURFACE_SHEETS\|cubeFootprintForSample\|FIELD_DRAW_TOP_FACE\|data-bait-no-surface-sheets\|MODULE_VERSION" \
  static/js/layers/bait-3d.js static/js/index.js templates/index.html

echo
 echo "== endpoint field payload smoke =="
if command -v curl >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
  if curl -fsS --max-time 20 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=0,3.048,6.096,9.144,12.192,15.24,18.288,21.336,24.384,27.432,30.48,36.576,45.72,60.96,76.2,91.44&grid=20&max_clouds=0&max_cells=2400&threshold=0.50&max_field_points=2000&chlorophyll=warm&truth=1&mode=field&render=cubes" \
    | jq '{ok, source, field_sample_count, field_render_policy, shape, first_field_sample: (.field_samples[0] // null)}'; then
    true
  else
    echo "local server not reachable on 127.0.0.1:8000; endpoint smoke skipped"
  fi
else
  echo "curl/jq unavailable; skipped live endpoint smoke"
fi

echo
cat <<'TXT'
Browser console check after hard refresh:
({
  stats: window.__gfsBaitFieldStats,
  cubes: document.querySelectorAll('[data-bait-renderer="bait-probability-contoured-cubes"]').length,
  noSheet: document.querySelectorAll('[data-bait-no-surface-sheets="true"]').length,
  optionalTopFaces: document.querySelectorAll('[data-bait-top-face-optional="true"]').length,
  verticalEdges: document.querySelectorAll('[data-bait-cube-face="cube-vertical-edge"]').length,
  glows: document.querySelectorAll('[data-bait-renderer="bait-probability-glow-particle"]').length
})
Expected:
  stats.renderer == "bait_probability_scalar_field_true_cube_glyphs_v3_no_sheets"
  stats.no_surface_sheets == true
  optionalTopFaces == 0 by default
  verticalEdges > 0
TXT

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail=0
check(){
  local label="$1"; shift
  if "$@"; then echo "✓ $label"; else echo "✗ $label" >&2; fail=1; fi
}
check "canonical-only broadcast route: alias removed" bash -c "grep -q '@app.get(\"/broadcast\")' server/routes_core.py && ! grep -q 'mobile-broadcast\|/broadcast/mobile' server/routes_core.py"
check "canonical-only watch route: alias removed" bash -c "grep -q '@app.get(\"/watch\")' server/routes_core.py && ! grep -q '/watch/mobile' server/routes_core.py"
check "broadcast status API present" grep -q "/api/broadcast/status" server/broadcast/routes.py
check "status documents unified route policy" grep -q "mobile_and_desktop_supported_on_same_routes" server/broadcast/routes.py
check "native SpeechRecognition path present" grep -q 'startNativeSpeechRecognition' static/js/broadcast.js
check "server PCM Firefox fallback present" grep -q 'server PCM capture started' static/js/broadcast.js
check "STT transcript websocket type handled" grep -q 'stt_transcript' server/broadcast/routes.py
check "server PCM chunks treated final unless interim" grep -q 'stt_final = not bool(data.get("interim")' server/broadcast/routes.py
check "screen share capability guard present" grep -q 'hasScreenShareSupport' static/js/broadcast.js
check "single-tap mobile control guard present" grep -q 'reliable single-tap' static/js/broadcast.js
check "camera front/back scoring present" grep -q 'scoreFrontCamera' static/js/broadcast.js
check "broadcast page cache-busted unified route" grep -q 'broadcast-unified-route-v13' static/broadcast.html
check "watch page cache-busted unified route" grep -q 'watch-unified-route-v13' static/watch.html
python3 -m py_compile server/broadcast/routes.py server/routes_core.py >/dev/null
node --check static/js/broadcast.js >/dev/null
check "python/js syntax checks pass" test $? -eq 0
if [[ $fail -ne 0 ]]; then exit 1; fi

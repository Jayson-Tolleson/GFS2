#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail=0
check(){
  local label="$1"; shift
  if "$@"; then echo "✓ $label"; else echo "✗ $label" >&2; fail=1; fi
}
check "only canonical /broadcast page route is registered" bash -c "grep -q '@app.get(\"/broadcast\")' server/routes_core.py && ! grep -q '/broadcast/mobile\|mobile-broadcast' server/routes_core.py"
check "only canonical /watch page route is registered" bash -c "grep -q '@app.get(\"/watch\")' server/routes_core.py && ! grep -q '/watch/mobile' server/routes_core.py"
check "broadcast html declares unified mobile/desktop canonical route" grep -q "unifiedMobileDesktopRoute:true" static/broadcast.html
check "watch html declares unified mobile/desktop canonical route" grep -q "unifiedMobileDesktopRoute:true" static/watch.html
check "status API exposes canonical route policy" grep -q "canonical_only" server/broadcast/routes.py
check "STT and AI route patch retained" grep -q "stt_transcript" server/broadcast/routes.py
check "broadcast browser capability probes retained" grep -q "hasScreenShareSupport" static/js/broadcast.js
python3 -m py_compile server/routes_core.py server/broadcast/routes.py >/dev/null
node --check static/js/broadcast.js >/dev/null
node --check static/js/watch.js >/dev/null
check "syntax checks pass" test $? -eq 0
if [[ $fail -ne 0 ]]; then exit 1; fi

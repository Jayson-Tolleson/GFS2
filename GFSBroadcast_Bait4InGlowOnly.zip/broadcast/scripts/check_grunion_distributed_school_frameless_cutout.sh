#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== syntax =="
python3 -m py_compile server/gfs/bait_volume.py server/gfs/bathymetry_tiles.py server/gfs/routes.py
node --check static/js/layers/bait-3d.js
node --check static/js/layers/ocean-glass.js

echo "== contracts =="
grep -q "viewport_clip_policy" server/gfs/bait_volume.py
grep -q "_spatially_distributed_cells" server/gfs/bait_volume.py
grep -q "grunion_school_bait_renderer_v2" static/js/layers/bait-3d.js
grep -q "schoolHeadingForCloud" static/js/layers/bait-3d.js
grep -q "GFS_OCEAN_CUTOUT_DRAW_SKIRT ?? '0'" static/js/layers/ocean-glass.js
test -x scripts/seed_bathymetry_socal_cache.sh

echo "== live endpoint if server is running =="
if curl -fsS --max-time 3 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=5,10,20,35,50,75,100&grid=16&max_clouds=24&max_cells=1200" >/tmp/gfs_bait3d_check.json 2>/dev/null; then
  jq '{ok,source,shape,cloud_count,bathymetry:{tile_count:.bathymetry.tile_count,viewport_clipped_cell_count:.bathymetry.viewport_clipped_cell_count,distributed_cell_count:.bathymetry.distributed_cell_count,viewport_clip_policy:.bathymetry.viewport_clip_policy},first_cloud:(.clouds[0]//null)|{id,lat,lon,probability,particle_count_hint,top_depth_m,bottom_depth_m,drift_heading_deg}}' /tmp/gfs_bait3d_check.json
else
  echo "server not running on 127.0.0.1:8000; skipped live check"
fi

echo "PASS grunion distributed school frameless cutout pass"

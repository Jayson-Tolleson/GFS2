#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== syntax =="
python3 -m py_compile server/gfs/bathymetry_tiles.py server/gfs/bait_volume.py server/gfs/routes.py
node --check static/js/layers/bait-3d.js
node --check static/js/layers/ocean-glass.js
node --check static/js/gfs/cloud-zones.js

echo "== markdown cleanup =="
find . -name '*.md' | sort
MD_COUNT=$(find . -name '*.md' | wc -l | tr -d ' ')
echo "markdown_count=$MD_COUNT"
test "$MD_COUNT" -eq 1

echo "== bathymetry cache presence =="
CACHE_DIR="data_sources/bathymetry/etopo2022_4deg_tiles"
COUNT=$(find "$CACHE_DIR" -maxdepth 1 -name '*.json' -type f 2>/dev/null | wc -l | tr -d ' ' || true)
echo "tile_json_count=$COUNT"
if [[ "$COUNT" -lt 6 && -x scripts/seed_bathymetry_socal_cache.sh ]]; then
  echo "cache has fewer than 6 seed tiles; seed script is available"
fi

echo "== contracts =="
grep -R "known_inland\|Salton\|Death Valley" server/gfs/bathymetry_tiles.py server/gfs/bait_volume.py >/dev/null
grep -R "grunion_geospatial_streak_renderer_v4_landmasked\|grunion-geospatial-streak" static/js/layers/bait-3d.js >/dev/null
grep -R "CLOUD_FRAMELESS_DEFAULT" static/js/gfs/cloud-zones.js >/dev/null

echo "== live endpoints if server is running =="
if curl -fsS --max-time 3 "http://127.0.0.1:8000/gfs/api/bathymetry-tiles?bbox=-125,32,-117,38&lod=coarse" >/tmp/lftr_bathy.json 2>/dev/null; then
  jq '{ok,tile_count,water_cells_total:([.tiles[]?.water_cells? // [] | length] | add // 0), sample_mode:(.tiles[0].cutaway_mask.mode // null), suppressed:([.tiles[]?.shoreline?.suppressed_inland_depression_cells // 0] | add // 0)}' /tmp/lftr_bathy.json
else
  echo "bathymetry endpoint not reachable; server may be stopped"
fi
if curl -fsS --max-time 3 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=5,10,20,35,50,75,100&grid=16&max_clouds=24&max_cells=1200" >/tmp/lftr_bait3d.json 2>/dev/null; then
  jq '{ok,shape,cloud_count,source, viewport_clip_policy:(.bathymetry.viewport_clip_policy // null), first_cloud:(.clouds[0] // null | {id,lat,lon,probability,drift_heading_deg})}' /tmp/lftr_bait3d.json
else
  echo "bait endpoint not reachable; server may be stopped"
fi
if curl -fsS --max-time 3 "http://127.0.0.1:8000/gfs/api/field?field=current&bbox=-125,32,-117,38" >/tmp/lftr_current.json 2>/dev/null; then
  jq '{ok,source,count,payload_state, sample:(.points[0] // .ocean_points[0] // .current_points[0] // null | {lat,lon,sst_c,water_temp_f,current_speed_kt,direction_deg,salinity})}' /tmp/lftr_current.json
else
  echo "field current endpoint not reachable; server may be stopped"
fi

echo "PASS grunion landmask orientation boater audit"

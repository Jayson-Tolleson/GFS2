#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== docs =="
MD_COUNT="$(find . -type f -name '*.md' | wc -l | tr -d ' ')"
echo "markdown_count=$MD_COUNT"
if [[ "$MD_COUNT" != "1" || ! -f README.md ]]; then
  echo "Expected exactly one README.md" >&2
  find . -type f -name '*.md' >&2
  exit 1
fi

echo "== syntax =="
python3 -m py_compile server/gfs/bathymetry_tiles.py server/gfs/bait_volume.py server/gfs/routes.py
node --check static/js/layers/bait-3d.js
node --check static/js/layers/ocean-glass.js

echo "== source contracts =="
grep -q "ocean_connected" server/gfs/bathymetry_tiles.py
grep -q "Death Valley" server/gfs/bathymetry_tiles.py
grep -q "ocean_connected" server/gfs/bait_volume.py
grep -q "grunion_school_bait_renderer_v3_landmasked" static/js/layers/bait-3d.js
grep -q "FRAMELESS_CUTOUT_MODE" static/js/layers/ocean-glass.js

echo "== live bathymetry/bait if server is running =="
if curl -fsS --max-time 4 "http://127.0.0.1:8000/gfs/api/bathymetry-tiles?bbox=-125,32,-117,38&lod=coarse" >/tmp/lftr_bathy_check.json; then
  jq '{ok,tile_count,water_cells_total: ([.tiles[]?.water_cells? // [] | length] | add // 0), suppressed_inland: ([.tiles[]?.cutaway_mask?.suppressed_inland_depression_cells // 0] | add // 0), sample_mode:(.tiles[0].cutaway_mask.mode // null)}' /tmp/lftr_bathy_check.json
else
  echo "server not running; skipped live bathymetry check"
fi
if curl -fsS --max-time 8 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=5,10,20,35,50,75,100&grid=16&max_clouds=24&max_cells=1200" >/tmp/lftr_bait3d_check.json; then
  jq '{ok,source,shape,cloud_count,bathymetry:{raw:.bathymetry.raw_cell_count_before_viewport_clip,clipped:.bathymetry.viewport_clipped_cell_count,distributed:.bathymetry.distributed_cell_count,policy:.bathymetry.viewport_clip_policy},first_cloud:(.clouds[0]//null)|{id,lat,lon,probability,particle_count_hint,drift_heading_deg}}' /tmp/lftr_bait3d_check.json
else
  echo "server not running; skipped live bait volume check"
fi

echo "PASS landmasked grunion clean installer"

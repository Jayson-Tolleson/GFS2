#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo '== lifted ocean floor cutout contract =='
grep -n "FLOOR_LIFT\|standard_no_glass_lifted_bathymetry\|data-ocean-floor-lift" static/js/layers/ocean-glass.js | sed -n '1,160p'
echo
echo '== cache busting =='
grep -n "lifted-ocean-floor-cutout-v6" static/js/index.js static/gfs.html templates/index.html | sed -n '1,120p'

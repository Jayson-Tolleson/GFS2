#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JS="$ROOT/static/js/layers/ocean-glass.js"
INDEX="$ROOT/static/js/index.js"
README="$ROOT/README.md"

echo "[check] ocean cutout Google-floor math / no visual bathymetry tiles"
node --check "$JS" >/dev/null
node --check "$INDEX" >/dev/null

grep -q "GFS_OCEAN_CUTOUT_RENDER_BATHYMETRY_TILES" "$JS"
grep -q "?? '0'" "$JS"
grep -q "single_google_floor_math_cutout_no_bathymetry_tiles" "$JS"
grep -q "viewport_google_floor_math_cutout_no_bathymetry_tiles" "$JS"
grep -q "landmask_bathymetry_math_retained" "$JS"
grep -q "retained_server_side_for_ocean_truth_bait_water_fraction_not_rendered_as_tiles" "$JS"
grep -Eq "google-floor-math-cutout-v8|bait-scalar-cloud-no-fake-boats-v11" "$INDEX"
grep -q "Google-floor math cutout" "$README"

if grep -q "GFS_OCEAN_GLASS_BATHYMETRY ?? '1'" "$JS"; then
  echo "[fail] visual bathymetry tiling still defaults on" >&2
  exit 1
fi

echo "[ok] visual bathymetry tiling is off by default; server bathymetry/landmask math remains retained"

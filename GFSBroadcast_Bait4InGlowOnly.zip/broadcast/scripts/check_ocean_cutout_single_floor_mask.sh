#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JS="$ROOT/static/js/layers/ocean-glass.js"
INDEX="$ROOT/static/js/index.js"

echo "[check] ocean cutout single Google-floor mask / no visual bathymetry tiles"
node --check "$JS" >/dev/null
node --check "$INDEX" >/dev/null

grep -q "GFS_OCEAN_CUTOUT_SINGLE_FLOOR" "$JS"
grep -q "FLOOR_MASK_MODE" "$JS"
grep -q "GFS_OCEAN_CUTOUT_RENDER_BATHYMETRY_TILES" "$JS"
grep -q "single_google_floor_math_cutout_no_bathymetry_tiles" "$JS"
grep -Eq "google-floor-math-cutout-v8|bait-scalar-cloud-no-fake-boats-v11" "$INDEX"

echo "ok: ocean cutout draws one single mathematical Google-floor mask; visual bathymetry tiles are debug-only"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BBOX="${1:--125,32,-117,38}"
BASE="${GFS_BASE_URL:-http://127.0.0.1:8000}"

echo "== native 3D cache status from ocean truth =="
curl -sS "$BASE/gfs/api/ocean-truth?bbox=$BBOX&products=bait,boats,ocean&max_samples=20&chlorophyll=warm&warm=1" \
| jq '{
  ok,
  schema,
  sample_count,
  query_contract,
  rtofs_3d,
  first_sample: (.samples[0] // null | {
    lon, lat, source, sample_method, interpolation_basis,
    surface: {sst_c, salinity, current_speed_kt, direction_deg},
    bait: {bait_depth_m, bait_altitude_m, bait_temperature_c, bait_salinity, bait_current_speed_kt, bait_direction_deg},
    render_contract: "frontend exaggerates negative visual altitude; true depth remains in data-bait-true-depth-m",
    bait_sample
  })
}'

echo
cat <<'EOF'
Expected after the warmer finishes:
  rtofs_3d.ok == true
  rtofs_3d.status == "ready"
  rtofs_3d.field_shape is [z,y,x]
  rtofs_3d cache coordinate_mode is "curvilinear_2d_mean_axes" or "rectilinear_1d"
  first_sample.sample_method == "rtofs_native_3d_trilinear"
  first_sample.bait.bait_depth_m > 0
  first_sample.bait.bait_temperature_c/current/salinity are non-null when present in source file

If rtofs_3d.status is cache_miss/already_warming, run:
  python3 scripts/warm_rtofs_3d_truth_cache.py --bbox="$BBOX"
EOF

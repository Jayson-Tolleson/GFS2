#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

CACHE_DIR="data_sources/bathymetry/etopo2022_4deg_tiles"
mkdir -p "$CACHE_DIR"

echo "== cache files =="
COUNT="$(find "$CACHE_DIR" -maxdepth 1 -type f -name 'etopo2022_4deg_*.json' | wc -l | tr -d ' ')"
echo "$COUNT"

if [[ "$COUNT" -eq 0 ]]; then
  echo "== seed missing; attempting seed build =="
  bash scripts/seed_bathymetry_socal_cache.sh "$(pwd)" || true
fi

echo "== cache summary =="
python3 - <<'PY'
from pathlib import Path
import json
root = Path('data_sources/bathymetry/etopo2022_4deg_tiles')
files = sorted(root.glob('etopo2022_4deg_*.json'))
water = 0
for p in files:
    d = json.loads(p.read_text())
    wc = d.get('water_cells')
    water += len(wc) if isinstance(wc, list) else int(wc or 0)
print(json.dumps({"tile_count": len(files), "water_cells": water}, indent=2))
if len(files) < 6:
    raise SystemExit(1)
PY

echo "== live endpoints if server is running =="
if curl -fsS --max-time 2 "http://127.0.0.1:8000/health" >/dev/null 2>&1; then
  curl -sS "http://127.0.0.1:8000/gfs/api/bathymetry-tiles?bbox=-125,32,-117,38&lod=coarse" \
    | jq '{ok,tile_count,water_cells_total: ([.tiles[]?.water_cells? // [] | length] | add // 0), cache}'
  curl -sS "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=5,10,20,35,50,75,100&grid=16&max_clouds=24&max_cells=1200" \
    | jq '{ok,source,shape,cloud_count}'
else
  echo "server not running; skipped endpoint checks"
fi

echo "PASS seeded bathymetry installer"

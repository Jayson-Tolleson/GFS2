#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

echo "== syntax =="
python3 -m py_compile \
  server/gfs/rtofs_3d_truth.py \
  server/gfs/ocean_truth.py \
  server/gfs/bait_volume.py \
  server/gfs/routes.py \
  scripts/warm_rtofs_3d_truth_cache.py

if command -v node >/dev/null 2>&1; then
  node --check static/js/layers/bait-3d.js
  node --check static/js/layers/boats.js
  node --check static/js/index.js
fi

echo

echo "== markdown cleanup =="
find . \
  -path "./venv" -prune -o \
  -path "./.git" -prune -o \
  -path "./node_modules" -prune -o \
  -name "*.md" -type f -print | sort
markdown_count="$(find . -path "./venv" -prune -o -path "./.git" -prune -o -path "./node_modules" -prune -o -name "*.md" -type f -print | wc -l | tr -d ' ')"
echo "markdown_count=${markdown_count}"

echo

echo "== ocean truth endpoint =="
curl -sS "http://127.0.0.1:8000/gfs/api/ocean-truth?bbox=-125,32,-117,38&products=bait,boats,ocean&depths=0,5,10,20,35,50,75,100&max_samples=1200&chlorophyll=warm" \
  | jq '{
      ok,
      schema,
      sample_count,
      source,
      query_contract: .query_contract.name,
      truth_is_not_voxels: .query_contract.truth_is_not_voxels,
      chlorophyll: {status:.chlorophyll.status, ready:.chlorophyll.ready, ttl_s:.chlorophyll.ttl_s},
      rtofs_surface: {ok:.rtofs_surface.ok, count:.rtofs_surface.count, source:.rtofs_surface.source},
      rtofs_3d: {ok:.rtofs_3d.ok, status:.rtofs_3d.status, field_shape:.rtofs_3d.field_shape, depth_values_m:.rtofs_3d.depth_values_m, cache:.rtofs_3d.cache, warmer:.rtofs_3d.warmer},
      bathymetry: {tile_count:.bathymetry.tile_count, viewport_clipped_cell_count:.bathymetry.viewport_clipped_cell_count, mask:.bathymetry.mask},
      boats_points: (.products.boats.oceanPoints.count // 0)
    }'

echo

echo "== bait volume now driven by ocean truth =="
curl -sS "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=0,5,10,20,35,50,75,100&grid=16&max_clouds=48&max_cells=1200&chlorophyll=warm&truth=1&warm=1" \
  | jq '{
      ok,
      source,
      shape,
      cloud_count,
      ocean_truth: {enabled:.ocean_truth.enabled, sample_count:.ocean_truth.sample_count, chlorophyll:.ocean_truth.chlorophyll.status, rtofs_3d:.rtofs_3d},
      first_cloud: (.clouds[0] // null),
      subsurface_depths: [.clouds[]? | {id, top_depth_m, bottom_depth_m, bait_depth_m, bait_altitude_m, heading:.drift_heading_deg, chlorophyll_status, sample_method}] | .[0:5]
    }'

echo

echo "== boater/current audit =="
curl -sS "http://127.0.0.1:8000/gfs/api/field?field=current&bbox=-125,32,-117,38" \
  | jq '{ok, source, count, status, cache, first:(.points[0] // .current_points[0] // .ocean_points[0] // null)}'

echo

echo "== frontend contract grep =="
grep -R "grunion_ocean_truth_subsurface_streak_renderer_v5\|/gfs/api/ocean-truth\|visual altitude\|data-bait-true-depth-m\|curvilinear_2d" -n static/js/layers static/js/index.js server/gfs | sed -n '1,100p'

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _normalize_argv(argv: list[str]) -> list[str]:
    """Allow --bbox -125,32,-117,38 as well as --bbox=-125,32,-117,38."""
    out: list[str] = []
    i = 0
    while i < len(argv):
        if argv[i] in {"--bbox", "--depths"} and i + 1 < len(argv):
            out.append(f"{argv[i]}={argv[i + 1]}")
            i += 2
            continue
        out.append(argv[i])
        i += 1
    return out


def _disk_hint(path: str = ".cache") -> dict:
    try:
        usage = shutil.disk_usage(path)
        return {"path": str(Path(path).resolve()), "free_mb": round(usage.free / 1024 / 1024, 1), "total_mb": round(usage.total / 1024 / 1024, 1)}
    except Exception as exc:
        return {"path": path, "error": str(exc)}


os.environ.setdefault("GFS_RTOFS_FILE_CACHE_DIR", str((ROOT / ".cache" / "rtofs" / "files").resolve()))
os.environ.setdefault("GFS_RTOFS_SAMPLE_CACHE_DIR", str((ROOT / ".cache" / "rtofs" / "samples").resolve()))

from server.gfs.rtofs_source import (
    sample_rtofs_surface,
    sample_rtofs_3d,
    find_latest_rtofs_cycle,
    rtofs_surface_candidates,
    rtofs_3d_candidates,
    load_cached_rtofs_surface,
    warm_rtofs_surface_cache,
)

p = argparse.ArgumentParser(description="Probe/consume NOAA/NCEP RTOFS for LFTR bbox ocean current/SST/depth data")
p.add_argument('--bbox', default='-125,32,-117,38', help='west,south,east,north')
p.add_argument('--surface', action='store_true', help='surface mode; default reads cached JSON unless --live is set')
p.add_argument('--3d', dest='depth3d', action='store_true', help='live 3D/depth probe; can be heavy')
p.add_argument('--depths', default='', help='comma depths in meters, e.g. 0,10,25,50')
p.add_argument('--max-points', type=int, default=1500)
p.add_argument('--live', action='store_true', help='perform live provider sample; can block if NOAA/NetCDF is slow')
p.add_argument('--warm', action='store_true', help='download/open local 2ds file and write JSON sample cache')
args = p.parse_args(_normalize_argv(sys.argv[1:]))

depths = [float(x) for x in args.depths.split(',') if x.strip()] if args.depths else None
out = {
    "latest": find_latest_rtofs_cycle(),
    "surface_candidate_count": len(rtofs_surface_candidates()),
    "depth_candidate_count": len(rtofs_3d_candidates(bbox=args.bbox)),
    "cache_dir": os.environ.get("GFS_RTOFS_FILE_CACHE_DIR"),
    "sample_cache_dir": os.environ.get("GFS_RTOFS_SAMPLE_CACHE_DIR"),
    "disk": _disk_hint(str(ROOT)),
}
if args.warm:
    out["sample"] = warm_rtofs_surface_cache(args.bbox, max_points=args.max_points)
elif args.live and args.depth3d:
    out["sample"] = sample_rtofs_3d(args.bbox, depths=depths, max_points=args.max_points)
elif args.live:
    out["sample"] = sample_rtofs_surface(args.bbox, max_points=args.max_points)
else:
    out["sample"] = load_cached_rtofs_surface(args.bbox)
    out["note"] = "cache-only by default; use --warm to create cache or --live for old blocking live probe"
print(json.dumps(out, indent=2, sort_keys=True, default=str))

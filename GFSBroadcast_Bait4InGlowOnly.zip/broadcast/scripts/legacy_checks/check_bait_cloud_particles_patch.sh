#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BBOX_LOCAL="${BBOX_LOCAL:--125,32,-117,38}"

printf '===== BAIT CLOUD FRONTEND CONTRACT =====\n'
python3 - <<'PY'
from pathlib import Path
s=Path('static/js/gfs/bait-zones.js').read_text()
checks={
 'particles_enabled_const':'BAIT_CLOUD_PARTICLES_ENABLED' in s,
 'particle_scale_const':'BAIT_CLOUD_PARTICLE_SCALE' in s,
 'high_contrast_palette':'BAIT_CLOUD_PALETTE' in s,
 'particle_reconciler':'reconcileBaitCloudParticles' in s,
 'advanced_bait_cloud_renderer':'advanced-bait-cloud' in s,
 'flat_20ft_body':'BAIT_CLOUD_BODY_HEIGHT_FT' in s and '20' in s,
 'payload_preserved_polygons':'reconcileBaitPolygons' in s,
}
for k,v in checks.items(): print(f'{k}= {v}')
PY

printf '\n===== BAIT PAYLOAD STILL PRESENT =====\n'
curl -sS "http://127.0.0.1:8000/gfs/api/scene-frame?bbox=${BBOX_LOCAL}&visible_bbox=${BBOX_LOCAL}&layers=bait,boater,shark-intel&mode=fast&refresh=0&provider_jobs=0&reason=bait_cloud_payload_contract_probe" \
  | jq '{
    bait:{source:.layers.bait.source,status:.layers.bait.status,polygons:(.layers.bait.polygons|length?),ocean_points:(.layers.bait.oceanPoints.points|length?),level_contract:.layers.bait.level_contract},
    boater:{source:.layers.boater.source,status:.layers.boater.status,boats:(.layers.boater.boats|length?),ocean_points:(.layers.boater.oceanPoints.points|length?)},
    shark:{source:.layers["shark-intel"].source,status:.layers["shark-intel"].status,polygons:(.layers["shark-intel"].polygons|length?)}
  }'

printf '\n===== BROWSER EXPECTED DEBUG =====\n'
printf '%s\n' '[gfs bait] reconciled polygons { renderer: advanced-bait-cloud, baitCloudParticles: {...}, maxCloudHeightFt: 20 }'
printf '%s\n' 'DOM check in browser console: document.querySelectorAll("[data-bait-renderer=advanced-bait-cloud-particle]").length'

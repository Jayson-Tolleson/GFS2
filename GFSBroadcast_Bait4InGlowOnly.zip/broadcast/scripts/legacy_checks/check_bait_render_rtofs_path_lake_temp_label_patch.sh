#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== bait renderer path precedence =="
python3 - <<'PY'
from pathlib import Path
s = Path('static/js/gfs/bait-zones.js').read_text()
need = [
  'const raw = Array.isArray(poly?.path) ? poly.path',
  'Array.isArray(poly?.render_path) ? poly.render_path',
  'Array.isArray(poly?.geometry?.coordinates) ? poly.geometry.coordinates',
  'Array.isArray(poly?.coordinates) ? poly.coordinates',
]
for n in need:
    assert n in s, f'missing {n}'
assert s.index('const raw = Array.isArray(poly?.path) ? poly.path') < s.index('Array.isArray(poly?.coordinates) ? poly.coordinates')
print('ok: bait path wins before raw coordinates')
PY

echo "== lake temp labels above map =="
python3 - <<'PY'
from pathlib import Path
s = Path('static/js/gfs/inland-water.js').read_text()
for n in [
  'Math.max(130, Math.min(900, range / 1500))',
  "marker.setAttribute('z-index', '900000')",
  "data-inland-temp-label-above-map",
]:
    assert n in s, f'missing {n}'
print('ok: inland temp labels lifted and tagged')
PY

echo "ok: bait render RTOFS path + lake temp label patch validated"

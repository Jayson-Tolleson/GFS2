#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"

echo "BATHYMETRY 4-DEG TILE CHECK"
echo "BASE=$BASE"
echo "BBOX=$BBOX"
echo

echo "1) cache-read endpoint"
curl -sS "$BASE/gfs/api/bathymetry-tiles?bbox=$BBOX&tile_deg=4&grid=8&limit=40" \
  | jq '{
      ok,
      source,
      tile_deg,
      requested_tile_count,
      tile_count,
      missing_tile_count,
      cache,
      build_command,
      sample: ((.tiles[0] // null) | if . then {
        tile_id,
        bbox,
        water_fraction,
        floor_depth_m,
        depth_min_m,
        depth_mean_m,
        depth_max_m,
        render_grid: .render_grid.rows, cutaway_mask: .cutaway_mask
      } else null end)
    }'

echo
echo "2) dry-run builder tile plan"
python3 scripts/build_bathymetry_4deg_cache.py --bbox="$BBOX" --dry-run \
  | jq '{ok, action, tile_deg, grid, tile_count, first_tile: .tiles[0]}'

echo
echo "To fetch/build missing NOAA ETOPO 2022 source tiles for this bbox:"
echo "  python3 scripts/build_bathymetry_4deg_cache.py --bbox=\"$BBOX\" --grid 8"
echo
echo "After building, rerun this script and open /GFS. Console: window.__gfsOceanGlassStats"

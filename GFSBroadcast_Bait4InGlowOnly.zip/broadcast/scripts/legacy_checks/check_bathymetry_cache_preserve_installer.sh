#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "== installer cache-preserve contract =="
grep -q "preserve_runtime_caches_pre" deploy/install.sh
grep -q "restore_runtime_caches_post" deploy/install.sh
grep -q "data_sources/bathymetry" deploy/install.sh
test -x scripts/package_with_bathymetry_cache.sh

echo "== local bathymetry cache inventory =="
python3 - <<'PY'
from pathlib import Path
root = Path.cwd()
cache = root / 'data_sources' / 'bathymetry' / 'etopo2022_4deg_tiles'
files = sorted(cache.glob('etopo2022_4deg_*.json')) if cache.exists() else []
print({
  'cache_dir': str(cache),
  'tile_count': len(files),
  'installer_preserves_runtime_cache': True,
  'package_helper': 'scripts/package_with_bathymetry_cache.sh',
})
PY

echo "PASS bathymetry cache preserve installer"

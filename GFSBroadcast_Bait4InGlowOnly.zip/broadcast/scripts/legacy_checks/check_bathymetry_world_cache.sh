#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"
GRID="${GRID:-16}"

echo "BATHYMETRY WORLD CACHE / SHORELINE GLASS CHECK"
echo "BASE=$BASE"
echo "BBOX=$BBOX"
echo "GRID=$GRID"

echo
echo "1) syntax"
python3 -m py_compile server/gfs/bathymetry_tiles.py scripts/build_bathymetry_4deg_cache.py
node --check static/js/layers/ocean-glass.js
node --check static/js/index.js

echo
echo "2) local cache inventory"
python3 scripts/build_bathymetry_4deg_cache.py --world --grid "$GRID" --dry-run --max-build 1 \
  | jq '{ok, mode, tile_deg, grid, total_tile_count, cache}'

echo
echo "3) server cache inventory endpoint"
curl -sS "$BASE/gfs/api/bathymetry-cache?tile_deg=4" \
  | jq '{ok, schema, tile_deg, cached_tile_count, global_tile_count, coverage_fraction, grid_counts, world_build_command}'

echo
echo "4) padded viewport bathymetry tiles from cache"
curl -sS "$BASE/gfs/api/bathymetry-tiles?bbox=$BBOX&tile_deg=4&grid=$GRID&limit=72" \
  | jq '{
      ok,
      source,
      tile_deg,
      requested_tile_count,
      tile_count,
      missing_tile_count,
      cache: .cache,
      shoreline_summary: {
        total_water_cells: ([.tiles[]?.cutaway_mask.water_render_cells // 0] | add // 0),
        total_land_cells: ([.tiles[]?.cutaway_mask.land_render_cells // 0] | add // 0),
        grids: [.tiles[]? | .render_grid.rows] | unique,
        tiles: [.tiles[]? | {tile_id, water_fraction, grid: .render_grid.rows, water_cells: .cutaway_mask.water_render_cells, land_cells: .cutaway_mask.land_render_cells}]
      }
    }'

echo
echo "5) useful world build commands"
cat <<EOF
# Local/high-priority viewport cache at tighter shoreline detail:
python3 scripts/build_bathymetry_4deg_cache.py --bbox=$BBOX --grid 32 --force

# Whole-world resumable cache, grid 16, 250 tiles per run:
python3 scripts/build_bathymetry_4deg_cache.py --world --grid 16 --missing-only --max-build 250

# Continue later by increasing --start-index, or just rerun missing-only until coverage is 1.0.
EOF

echo
echo "Browser console after /GFS:"
echo "  window.__gfsOceanGlassStats.bathymetry.water_mask"
echo "  window.__gfsOceanGlassStats.request_bbox"
echo "  window.__gfsOceanGlassStats.padded_bbox"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== syntax =="
node --check static/js/gfs/boats.js
node --check static/js/layers/boats.js

echo "== contract grep =="
grep -q "singleProjectionMode" static/js/gfs/boats.js
grep -q "BOAT_UNDERGLOW_ENABLED" static/js/gfs/boats.js
grep -q "BOAT_BEACON_ENABLED" static/js/layers/boats.js
grep -q "BOAT_CURRENT_ZONES_ENABLED" static/js/layers/boats.js
grep -q "disabled_single_projection_boats" static/js/layers/boats.js

echo "== live stats hint =="
cat <<'HINT'
Open /GFS and run:
({
  boats: window.__gfsBoatsRenderState?.lastStats,
  beacons: window.__gfsBoaterBeaconStats
})

Expected defaults:
  boats.singleProjectionMode === true
  boats.underglowEnabled === false
  boats.visibilityBeaconEnabled === false
  boats.currentZonesEnabled === false
  beacons.enabled === false
HINT

echo "PASS boat single projection cleanup"

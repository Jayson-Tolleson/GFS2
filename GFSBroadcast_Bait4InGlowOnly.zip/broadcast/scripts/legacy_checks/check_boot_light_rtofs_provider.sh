#!/usr/bin/env bash
set -euo pipefail
cd "${APP_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"
python - <<'PY'
import sys
from server.gfs.providers.rtofs import OceanProvider
mods = set(sys.modules)
heavy = sorted(m for m in mods if m.split('.')[0] in {'xarray','cfgrib','netCDF4','h5netcdf','scipy'})
assert not heavy, f"RTOFS provider boot import pulled native-heavy modules: {heavy[:20]}"
p = OceanProvider()
assert p.provider_name == 'rtofs'
print('ok boot-light rtofs provider contract', p.provider_contract)
PY

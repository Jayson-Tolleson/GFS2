#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check static/js/gfs/layers/renderer_layer.js
node --check static/js/gfs/layer_engine.js
node --check static/js/gfs/main.js
python3 -m py_compile server/gfs/pipeline.py
grep -R "render/stage\|render/pipeline-summary\|render/server-frame\|lftr_render_debug_v1" -n \
  static/js/gfs/layers/renderer_layer.js static/js/gfs/layer_engine.js static/js/gfs/main.js server/gfs/pipeline.py >/dev/null
echo "OK clean render debug patch installed"

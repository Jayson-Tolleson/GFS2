#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

FILE="static/js/gfs/cloud-zones.js"

echo "== Cloud sea-level clamp static contract =="

grep -q "CLOUD_SEA_LEVEL_CLAMP_M" "$FILE"
grep -q "CLOUD_POLYGON_EXTRUDE_TO_GROUND" "$FILE"
grep -q "function clampCloudAltitudeMeters" "$FILE"
grep -q "function cloudExtrusionPolicy" "$FILE"
grep -q "extrudeToGround: cloudExtrusionPolicy().extrudeToGround" "$FILE"
grep -q "data-cloud-sea-level-clamped" "$FILE"
grep -q "data-cloud-extrude-to-ground" "$FILE"

# There are three cloud polygon creation paths: backend shells, contour shells, grid/frontend shells.
COUNT="$(grep -c "extrudeToGround: cloudExtrusionPolicy().extrudeToGround" "$FILE")"
if [ "$COUNT" -lt 3 ]; then
  echo "Expected at least 3 cloud extrusion policy applications, found $COUNT" >&2
  exit 1
fi

node --check "$FILE"
node --check static/js/layers/clouds.js

echo "OK: cloud polygons are sea-level clamped and extrusion-to-ground is disabled by default."

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "===== depth intelligence ft-display source check ====="
grep -R "Preferred bait depth .* m\|Bait .* @ .* m\|best bait signal near .* m\|Positive extrusion: .* m above water" -n static/js/gfs server/gfs server/gfs_service_parts && {
  echo "ERROR: meter-based depth display string still present" >&2
  exit 1
} || true

echo "===== JS syntax ====="
node --check static/js/gfs/hud.js
node --check static/js/gfs/inland-water.js

echo "===== Python syntax ====="
python3 -m py_compile \
  server/gfs/derive/bait.py \
  server/gfs/providers/rtofs_noaa.py \
  server/gfs/shark_intel.py \
  server/gfs_service_parts/ocean_bait_frame.py \
  server/gfs_service_parts/tiles_scene.py

echo "===== feet contract markers ====="
grep -R "feet_universal\|depth_unit_contract\|target_swim_depth_ft\|preferred_depth_ft\|depth_min_ft\|depth_max_ft" -n \
  server/gfs server/gfs_service_parts static/js/gfs/hud.js static/js/gfs/inland-water.js | head -120

echo "OK: depth intelligence public display prefers feet; meters remain internal only."

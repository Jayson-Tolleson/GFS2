#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "FAIL: $*" >&2; exit 1; }
grep -R "GFS_OCEAN_PROVIDER_MAX_SCHEDULED_TILES.*36" -n scripts/run_broadcast_service.sh >/dev/null || fail "provider scheduled tile default is not 36"
grep -R "fixed_36_provider_tiles_per_authoritative_ocean_viewport_refresh_batch_deduped" -n server/gfs_service_parts/ocean_bait_frame.py >/dev/null || fail "fixed-36 provider policy missing"
grep -R "Do not feed ocean layers through generic scene-tile warm" -n server/gfs_service_parts/ocean_bait_frame.py >/dev/null || fail "nested scene-tile/ocean fanout guard missing"
grep -R "viewport_too_large_for_recent_ocean_priority" -n server/gfs_service_parts/lightning_cache_media.py >/dev/null || fail "large fallback recent viewport guard missing"
grep -R "ocean/bootstrap-refresh-held" -n static/js/gfs/main.js >/dev/null || fail "client boot ocean hold debug missing"
echo "OK fixed-36 ocean provider with no nested global viewport fanout"

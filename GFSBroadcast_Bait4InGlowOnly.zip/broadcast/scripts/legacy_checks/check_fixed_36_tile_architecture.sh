#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail=0
say(){ printf '%s\n' "$*"; }
want(){ if "$@"; then say "[PASS] $*"; else say "[FAIL] $*"; fail=1; fi; }

want grep -R "DEFAULT_VIEWPORT_GRID = int(os.getenv(\"GFS_VIEWPORT_TILE_GRID\", \"6\")" -n server/gfs/tile_contract.py
want grep -R "fixed_6x6_36_tiles" -n server/gfs server/gfs_service_parts
want grep -R "VIEWPORT_TILE_COUNT = 36" -n server/gfs/viewport36.py
want grep -R "def _split_ocean_provider_tiles" -n server/gfs_service_parts/ocean_bait_frame.py
want grep -R "split_viewport_tiles(b, grid=VIEWPORT_TILE_GRID)" -n server/gfs_service_parts/ocean_bait_frame.py
want grep -R "max_ocean_refresh_tiles.*VIEWPORT_TILE_COUNT\|max_ocean_refresh_tiles.*36" -n server/gfs_service_parts server/gfs
want grep -R "global_regional_local" -n server/gfs server/gfs_service_parts
want grep -R "expand_bbox_for_camera" -n server/gfs/routes.py server/gfs/viewport36.py
if grep -R "schema\": \"lftr_viewport_tile_plan_v2_24x24\"\|split_visible_viewport_into_congruent_24x24_tiles\|one_viewport_bbox_split_into_24x24" -n server/gfs server/gfs_service_parts; then
  say "[FAIL] legacy 24x24 provider contract string still active"
  fail=1
else
  say "[PASS] no active legacy 24x24 provider contract strings"
fi
exit "$fail"

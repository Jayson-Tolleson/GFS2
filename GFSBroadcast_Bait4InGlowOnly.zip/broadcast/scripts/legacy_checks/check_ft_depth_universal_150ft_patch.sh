#!/usr/bin/env bash
set -euo pipefail
cd "${1:-$(pwd)}"

PY=${PYTHON:-python3}

echo "===== PY COMPILE ====="
$PY -m py_compile server/gfs/providers/rtofs_noaa.py

echo "===== RTOFS UNIVERSAL FT DEPTH LADDER ====="
grep -n 'GFS_RTOFS_DEPTH_TARGETS_FT.*0,5,10,25,50,100,150\|RTOFS_DEPTH_MAX_SLICES.*7' server/gfs/providers/rtofs_noaa.py

echo "===== NEGATIVE FT DEPTH KEYS / 150 FT ====="
grep -n 'def _depth_key_from_target_ft\|target_depth_ft\|sample_z_ft_negative_below_water_render_extrusion_ft_positive\|feet_universal_negative_below_water' server/gfs/providers/rtofs_noaa.py | head -80

echo "===== STATIC DEPTH POLICY SMOKE ====="
$PY - <<'PY'
from server.gfs.providers import rtofs_noaa as r
for stride in [12, 6, 3, 1]:
    specs = r._depth_targets_for_stride(stride)
    print('stride', stride, 'ft_targets', [s['target_depth_ft'] for s in specs], 'keys', [r._depth_key_from_target_ft(s['target_depth_ft']) for s in specs])
assert [s['target_depth_ft'] for s in r._depth_targets_for_stride(1)] == [0.0, 5.0, 10.0, 25.0, 50.0, 100.0, 150.0]
assert r._depth_key_from_target_ft(150) == '-150ft'
print('OK: universal feet depth ladder includes -150ft and exports negative-ft keys')
PY

echo "OK: RTOFS depth public contract is feet-first with -150ft included."

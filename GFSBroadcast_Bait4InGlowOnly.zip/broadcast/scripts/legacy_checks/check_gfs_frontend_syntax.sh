#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check static/js/gfs/main.js
printf 'OK: static/js/gfs/main.js parses\n'

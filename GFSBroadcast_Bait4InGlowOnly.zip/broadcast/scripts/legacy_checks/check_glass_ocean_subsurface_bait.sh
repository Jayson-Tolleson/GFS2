#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"

echo "GLASS OCEAN + SUBSURFACE BAIT CHECK"
echo "BASE=$BASE"
echo "BBOX=$BBOX"
echo

echo "1) JS syntax"
node --check static/js/layers/ocean-glass.js
node --check static/js/layers/bait.js
node --check static/js/index.js

echo
echo "2) scene-frame atmosphere + marine readiness"
curl -sS "$BASE/gfs/api/scene-frame?bbox=$BBOX&layers=clouds,rain,bait,boats,lightning" \
  | jq '{
      ok,
      source,
      layer_keys: (.layers | keys),
      clouds: {status: .layers.clouds.status, source: .layers.clouds.source, count: .layers.clouds.count},
      rain: {status: .layers.rain.status, source: .layers.rain.source, count: .layers.rain.count},
      bait: {
        status: .layers.bait.status,
        source: .layers.bait.source,
        count: .layers.bait.count,
        polygons: ((.layers.bait.polygons // []) | length),
        rows: ((.layers.bait.advancedBaitRows // []) | length),
        ocean_points: ((.layers.bait.oceanPoints.points // []) | length)
      },
      boater: {
        status: .layers.boater.status,
        source: .layers.boater.source,
        count: .layers.boater.count,
        boats: ((.layers.boater.boats // []) | length),
        ocean_points: ((.layers.boater.oceanPoints.points // []) | length)
      }
    }'


echo
echo "3) 4-degree bathymetry tile cache status"
curl -sS "$BASE/gfs/api/bathymetry-tiles?bbox=$BBOX&tile_deg=4&grid=8&limit=40" \
  | jq '{
      ok,
      source,
      tile_deg,
      requested_tile_count,
      tile_count,
      missing_tile_count,
      cache,
      sample: ((.tiles[0] // null) | if . then {tile_id, bbox, water_fraction, floor_depth_m, depth_mean_m, depth_max_m, cutaway_mask} else null end)
    }'

echo
echo "4) authoritative field=current fallback sample for subsurface bait/boats"
curl -sS "$BASE/gfs/api/field?field=current&bbox=$BBOX" \
  | jq '{
      ok,
      source,
      count,
      sample: ((.points[0] // .ocean_points[0] // .current_points[0]) | {
        lat, lon, current_speed_kt, direction_deg, sst_c, water_temp_f, salinity
      })
    }'

echo
echo "Browser console after opening /GFS:"
echo "  window.__gfsOceanGlassStats"
echo "  window.__gfsBaitBeaconStats"
echo "  window.__gfsLayerDomStats"
echo "  window.__gfsLatestSceneSummary"

#!/usr/bin/env bash
set -euo pipefail
cd "${1:-$(pwd)}"

echo "[check] GLM lightning module exists"
test -f server/gfs_service_parts/GLMLightning.py
grep -q "class GLMLightningMixin" server/gfs_service_parts/GLMLightning.py
grep -q "GFS_GLM_FLASH_TTL_SECONDS.*120" server/gfs_service_parts/GLMLightning.py

echo "[check] boot layers are atmosphere/lightning only"
grep -q 'BOOT_SCENE_CACHE_DEFAULT_LAYERS = \["locations", "clouds", "rain", "lightning"\]' server/gfs_service.py

echo "[check] generic globe/scene tile warmer blocks ocean layers"
grep -q "generic_scene_tile_warmer_is_atmosphere_only_rtofs_ocean_has_separate_owner" server/gfs_service_parts/ocean_bait_frame.py
grep -q "priority_ocean_layers_skipped_legacy_scene_tile_path" server/gfs_service_parts/ocean_bait_frame.py
grep -q "generic_scene_tiles_never_call_ocean_provider" server/gfs_service_parts/tiles_scene.py

echo "[check] scene-cache layer builder blocks legacy ocean provider calls"
grep -q "legacy_scene_tile_ocean_blocked" server/gfs_service_parts/lightning_cache_media.py
grep -q "rtofs_ocean_not_scene_cache_child_bbox" server/gfs_service_parts/lightning_cache_media.py

echo "[check] python syntax"
python3 -m py_compile \
  server/gfs_service_parts/GLMLightning.py \
  server/gfs_service_parts/lightning_cache_media.py \
  server/gfs_service_parts/ocean_bait_frame.py \
  server/gfs_service_parts/tiles_scene.py \
  server/gfs_service.py

echo "OK: GLM lightning, NCSS/GFS atmosphere warm, and RTOFS/ocean ownership are separated."

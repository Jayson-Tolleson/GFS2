#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-venv/bin/python}"
[ -x "$PYTHON" ] || PYTHON=python3

echo "== compile shoreline boot files =="
"$PYTHON" -m py_compile server/gfs/inland/payloads.py server/gfs_service_parts/lightning_cache_media.py server/gfs/routes.py static/js/gfs/inland-water.js static/js/gfs/main.js 2>/dev/null || python3 -m py_compile server/gfs/inland/payloads.py server/gfs_service_parts/lightning_cache_media.py server/gfs/routes.py

echo "== direct inland-water boot overview payload =="
"$PYTHON" - <<'PY'
from pathlib import Path
from server.gfs.inland.payloads import inland_water_payload
b = {"west": -125, "south": 32, "east": -117, "north": 38}
out = inland_water_payload(Path("static"), b, source="auto", geometry="vector", lod="overview", scene_tier="global")
print({
  "ok": out.get("ok"),
  "source": out.get("source"),
  "count": out.get("count"),
  "one_per_tile": (out.get("diagnostics") or {}).get("quantity_filter", {}).get("policy"),
  "first": (out.get("polygons") or [{}])[0].get("name"),
})
assert out.get("ok") is True
assert int(out.get("count") or 0) > 0
PY

echo "== live endpoint, if server is running =="
if curl -fsS http://127.0.0.1:8000/gfs/api/health >/dev/null 2>&1; then
  curl -sS "http://127.0.0.1:8000/gfs/api/scene-cache?bbox=-125,32,-117,38&visible_bbox=-125,32,-117,38&scene_tier=global&layers=inland-water,inland_water_temp&mode=fast&fast=1" \
    | jq '.layers["inland-water"].source,.layers["inland-water"].count,.layers.inland_water_temp.count,.layers.inland_water_temp.one_largest_lake_per_tile'
else
  echo "server not running on 127.0.0.1:8000; skipped curl"
fi

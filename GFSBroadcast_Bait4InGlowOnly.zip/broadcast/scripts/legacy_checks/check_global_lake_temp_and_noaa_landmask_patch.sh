#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

fail(){ echo "FAIL: $*" >&2; exit 1; }

python3 -m py_compile \
  server/gfs/noaa_landmask_cache.py \
  server/gfs_service.py \
  server/gfs_service_parts/lightning_cache_media.py \
  server/gfs_service_parts/ocean_bait_frame.py

python3 - <<'PY'
from pathlib import Path
from server.gfs.noaa_landmask_cache import ensure_noaa_landmask_cache, landmask_cache_dir
base = Path.cwd()
meta = ensure_noaa_landmask_cache(base, fetch=False)
print('noaa_landmask_cache_status=', meta.get('status'), 'archive_bytes=', meta.get('archive_bytes'), 'dir=', landmask_cache_dir(base))
assert meta.get('contract') == 'noaa_gshhg_landmask_artifact_cached_long_ttl_boot_checked_once'
PY

grep -q "cached inland temp companion" static/js/gfs/main.js || fail "main.js does not keep global inland_water_temp"
grep -q "cached temp companion" static/js/gfs/world_subscription_renderer.js || fail "world subscription still gates temp companion"
grep -q "global_boot_estimated_lake_surface_temp" server/gfs_service_parts/lightning_cache_media.py || fail "missing global estimated temp fallback"
grep -q "noaa_landmask_cache" server/gfs_service.py || fail "service boot does not schedule NOAA landmask cache"
grep -q "noaa_landmask_cache" server/gfs_service_parts/ocean_bait_frame.py || fail "ocean payloads do not expose NOAA landmask cache metadata"

echo "OK: global lake temp companion + estimated labels + NOAA/GSHHG long-lived landmask cache patch installed"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

grep -q "boot_global_shoreline_one_per_tile" static/js/gfs/main.js
grep -q "Mission layers should become visible" static/js/gfs/main.js
grep -q "bait: this.layerOn('bait')" static/js/gfs/world_subscription_renderer.js
grep -q "boater: this.layerOn('boater')" static/js/gfs/world_subscription_renderer.js
grep -q "tier === 'global'" static/js/gfs/inland-water.js
grep -q "lftr_inland_water_temp_v6_cache_only_global_one_largest_lake_per_tile" server/gfs_service_parts/lightning_cache_media.py

python3 -m py_compile server/gfs_service_parts/lightning_cache_media.py server/gfs/inland/payloads.py server/gfs/routes.py server/gfs_service_parts/tiles_scene.py
node --check static/js/gfs/main.js
node --check static/js/gfs/world_subscription_renderer.js
node --check static/js/gfs/inland-water.js

echo "OK global shoreline/mission layer boot contract"

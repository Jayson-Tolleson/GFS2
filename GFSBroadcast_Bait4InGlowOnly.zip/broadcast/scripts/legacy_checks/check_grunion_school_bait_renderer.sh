#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== syntax =="
node --check static/js/layers/bait-3d.js >/dev/null

echo "== contracts =="
grep -q "grunion_school_bait_renderer_v1" static/js/layers/bait-3d.js
grep -q "data-grunion" static/js/layers/bait-3d.js
grep -q "__gfsBaitSchoolStats" static/js/layers/bait-3d.js
grep -q "grunion_like" static/js/layers/bait-3d.js

echo "== live endpoint if server is running =="
if curl -fsS --max-time 5 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=5,10,20,35,50,75,100&grid=16&max_clouds=24&max_cells=1200" >/tmp/gfs_bait3d_probe.json 2>/dev/null; then
  jq '{ok, source, shape, cloud_count, first_cloud: (.clouds[0] // null) | {id, probability, particle_count_hint, top_depth_m, bottom_depth_m, drift_heading_deg}}' /tmp/gfs_bait3d_probe.json
else
  echo "server not running; skipped live endpoint"
fi

echo "PASS grunion school bait renderer"

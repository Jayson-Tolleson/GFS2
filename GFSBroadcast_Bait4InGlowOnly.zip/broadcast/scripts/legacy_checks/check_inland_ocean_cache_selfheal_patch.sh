#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile \
  server/gfs/rtofs_source.py \
  server/gfs/inland/payloads.py \
  server/gfs_service_parts/lightning_cache_media.py

grep -R "GLOBAL_LAKE_OVERVIEW_ENABLED = str(os.getenv(\"LFTR_GLOBAL_LAKE_OVERVIEW_ENABLED\", \"1\"" -n server/gfs/inland/payloads.py >/dev/null
grep -R "lock_pid_alive" -n server/gfs/rtofs_source.py >/dev/null
grep -R "global_geometry_cache_miss_no_temp_decode" -n server/gfs_service_parts/lightning_cache_media.py >/dev/null
grep -R "preserve_empty_payload_no_last_good" -n static/js/gfs/layers/renderer_layer.js >/dev/null

echo "OK inland/ocean cache self-heal patch installed"

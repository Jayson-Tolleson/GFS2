#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "FAIL: $*" >&2; exit 1; }
python3 -m py_compile server/gfs/inland/payloads.py || fail "payloads.py does not compile"
node --check static/js/gfs/inland-water.js >/dev/null || fail "inland-water.js does not parse"
grep -q 'LFTR_GLOBAL_LAKE_OVERVIEW_ENABLED", "0"' server/gfs/inland/payloads.py || fail "Hydrolakes default must be disabled"
grep -q 'INLAND_GLOBAL_ALLOW_LOCAL_REAL_VECTOR_FALLBACK' server/gfs/inland/payloads.py || fail "missing local real-vector fallback flag"
grep -q 'runtime_nhd_arcgis_real_vector_global_uses_finer' server/gfs/inland/payloads.py || fail "missing real-vector fallback source"
grep -q 'preserve-real-vector-skip-hydrolakes' static/js/gfs/inland-water.js || fail "frontend must skip hydrolakes downgrade"
grep -q 'data-inland-real-vector' static/js/gfs/inland-water.js || fail "frontend must tag real vector geometry"
grep -q 'LFTR_INLAND_GLOBAL_ALLOW_LOCAL_REAL_VECTOR_FALLBACK=1' .env.example || fail "env example missing real-vector fallback"
echo "ok: inland real-vector geometry once patch validated"

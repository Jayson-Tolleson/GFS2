#!/usr/bin/env bash
set -euo pipefail
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }

grep -R --exclude="check_inland_single_cache_contract.sh" "nhdplus_hr_state_cache" -n server scripts deploy install.sh broadcast.sh 2>/dev/null && fail "state sidecar cache still referenced in active code" || pass "no active nhdplus_hr_state_cache references"
grep -R "single_shared_viewport_tile_cache_no_state_sidecar" -n server/gfs/inland server/gfs_service_parts >/dev/null || fail "missing single-cache inland contract"
grep -R "lftr_inland_water_temp_v5_cache_only_global_one_label_per_tile_then_detail_bait" -n server/gfs_service_parts >/dev/null || fail "missing cache-only one-label temp contract"
grep -R "INLAND_GLOBAL_TEMP_LABEL_CAP = 36" -n static/js/gfs/inland-water.js >/dev/null || fail "frontend global temp label cap not 36"
grep -R "max_tiles.*36\|tiles36\|up to 36" -n server/gfs server/gfs_service_parts static/js/gfs scripts >/dev/null || fail "missing 36-tile inland cap evidence"
python3 -m py_compile server/gfs/inland/payloads.py server/gfs/inland/cache.py server/gfs/routes.py server/gfs_service_parts/tiles_scene.py server/gfs_service_parts/lightning_cache_media.py
pass "inland single-cache/global-one-label/detail-full contract passes"

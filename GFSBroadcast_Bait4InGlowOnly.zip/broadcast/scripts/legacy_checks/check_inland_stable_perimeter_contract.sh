#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "[FAIL] $*" >&2; exit 1; }
grep -q 'LFTR_GLOBAL_LAKE_OVERVIEW_ENABLED", "0"' server/gfs/inland/payloads.py || fail "legacy overview fallback must be disabled by default"
grep -q 'stable_real_vector_perimeter_zoom_adds_detail_overlays' static/js/gfs/inland-water.js || fail "missing stable perimeter prune policy"
grep -q 'data-inland-stable-shoreline' static/js/gfs/inland-water.js || fail "missing stable shoreline element tag"
grep -q 'admin=1&explicit=1' static/js/gfs/main.js || fail "world/global build-cache must intentionally launch real vector NHD build"
grep -q 'lftr_inland_water_v21_stable_perimeter_real_vector_global_one_per_tile_zoom_adds_detail' server/gfs/inland/payloads.py || fail "missing v21 contract marker"
echo "[OK] inland stable-perimeter contract: global full real-vector perimeter persists; zoom adds child details"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile server/gfs/inland/payloads.py server/gfs_service_parts/lightning_cache_media.py
grep -R "surface_grid_cell_outside_lake_polygon\|sample_rejected_by_lake_geometry\|lake_path=item.get" -n \
  server/gfs/inland/payloads.py server/gfs_service_parts/lightning_cache_media.py >/dev/null
printf 'OK inland surface temp geometry guard is installed\n'

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
FILE="server/gfs/inland/payloads.py"
echo "[check] inland water temps must prefer surface TMP and only fallback to height-above-ground 0m"
grep -n "primary_surface_tmp_fallback_height_above_ground_0m\|primary_temperature_surface_fallback_height_above_ground_0m" "$FILE"
grep -n "Temperature_surface\|TMP_surface\|height_above_ground_0m" "$FILE" | head -40
python3 - <<'PY'
from pathlib import Path
s=Path('server/gfs/inland/payloads.py').read_text()
start=s.index('def _select_inland_water_temp_da')
end=s.index('def _sample_surface_temperature_from_groups', start)
selector=s[start:end]
bad=['groups.get("2m")','safe_data_var(ds, ["t2m"','skt','SKT']
hits=[b for b in bad if b in selector]
if hits:
    raise SystemExit('FAIL: selector samples forbidden temp sources: '+','.join(hits))
func=s[s.index('def sample_surface_temperature'):s.index('def _inland_temp_factor_pct')]
if 'ncss_surface_or_height0m_temperature_no_filter' not in func:
    raise SystemExit('FAIL: expected no-filter surface/0m temperature method marker')
if 't2m' not in func or 'excluded' not in func:
    raise SystemExit('FAIL: expected explicit t2m exclusion metadata')
print('OK: selector ignores 2m/sigma/pressure-difference/skin and returns surface or height-0m only.')
PY
echo "OK: inland-water temp source is surface TMP primary, height-above-ground 0m fallback only."

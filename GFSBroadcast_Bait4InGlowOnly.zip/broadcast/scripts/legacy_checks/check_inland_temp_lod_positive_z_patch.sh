#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo '[check] JS syntax'
node --check static/js/gfs/main.js
node --check static/js/gfs/inland-water.js
node --check static/js/gfs/boats.js
node --check static/js/gfs/world_subscription_renderer.js

echo '[check] Python syntax'
python3 -m py_compile server/gfs/viewport36.py

echo '[check] policy strings'
grep -q 'width <= 8.0 && height <= 6.0 && area <= 36.0' static/js/gfs/main.js
grep -q 'authoritativeTemperaturePoints' static/js/gfs/inland-water.js
grep -q 'data-inland-positive-z' static/js/gfs/inland-water.js
grep -q 'INLAND_BAIT_OVERLAY_MIN_ALTITUDE_M' static/js/gfs/inland-water.js
grep -q 'width <= 8.0 and height <= 6.0 and area <= 36.0' server/gfs/viewport36.py

echo '[check] inland temp one-label + positive-z + 2-level LOD patch OK'

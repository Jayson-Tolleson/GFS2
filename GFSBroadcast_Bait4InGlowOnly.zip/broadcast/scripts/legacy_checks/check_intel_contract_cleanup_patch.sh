#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile server/gfs/intel_contract.py server/gfs_service_parts/ocean_bait_frame.py server/gfs_service_parts/lightning_cache_media.py
node --check static/js/gfs/intel_contract.js
node --check static/js/gfs/inland-water.js
python3 - <<'PY'
from server.gfs.intel_contract import OCEAN_MISSION_LAYERS, normalize_lod_name
assert tuple(OCEAN_MISSION_LAYERS) == ("bait", "boater", "shark-intel")
assert normalize_lod_name("world") == "global"
assert normalize_lod_name("harbor") == "local"
print("OK intel contract cleanup installed")
PY

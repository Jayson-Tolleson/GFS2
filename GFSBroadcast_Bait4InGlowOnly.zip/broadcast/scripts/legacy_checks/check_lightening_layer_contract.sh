#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check static/js/gfs/lightening.js
node --check static/js/gfs/lightning-zones.js
node --check static/js/gfs/main.js
python3 -m py_compile server/gfs/live_frame.py server/gfs/routes.py server/gfs_service_parts/GLMLightning.py
if ! grep -q "renderLighteningLayer" static/js/gfs/main.js; then
  echo "main.js is not wired to lightening.js" >&2
  exit 1
fi
if ! grep -q '@bp.get("/gfs/api/lightening")' server/gfs/routes.py; then
  echo "missing /gfs/api/lightening alias" >&2
  exit 1
fi
if grep -RIn "live_frame_lightning_simplified_no_provider_call\|deferred_manual_visual_only" server/gfs/live_frame.py static/js/gfs >/tmp/lightening_bad_refs.txt; then
  cat /tmp/lightening_bad_refs.txt >&2
  exit 1
fi
echo "lightening layer contract ok"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

grep -q "LIVE_CLOUD_TILE_FORMATION" static/js/gfs/cloud-zones.js
grep -q "CLOUD_CLIENT_ADVECTION_ENABLED" static/js/gfs/cloud-zones.js
grep -q "no_client_advection_or_morph_loop" static/js/gfs/cloud-zones.js
grep -q "live_tile_formed_clouds_no_client_advection" static/js/gfs/cloud-zones.js
grep -q "live-cloud-tile" server/gfs_service_parts/atmosphere.py
grep -q "cloud_tile_key" static/js/gfs/main.js
grep -q "GFS_CLOUD_TILE_QUANTIZE_DEG" .env.example
python3 -m py_compile server/gfs_service_parts/atmosphere.py
node --check static/js/gfs/cloud-zones.js >/dev/null
node --check static/js/gfs/main.js >/dev/null

echo "live cloud tile formation patch checks passed"

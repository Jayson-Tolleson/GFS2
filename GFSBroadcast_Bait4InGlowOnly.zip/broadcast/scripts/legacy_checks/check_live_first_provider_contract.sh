#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile server/gfs/live_frame.py server/gfs/routes.py scripts/rtofs_fetch_worker.py
node --check static/js/gfs/api.js
node --check static/js/gfs/main.js
node --check static/js/gfs/world_subscription_renderer.js
if ! grep -RIn "/gfs/api/live-frame" server/gfs/routes.py static/js/gfs/api.js static/js/gfs/main.js >/dev/null; then
  echo "live-frame route/wiring missing" >&2
  exit 1
fi
if grep -RIn "nudgeMainSceneCacheRefresh(vp, 'browser_2min_ttl_heartbeat'\|boot_background_refresh_clouds_only\|post_warm_background_65000" static/js/gfs/main.js; then
  echo "cache refresh train still wired in main.js" >&2
  exit 1
fi
if grep -RIn "hycom\|HYCOM\|Hycom\|indexgfs" static server templates deploy main.py install.sh broadcast.sh --exclude-dir=.git; then
  echo "legacy hycom/indexgfs reference found in app source" >&2
  exit 1
fi
echo "live-first provider contract ok"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BBOX_LOCAL="${BBOX_LOCAL:--125,32,-117,38}"
BBOX_GLOBAL="${BBOX_GLOBAL:--136,32,-94,55}"
echo "===== NIFTY: lake temp companion global ====="
curl -sS "http://127.0.0.1:8000/gfs/api/scene-frame?bbox=${BBOX_GLOBAL}&visible_bbox=${BBOX_GLOBAL}&layers=inland-water,inland_water_temp&mode=fast&refresh=0&provider_jobs=0&reason=nifty_global_lake_temp_check" \
  | jq '{inland:.render_debug.layers["inland-water"], temp:.render_debug.layers.inland_water_temp, tempLabels:(.layers.inland_water_temp.tempLabels|length?), first:(.layers.inland_water_temp.tempLabels[0] // null | {name,water_temp_f,source,confidence,temp_var,temp_level,global_boot_estimated})}'
echo "===== NIFTY: all ocean pills local shared cache ====="
curl -sS "http://127.0.0.1:8000/gfs/api/scene-frame?bbox=${BBOX_LOCAL}&visible_bbox=${BBOX_LOCAL}&layers=bait,boater,shark-intel&mode=fast&refresh=0&provider_jobs=0&reason=nifty_ocean_pills_check" \
  | jq '{repair:.render_debug.ocean_pill_merge_repair, level_contract:.render_debug.level_contract, bait:{source:.layers.bait.source,status:.layers.bait.status,polygons:(.layers.bait.polygons|length?),levels:.layers.bait.depth_levels_ft}, boater:{source:.layers.boater.source,status:.layers.boater.status,boats:(.layers.boater.boats|length?),ocean_points:(.layers.boater.oceanPoints.points|length?),levels:.layers.boater.depth_levels_ft}, shark:{source:.layers["shark-intel"].source,status:.layers["shark-intel"].status,polygons:(.layers["shark-intel"].polygons|length?),levels:.layers["shark-intel"].depth_levels_ft}}'
echo "===== NIFTY: lake env URL variable split ====="
python3 - <<'PY'
from server.gfs.tile_contract import provider_url, LAKE_WATER_TEMP_NCSS_VARS, LOCATION_INTEL_AIR_TEMP_NCSS_VARS
url = provider_url('lake_environment', {'west':-118,'south':33,'east':-117,'north':34})
print('LAKE_WATER_TEMP_NCSS_VARS=', LAKE_WATER_TEMP_NCSS_VARS)
print('LOCATION_INTEL_AIR_TEMP_NCSS_VARS=', LOCATION_INTEL_AIR_TEMP_NCSS_VARS)
print('has surface temp var=', any(x in url for x in LAKE_WATER_TEMP_NCSS_VARS))
print('has 2m air context=', any(x in url for x in LOCATION_INTEL_AIR_TEMP_NCSS_VARS))
PY

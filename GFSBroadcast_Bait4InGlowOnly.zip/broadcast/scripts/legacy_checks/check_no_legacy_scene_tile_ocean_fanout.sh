#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile server/gfs_service_parts/tiles_scene.py server/gfs_service_parts/lightning_cache_media.py server/gfs_service_parts/ocean_bait_frame.py
if grep -R "24x24_per_selected_provider" -n static server scripts 2>/dev/null; then
  echo "FAIL legacy 24x24 provider-grid string still present" >&2
  exit 1
fi
grep -R "generic_scene_tiles_never_call_ocean_provider" -n server/gfs_service_parts/tiles_scene.py >/dev/null
grep -R "skipped_legacy_scene_tile_ocean_fanout" -n server/gfs_service_parts/lightning_cache_media.py >/dev/null
echo "OK no legacy scene-tile ocean fanout: scene tiles are weather-only; ocean uses one 6x6/36 authoritative viewport refresh."

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "[check] JS syntax"
node --check static/js/gfs/main.js
node --check static/js/gfs/inland-water.js

echo "[check] ocean layers stay subscribed at global boot/cache"
grep -q "ocean_bait_boats_always_subscribed_global_cache_read" static/js/gfs/main.js
grep -q "ocean/bootstrap-refresh-allowed-cache-only" static/js/gfs/main.js

echo "[check] inland temp labels are keyed/versioned and no-flash"
grep -q "data-inland-temp-key" static/js/gfs/inland-water.js
grep -q "inland-water/temp-render-skip" static/js/gfs/inland-water.js
grep -q "same_lake_same_temp_version_do_not_rebuild_marker" static/js/gfs/inland-water.js
grep -q "stable_real_vector_perimeter_no_flash_temp_metadata_updates" static/js/gfs/inland-water.js

echo "[ok] ocean always + inland anti-flash patch checks passed"

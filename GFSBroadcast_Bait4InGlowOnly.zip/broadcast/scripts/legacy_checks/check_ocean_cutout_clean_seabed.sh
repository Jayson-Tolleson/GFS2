#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "=== Ocean Cutout Clean Seabed Static Check ==="
python3 -m py_compile server/gfs/bathymetry_tiles.py scripts/build_bathymetry_4deg_cache.py server/gfs/routes.py
node --check static/js/layers/ocean-glass.js

echo
python3 - <<'PY'
from pathlib import Path
s = Path('static/js/layers/ocean-glass.js').read_text()
need = [
  'CLEAN_SEABED_MODE',
  'DRAW_CELL_GRID_LINES',
  'DRAW_CELL_VERTICAL_EDGES',
  'DRAW_CELL_FLOOR_RIMS',
  'DRAW_CELL_SKIRT_WALLS',
  'sand_depth_v1_clean_seabed',
  'clean_sand_seabed_no_marching_square_window_helpers',
]
missing = [x for x in need if x not in s]
print({'ok': not missing, 'missing': missing})
if missing:
    raise SystemExit(1)
PY

echo
cat <<'NOTE'
Browser console proof after opening /GFS:
({
  cutout: window.__gfsOceanCutoutStats,
  waterMask: window.__gfsOceanCutoutStats?.bathymetry?.water_mask
})

Expected:
  clean_seabed_mode: true
  draw_cell_grid_lines: false
  draw_cell_vertical_edges: false
  draw_cell_floor_rims: false
  draw_cell_skirt_walls: false
  palette: sand_depth_v1_clean_seabed
NOTE

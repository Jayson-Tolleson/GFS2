#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"
GRID="${GRID:-32}"

cat <<HDR
LFTR NO-GLASS PADDED OCEAN CUTOUT CHECK
BASE=$BASE
BBOX=$BBOX
GRID=$GRID
HDR

echo
echo "1) syntax"
python3 -m py_compile server/gfs/bathymetry_tiles.py scripts/build_bathymetry_4deg_cache.py
node --check static/js/layers/ocean-glass.js
node --check static/js/index.js

echo
echo "2) bathymetry cache/API for padded-world tile source"
curl -sS "$BASE/gfs/api/bathymetry-tiles?bbox=$BBOX&tile_deg=4&grid=$GRID&limit=72" \
  | jq '{
      ok,
      source,
      tile_deg,
      requested_tile_count,
      tile_count,
      missing_tile_count,
      cache,
      water_cells: ([.tiles[]?.cutaway_mask.water_render_cells // 0] | add // 0),
      land_cells: ([.tiles[]?.cutaway_mask.land_render_cells // 0] | add // 0),
      sample_tiles: [.tiles[]? | {tile_id, bbox, water_fraction, grid: .render_grid.rows, water_cells: .cutaway_mask.water_render_cells, land_cells: .cutaway_mask.land_render_cells}] | .[:8]
    }'

echo
echo "3) scene-frame still healthy"
curl -sS "$BASE/gfs/api/scene-frame?bbox=$BBOX&layers=clouds,rain,bait,boats" \
  | jq '{
      ok,
      source,
      layer_keys: (.layers | keys),
      clouds: {status: .layers.clouds.status, count: .layers.clouds.count, source: .layers.clouds.source},
      rain: {status: .layers.rain.status, count: .layers.rain.count, source: .layers.rain.source},
      bait: {status: .layers.bait.status, count: .layers.bait.count, source: .layers.bait.source},
      boater: {status: .layers.boater.status, count: .layers.boater.count, source: .layers.boater.source}
    }'

echo
echo "4) browser console proof after opening /GFS"
cat <<'BROWSER'
({
  cutout: window.__gfsOceanCutoutStats,
  oldAlias: window.__gfsOceanGlassStats,
  drawSurface: window.__gfsOceanCutoutStats?.draw_surface,
  mode: window.__gfsOceanCutoutStats?.cutout_mode,
  raw: window.__gfsOceanCutoutStats?.raw_bbox,
  padded: window.__gfsOceanCutoutStats?.padded_bbox,
  request: window.__gfsOceanCutoutStats?.request_bbox,
  waterMask: window.__gfsOceanCutoutStats?.bathymetry?.water_mask,
})
BROWSER

echo
echo "Expected browser signs: drawSurface=false, mode=no_glass_surface_floor_edges_only, rendered_diorama_cells > 0."

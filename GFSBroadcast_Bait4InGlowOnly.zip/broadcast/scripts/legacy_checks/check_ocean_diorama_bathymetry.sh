#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"
GRID="${GRID:-16}"

cat <<EOF
OCEAN DIORAMA / BATHYMETRY CELL CHECK
BASE=$BASE
BBOX=$BBOX
GRID=$GRID
EOF

echo
echo "1) frontend syntax"
node --check static/js/layers/ocean-glass.js
node --check static/js/layers/bait.js
node --check static/js/index.js

echo
echo "2) cached NOAA ETOPO bathymetry tiles"
curl -sS "$BASE/gfs/api/bathymetry-tiles?bbox=$BBOX&tile_deg=4&grid=$GRID&limit=40" \
  | jq '{
      ok,
      source,
      tile_deg,
      requested_tile_count,
      tile_count,
      missing_tile_count,
      cache,
      summary: {
        total_water_cells: ([.tiles[]?.cutaway_mask.water_render_cells // 0] | add // 0),
        total_land_cells: ([.tiles[]?.cutaway_mask.land_render_cells // 0] | add // 0),
        water_fractions: [.tiles[]? | {tile_id, water_fraction, depth_mean_m, depth_max_m, render_grid: .render_grid.rows, has_cell_water_fraction: (.render_grid.water_fraction != null), water_cells: .cutaway_mask.water_render_cells, land_cells: .cutaway_mask.land_render_cells}]
      }
    }'

echo
echo "3) full scene-frame health"
curl -sS "$BASE/gfs/api/scene-frame?bbox=$BBOX&layers=clouds,rain,bait,boats,lightning" \
  | jq '{
      ok,
      ts,
      clouds: {status: .layers.clouds.status, source: .layers.clouds.source, count: .layers.clouds.count},
      rain: {status: .layers.rain.status, source: .layers.rain.source, count: .layers.rain.count},
      bait: {status: .layers.bait.status, source: .layers.bait.source, count: .layers.bait.count, rows: ((.layers.bait.advancedBaitRows // []) | length), ocean_points: ((.layers.bait.oceanPoints.points // []) | length)},
      boater: {status: .layers.boater.status, source: .layers.boater.source, count: .layers.boater.count, boats: ((.layers.boater.boats // []) | length), ocean_points: ((.layers.boater.oceanPoints.points // []) | length)},
      lightning: {status: .layers.lightning.status, cloud_lightning_events: ((.layers.clouds.lightning_events // []) | length)}
    }'

echo
echo "4) browser console proof after opening /GFS"
echo "  window.__gfsOceanGlassStats"
echo "  window.__gfsOceanGlassStats.bathymetry.water_mask"
echo "  window.__gfsOceanGlassStats.bathymetry.rendered_tiles"
echo "  window.__gfsBaitBeaconStats"
echo
cat <<'EOF'
Desired ocean-glass stats:
  source = cached_noaa_etopo2022_4deg_water_masked_glass_ocean_tiles
  bathymetry.ok = true
  bathymetry.water_mask.rendered_diorama_cells > 0
  bathymetry.water_mask.min_cell_water_fraction is present
  request_bbox is tile-aligned and padded_bbox reflects camera tilt/heading
  rendered_tiles[].cutaway_mode = full_ocean_bathymetry_cells OR bathymetry_water_cells

Note: this is a gmp-map-3d bathymetry diorama overlay. It does not remove Google native water yet.
EOF

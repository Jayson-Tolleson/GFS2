#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

f="static/js/gfs/main.js"
test -f "$f"

grep -q "LOCAL_OCEAN_READBACK_MAX_WIDTH_DEG" "$f"
grep -q "scheduleLocalOceanReadbackIfNeeded" "$f"
grep -q "ocean/local-readback-start" "$f"
grep -q "global_ocean_cache_only_then_local_rtofs_tile_readback_apply_to_renderer" "$f"
grep -q "oceanPoints?.points" "$f"
grep -q "applySceneCachePayload(payload, reason);" "$f"

if command -v node >/dev/null 2>&1; then
  node --check "$f" >/dev/null
fi

echo "ok: ocean local readback render bridge patch validated"

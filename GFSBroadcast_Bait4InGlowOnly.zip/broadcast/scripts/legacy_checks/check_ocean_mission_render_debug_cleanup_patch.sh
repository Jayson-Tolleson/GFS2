#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$(pwd)}"
cd "$ROOT"
python3 -m py_compile server/gfs/pipeline.py server/gfs_service_parts/lightning_cache_media.py
node --check static/js/gfs/main.js >/dev/null
node --check static/js/gfs/world_subscription_renderer.js >/dev/null
node --check static/js/gfs/layers/renderer_layer.js >/dev/null
node --check static/js/gfs/layer_engine.js >/dev/null
grep -q "OCEAN_MISSION_REQUIRED_LAYERS" static/js/gfs/main.js
grep -q "sharkIntel: this.layerOn('shark-intel')" static/js/gfs/world_subscription_renderer.js
grep -q "never strand shark-intel" server/gfs/pipeline.py
grep -q "__GFS_DEBUG_PANEL_EVENT" static/js/gfs/layers/renderer_layer.js
grep -q "render_debug" static/gfs.html
echo "OK ocean mission bundle + clean render debug cleanup is installed"

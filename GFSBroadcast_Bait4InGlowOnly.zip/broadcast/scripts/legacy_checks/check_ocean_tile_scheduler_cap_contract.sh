#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "FAIL: $*" >&2; exit 1; }

if rg -n --glob '!docs/archive/**' --glob '!*.md' --glob '!*.txt' --glob '!scripts/check_ocean_tile_scheduler_cap_contract.sh' 'ocean/tile-refresh scheduled=' server scripts static/js/gfs >/tmp/lftr_ocean_old_tile_log.txt 2>/dev/null; then
  echo 'FAIL old uncapped ocean/tile-refresh scheduled= log string still exists:' >&2
  cat /tmp/lftr_ocean_old_tile_log.txt >&2
  exit 1
fi

for pattern in '_cap_ocean_provider_tiles' 'GFS_OCEAN_PROVIDER_MAX_SCHEDULED_TILES' 'requested_tiles_total=%s scheduled=%s' 'skipped_tiles_budget' 'partial_refresh'; do
  rg -n "$pattern" server/gfs_service_parts/ocean_bait_frame.py >/dev/null || fail "missing ocean tile cap pattern: $pattern"
done

if rg -n 'GFS_OCEAN_PROVIDER_MAX_SYNC_TILES.*36|"global": 36, "regional": 36, "local": 36' server scripts/run_broadcast_service.sh >/tmp/lftr_ocean_36.txt 2>/dev/null; then
  echo 'FAIL unsafe 36-tile ocean default still present:' >&2
  cat /tmp/lftr_ocean_36.txt >&2
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
src = Path('server/gfs_service_parts/ocean_bait_frame.py').read_text()
assert 'GFS_OCEAN_PROVIDER_MAX_SCHEDULED_TILES' in src
assert 'GFS_CACHE_WARM_OCEAN_MAX_TILES' in src
assert 'hard_capped_ocean_provider_tiles_center_first_prevent_curl_oom' in src
assert 'requested_tiles_total' in src and 'skipped_tiles_budget' in src and 'partial_refresh' in src
PY

echo 'OK ocean tile scheduler cap contract present'

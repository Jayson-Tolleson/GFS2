#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check static/js/gfs/main.js
node --check static/js/gfs/world_subscription_renderer.js
python3 -m py_compile server/gfs/providers/rtofs.py scripts/rtofs_fetch_worker.py scripts/run_hypercorn_single.py
# App sources should not reference removed ocean legacy names or stale index route.
if grep -RIn "hycom\|HYCOM\|Hycom\|indexgfs" static server templates deploy main.py install.sh broadcast.sh --exclude-dir=.git; then
  echo "legacy ocean/indexgfs reference found in app source" >&2
  exit 1
fi
grep -q "BOOT_HEAVY_LAYER_RE" static/js/gfs/main.js
grep -q "ocean/bootstrap-refresh-held" static/js/gfs/main.js
grep -q "world/boot-light-layer-filter" static/js/gfs/world_subscription_renderer.js
echo "pop-safe render contract OK"

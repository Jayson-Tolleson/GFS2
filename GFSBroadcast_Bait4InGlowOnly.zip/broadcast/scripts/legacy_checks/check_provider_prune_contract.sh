#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }

grep -q 'include_provider_jobs: bool = False' server/gfs/pipeline.py || fail 'scene-frame pipeline must default provider_jobs off'
grep -q 'request.args.get("provider_jobs", "0")' server/gfs/routes.py || fail '/scene-frame route must default provider_jobs=0'
pass 'scene-frame provider job fanout is off by default'

grep -q 'def _manual_provider_debug_allowed' server/gfs/routes.py || fail 'manual provider-debug guard missing'
grep -q 'lftr_provider_debug_blocked_v1' server/gfs/routes.py || fail 'provider-debug blocked payload missing'
pass 'legacy provider/debug routes require manual override'

grep -q 'fallback_warm_used": False' server/gfs_service_parts/ocean_bait_frame.py || fail '/field current still appears to allow fallback warm'
! grep -q 'fallback_warm_used": True' server/gfs_service_parts/ocean_bait_frame.py || fail '/field current still contains fallback_warm_used=True'
pass '/field?field=current is cache/bridge read-only and does not wake RTOFS'

grep -q 'def provider_ledger_payload' server/gfs_service.py || fail 'provider ledger payload missing'
grep -q '/gfs/api/provider-ledger' server/gfs/routes.py || fail 'provider ledger route missing'
pass 'provider ledger route exists'

grep -q 'ocean_bundle_dependency' server/gfs_service_parts/lightning_cache_media.py || fail 'ocean bundle dependency coalescing missing'
pass 'boater can own one RTOFS refresh tick for dependent ocean layers'

python3 -m py_compile main.py server/gfs_service.py server/gfs_service_parts/core.py server/gfs_service_parts/ocean_bait_frame.py server/gfs_service_parts/lightning_cache_media.py server/gfs/routes.py server/gfs/pipeline.py
pass 'patched Python files compile'

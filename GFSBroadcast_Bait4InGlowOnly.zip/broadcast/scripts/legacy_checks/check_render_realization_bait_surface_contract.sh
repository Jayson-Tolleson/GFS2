#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check static/js/gfs/layers/renderer_layer.js
node --check static/js/gfs/layer_engine.js
node --check static/js/gfs/bait-zones.js
python3 -m py_compile server/gfs/derive/bait.py
python3 - <<'PY'
from pathlib import Path
checks = {
  'renderer promise tracking': ('static/js/gfs/layers/renderer_layer.js', 'draw_async_pending'),
  'render telemetry': ('static/js/gfs/layers/renderer_layer.js', '__gfsRenderTelemetry'),
  'engine realization estimate': ('static/js/gfs/layer_engine.js', 'render_realization_estimate'),
  'bait surface altitude': ('static/js/gfs/bait-zones.js', 'BAIT_CLOUD_SURFACE_ALTITUDE_FT'),
  'organic fallback': ('server/gfs/derive/bait.py', 'organic_score_patch_fallback_not_square'),
}
missing = []
for name, (path, needle) in checks.items():
    if needle not in Path(path).read_text():
        missing.append(f'{name}: {path} missing {needle}')
if missing:
    raise SystemExit('\n'.join(missing))
print('render realization + bait surface contract ok')
PY
! grep -RIn --exclude=check_render_realization_bait_surface_contract.sh "legacy_ocean_name_removed\|indexgfs" .

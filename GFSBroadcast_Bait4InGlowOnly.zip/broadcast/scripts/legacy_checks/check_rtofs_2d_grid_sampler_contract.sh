#!/usr/bin/env bash
set -u
cd "$(dirname "$0")/.." || exit 1
PY="venv/bin/python"
[ -x "$PY" ] || PY="python3"

BBOX="${1:--125,32,-117,38}"
echo "== rtofs deps =="
$PY - <<'PY'
for m in ["xarray","netCDF4","h5netcdf","numpy","requests"]:
    try:
        __import__(m); print("OK", m)
    except Exception as e:
        print("BAD", m, e)
PY

echo "== synthetic 2d curvilinear unit =="
$PY - <<'PY'
import numpy as np, xarray as xr
from server.gfs.models import BBox
from server.gfs.providers.rtofs_noaa import _payload_from_dataset
from server.gfs.rtofs_source import _points_from_raw
Y,X=20,30
lat=np.linspace(30,40,Y)[:,None]+np.zeros((Y,X))
lon=np.zeros((Y,X))+np.linspace(230,250,X)[None,:]
ds=xr.Dataset({
 'sst':(('MT','Layer','Y','X'),np.ones((1,1,Y,X))*15),
 'u_velocity':(('MT','Layer','Y','X'),np.ones((1,1,Y,X))*0.2),
 'v_velocity':(('MT','Layer','Y','X'),np.ones((1,1,Y,X))*-0.1),
 'Latitude':(('Y','X'),lat), 'Longitude':(('Y','X'),lon)
}, coords={'MT':[0],'Layer':[0],'Y':np.arange(Y),'X':np.arange(X)})
raw,diag=_payload_from_dataset(ds,BBox(-125,32,-117,38),1,'synthetic','cycle')
pts=_points_from_raw(raw or {},BBox(-125,32,-117,38),100)
print({'payload_ok': bool(raw), 'reason': diag.get('reason'), 'grid_kind': (diag.get('subset') or {}).get('grid_kind'), 'points': pts.get('count')})
raise SystemExit(0 if raw and pts.get('count',0)>0 and (diag.get('subset') or {}).get('grid_kind')=='2d_curvilinear' else 2)
PY

echo "== live warmer bbox=$BBOX =="
timeout 150s $PY scripts/warm_rtofs_surface_cache.py --bbox="$BBOX" --max-points 3000 | tee /tmp/rtofs_2d_sampler_check.json
jq '.ok,.status,.count,.selected_surface.product,.diagnostics.attempts[-1].parse.subset.grid_kind,.diagnostics.attempts[-1].parse.reason' /tmp/rtofs_2d_sampler_check.json 2>/dev/null || true

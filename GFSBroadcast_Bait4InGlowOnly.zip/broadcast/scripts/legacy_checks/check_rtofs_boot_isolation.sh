#!/usr/bin/env bash
set -euo pipefail
cd "${APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
python3 - <<'PY'
import sys
import server.gfs.providers.rtofs as r
bad = [m for m in ("xarray", "netCDF4", "h5netcdf", "cfgrib", "scipy") if m in sys.modules]
if bad:
    raise SystemExit("boot-light RTOFS contract imported native modules: " + ", ".join(bad))
p = r.OceanProvider()
print("ok boot-light rtofs provider", p.provider_name, p.boot_policy, p.wake_policy)
PY

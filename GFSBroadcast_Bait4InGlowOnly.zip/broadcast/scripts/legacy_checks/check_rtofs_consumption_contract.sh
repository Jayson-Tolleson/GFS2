#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PY="venv/bin/python"
if [ ! -x "$PY" ]; then PY="python3"; fi
BBOX="${1:--125,32,-117,38}"

echo "== compile rtofs consumption =="
$PY -m py_compile server/gfs/rtofs_source.py server/gfs/routes.py server/gfs_service_parts/ocean_bait_frame.py scripts/warm_rtofs_surface_cache.py scripts/diag_rtofs.py

echo "== deps =="
$PY - <<'PY'
for m in ["xarray","netCDF4","h5netcdf","numpy","requests"]:
    __import__(m)
    print("OK", m)
PY

echo "== endpoint cache status, no live open =="
curl --max-time 15 -sS "http://127.0.0.1:8000/gfs/api/rtofs/diag?bbox=$BBOX&live=0" \
  | jq '.ok,.status,.remote_open_in_request,.selected_surface.product,.count,.cache.path,.next_step'

echo "== spawn warmer through endpoint =="
curl --max-time 15 -sS "http://127.0.0.1:8000/gfs/api/rtofs/diag?bbox=$BBOX&warm=1&live=0" \
  | jq '.ok,.status,.warmer'

echo "== optional manual warmer command =="
echo "$PY scripts/warm_rtofs_surface_cache.py --bbox=$BBOX --max-points 3000"

echo "== after warmer completes, verify current consumption =="
echo "curl -sS \"http://127.0.0.1:8000/gfs/api/field?field=current&bbox=$BBOX\" | jq '.ok,.source,.status,.count,.current_points[0]'"

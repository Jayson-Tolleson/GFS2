#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON_BIN="${PYTHON_BIN:-python3}"

need() {
  local pat="$1" file="$2"
  if grep -R "$pat" -n "$file" >/dev/null; then
    echo "[PASS] $pat in $file"
  else
    echo "[FAIL] missing $pat in $file" >&2
    exit 1
  fi
}

need "RTOFS_ENABLE_DEPTH_SLICES" server/gfs/providers/rtofs_noaa.py
need "rtofs_glo_3dz_" server/gfs/providers/rtofs_noaa.py
need "_depth_targets_for_stride" server/gfs/providers/rtofs_noaa.py
need "global, roughly 1 degree" server/gfs/providers/rtofs_noaa.py
need "regional, roughly 0.5 degree" server/gfs/providers/rtofs_noaa.py
need "local, roughly 0.25 degree" server/gfs/providers/rtofs_noaa.py
need "bait_depth_intel" server/gfs/providers/rtofs_noaa.py
need "depth_slices" server/gfs/providers/rtofs_noaa.py
need "rtofs_depth_slices_v1" server/gfs_service_parts/ocean_bait_frame.py
need "fishing_style" server/gfs_service_parts/ocean_bait_frame.py
need "shark_depth_intel" server/gfs_service_parts/ocean_bait_frame.py
need "preferred_bait_depth_ft" server/gfs/shark_intel.py
need "RTOFS depth-slice" server/gfs/shark_intel.py

$PYTHON_BIN -m py_compile server/gfs/providers/rtofs_noaa.py server/gfs/shark_intel.py server/gfs_service_parts/ocean_bait_frame.py

echo "[PASS] RTOFS depth/bait/shark contract is present"

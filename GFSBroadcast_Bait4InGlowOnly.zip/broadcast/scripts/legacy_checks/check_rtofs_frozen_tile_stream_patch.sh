#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile server/gfs/rtofs_source.py server/gfs/providers/rtofs_noaa.py
python3 - <<'PY'
from pathlib import Path
checks = {
    'server/gfs/providers/rtofs_noaa.py': [
        'RTOFS_LOCAL_FILE_FIRST',
        'download_returned_html_error',
        '_candidate_urls() + _grib2_filter_candidate_urls',
        'GFS_RTOFS_CURL_MAX_TIME_S", "240"',
    ],
    'server/gfs/rtofs_source.py': [
        '_quantize_rtofs_tile_bbox',
        'GFS_RTOFS_TILE_QUANTIZE_DEG',
        'Stable ocean tile key',
    ],
    'RTOFS_FROZEN_TILE_STREAM_PLAN.md': [
        'curl downloads',
        'local',
        'SST-valid ocean mask',
    ],
}
missing = []
for file, needles in checks.items():
    text = Path(file).read_text()
    for needle in needles:
        if needle not in text:
            missing.append(f"{file}: {needle}")
if missing:
    raise SystemExit('Missing expected patch markers:\n' + '\n'.join(missing))
print('RTOFS frozen tile stream patch markers OK')
PY

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail=0
check(){ if grep -R "$1" -n "$2" >/dev/null 2>&1; then echo "[PASS] $1 in $2"; else echo "[FAIL] $1 missing in $2"; fail=1; fi; }
check "GFS_RTOFS_ENABLE_GRIB2_FILTER" server/gfs/providers/rtofs_noaa.py
check "filter_rtofs.pl" server/gfs/providers/rtofs_noaa.py
check "_rtofs_filter_url" server/gfs/providers/rtofs_noaa.py
check "subregion" server/gfs/providers/rtofs_noaa.py
check "leftlon" server/gfs/providers/rtofs_noaa.py
check "rightlon" server/gfs/providers/rtofs_noaa.py
check "toplat" server/gfs/providers/rtofs_noaa.py
check "bottomlat" server/gfs/providers/rtofs_noaa.py
check "var_WTMP" server/gfs/providers/rtofs_noaa.py
check "var_SALTY" server/gfs/providers/rtofs_noaa.py
check "var_UOGRD" server/gfs/providers/rtofs_noaa.py
check "var_VOGRD" server/gfs/providers/rtofs_noaa.py
check "cfgrib.open_datasets" server/gfs/providers/rtofs_noaa.py
check "whole_file_request" server/gfs/providers/rtofs_noaa.py
check "coordinate_bounded_request" server/gfs/providers/rtofs_noaa.py
python3 -m py_compile server/gfs/providers/rtofs_noaa.py
exit $fail

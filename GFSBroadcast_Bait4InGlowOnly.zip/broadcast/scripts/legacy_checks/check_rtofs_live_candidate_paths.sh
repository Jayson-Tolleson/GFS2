#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON_BIN="${PYTHON_BIN:-python3}"

$PYTHON_BIN - <<'PY'
from server.gfs.models import BBox
from server.gfs.providers.rtofs_noaa import _candidate_date_strings, _depth_candidate_urls, _candidate_urls

bbox = BBox(west=-118.8, south=32.8, east=-117.1, north=34.4)
dates = _candidate_date_strings()
depth = _depth_candidate_urls(bbox)
surf = _candidate_urls()
assert dates, "no live/candidate RTOFS dates"
assert any("rtofs_glo_3dz_" in d.get("url", "") and "US_west" in d.get("url", "") for d in depth), "missing US_west 3dz candidates"
assert any("rtofs_glo_2ds_" in d.get("url", "") for d in surf), "missing 2ds fallback candidates"
print("[PASS] RTOFS candidate dates:", dates[:3])
print("[PASS] first primary candidate:", depth[0]["url"] if depth else None)
print("[PASS] first fallback candidate:", surf[0]["url"] if surf else None)
PY

#!/usr/bin/env bash
set -euo pipefail
echo "[check] RTOFS wake lock is self-healing and global bboxes are rejected"
grep -R "viewport_too_large_for_rtofs_wake" -n server/gfs/rtofs_source.py server/gfs/pipeline.py
grep -R "self_clearing_rtofs_warm_lock_v2\|--lock" -n server/gfs/rtofs_source.py scripts/warm_rtofs_surface_cache.py
echo "[check] Inland water temp is metadata-only and shoreline is stable"
grep -R "inland_water_temp" -n server/gfs_service.py
grep -R "stable_real_vector_perimeter_no_flash_temp_metadata_updates\|metadata_only_do_not_rebuild_perimeter" -n static/js/gfs/inland-water.js static/js/gfs/main.js server/gfs_service_parts/lightning_cache_media.py
echo "OK: RTOFS stale locks/global wake and inland shoreline flashing controls are present."

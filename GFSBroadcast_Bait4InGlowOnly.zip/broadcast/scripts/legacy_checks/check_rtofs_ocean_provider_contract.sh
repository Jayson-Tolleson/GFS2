#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
pass(){ echo "[PASS] $*"; }
fail(){ echo "[FAIL] $*"; exit 1; }

grep -R "GFS_OCEAN_PRIMARY_PROVIDER.*rtofs" -n server/gfs/providers/rtofs.py >/dev/null || fail "RTOFS is not the default ocean primary provider"
pass "RTOFS is default primary provider"

grep -R "rtofs_ocean_bundle" -n server/gfs/providers server/gfs_service.py server/gfs_service_parts >/dev/null || fail "rtofs_ocean_bundle ledger family missing"
pass "rtofs_ocean_bundle ledger family is wired"

grep -R "rtofs_glo_3dz_.*6hrly_hvr" -n server/gfs/providers/rtofs_noaa.py >/dev/null || fail "RTOFS 3-D regional HVR primary candidate path missing"
pass "RTOFS 3-D regional HVR primary path exists"

grep -R "rtofs_glo_2ds_n.*3hrly" -n server/gfs/providers/rtofs_noaa.py >/dev/null || fail "RTOFS 2-D surface fallback candidate path missing"
pass "RTOFS 2-D surface fallback candidate path exists"

grep -R "_candidate_date_strings" -n server/gfs/providers/rtofs_noaa.py >/dev/null || fail "RTOFS live directory discovery missing"
pass "RTOFS live directory discovery present"

grep -R "global_12_regional_6_local_3" -n server/gfs/providers/rtofs_noaa.py >/dev/null || fail "RTOFS three-LOD stride policy missing"
pass "RTOFS LOD stride policy present"

python3 -m py_compile server/gfs/providers/rtofs_noaa.py server/gfs/providers/rtofs.py
pass "RTOFS provider Python compiles"

#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
PY="${PYTHON:-$APP_DIR/venv/bin/python}"
if [[ ! -x "$PY" ]]; then
  echo "FAIL: expected venv python at $PY" >&2
  exit 1
fi
"$PY" - <<'PY'
import importlib.util
mods = ("xarray", "netCDF4", "h5netcdf", "h5py", "fsspec", "numpy", "requests")
missing = [m for m in mods if importlib.util.find_spec(m) is None]
if missing:
    raise SystemExit("FAIL missing RTOFS deps: " + ",".join(missing))
print("OK RTOFS deps installed: " + ", ".join(mods))
PY

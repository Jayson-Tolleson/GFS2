#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"
URL="$BASE/gfs/api/scene-frame?bbox=$BBOX&layers=clouds,rain"

echo "Checking scene-frame clouds/rain bridge"
echo "URL: $URL"

body="$(curl -sS --connect-timeout 8 --max-time 60 "$URL")"
echo "$body" | jq '{
  ok,
  source,
  layer_keys: (.layers | keys),
  atmosphere_live_bridge: .diagnostics.atmosphere_live_bridge,
  clouds: {
    ok: .layers.clouds.ok,
    status: .layers.clouds.status,
    payload_state: .layers.clouds.payload_state,
    source: .layers.clouds.source,
    count: .layers.clouds.count,
    items: ((.layers.clouds.items // []) | length),
    features: ((.layers.clouds.features // []) | length),
    cloud_regions: ((.layers.clouds.cloud_regions // []) | length),
    request_state: .layers.clouds.request_state,
    display_state: .layers.clouds.display_state
  },
  rain: {
    ok: .layers.rain.ok,
    status: .layers.rain.status,
    payload_state: .layers.rain.payload_state,
    source: .layers.rain.source,
    count: .layers.rain.count,
    features: ((.layers.rain.features // []) | length),
    precip_columns: ((.layers.rain.precip_columns // []) | length),
    request_state: .layers.rain.request_state,
    display_state: .layers.rain.display_state
  }
}'

# The first run may legally be fetching_fresh if no retained cloud tile exists.
# A hard failure is only when the scene-frame bridge diagnostic is missing or false.
echo "$body" | jq -e '.ok == true and (.diagnostics.atmosphere_live_bridge.applied == true or .diagnostics.atmosphere_live_bridge.reason == "atmosphere_layers_already_renderable")' >/dev/null

echo "OK: scene-frame clouds/rain bridge is wired. If first run says fetching_fresh, run again after the provider warm finishes."

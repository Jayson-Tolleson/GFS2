#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

summarize_jq='{
      ok,
      source,
      ts,
      layers: (.layers | keys),
      clouds: {
        status: .layers.clouds.status,
        source: .layers.clouds.source,
        count: .layers.clouds.count,
        items: ((.layers.clouds.items // []) | length),
        features: ((.layers.clouds.features // []) | length),
        cloud_regions: ((.layers.clouds.cloud_regions // []) | length),
        valid_time: .layers.clouds.valid_time,
        display_state: .layers.clouds.display_state
      },
      rain: {
        status: .layers.rain.status,
        source: .layers.rain.source,
        count: .layers.rain.count,
        features: ((.layers.rain.features // []) | length),
        precip_columns: ((.layers.rain.precip_columns // []) | length),
        valid_time: .layers.rain.valid_time,
        display_state: .layers.rain.display_state
      },
      bait: {
        status: .layers.bait.status,
        source: .layers.bait.source,
        count: .layers.bait.count,
        polygons: (((.layers.bait.polygons // []) | length) + ((.layers.bait.outer_polygons // []) | length) + ((.layers.bait.inner_polygons // []) | length) + ((.layers.bait.core_polygons // []) | length)),
        rows: ((.layers.bait.advancedBaitRows // .layers.bait.advanced_bait_rows // []) | length),
        ocean_points: ((.layers.bait.oceanPoints.points // .layers.bait.ocean_points // []) | length)
      },
      boater: {
        status: .layers.boater.status,
        source: .layers.boater.source,
        count: .layers.boater.count,
        boats: ((.layers.boater.boats // []) | length),
        ocean_points: ((.layers.boater.oceanPoints.points // .layers.boater.ocean_points // []) | length),
        sample: (.layers.boater.oceanPoints.points[0] // .layers.boater.ocean_points[0] // .layers.boater.boats[0] // null | if . == null then null else {lat, lon, current_speed_kt, direction_deg, sst, sst_c, water_temp_f, salinity} end)
      },
      lightning: {
        status: .layers.lightning.status,
        source: .layers.lightning.source,
        flashes: ((.layers.lightning.flashes // []) | length),
        items: ((.layers.lightning.items // []) | length),
        cloud_lightning_events: ((.layers.clouds.lightning_events // []) | length)
      },
      inland_water: {
        status: .layers["inland-water"].status,
        source: .layers["inland-water"].source,
        count: .layers["inland-water"].count,
        polygons: ((.layers["inland-water"].polygons // []) | length),
        temp_points: ((.layers["inland-water"].temperature_points // []) | length)
      },
      diagnostics: {
        atmosphere_bridge: .diagnostics.atmosphere_live_bridge,
        ocean_merge_repair: .diagnostics.ocean_pill_merge_repair,
        rtofs_ocean_wake: .diagnostics.rtofs_ocean_wake
      }
    }'

echo "SCENE-FRAME RENDER ADAPTER CHECK"
echo "BASE=$BASE"
echo "BBOX=$BBOX"
echo

echo "1) JS syntax"
for f in \
  "$ROOT/static/js/index.js" \
  "$ROOT/static/js/layers/scene-frame-utils.js" \
  "$ROOT/static/js/layers/clouds.js" \
  "$ROOT/static/js/layers/rain.js" \
  "$ROOT/static/js/layers/ocean-glass.js" \
  "$ROOT/static/js/layers/bait.js" \
  "$ROOT/static/js/layers/boats.js" \
  "$ROOT/static/js/layers/lightning.js" \
  "$ROOT/static/js/layers/inland-water.js"; do
  node --check "$f" || exit 1
done

echo
echo "2) combined all-layer scene-frame summary"
ALL_JSON="$(mktemp)"
MARINE_JSON="$(mktemp)"
FIELD_JSON="$(mktemp)"
trap 'rm -f "$ALL_JSON" "$MARINE_JSON" "$FIELD_JSON"' EXIT
curl -sS --max-time 45 "$BASE/gfs/api/scene-frame?bbox=$BBOX&layers=clouds,rain,bait,boats,lightning,inland-water" > "$ALL_JSON"
jq "$summarize_jq" "$ALL_JSON"

echo
echo "3) marine-only supplement summary; browser now uses this as fallback if all-layer marine is warming"
curl -sS --max-time 60 "$BASE/gfs/api/scene-frame?bbox=$BBOX&layers=bait,boats" > "$MARINE_JSON"
jq "$summarize_jq" "$MARINE_JSON"

echo
echo "4) current-field fallback summary; browser uses this if scene-frame marine refuses to wake"
curl -sS --max-time 60 "$BASE/gfs/api/field?field=current&bbox=$BBOX" > "$FIELD_JSON"
jq '{ok, source, count, sample: ((.points[0] // .ocean_points[0] // .current_points[0] // null) | if . then {lat, lon, current_speed_kt, direction_deg, sst_c, water_temp_f, salinity} else null end)}' "$FIELD_JSON"

echo
echo "5) adapter verdict"
jq -n --slurpfile all "$ALL_JSON" --slurpfile marine "$MARINE_JSON" --slurpfile field "$FIELD_JSON" '
  def b($x): ($x.layers.bait // {});
  def o($x): ($x.layers.boater // {});
  def baitReady($x): (((b($x).polygons // [])|length) + ((b($x).outer_polygons // [])|length) + ((b($x).inner_polygons // [])|length) + ((b($x).advancedBaitRows // b($x).advanced_bait_rows // [])|length) + ((b($x).oceanPoints.points // b($x).ocean_points // [])|length)) > 0;
  def boaterReady($x): (((o($x).boats // [])|length) + ((o($x).oceanPoints.points // o($x).ocean_points // [])|length)) > 0;
  {
    all_layer_clouds_ready: (($all[0].layers.clouds.count // 0) > 0),
    all_layer_rain_ready: (($all[0].layers.rain.count // 0) > 0),
    all_layer_bait_ready: baitReady($all[0]),
    all_layer_boater_ready: boaterReady($all[0]),
    marine_supplement_bait_ready: baitReady($marine[0]),
    marine_supplement_boater_ready: boaterReady($marine[0]),
    field_current_ready: (($field[0].ok == true) and (($field[0].count // 0) > 0)),
    field_current_count: ($field[0].count // 0),
    browser_policy: "render clouds/rain first, draw ocean-glass viewport theater, then paint bait/boater from scene-frame or /field?field=current"
  }'

echo
echo "Adapter check complete. In the browser console, window.__gfsLatestSceneSummary should show marine after the supplement returns."

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

PY="${PYTHON:-venv/bin/python}"
BBOX="${BBOX:--125,32,-117,38}"
BASE="${BASE:-http://127.0.0.1:8000}"

echo "== compile bridge files =="
"$PY" -m py_compile \
  server/gfs_service_parts/lightning_cache_media.py \
  server/gfs_service_parts/ocean_bait_frame.py \
  server/gfs/rtofs_source.py \
  scripts/warm_rtofs_surface_cache.py

echo "== static contract grep =="
grep -q 'scene_frame_boater_consumes_warmed_rtofs_json' server/gfs_service_parts/lightning_cache_media.py
grep -q 'scene_frame_bait_consumes_warmed_rtofs_json' server/gfs_service_parts/lightning_cache_media.py
grep -q 'def _rtofs_points_to_bait_ocean_grid' server/gfs_service_parts/lightning_cache_media.py
grep -q 'read_rtofs_scene_bridge' server/gfs_service_parts/lightning_cache_media.py

echo "== warm RTOFS cache =="
"$PY" scripts/warm_rtofs_surface_cache.py --bbox="$BBOX" --max-points "${MAX_POINTS:-3000}" \
  | tee /tmp/lftr_rtofs_warm_bridge.json \
  | jq '.ok,.status,.count,.source'

echo "== field/current bridge =="
curl --max-time 20 -sS "$BASE/gfs/api/field?field=current&bbox=$BBOX" \
  | tee /tmp/lftr_rtofs_field_bridge.json \
  | jq '.ok,.source,.status,.count,.current_points[0]'

echo "== scene-frame boater/bait bridge =="
curl --max-time 25 -sS "$BASE/gfs/api/scene-frame?bbox=$BBOX&visible_bbox=$BBOX&layers=boater,bait" \
  | tee /tmp/lftr_rtofs_scene_bridge.json \
  | jq '.ok,
        .layers.boater.source,
        (.layers.boater.boats|length),
        .layers.boater.oceanPoints.count,
        .layers.bait.source,
        .layers.bait.count,
        .layers.bait.polygon_count,
        (.layers.bait.bait.polygons|length)'

echo "== pass criteria =="
jq -e '.layers.boater.oceanPoints.count > 0' /tmp/lftr_rtofs_scene_bridge.json >/dev/null
jq -e '((.layers.boater.boats|length) > 0) or (.layers.boater.oceanPoints.count > 0)' /tmp/lftr_rtofs_scene_bridge.json >/dev/null
jq -e '(.layers.bait.count // .layers.bait.polygon_count // (.layers.bait.bait.polygons|length) // 0) >= 0' /tmp/lftr_rtofs_scene_bridge.json >/dev/null

echo "OK scene-frame RTOFS bridge contract verified"

#!/usr/bin/env bash
set -euo pipefail
PY=${PY:-python3}
$PY -m py_compile server/gfs/pipeline.py server/gfs/rtofs_source.py server/gfs_service_parts/lightning_cache_media.py server/gfs_service_parts/ocean_bait_frame.py

echo "[check] scene-frame should enqueue RTOFS/ocean wake for explicit boater,bait cache miss"
grep -R "rtofs/ocean-wake-enqueued" -n server/gfs/pipeline.py
grep -R "spawn_rtofs_surface_warmer(visible_bbox" -n server/gfs/pipeline.py
grep -R '"boater": ("rtofs_ocean"' -n server/gfs/pipeline.py

echo "[check] legacy scene-tile ocean fanout remains blocked"
grep -R "legacy_scene_tile_ocean_blocked\|explicit_visible_bbox_required_for_ocean_provider" -n server/gfs_service_parts/lightning_cache_media.py >/dev/null

echo "OK: explicit scene-frame boater/bait requests can wake RTOFS while legacy child-tile ocean remains blocked."

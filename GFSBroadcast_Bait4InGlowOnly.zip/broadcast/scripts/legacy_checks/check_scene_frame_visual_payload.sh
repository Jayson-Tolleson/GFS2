#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"
echo "SCENE-FRAME VISUAL PAYLOAD CHECK"
echo "BASE=$BASE"
echo "BBOX=$BBOX"
echo

echo "1) marine-only scene-frame"
curl -sS "$BASE/gfs/api/scene-frame?bbox=$BBOX&layers=bait,boats" | jq '{
  ok,
  layers: (.layers | keys),
  diagnostics: .diagnostics,
  bait: {
    status: .layers.bait.status,
    source: .layers.bait.source,
    count: .layers.bait.count,
    polygons: ((.layers.bait.polygons // []) | length),
    rows: ((.layers.bait.advancedBaitRows // []) | length),
    ocean_points: ((.layers.bait.oceanPoints.points // []) | length),
    sample: ((.layers.bait.advancedBaitRows[0] // null) | if . then {lat, lon, probability, bait_depth_ft, water} else null end)
  },
  boater: {
    status: .layers.boater.status,
    source: .layers.boater.source,
    count: .layers.boater.count,
    boats: ((.layers.boater.boats // []) | length),
    ocean_points: ((.layers.boater.oceanPoints.points // []) | length),
    sample_boat: ((.layers.boater.boats[0] // null) | if . then {lat, lon, heading, headingDeg, current_speed_kt, current, water, safety} else null end),
    sample_ocean: ((.layers.boater.oceanPoints.points[0] // null) | if . then {lat, lon, current_speed_kt, direction_deg, sst_c, water_temp_f, salinity} else null end)
  }
}'

echo
echo "2) authoritative current field fallback"
curl -sS "$BASE/gfs/api/field?field=current&bbox=$BBOX" | jq '{
  ok,
  source,
  count,
  sample: ((.points[0] // .ocean_points[0] // .current_points[0] // null) | if . then {lat, lon, current_speed_kt, direction_deg, sst_c, water_temp_f, salinity} else null end)
}'

echo
echo "Browser console after opening /GFS:"
echo "  window.__gfsOceanGlassStats"
echo "  window.__gfsLayerDomStats"
echo "  window.__gfsBoaterBeaconStats"
echo "  window.__gfsBaitBeaconStats"
echo "  window.__gfsLatestSceneSummary"

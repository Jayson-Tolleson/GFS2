#!/usr/bin/env bash
set -u
BASE="${BASE:-http://127.0.0.1:8000}"
BBOX="${BBOX:--125,32,-117,38}"

echo "SHORELINE-SAFE / BATHYMETRY DIORAMA CUTAWAY CHECK"
echo "BASE=$BASE"
echo "BBOX=$BBOX"
echo

echo "1) frontend syntax"
node --check static/js/layers/ocean-glass.js
node --check static/js/layers/bait.js
node --check static/js/index.js

echo
echo "2) bathymetry tile cache and water-mask metadata"
curl -sS "$BASE/gfs/api/bathymetry-tiles?bbox=$BBOX&tile_deg=4&grid=8&limit=40" \
  | jq '{
      ok,
      source,
      tile_deg,
      requested_tile_count,
      tile_count,
      missing_tile_count,
      cache,
      tiles: [(.tiles // [])[0:8][] | {
        tile_id,
        bbox,
        water_fraction,
        depth_mean_m,
        depth_max_m,
        render_grid: .render_grid.rows,
        cutaway_mask
      }]
    }'

echo
echo "3) expected browser stats after opening /GFS"
echo "  window.__gfsOceanGlassStats.bathymetry.water_mask"
echo "  window.__gfsOceanGlassStats.bathymetry.rendered_tiles"
echo
echo "Desired modes:"
echo "  full_ocean_tile for open-water tiles"
echo "  bathymetry_water_cells for mixed land/water tiles"
echo "  no raw square cutaway over coastal land unless water_fraction is near 1.0"

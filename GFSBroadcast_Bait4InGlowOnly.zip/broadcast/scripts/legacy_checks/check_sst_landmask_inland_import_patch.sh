#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

python3 -m py_compile \
  server/gfs/ocean_landmask.py \
  server/gfs/derive/bait.py \
  server/gfs/providers/rtofs_noaa.py \
  server/gfs/providers/rtofs.py

python3 - <<'PY'
from pathlib import Path
s = Path('static/js/gfs/inland-water.js').read_text()
assert 'function cssEscapeInland' in s
assert 'replace(/\\\\/g' in s, 'inland-water css escape backslash regex fix missing'
assert 'replace(/"/g' in s, 'inland-water quote escape regex fix missing'
PY

if command -v node >/dev/null 2>&1; then
  node --check static/js/gfs/inland-water.js
  node --check static/js/gfs/bait-zones.js
fi

grep -q "plausible_sst_c_primary_paired_current_secondary" server/gfs/ocean_landmask.py
grep -q "no_ocean_mask_no_bait_never_draw_fallback_on_land" static/js/gfs/bait-zones.js
grep -q "plausible_sst_c" server/gfs/derive/bait.py

echo "OK: SST landmask + bait ocean gate + inland-water import syntax patch installed"

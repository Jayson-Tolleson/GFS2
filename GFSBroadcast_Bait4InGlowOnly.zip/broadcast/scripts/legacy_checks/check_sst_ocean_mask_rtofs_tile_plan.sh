#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== compile SST ocean-mask/RTOFS tile plan modules =="
python3 -m py_compile \
  server/gfs/ocean_landmask.py \
  server/gfs/rtofs_source.py \
  server/gfs_service_parts/ocean_bait_frame.py

echo "== symbol contract =="
grep -R "def load_cached_rtofs_ocean_mask\|def rtofs_ocean_mask_cache_path\|def annotate_tiles_with_ocean_mask\|GFS_RTOFS_SST_MASK_TILE_PLAN" \
  -n server/gfs/ocean_landmask.py server/gfs/rtofs_source.py server/gfs_service_parts/ocean_bait_frame.py

echo "== runtime smoke: pure mask tile planner =="
python3 - <<'PY'
from server.gfs.ocean_landmask import annotate_tiles_with_ocean_mask
mask_payload={
  "ok": True,
  "mask_source": "rtofs_sst_validity",
  "bbox": [-2,0,2,2],
  "lat_values": [0.25,0.75,1.25,1.75],
  "lon_values": [-1.75,-0.75,0.75,1.75],
  "mask": [
    [False,False,True,True],
    [False,False,True,True],
    [False,False,True,True],
    [False,False,True,True],
  ],
}
tiles=[{"west":-2,"south":0,"east":0,"north":2,"tile_id":"land"},{"west":0,"south":0,"east":2,"north":2,"tile_id":"water"}]
requested,diag=annotate_tiles_with_ocean_mask(tiles,mask_payload)
print(diag)
assert len(requested)==1, requested
assert requested[0]["tile_id"]=="water", requested
assert diag["tiles_skipped_land"]==1, diag
PY

echo "OK: SST ocean mask can skip land-only provider tiles without reducing ocean quality."

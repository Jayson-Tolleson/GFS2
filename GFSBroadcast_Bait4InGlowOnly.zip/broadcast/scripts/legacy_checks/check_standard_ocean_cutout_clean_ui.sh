#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== template no ocean cutout pill =="
if grep -Rni "Ocean Cutout: Standard" templates/index.html; then
  echo "FAIL visible Ocean Cutout pill still exists" >&2
  exit 1
fi

echo "== ocean cutout still standard in index =="
grep -Rni "ocean-glass" static/js/index.js >/dev/null
grep -Rni "standard infrastructure" static/js/index.js >/dev/null

echo "== clean debug defaults =="
grep -Rni "GFS_OCEAN_CUTOUT_TILE_BOUNDARY_RIMS.*'0'" static/js/layers/ocean-glass.js >/dev/null
grep -Rni "GFS_OCEAN_CUTOUT_TILE_VERTICAL_EDGES.*'0'" static/js/layers/ocean-glass.js >/dev/null
grep -Rni "standard_ocean_cutout_clean_seabed_no_ui_pill" static/js/layers/ocean-glass.js >/dev/null

echo "== bait tiny particle renderer =="
grep -Rni "probability-volume-tiny-particle" static/js/layers/bait-3d.js >/dev/null

echo "== syntax =="
node --check static/js/index.js >/dev/null
node --check static/js/layers/ocean-glass.js >/dev/null
node --check static/js/layers/bait-3d.js >/dev/null

echo "PASS standard ocean cutout clean UI pass"

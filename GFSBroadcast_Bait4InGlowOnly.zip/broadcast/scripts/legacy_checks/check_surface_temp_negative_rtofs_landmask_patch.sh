#!/usr/bin/env bash
set -euo pipefail
cd "${1:-$(pwd)}"

echo "===== PY COMPILE ====="
python3 -m py_compile \
  server/gfs/inland/payloads.py \
  server/gfs/providers/rtofs_noaa.py \
  server/gfs/noaa_landmask_cache.py

echo "===== GFS INLAND TEMP POLICY ====="
grep -n "surface_tmp_only_no_air_level_fallback\|temperature_surface_only_no_air_level_fallback\|surface_tmp_missing_no_air_level_fallback" server/gfs/inland/payloads.py
if grep -n "height_above_ground_0m.*fallback\|Temperature_height_above_ground@0m" server/gfs/inland/payloads.py; then
  echo "Unexpected height-above-ground temp fallback still present" >&2
  exit 1
fi

echo "===== RTOFS SURFACE FILTER POLICY ====="
grep -n '"lev_surface", "on"' server/gfs/providers/rtofs_noaa.py
if grep -n '"all_lev", "on"' server/gfs/providers/rtofs_noaa.py; then
  echo "Unexpected all_lev RTOFS surface request still present" >&2
  exit 1
fi

echo "===== RTOFS NEGATIVE DEPTH AXIS POLICY ====="
grep -n "sample_z_m\|negative_depth_below_water_positive_render_extrusion\|sample_z_m_negative_below_water" server/gfs/providers/rtofs_noaa.py | head -40

echo "===== NOAA LANDMASK CACHE FALLBACKS ====="
grep -n "gshhg-shp-2.3.7.zip\|naturalearth.s3.amazonaws.com\|3650" server/gfs/noaa_landmask_cache.py

echo "OK: surface temp only, RTOFS surface filter, negative below-water depth axis, long-lived landmask fallbacks present."

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "===== CONTRACT: Temperature_surface only for lake-water labels ====="
python3 - <<'PY'
from server.gfs.tile_contract import provider_url, LAKE_WATER_TEMP_NCSS_VARS, LOCATION_INTEL_AIR_TEMP_NCSS_VARS
url = provider_url('lake_environment', {'west':-125,'south':32,'east':-117,'north':38})
print('LAKE_WATER_TEMP_NCSS_VARS=', LAKE_WATER_TEMP_NCSS_VARS)
print('LOCATION_INTEL_AIR_TEMP_NCSS_VARS=', LOCATION_INTEL_AIR_TEMP_NCSS_VARS)
print('provider_url_has_Temperature_surface=', 'Temperature_surface' in url)
print('provider_url_has_TMP_surface=', 'TMP_surface' in url)
print('provider_url_has_t0m=', 't0m' in url)
print('provider_url_has_2m_air_context=', 'Temperature_height_above_ground' in url)
assert LAKE_WATER_TEMP_NCSS_VARS == ['Temperature_surface']
assert LOCATION_INTEL_AIR_TEMP_NCSS_VARS == ['Temperature_height_above_ground']
assert 'Temperature_surface' in url
assert 'TMP_surface' not in url and 't0m' not in url and 'TMP:surface' not in url
PY

echo

echo "===== CONTRACT: ocean selected before inland ====="
python3 - <<'PY'
from server.gfs.pipeline import normalize_scene_layers
layers = normalize_scene_layers(['inland-water','inland_water_temp','bait'])
print('normalized=', layers)
assert layers.index('bait') < layers.index('inland-water')
assert layers.index('shark-intel') < layers.index('inland-water')
assert layers.index('boater') < layers.index('inland-water')
PY

echo

echo "===== GLOBAL TEMP PAYLOAD SAMPLE ====="
BBOX_GLOBAL="${BBOX_GLOBAL:--136,32,-94,55}"
if curl -fsS "http://127.0.0.1:8000/gfs/api/scene-frame?bbox=${BBOX_GLOBAL}&visible_bbox=${BBOX_GLOBAL}&layers=inland-water,inland_water_temp&mode=fast&refresh=0&provider_jobs=0&reason=temperature_surface_ocean_first_contract" \
  | jq '{temp_debug:.render_debug.layers.inland_water_temp, tempLabels:(.layers.inland_water_temp.tempLabels|length?), first:(.layers.inland_water_temp.tempLabels[0] // null | {name, water_temp_f, source, source_temp, confidence, temp_var, temp_level, reason_temp})}'; then
  true
else
  echo "server not reachable on 127.0.0.1:8000; static contract checks above passed"
fi

echo

echo "===== OCEAN + INLAND ORDER SAMPLE ====="
BBOX_LOCAL="${BBOX_LOCAL:--125,32,-117,38}"
if curl -fsS "http://127.0.0.1:8000/gfs/api/scene-frame?bbox=${BBOX_LOCAL}&visible_bbox=${BBOX_LOCAL}&layers=inland-water,inland_water_temp,bait,boater,shark-intel&mode=fast&refresh=0&provider_jobs=0&reason=ocean_first_contract" \
  | jq '{selected_layers, level_contract:.render_debug.level_contract, bait:{source:.layers.bait.source,status:.layers.bait.status,polygons:(.layers.bait.polygons|length?)}, boater:{source:.layers.boater.source,status:.layers.boater.status,boats:(.layers.boater.boats|length?)}, shark:{source:.layers["shark-intel"].source,status:.layers["shark-intel"].status,polygons:(.layers["shark-intel"].polygons|length?)}, inland:{source:.layers["inland-water"].source,status:.layers["inland-water"].status,polygons:(.layers["inland-water"].polygons|length?)}, temp:{source:.layers.inland_water_temp.source,tempLabels:(.layers.inland_water_temp.tempLabels|length?)}}'; then
  true
else
  echo "server not reachable on 127.0.0.1:8000; static contract checks above passed"
fi

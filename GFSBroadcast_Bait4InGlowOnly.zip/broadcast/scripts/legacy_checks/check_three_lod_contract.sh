#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON_BIN="${PYTHON_BIN:-python3}"

$PYTHON_BIN - <<'PY'
from server.gfs.viewport36 import LOD_LEVELS, normalize_lod, lod_for_bbox
assert tuple(LOD_LEVELS) == ("global", "regional", "local"), LOD_LEVELS
assert normalize_lod("world") == "global"
assert normalize_lod("harbor") == "local"
assert normalize_lod("coastal") == "local"
assert lod_for_bbox({"west":-118.8,"south":32.8,"east":-117.1,"north":34.4}) == "local"
print("[PASS] canonical LODs are global/regional/local; legacy names alias at boundary only")
PY

# Policy text should not advertise harbor/coastal as LOD levels. Habitat/fishing prose may still mention real harbors/coasts.
if grep -R "harbor_1\|regional/coastal/local/harbor\|world/global = stride\|harbor       = stride" -n server static README.md scripts/check_rtofs_ocean_provider_contract.sh scripts/check_rtofs_depth_bait_shark_contract.sh 2>/dev/null; then
  echo "[FAIL] found legacy LOD policy text" >&2
  exit 1
fi

echo "[PASS] no advertised fourth LOD policy remains"

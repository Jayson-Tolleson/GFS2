#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "[check] python compile"
python3 -m py_compile \
  server/gfs/viewport36.py \
  server/gfs/routes.py \
  server/gfs/inland/payloads.py \
  server/gfs_service_parts/tiles_scene.py \
  server/gfs_service_parts/lightning_cache_media.py \
  server/gfs_service_parts/ocean_bait_frame.py

echo "[check] frontend syntax"
if command -v node >/dev/null 2>&1; then
  node --check static/js/gfs/main.js
  node --check static/js/gfs/cloud-zones.js
  node --check static/js/gfs/inland-water.js
  node --check static/js/gfs/bait-zones.js
  node --check static/js/gfs/boats.js
  node --check static/js/gfs/world_subscription_renderer.js
else
  echo "node not installed; skipping JS syntax checks"
fi

echo "[check] two-level policy strings"
grep -R "two_level_global_local_weather_stable_ocean_inland_detail_only\|Two-level LOD\|two-level LOD\|two_level_lod" \
  server/gfs server/gfs_service_parts static/js/gfs TWO_LEVEL_LOD_REALITY_PLAN.md >/dev/null

if grep -R "return 'regional'\|LOD_REGIONAL" -n server/gfs server/gfs_service_parts static/js/gfs 2>/dev/null; then
  echo "[warn] found active regional tier strings above; verify they are compatibility-only" >&2
fi

echo "OK two-level LOD policy patch present"

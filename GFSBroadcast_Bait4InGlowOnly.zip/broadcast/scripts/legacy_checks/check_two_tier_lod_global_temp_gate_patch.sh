#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile server/gfs/viewport36.py server/gfs/routes.py server/gfs_service_parts/lightning_cache_media.py
node --check static/js/gfs/main.js >/dev/null
node --check static/js/gfs/inland-water.js >/dev/null
node --check static/js/gfs/world_subscription_renderer.js >/dev/null
node --check static/js/gfs/bait-zones.js >/dev/null
# Global wide views must not request live inland temp companion or decode GFS surface TMP per lake.
grep -q "global_tier_live_temp_decode_disabled" server/gfs_service_parts/lightning_cache_media.py
grep -q "lftr_inland_water_temp_labels_v7_two_tier_global_cache_only_local_live" server/gfs_service_parts/lightning_cache_media.py
grep -q "lod_for_bbox" server/gfs_service_parts/lightning_cache_media.py
grep -q "sceneTierForViewport(options.viewport || {}) === 'local'" static/js/gfs/world_subscription_renderer.js
grep -q "inlandWaterTemp: inlandAllowed && isInlandDetailViewport(viewport)" static/js/gfs/main.js
grep -q "width <= 8.0 and height <= 6.0 and area <= 36.0" server/gfs/viewport36.py
echo "OK two-tier LOD rectified: global cache-only inland temp; local-only live temp/bait detail"

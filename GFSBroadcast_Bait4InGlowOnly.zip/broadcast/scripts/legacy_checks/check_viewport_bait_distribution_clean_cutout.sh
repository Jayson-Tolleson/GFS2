#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== syntax =="
node --check static/js/layers/ocean-glass.js
node --check static/js/layers/bait-3d.js

echo "== contracts =="
grep -q "FRAMELESS_CUTOUT_MODE" static/js/layers/ocean-glass.js
grep -q "GFS_OCEAN_CUTOUT_DRAW_SHORELINE ?? '0'" static/js/layers/ocean-glass.js
grep -q "FETCH_MAX_CLOUDS" static/js/layers/bait-3d.js
grep -q "selectViewportClouds" static/js/layers/bait-3d.js
grep -q "viewport_cloud_selection" static/js/layers/bait-3d.js

echo "== live endpoint if server is running =="
if curl -fsS --max-time 4 "http://127.0.0.1:8000/gfs/api/bait-3d-volume?bbox=-125,32,-117,38&depths=5,10,20,35,50,75,100&grid=16&max_clouds=96&max_cells=1200" >/tmp/lftr_bait_volume_check.json 2>/dev/null; then
  jq '{ok,source,shape,cloud_count,first_cloud:(.clouds[0]//null)|{id,lat,lon,probability,top_depth_m,bottom_depth_m}}' /tmp/lftr_bait_volume_check.json
else
  echo "server not running on 127.0.0.1:8000; skipped live endpoint check"
fi

echo "PASS viewport bait distribution clean cutout"

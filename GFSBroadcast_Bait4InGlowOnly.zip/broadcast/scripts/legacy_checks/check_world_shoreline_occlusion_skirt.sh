#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

echo "=== LFTR world shoreline occlusion skirt check ==="

echo
echo "1) Python/backend syntax"
python3 -m py_compile server/gfs/bathymetry_tiles.py scripts/build_bathymetry_4deg_cache.py

echo
echo "2) Frontend syntax"
node --check static/js/layers/ocean-glass.js >/dev/null

echo
echo "3) Bathymetry cache inventory"
curl -sS "http://127.0.0.1:8000/gfs/api/bathymetry-cache?tile_deg=4" \
  | jq '{ok, schema, tile_deg, cached_tile_count, global_tile_count, coverage_fraction, water_tile_files, land_tile_files, world_build_command}'

echo
echo "4) Shoreline/skirt bathymetry payload"
curl -sS "http://127.0.0.1:8000/gfs/api/bathymetry-tiles?bbox=-125,32,-117,38&tile_deg=4&grid=32&limit=72" \
  | jq '{
      ok,
      schema,
      source,
      tile_deg,
      requested_tile_count,
      tile_count,
      missing_tile_count,
      cutaway,
      cache: {mode: .cache.mode, hit_count: .cache.hit_count, root: .cache.root},
      totals: {
        renderable_water_cells: ([.tiles[]?.cutaway_mask.water_render_cells // 0] | add // 0),
        raw_water_cells: ([.tiles[]?.cutaway_mask.raw_water_cells // 0] | add // 0),
        shoreline_edges: ([.tiles[]?.cutaway_mask.shoreline_edge_count // 0] | add // 0),
        water_cell_records: ([.tiles[]?.cutaway_mask.water_cell_records_returned // 0] | add // 0)
      },
      sample_tiles: [.tiles[]? | {
        tile_id,
        bbox,
        water_fraction,
        grid: .render_grid.rows,
        cutaway: .cutaway,
        shoreline: .shoreline,
        renderable_water_cells: .cutaway_mask.water_render_cells,
        shoreline_edges: (.shoreline_edges | length),
        first_water_cell: (.water_cells[0] // null)
      }] | .[:8]
    }'

echo
echo "Browser console after opening /GFS:"
echo "({ cutout: window.__gfsOceanCutoutStats, waterMask: window.__gfsOceanCutoutStats?.bathymetry?.water_mask })"

#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${1:-$HOME/broadcast}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="${2:-$APP_DIR/GFSBroadcast_WithLocalBathymetryCache_${STAMP}.zip}"
TMP="$(mktemp -d /tmp/lftr-cache-package.XXXXXX)"
trap 'rm -rf "$TMP"' EXIT

if [[ ! -d "$APP_DIR" ]]; then
  echo "APP_DIR not found: $APP_DIR" >&2
  exit 1
fi

CACHE_SRC="$APP_DIR/data_sources/bathymetry/etopo2022_4deg_tiles"
count_tiles() {
  find "$CACHE_SRC" -maxdepth 1 -type f -name 'etopo2022_4deg_*.json' 2>/dev/null | wc -l | tr -d ' '
}

COUNT="$(count_tiles)"
if [[ "$COUNT" -eq 0 && "${LFTR_PACKAGE_AUTOBUILD_BATHYMETRY:-1}" == "1" ]]; then
  echo "No local bathymetry tiles found. Building SoCal seed cache before packaging..."
  if [[ -x "$APP_DIR/scripts/seed_bathymetry_socal_cache.sh" ]]; then
    bash "$APP_DIR/scripts/seed_bathymetry_socal_cache.sh" "$APP_DIR" || true
  elif [[ -f "$APP_DIR/scripts/build_bathymetry_4deg_cache.py" ]]; then
    "$APP_DIR/venv/bin/python" "$APP_DIR/scripts/build_bathymetry_4deg_cache.py" --bbox=-125,32,-117,38 --grid 32 --force || true
  fi
  COUNT="$(count_tiles)"
fi

if [[ "$COUNT" -eq 0 && "${ALLOW_EMPTY_BATHYMETRY_PACKAGE:-0}" != "1" ]]; then
  echo "Refusing to create a 'with local bathymetry cache' package with 0 tiles." >&2
  echo "Build the cache first:" >&2
  echo "  cd $APP_DIR && source venv/bin/activate && bash scripts/seed_bathymetry_socal_cache.sh $APP_DIR" >&2
  echo "Or set ALLOW_EMPTY_BATHYMETRY_PACKAGE=1 to override." >&2
  exit 2
fi

mkdir -p "$TMP/broadcast"
rsync -a \
  --exclude '.git/' \
  --exclude '__pycache__/' \
  --exclude '*.pyc' \
  --exclude 'venv/' \
  --exclude '.venv/' \
  --exclude 'node_modules/' \
  --exclude 'mnt/' \
  --exclude 'logs/' \
  "$APP_DIR/" "$TMP/broadcast/"

CACHE_DST="$TMP/broadcast/data_sources/bathymetry/etopo2022_4deg_tiles"
mkdir -p "$CACHE_DST"
COUNT="$(find "$CACHE_DST" -maxdepth 1 -type f -name 'etopo2022_4deg_*.json' | wc -l | tr -d ' ')"
WATER_CELLS="$(python3 - "$CACHE_DST" <<'PYCELLS' 2>/dev/null || echo 0
from pathlib import Path
import json, sys
root = Path(sys.argv[1])
total = 0
for p in root.glob('etopo2022_4deg_*.json'):
    try:
        d = json.loads(p.read_text())
        wc = d.get('water_cells')
        total += len(wc) if isinstance(wc, list) else int(wc or 0)
    except Exception:
        pass
print(total)
PYCELLS
)"

cat > "$TMP/broadcast/data_sources/bathymetry/PACKAGED_CACHE_MANIFEST.json" <<JSON
{
  "ok": true,
  "packaged_at_utc": "$STAMP",
  "source_app_dir": "$APP_DIR",
  "bathymetry_tile_count": $COUNT,
  "water_cells_estimate": $WATER_CELLS,
  "cache_dir": "data_sources/bathymetry/etopo2022_4deg_tiles",
  "seed_bbox": [-125, 32, -117, 38],
  "seed_grid": 32,
  "note": "Installer package generated locally from a server with existing NOAA ETOPO bathymetry tile cache."
}
JSON

(
  cd "$TMP"
  zip -qr "$OUT" broadcast
)

printf 'Created %s\n' "$OUT"
printf 'Included bathymetry tile count: %s\n' "$COUNT"
printf 'Included water cells estimate: %s\n' "$WATER_CELLS"

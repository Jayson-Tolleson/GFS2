#!/usr/bin/env bash
set -euo pipefail

# Probe one coordinate-bounded RTOFS GRIB2 tile. This is the LFTR provider
# contract shape: file + vars + levels + subregion coordinates + dir.
DATE="${1:-${RTOFS_DATE:-$(date -u +%Y%m%d)}}"
FILE="${2:-${RTOFS_FILE:-rtofs_glo_3dz_f006.grib2}}"
# Default: one small SoCal tile in 0..360 lon coordinates.
LEFTLON="${LEFTLON:-241.20}"
RIGHTLON="${RIGHTLON:-241.48}"
TOPLAT="${TOPLAT:-34.40}"
BOTTOMLAT="${BOTTOMLAT:-34.13}"
OUT="${OUT:-/tmp/lftr_rtofs_one_tile.grib2}"

URL="https://nomads.ncep.noaa.gov/cgi-bin/filter_rtofs.pl?file=${FILE}&all_lev=on&var_WTMP=on&var_TMP=on&var_SALTY=on&var_SALIN=on&var_UOGRD=on&var_UGRD=on&var_VOGRD=on&var_VGRD=on&var_SSHG=on&subregion=&leftlon=${LEFTLON}&rightlon=${RIGHTLON}&toplat=${TOPLAT}&bottomlat=${BOTTOMLAT}&dir=%2Frtofs.${DATE}"

echo "DATE=$DATE"
echo "FILE=$FILE"
echo "BBOX_0360 left=$LEFTLON right=$RIGHTLON top=$TOPLAT bottom=$BOTTOMLAT"
echo "$URL"

curl -L -sS -w "\nHTTP=%{http_code} SIZE=%{size_download} TIME=%{time_total}\n" "$URL" -o "$OUT"
file "$OUT" || true
ls -lh "$OUT" || true
if file "$OUT" | grep -qi html; then
  echo "[FAIL] response is HTML, not GRIB2" >&2
  head -40 "$OUT" >&2 || true
  exit 2
fi
if command -v grib_ls >/dev/null 2>&1; then
  grib_ls "$OUT" | head -40 || true
fi

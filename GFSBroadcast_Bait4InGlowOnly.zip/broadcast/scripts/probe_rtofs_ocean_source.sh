#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BBOX="${1:--118.8,32.8,-117.1,34.4}"
STRIDE="${2:-12}"
python3 - <<PY
from server.gfs.models import BBox
from server.gfs.providers.rtofs_noaa import fetch_rtofs_subset_sync
w,s,e,n = [float(x) for x in "$BBOX".split(',')]
payload, vt = fetch_rtofs_subset_sync(bbox=BBox(west=w,south=s,east=e,north=n), stride=int("$STRIDE"), valid_time=None)
meta = payload.get('source_meta', {})
print({
  'ok': bool(meta.get('live_ocean_truth_ok') or meta.get('real_subset')),
  'provider': meta.get('provider_ledger_family'),
  'source': meta.get('ocean_source'),
  'mode': meta.get('mode'),
  'grid_shape': meta.get('grid_shape'),
  'selected_dataset': meta.get('selected_dataset'),
  'selected_vars': meta.get('selected_vars'),
  'depth_slice_status': meta.get('depth_slice_status'),
  'depth_source': meta.get('depth_source'),
  'depth_selected_dataset': meta.get('depth_selected_dataset'),
  'depth_keys': meta.get('depth_keys'),
  'bait_depth_intel': meta.get('bait_depth_intel'),
  'blocking_reasons': meta.get('blocking_reasons'),
  'diagnostics_count': len(meta.get('diagnostics') or []),
})
PY

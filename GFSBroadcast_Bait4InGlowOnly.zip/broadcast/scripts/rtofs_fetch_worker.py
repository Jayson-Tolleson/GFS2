#!/usr/bin/env python3
from __future__ import annotations

"""Isolated RTOFS fetch worker.

The main Quart/Hypercorn process launches this script only after boot, only for
an approved visible_bbox ocean wake.  Native RTOFS/xarray/netCDF/cfgrib imports
stay here so failures cannot stop /health or /gfs.
"""

import json
import os
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

APP_DIR = Path(os.getenv("APP_DIR", Path(__file__).resolve().parents[1])).resolve()
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))
os.chdir(str(APP_DIR))


def _dt(value: Any) -> datetime | None:
    if not value:
        return None
    text = str(value)
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        out = datetime.fromisoformat(text)
        if out.tzinfo is None:
            out = out.replace(tzinfo=timezone.utc)
        return out
    except Exception:
        return None


def _json_default(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    try:
        import numpy as np  # type: ignore
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
    except Exception:
        pass
    try:
        if hasattr(value, "tolist"):
            return value.tolist()
    except Exception:
        pass
    return str(value)


def main() -> int:
    try:
        req = json.loads(sys.stdin.read() or "{}")
        b = req.get("bbox") or {}
        from server.gfs.models import BBox
        from server.gfs.providers.rtofs_noaa import fetch_rtofs_subset_sync

        bbox = BBox(west=float(b["west"]), south=float(b["south"]), east=float(b["east"]), north=float(b["north"]))
        payload, valid_time = fetch_rtofs_subset_sync(
            bbox=bbox,
            stride=max(1, int(req.get("stride") or 1)),
            valid_time=_dt(req.get("valid_time")),
        )
        print(json.dumps({"ok": True, "payload": payload, "valid_time": valid_time.isoformat() if isinstance(valid_time, datetime) else None}, default=_json_default), flush=True)
        return 0
    except BaseException as exc:
        print(json.dumps({"ok": False, "reason": "rtofs_worker_exception", "error": str(exc), "traceback": traceback.format_exc()[-4000:]}), flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

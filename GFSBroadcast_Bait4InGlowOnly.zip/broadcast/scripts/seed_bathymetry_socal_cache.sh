#!/usr/bin/env bash
set -uo pipefail

APP_DIR="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
BBOX="${LFTR_SEED_BATHYMETRY_BBOX:--125,32,-117,38}"
GRID="${LFTR_SEED_BATHYMETRY_GRID:-32}"
FORCE="${LFTR_SEED_BATHYMETRY_FORCE:-0}"
MIN_TILES="${LFTR_SEED_BATHYMETRY_MIN_TILES:-6}"
CACHE_DIR="$APP_DIR/data_sources/bathymetry/etopo2022_4deg_tiles"
PY="$APP_DIR/venv/bin/python"
[[ -x "$PY" ]] || PY="$(command -v python3 || true)"

mkdir -p "$CACHE_DIR"

tile_count() {
  find "$CACHE_DIR" -maxdepth 1 -type f -name 'etopo2022_4deg_*.json' 2>/dev/null | wc -l | tr -d ' '
}

summarize_cache() {
  "$PY" - "$CACHE_DIR" <<'PY' 2>/dev/null || true
from pathlib import Path
import json, sys
root = Path(sys.argv[1])
files = sorted(root.glob('etopo2022_4deg_*.json'))
water = 0
unreadable = 0
for p in files:
    try:
        d = json.loads(p.read_text())
        wc = d.get('water_cells')
        if isinstance(wc, list):
            water += len(wc)
        elif isinstance(wc, int):
            water += wc
        else:
            rg = d.get('render_grid') or {}
            wf = rg.get('water_fraction') or []
            for row in wf:
                if isinstance(row, list):
                    water += sum(1 for v in row if isinstance(v, (int, float)) and v > 0)
    except Exception:
        unreadable += 1
print(json.dumps({"tile_count": len(files), "water_cells_estimate": water, "unreadable": unreadable}, indent=2))
PY
}

COUNT="$(tile_count)"
echo "LFTR bathymetry seed cache: APP_DIR=$APP_DIR"
echo "LFTR bathymetry seed cache: existing_tile_count=$COUNT cache_dir=$CACHE_DIR"

if [[ "$FORCE" != "1" && "$COUNT" -ge "$MIN_TILES" ]]; then
  echo "LFTR bathymetry seed cache: already seeded; skipping build"
  summarize_cache
  exit 0
fi

if [[ ! -f "$APP_DIR/scripts/build_bathymetry_4deg_cache.py" ]]; then
  echo "LFTR bathymetry seed cache: missing builder script" >&2
  exit 2
fi

if [[ -z "$PY" || ! -x "$PY" ]]; then
  echo "LFTR bathymetry seed cache: python not found" >&2
  exit 2
fi

# The NOAA/xarray/netCDF stack may occasionally segfault during interpreter cleanup after
# the JSON files have been written.  Do not trust the process exit alone; verify files.
echo "LFTR bathymetry seed cache: building bbox=$BBOX grid=$GRID"
set +e
"$PY" "$APP_DIR/scripts/build_bathymetry_4deg_cache.py" --bbox="$BBOX" --grid "$GRID" --force
BUILD_RC=$?
set -e

COUNT="$(tile_count)"
echo "LFTR bathymetry seed cache: builder_exit=$BUILD_RC post_tile_count=$COUNT"
summarize_cache

if [[ "$COUNT" -lt "$MIN_TILES" ]]; then
  echo "LFTR bathymetry seed cache: FAILED expected at least $MIN_TILES tiles, found $COUNT" >&2
  exit 1
fi

# 139 is a segfault; tolerate it only if the seed cache exists.
if [[ "$BUILD_RC" -ne 0 && "$BUILD_RC" -ne 139 ]]; then
  echo "LFTR bathymetry seed cache: warning builder returned $BUILD_RC after writing tiles" >&2
fi

exit 0

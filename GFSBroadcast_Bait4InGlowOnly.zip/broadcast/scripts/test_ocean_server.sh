#!/usr/bin/env bash
set -u
cd "$(dirname "$0")/.." || exit 1
PY="venv/bin/python"
if [ ! -x "$PY" ]; then
  echo "ERROR: expected service venv at $PWD/venv/bin/python" >&2
  echo "Run: python3 -m venv venv && venv/bin/python -m pip install -r requirements.txt" >&2
  exit 2
fi
BBOX="${1:--125,32,-117,38}"
export GFS_RTOFS_FILE_CACHE_DIR="${GFS_RTOFS_FILE_CACHE_DIR:-$PWD/.cache/rtofs}"
mkdir -p "$GFS_RTOFS_FILE_CACHE_DIR"

echo "== disk =="
df -h "$PWD" /tmp || true

echo
echo "== deps using service venv =="
"$PY" - <<'PY'
mods = ["xarray", "netCDF4", "h5netcdf", "h5py", "fsspec", "numpy", "requests"]
for m in mods:
    try:
        __import__(m)
        print("OK", m)
    except Exception as e:
        print("MISSING/ERR", m, e)
PY

echo
echo "== compile =="
"$PY" -m py_compile \
  server/gfs/providers/rtofs_noaa.py \
  server/gfs/rtofs_source.py \
  server/gfs/routes.py \
  server/gfs_service_parts/ocean_bait_frame.py \
  scripts/diag_rtofs.py

echo
echo "== rtofs cli surface =="
"$PY" scripts/diag_rtofs.py --bbox="$BBOX" --surface --max-points 500 \
  | jq '.cache_dir,.disk,.sample.ok,.sample.source,.sample.count,.sample.error,.sample.diagnostics'

echo
echo "== app health =="
curl -sS "http://127.0.0.1:8000/gfs/api/health" | jq '.ok,.source,.last_error' || true

echo
echo "== rtofs endpoint =="
curl -sS "http://127.0.0.1:8000/gfs/api/rtofs/diag?bbox=$BBOX" \
  | jq '.ok,.source,.count,.selected_surface,.diagnostics,.error' || true

echo
echo "== current field bridge =="
curl -sS "http://127.0.0.1:8000/gfs/api/field?field=current&bbox=$BBOX" \
  | jq '.ok,.source,.status,.payload_state,.count,.current_points[0]' || true

echo
echo "== boater/bait buckets =="
curl -sS "http://127.0.0.1:8000/gfs/api/scene-frame?bbox=$BBOX&layers=boater,bait" \
  | jq '.ok,.layers.boater.boats,.layers.boater.oceanPoints.points,.layers.boater.oceanAnalysisPoints.points,.layers.bait.source,.layers.bait.count' || true

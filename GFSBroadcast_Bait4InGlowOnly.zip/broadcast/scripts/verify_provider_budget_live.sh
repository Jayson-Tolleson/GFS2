#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://127.0.0.1:8000}"
BBOX="${LFTR_VERIFY_BBOX:--118.80,32.80,-117.10,34.40}"
python3 - <<'PY' "$BASE" "$BBOX"
import json, sys, urllib.request, urllib.parse
base=sys.argv[1].rstrip('/')
bbox=sys.argv[2]

def get(path):
    url=base+path
    with urllib.request.urlopen(url, timeout=15) as r:
        data=r.read().decode('utf-8','replace')
    try:
        return json.loads(data)
    except Exception as exc:
        raise SystemExit(f"[FAIL] non-json response {path}: {exc}: {data[:200]}")

def fail(msg):
    raise SystemExit('[FAIL] '+msg)

def pass_(msg):
    print('[PASS]', msg)

scene=get('/gfs/api/scene-frame?bbox='+urllib.parse.quote(bbox)+'&layers=boater,bait,shark-intel')
pt=((scene.get('provider_tiles') or {}).get('job_count'))
if pt not in (0, None):
    fail(f'scene-frame default provider job_count should be 0, got {pt}')
pass_('scene-frame default provider jobs are disabled')

blocked=get('/gfs/api/clouds?bbox='+urllib.parse.quote(bbox))
if blocked.get('schema')!='lftr_provider_debug_blocked_v1':
    fail('/gfs/api/clouds should be blocked without ?manual=1')
pass_('legacy provider/debug endpoint is blocked by default')

field=get('/gfs/api/field?field=current&bbox='+urllib.parse.quote(bbox))
diag=field.get('diagnostics') if isinstance(field.get('diagnostics'), dict) else {}
if diag.get('fallback_warm_used') is True or field.get('fallback_warm_used') is True:
    fail('/field?current still woke legacy fallback warmer')
pass_('/field?current is bridge/cache read-only')

ledger=get('/gfs/api/provider-ledger?limit=20')
if ledger.get('schema')!='lftr_provider_ledger_v1':
    fail('provider ledger route did not return expected schema')
pass_('provider ledger route responds')

refresh=get('/gfs/api/cache/refresh?bbox='+urllib.parse.quote(bbox)+'&visible_bbox='+urllib.parse.quote(bbox)+'&layers=boater,bait,shark-intel&reason=verify_provider_budget')
jobs=refresh.get('jobs') or {}
if jobs.get('bait',{}).get('ttl_policy')!='ocean_bundle_dependency':
    fail('bait should depend on boater RTOFS bundle when refreshed together')
if jobs.get('shark-intel',{}).get('ttl_policy')!='ocean_bundle_dependency':
    fail('shark-intel should depend on boater RTOFS bundle when refreshed together')
pass_('ocean refresh coalesces bait/shark onto boater bundle')
print('[OK] provider budget live verification completed')
PY

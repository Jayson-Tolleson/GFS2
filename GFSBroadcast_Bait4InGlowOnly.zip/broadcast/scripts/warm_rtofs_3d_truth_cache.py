#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from server.gfs.rtofs_3d_truth import build_rtofs_3d_truth_cache


def main() -> int:
    ap = argparse.ArgumentParser(description="Warm the LFTR native RTOFS 3D trilinear OceanTruth cache")
    ap.add_argument("--bbox", required=True, help="west,south,east,north")
    ap.add_argument("--candidate-limit", type=int, default=8)
    ap.add_argument("--max-xy", type=int, default=None)
    ap.add_argument("--max-depth-m", type=float, default=None)
    ap.add_argument("--max-depth-levels", type=int, default=None)
    ap.add_argument("--lock", default="")
    args = ap.parse_args()
    lock = Path(args.lock) if args.lock else None
    try:
        payload = build_rtofs_3d_truth_cache(
            args.bbox,
            candidate_limit=args.candidate_limit,
            max_xy=args.max_xy,
            max_depth_m=args.max_depth_m,
            max_depth_levels=args.max_depth_levels,
        )
        print(json.dumps(payload, indent=2, default=str))
        return 0 if payload.get("ok") else 2
    finally:
        if lock:
            try:
                lock.unlink(missing_ok=True)
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENV_PYTHON = ROOT / "venv" / "bin" / "python"
if VENV_PYTHON.exists() and Path(sys.executable).resolve() != VENV_PYTHON.resolve():
    os.execv(str(VENV_PYTHON), [str(VENV_PYTHON), str(Path(__file__).resolve()), *sys.argv[1:]])
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    parser = argparse.ArgumentParser(description="Warm local RTOFS surface current/SST sample cache for LFTR.")
    parser.add_argument("--bbox", required=True, help="west,south,east,north. Use --bbox=-125,32,-117,38 when west is negative.")
    parser.add_argument("--step", type=int, default=int(os.getenv("GFS_RTOFS_WARM_STEP", "1") or "1"))
    parser.add_argument("--max-points", type=int, default=int(os.getenv("GFS_RTOFS_WARM_MAX_POINTS", "3000") or "3000"))
    parser.add_argument("--candidate-limit", type=int, default=int(os.getenv("GFS_RTOFS_WARM_CANDIDATE_LIMIT", "8") or "8"))
    parser.add_argument("--lock", default=None, help="Optional self-clearing warm lock path created by the HTTP wake bridge.")
    args = parser.parse_args()

    from server.gfs.rtofs_source import warm_rtofs_surface_cache

    result = {}
    try:
        result = warm_rtofs_surface_cache(
            args.bbox,
            step=max(1, args.step),
            max_points=max(1, args.max_points),
            candidate_limit=max(1, args.candidate_limit),
        )
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0 if result.get("ok") else 2
    finally:
        if args.lock:
            try:
                Path(args.lock).unlink(missing_ok=True)
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())

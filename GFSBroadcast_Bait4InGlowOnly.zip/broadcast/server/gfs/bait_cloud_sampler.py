from __future__ import annotations

"""Continuous bait field point-cloud sampler.

The returned particles are render samples from B(lat, lon, depth), not raw data
nodes and not a visible grid.  The input samples are finite extraction anchors
from the scalar field; this module expands them into an organic viewport cloud
while preserving the 80% top-field threshold and harbor-safe water policy.
"""

import math
import random
from typing import Any

FT_PER_M = 3.280839895
M_PER_FT = 0.3048


def _finite(value: Any, default: float | None = None) -> float | None:
    try:
        f = float(value)
        return f if math.isfinite(f) else default
    except Exception:
        return default


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _clamp01(value: float) -> float:
    return _clamp(float(value), 0.0, 1.0)


def _norm_lon(lon: Any) -> float:
    n = _finite(lon, 0.0) or 0.0
    return ((float(n) + 180.0) % 360.0) - 180.0


def _meters_to_lat(m: float) -> float:
    return float(m) / 111320.0


def _meters_to_lon(m: float, lat: float) -> float:
    return float(m) / max(1e-6, 111320.0 * math.cos(math.radians(float(lat))))


def _offset_lat_lon(lat: float, lon: float, east_m: float, north_m: float) -> tuple[float, float]:
    return (float(lat) + _meters_to_lat(north_m), _norm_lon(float(lon) + _meters_to_lon(east_m, lat)))


def _heading(sample: dict[str, Any]) -> float:
    explicit = _finite(sample.get("direction_deg", sample.get("heading", sample.get("drift_heading_deg"))), None)
    if explicit is not None:
        return explicit % 360.0
    u = _finite(sample.get("u_ms", sample.get("u", sample.get("current_u"))), 0.0) or 0.0
    v = _finite(sample.get("v_ms", sample.get("v", sample.get("current_v"))), 0.0) or 0.0
    if abs(u) > 1e-8 or abs(v) > 1e-8:
        return (math.degrees(math.atan2(u, v)) + 360.0) % 360.0
    return 90.0


def _sample_radius_m(sample: dict[str, Any], *, fallback_m: float = 140.0) -> float:
    bbox = sample.get("bbox") or []
    lat = _finite(sample.get("lat"), 0.0) or 0.0
    if isinstance(bbox, list) and len(bbox) >= 4:
        west, south, east, north = [_finite(x, 0.0) or 0.0 for x in bbox[:4]]
        lon_span = abs(_norm_lon(east) - _norm_lon(west))
        if lon_span > 180:
            lon_span = 360 - lon_span
        width_m = lon_span * 111320.0 * max(0.18, math.cos(math.radians(lat)))
        height_m = abs(north - south) * 111320.0
        p = _clamp01(_finite(sample.get("probability"), 0.80) or 0.80)
        return _clamp(max(width_m, height_m) * (0.10 + 0.28 * p), 25.0, 900.0)
    return fallback_m


def _alpha(probability: float, threshold: float) -> float:
    # A visible but gentle threshold: the point-cloud appears only in the top
    # 20%, then brightens strongly into the core.
    t = _clamp01((probability - threshold) / max(0.001, 1.0 - threshold))
    t = t * t * (3.0 - 2.0 * t)
    return _clamp(0.16 + 0.78 * t, 0.0, 0.96)


def _particle_count(probability: float, threshold: float, sample: dict[str, Any]) -> int:
    t = _clamp01((probability - threshold) / max(0.001, 1.0 - threshold))
    stack = math.sqrt(max(1.0, _finite(sample.get("field_stack_count"), 1.0) or 1.0))
    return max(1, min(7, int(round(1 + 5.0 * t * min(stack, 2.8)))))


def sample_visible_bait_particles(
    field_samples: list[dict[str, Any]],
    *,
    threshold: float = 0.80,
    max_particles: int = 12000,
) -> list[dict[str, Any]]:
    threshold = _clamp01(threshold)
    max_particles = max(1, int(max_particles or 12000))
    candidates: list[dict[str, Any]] = []
    for sample in field_samples or []:
        p = _clamp01(_finite(sample.get("probability"), (_finite(sample.get("probability_u8"), 0) or 0) / 255.0) or 0.0)
        if p < threshold:
            continue
        lat = _finite(sample.get("lat"), None)
        lon = _finite(sample.get("lon"), None)
        depth_m = abs(_finite(sample.get("depth_m", sample.get("bait_depth_m")), 0.0) or 0.0)
        bottom_m = _finite(sample.get("seafloor_depth_m", sample.get("bottom_depth_m")), None)
        if lat is None or lon is None or depth_m < 0.25:
            continue
        if bottom_m is not None and bottom_m > 0 and depth_m >= bottom_m - 0.2:
            continue
        radius_m = _sample_radius_m(sample)
        heading = _heading(sample)
        theta = math.radians(heading)
        sin_h = math.sin(theta)
        cos_h = math.cos(theta)
        seed = f"{sample.get('id', '')}:{lat:.5f}:{_norm_lon(lon):.5f}:{depth_m:.2f}:{p:.3f}"
        rnd = random.Random(seed)
        count = _particle_count(p, threshold, sample)
        for i in range(count):
            # Stratified random cloud sample in a current-oriented ellipse.  This
            # keeps the product organic and avoids visible checkerboard/grid rows.
            r = math.sqrt(rnd.random()) * radius_m
            a = rnd.random() * math.tau
            along = math.cos(a) * r * (1.25 + p * 0.95)
            across = math.sin(a) * r * (0.35 + p * 0.38)
            east_m = sin_h * along + cos_h * across
            north_m = cos_h * along - sin_h * across
            plat, plon = _offset_lat_lon(float(lat), float(lon), east_m, north_m)
            vertical_jitter_m = (rnd.random() - 0.5) * 4.2 * (0.45 + p)
            d = max(0.25, depth_m + vertical_jitter_m)
            if bottom_m is not None and bottom_m > 0:
                d = min(d, max(0.25, bottom_m - 0.25))
            alpha = _alpha(p, threshold)
            t = _clamp01((p - threshold) / max(0.001, 1.0 - threshold))
            candidates.append({
                "id": f"bait-field-cloud:{sample.get('id', 's')}:{i}",
                "lat": round(plat, 6),
                "lon": round(plon, 6),
                "depth_m": round(d, 3),
                "depth_ft": round(d * FT_PER_M, 2),
                "altitude_m": round(-abs(d), 3),
                "probability": round(p, 4),
                "probability_u8": int(round(p * 255)),
                "particle_alpha": round(alpha, 3),
                "glow_scale": round(0.30 + 0.70 * t, 3),
                "size_scale": round(0.85 + 0.95 * t, 3),
                "particle_radius_m": round(radius_m, 1),
                "body_length_in": 4.0,
                "body_shape": "ellipse_bait_sprite",
                "sprite_style": "cedar_plug_eye_silver_top_white_bottom_black_outline",
                "direction_deg": round(heading, 2),
                "temperature_c": sample.get("temperature_c"),
                "salinity": sample.get("salinity"),
                "current_speed_kt": sample.get("current_speed_kt"),
                "chlorophyll_mg_m3": sample.get("chlorophyll_mg_m3"),
                "sample_method": "continuous_scalar_field_importance_sample_ge_80pct",
                "source_sample_id": sample.get("id"),
                "selection_weight": round(p + rnd.random() * 0.035, 5),
            })
    if len(candidates) <= max_particles:
        return candidates

    candidates.sort(key=lambda x: float(x.get("selection_weight") or x.get("probability") or 0.0), reverse=True)
    hot_keep = max(150, int(max_particles * 0.34))
    selected = candidates[:hot_keep]
    rest = candidates[hot_keep:]
    if not rest:
        return selected[:max_particles]

    lats = [float(x["lat"]) for x in rest]
    lons = [_norm_lon(x["lon"]) for x in rest]
    deps = [float(x["depth_m"]) for x in rest]
    south, north = min(lats), max(lats)
    west, east = min(lons), max(lons)
    dep_max = max(1.0, max(deps))
    side = max(10, min(44, int(math.sqrt(max_particles) / 2)))
    buckets: dict[tuple[int, int, int], list[dict[str, Any]]] = {}
    for item in rest:
        lat = float(item["lat"]); lon = _norm_lon(item["lon"]); dep = float(item["depth_m"])
        key = (
            int(_clamp((lat - south) / max(0.0001, north - south), 0.0, 0.9999) * side),
            int(_clamp((lon - west) / max(0.0001, east - west), 0.0, 0.9999) * side),
            int(_clamp(dep / dep_max, 0.0, 0.9999) * 12),
        )
        buckets.setdefault(key, []).append(item)
    for stack in buckets.values():
        stack.sort(key=lambda x: float(x.get("selection_weight") or x.get("probability") or 0.0), reverse=True)
    keys = sorted(buckets.keys())
    while keys and len(selected) < max_particles:
        for key in list(keys):
            stack = buckets.get(key) or []
            if stack:
                selected.append(stack.pop(0))
            if not stack:
                buckets.pop(key, None)
                if key in keys:
                    keys.remove(key)
            if len(selected) >= max_particles:
                break
    return selected[:max_particles]

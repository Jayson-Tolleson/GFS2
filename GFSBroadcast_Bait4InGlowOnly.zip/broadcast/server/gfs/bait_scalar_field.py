from __future__ import annotations

"""Viewport scalar bait-field endpoint contract.

This module is intentionally a thin contract layer around the existing OceanTruth
bait probability volume.  It presents the new product as a harbor-aware continuous
B(lat, lon, depth) point-cloud extraction: only the top 20% (>=0.80 by default)
is returned for rendering.
"""

from pathlib import Path
from typing import Any

from server.gfs.bait_volume import bait_3d_volume_payload
from server.gfs.bait_cloud_sampler import sample_visible_bait_particles

DEFAULT_DEPTHS_M = "0.3048,1.524,3.048,4.572,6.096,7.62,9.144,10.668,12.192,15.24,18.288,21.336,24.384,27.432,30.48,36.576,45.72,60.96,76.2,91.44,121.92,152.4,200"
FIELD_EXTRACTION_FLOOR = 0.05



def _samples_from_full_field_payload(payload: dict[str, Any], *, min_probability: float = 0.02, max_points: int = 9000) -> list[dict[str, Any]]:
    """Recover extraction anchors from the full z-by-cell scalar field.

    The visible cloud still uses the 0.80 display threshold after calibration;
    this recovery only prevents an empty cloud when the first coarse extraction
    floor is too high for the current science score or while chlorophyll/RTOFS is
    still warming.
    """
    cells = payload.get("cells") or []
    depths = payload.get("depths_m") or []
    field = (payload.get("fields") or {}).get("bait_probability_u8") or []
    if not isinstance(cells, list) or not isinstance(depths, list) or not isinstance(field, list):
        return []
    out: list[dict[str, Any]] = []
    for zi, depth in enumerate(depths):
        if zi >= len(field) or not isinstance(field[zi], list):
            continue
        try:
            d = abs(float(depth))
        except Exception:
            continue
        row = field[zi]
        for ci, cell in enumerate(cells):
            if ci >= len(row) or not isinstance(cell, dict):
                continue
            try:
                u8 = int(row[ci] or 0)
            except Exception:
                u8 = 0
            p = max(0.0, min(1.0, u8 / 255.0))
            if p < min_probability:
                continue
            bottom = cell.get("bottom_depth_m") or cell.get("seafloor_depth_m") or 0
            try:
                bottom_f = float(bottom)
            except Exception:
                bottom_f = 0.0
            if bottom_f <= 1.0 or d >= bottom_f - 0.5:
                continue
            out.append({
                "id": f"bait-field-recovery:{ci}:{zi}",
                "cell_index": ci,
                "depth_index": zi,
                "lat": cell.get("lat"),
                "lon": cell.get("lon"),
                "bbox": cell.get("bbox"),
                "tile_id": cell.get("tile_id"),
                "depth_m": round(d, 3),
                "altitude_m": round(-abs(d), 3),
                "seafloor_depth_m": round(bottom_f, 2),
                "probability": round(p, 4),
                "probability_u8": u8,
                "temperature_c": cell.get("sst_c"),
                "salinity": cell.get("salinity"),
                "current_speed_kt": cell.get("current_speed_kt"),
                "direction_deg": cell.get("direction_deg"),
                "u_ms": cell.get("u_ms"),
                "v_ms": cell.get("v_ms"),
                "chlorophyll_mg_m3": cell.get("chlorophyll_mg_m3"),
                "sample_method": "bait_probability_scalar_field_full_field_recovery_sample",
            })
    out.sort(key=lambda x: float(x.get("probability") or 0.0), reverse=True)
    # Keep broad coverage after the strongest third.
    if len(out) <= max_points:
        return out
    hot = out[:max(250, int(max_points * 0.30))]
    rest = out[len(hot):]
    spread = []
    seen = set()
    for item in rest:
        key = (round(float(item.get("lat") or 0.0), 2), round(float(item.get("lon") or 0.0), 2), int(float(item.get("depth_m") or 0.0) // 8))
        if key in seen:
            continue
        seen.add(key)
        spread.append(item)
        if len(hot) + len(spread) >= max_points:
            break
    return (hot + spread)[:max_points]

def _calibrate_top_probability_band(samples: list[dict[str, Any]], *, threshold: float) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Map the viewport's hottest scalar-field band to the visible 0.80..1.0 range.

    The raw heuristic score is preserved as raw_probability.  Display probability
    is calibrated so the top field mass can render as the requested top-20% bait
    cloud even while the science score is still being tuned.
    """
    vals = sorted(float(s.get("probability") or 0.0) for s in samples if s.get("probability") is not None and float(s.get("probability") or 0.0) > 0.001)
    if not vals:
        return [], {"mode": "empty", "raw_cutoff": None, "raw_max": None}
    idx = max(0, min(len(vals) - 1, int(len(vals) * 0.80)))
    raw_cutoff = vals[idx]
    raw_max = max(vals[-1], raw_cutoff + 1e-6)
    out: list[dict[str, Any]] = []
    for s in samples:
        raw = float(s.get("probability") or 0.0)
        if raw < raw_cutoff:
            continue
        t = max(0.0, min(1.0, (raw - raw_cutoff) / max(1e-6, raw_max - raw_cutoff)))
        display = threshold + (1.0 - threshold) * t
        item = dict(s)
        item["raw_probability"] = round(raw, 4)
        item["probability"] = round(display, 4)
        item["probability_u8"] = int(round(display * 255))
        item["sample_method"] = f"{s.get('sample_method') or 'bait_probability_scalar_field'}_viewport_top20_calibrated"
        out.append(item)
    return out, {
        "mode": "viewport_top20_quantile",
        "raw_cutoff": round(raw_cutoff, 4),
        "raw_max": round(raw_max, 4),
        "display_threshold": round(threshold, 3),
        "visible_samples": len(out),
        "candidate_samples": len(samples),
    }


def bait_field_cloud_payload(
    app_root: Path | str | None,
    bbox: Any,
    *,
    threshold: float = 0.80,
    max_particles: int = 12000,
    max_field_points: int = 9000,
    max_cells: int = 2400,
    render_grid: int = 24,
    warm: bool = True,
    depths: Any = None,
) -> dict[str, Any]:
    threshold = max(0.0, min(1.0, float(threshold if threshold is not None else 0.80)))
    max_particles = max(1, int(max_particles or 12000))
    payload = bait_3d_volume_payload(
        app_root,
        bbox,
        depths=depths or DEFAULT_DEPTHS_M,
        render_grid=render_grid,
        limit=96,
        max_cells=max_cells,
        max_clouds=0,
        warm=warm,
        field_threshold=min(threshold, FIELD_EXTRACTION_FLOOR),
        max_field_points=max_field_points,
        render="particle_cloud",
    )
    raw_samples = payload.get("field_samples") or []
    recovery_used = False
    if len(raw_samples) < max(24, min(250, int(max_field_points * 0.04))):
        recovered = _samples_from_full_field_payload(payload, min_probability=0.02, max_points=max_field_points)
        if len(recovered) > len(raw_samples):
            raw_samples = recovered
            recovery_used = True
    samples, calibration = _calibrate_top_probability_band(raw_samples, threshold=threshold)
    if recovery_used:
        calibration = {**calibration, "recovery": "full_field_low_floor_extraction", "extraction_floor": 0.02}
    particles = sample_visible_bait_particles(samples, threshold=threshold, max_particles=max_particles)
    payload.update({
        "schema": "lftr_bait_scalar_field_cloud_v1",
        "source": "rtofs_bathymetry_harbor_aware_continuous_scalar_bait_field_cloud_v1",
        "threshold": round(threshold, 3),
        "visible_probability_min": round(threshold, 3),
        "hidden_probability_policy": "all scalar-field display probability below threshold is hidden; the visible field is calibrated to the viewport's top 20% bait mass while preserving raw_probability on each source sample",
        "probability_calibration": calibration,
        "raw_field_sample_count": len(raw_samples),
        "field_extraction_floor": FIELD_EXTRACTION_FLOOR,
        "field_samples": samples,
        "field_sample_count": len(samples),
        "particles": particles,
        "particle_count": len(particles),
        "max_particles": max_particles,
        "field_samples_are": "finite extraction anchors from B(lat, lon, depth); particles are continuous importance samples, not raw data nodes",
        "cloud_render_contract": {
            "truth": "continuous scalar bait field B(lat, lon, depth_m) -> probability_0_to_1",
            "display": "one underwater viewport point-cloud mass",
            "threshold": round(threshold, 3),
            "below_threshold": "hidden",
            "visible_portion": "top 20 percent of the viewport scalar field when threshold=0.80; raw_probability is retained for tuning",
            "sprite": "4 inch ellipse bait, silver top half, white bottom half, narrow black outline, cedar-plug painted eye, glow by probability",
            "lod": "none; viewport changes naturally request a new cloud",
        },
        "harbor_water_policy": {
            "respected": True,
            "min_water_fraction": 0.08,
            "min_depth_m": 0.20,
            "rule": "accept narrow ocean-connected harbor/coastal water; reject land and ocean_connected=false basins; do not smooth through land barriers",
        },
    })
    return payload

from __future__ import annotations

"""LFTR bait probability volume scaffold.

This endpoint keeps the science product array-native: depth is a dimension, not
an independent set of visual sheets.  Runtime HTTP remains safe: it reads the
existing lightweight RTOFS surface cache and cached ETOPO bathymetry tiles, then
emits a compact 3D probability mask plus cloud-shell summaries.  True RTOFS 3D
NetCDF cube ingestion can later replace the surface-seeded vertical estimates
without changing the frontend contract.
"""

import math
import os
import time
from pathlib import Path
from typing import Any

from server.gfs.bathymetry_tiles import bathymetry_tiles_payload
from server.gfs.rtofs_source import load_cached_rtofs_surface, spawn_rtofs_surface_warmer
from server.gfs.ocean_truth import ocean_truth_payload
from server.gfs.rtofs_3d_truth import compact_rtofs_3d_status, load_cached_rtofs_3d_truth, spawn_rtofs_3d_truth_warmer
from server.gfs.harbor_water_mask import harbor_water_valid, harbor_water_fraction, harbor_water_class

DEFAULT_DEPTHS_M = (0.0, 5.0, 10.0, 20.0, 35.0, 50.0, 75.0, 100.0, 150.0, 200.0)
FT_PER_M = 3.280839895
KT_PER_MS = 1.9438444924406


def _finite(value: Any, default: float | None = None) -> float | None:
    try:
        f = float(value)
        return f if math.isfinite(f) else default
    except Exception:
        return default


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _bbox_dict(bbox: Any) -> dict[str, float]:
    if isinstance(bbox, dict):
        return {
            "west": float(bbox.get("west", bbox.get("minLon", -125))),
            "south": float(bbox.get("south", bbox.get("minLat", 32))),
            "east": float(bbox.get("east", bbox.get("maxLon", -117))),
            "north": float(bbox.get("north", bbox.get("maxLat", 38))),
        }
    if isinstance(bbox, str):
        parts = [float(x.strip()) for x in bbox.split(",") if x.strip()]
        if len(parts) >= 4:
            return {"west": parts[0], "south": parts[1], "east": parts[2], "north": parts[3]}
    if isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
        return {"west": float(bbox[0]), "south": float(bbox[1]), "east": float(bbox[2]), "north": float(bbox[3])}
    return {"west": -125.0, "south": 32.0, "east": -117.0, "north": 38.0}



def _norm_lon(lon: Any) -> float:
    n = _finite(lon, 0.0) or 0.0
    return ((float(n) + 180.0) % 360.0) - 180.0


def _bbox_contains_point(bbox: dict[str, float], lat: float, lon: float, *, pad_deg: float = 0.0) -> bool:
    south = min(float(bbox["south"]), float(bbox["north"])) - pad_deg
    north = max(float(bbox["south"]), float(bbox["north"])) + pad_deg
    if lat < south or lat > north:
        return False
    west = _norm_lon(float(bbox["west"]) - pad_deg)
    east = _norm_lon(float(bbox["east"]) + pad_deg)
    x = _norm_lon(lon)
    if west <= east:
        return west <= x <= east
    return x >= west or x <= east


def _bbox_center(bbox: dict[str, float]) -> tuple[float, float]:
    return ((float(bbox["south"]) + float(bbox["north"])) / 2.0, _norm_lon((float(bbox["west"]) + float(bbox["east"])) / 2.0))


def _lon_span_deg(west: float, east: float) -> float:
    west_n = _norm_lon(west)
    east_n = _norm_lon(east)
    if east_n >= west_n:
        return max(0.001, east_n - west_n)
    return max(0.001, (180.0 - west_n) + (east_n + 180.0))


def _lon_offset_from_west(lon: float, west: float) -> float:
    x = _norm_lon(lon)
    w = _norm_lon(west)
    d = x - w
    if d < 0:
        d += 360.0
    return d


def _lon_abs_delta(a: float, b: float) -> float:
    d = abs(_norm_lon(a) - _norm_lon(b))
    return min(d, 360.0 - d)


def _cell_intersects_bbox(cell: dict[str, Any], bbox: dict[str, float], *, pad_deg: float = 0.0) -> bool:
    cb = cell.get("bbox") or []
    if not (isinstance(cb, list) and len(cb) >= 4):
        return _bbox_contains_point(bbox, float(cell.get("lat") or 0.0), float(cell.get("lon") or 0.0), pad_deg=pad_deg)
    west, south, east, north = [float(x) for x in cb[:4]]
    # Fast center test first, then corner tests so coastal cells touching the viewport survive.
    if _bbox_contains_point(bbox, float(cell.get("lat") or (south+north)/2), float(cell.get("lon") or (west+east)/2), pad_deg=pad_deg):
        return True
    for lat in (south, north):
        for lon in (west, east):
            if _bbox_contains_point(bbox, lat, lon, pad_deg=pad_deg):
                return True
    return False


def _spatially_distributed_cells(cells: list[dict[str, Any]], bbox: dict[str, float], max_cells: int) -> list[dict[str, Any]]:
    if len(cells) <= max_cells:
        return cells
    # Round-robin cells by viewport buckets instead of taking the first tile
    # encountered. This prevents far-west 4-degree tile order from dominating
    # bait math and piling fish in one corner.
    bucket_count = max(4, min(32, int(math.sqrt(max_cells) // 2 or 8)))
    south = min(float(bbox["south"]), float(bbox["north"]))
    north = max(float(bbox["south"]), float(bbox["north"]))
    west = _norm_lon(bbox["west"])
    lon_span = _lon_span_deg(float(bbox["west"]), float(bbox["east"]))
    lat_span = max(0.001, north - south)
    buckets: dict[tuple[int, int], list[dict[str, Any]]] = {}
    for cell in cells:
        lat = float(cell.get("lat") or 0.0)
        lon = _norm_lon(cell.get("lon") or 0.0)
        lon_t = _clamp(_lon_offset_from_west(lon, west) / lon_span, 0.0, 0.9999)
        lat_t = _clamp((lat - south) / lat_span, 0.0, 0.9999)
        key = (int(lat_t * bucket_count), int(lon_t * bucket_count))
        buckets.setdefault(key, []).append(cell)
    out: list[dict[str, Any]] = []
    ordered_keys = sorted(buckets.keys(), key=lambda k: (k[0], k[1]))
    cursor = 0
    while len(out) < max_cells and ordered_keys:
        key = ordered_keys[cursor % len(ordered_keys)]
        stack = buckets.get(key) or []
        if stack:
            # Use deepest/most oceanic cells first within bucket, but only one at a time.
            if len(stack) > 1 and not stack[0].get("__sorted"):
                stack.sort(key=lambda c: (float(c.get("water_fraction") or 0), float(c.get("bottom_depth_m") or 0)), reverse=True)
                stack[0]["__sorted"] = True
            out.append(stack.pop(0))
        if not stack:
            buckets.pop(key, None)
            ordered_keys = [k for k in ordered_keys if k in buckets]
            cursor = 0
        else:
            cursor += 1
    for cell in out:
        cell.pop("__sorted", None)
    return out

def _parse_depths(depths: Any = None, max_levels: int = 16) -> list[float]:
    if isinstance(depths, str) and depths.strip():
        raw = depths.replace(";", ",").split(",")
    elif isinstance(depths, (list, tuple)):
        raw = list(depths)
    else:
        raw = list(DEFAULT_DEPTHS_M)
    out: list[float] = []
    for v in raw:
        d = abs(_finite(v, float("nan")) or float("nan"))
        if not math.isfinite(d):
            continue
        d = round(_clamp(d, 0.0, 3000.0), 3)
        if d not in out:
            out.append(d)
        if len(out) >= max(1, int(max_levels or 16)):
            break
    return out or list(DEFAULT_DEPTHS_M)


def _point_lat_lon(p: dict[str, Any]) -> tuple[float | None, float | None]:
    lat = _finite(p.get("lat", p.get("latitude")))
    lon = _finite(p.get("lon", p.get("lng", p.get("longitude"))))
    return lat, lon


def _cell_center_from_bbox(b: dict[str, float]) -> tuple[float, float]:
    return ((float(b["south"]) + float(b["north"])) / 2.0, (float(b["west"]) + float(b["east"])) / 2.0)



def _is_known_inland_bait_exclusion(lat: float, lon: float) -> bool:
    try:
        lat = float(lat); lon = float(lon)
    except Exception:
        return False
    boxes = (
        (-117.65, 35.35, -116.15, 37.15),  # Death Valley
        (-116.45, 32.55, -115.15, 34.15),  # Salton Sea / Imperial basin
        (-113.25, 40.35, -111.65, 41.85),  # Great Salt Lake basin guard
    )
    return any(w <= lon <= e and s <= lat <= n for w, s, e, n in boxes)

def _tile_water_cells(tile: dict[str, Any], *, min_water_fraction: float = 0.08, min_depth_m: float = 0.20) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for cell in tile.get("water_cells") or []:
        bbox = cell.get("bbox")
        if not (isinstance(bbox, list) and len(bbox) >= 4):
            continue
        depth = _finite(cell.get("depth_m"))
        wf = harbor_water_fraction(cell)
        # Harbor water is deliberately accepted at low water_fraction.  The
        # bathymetry cache still blocks land/renderable=false and inland
        # ocean_connected=false basins, but narrow bays, marinas, channels, and
        # shallow coastal water must survive bait sampling.
        if depth is None or not harbor_water_valid(cell, min_fraction=min_water_fraction, min_depth_m=min_depth_m):
            continue
        west, south, east, north = [float(x) for x in bbox[:4]]
        lat, lon = _cell_center_from_bbox({"west": west, "south": south, "east": east, "north": north})
        if _is_known_inland_bait_exclusion(lat, lon):
            continue
        out.append({
            "tile_id": tile.get("tile_id"),
            "r": int(cell.get("r", cell.get("gy", 0)) or 0),
            "c": int(cell.get("c", cell.get("gx", 0)) or 0),
            "bbox": [west, south, east, north],
            "lat": round(lat, 6),
            "lon": round(lon, 6),
            "bottom_depth_m": round(float(depth), 2),
            "water_fraction": round(float(wf), 3),
            "water_class": harbor_water_class({**cell, "depth_m": depth, "water_fraction": wf}),
            "harbor_water_respected": True,
        })
    return out


def _nearest_surface_point(lat: float, lon: float, points: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not points:
        return None
    best: tuple[float, dict[str, Any]] | None = None
    mean_lat = math.radians(lat)
    for p in points:
        plat, plon = _point_lat_lon(p)
        if plat is None or plon is None:
            continue
        dx = (float(plon) - lon) * max(0.25, math.cos(mean_lat))
        dy = float(plat) - lat
        d2 = dx * dx + dy * dy
        if best is None or d2 < best[0]:
            best = (d2, p)
    return best[1] if best else None


def _gaussian(x: float, ideal: float, sigma: float) -> float:
    if sigma <= 0:
        return 0.0
    return math.exp(-0.5 * ((x - ideal) / sigma) ** 2)


def _current_score(speed_kt: float) -> float:
    # Bait tends to prefer moderate movement/edges: not dead still, not violent.
    if speed_kt <= 0:
        return 0.18
    rise = _clamp(speed_kt / 0.7, 0.0, 1.0)
    fall = _clamp(1.0 - max(0.0, speed_kt - 1.8) / 2.4, 0.0, 1.0)
    return _clamp(0.18 + 0.82 * min(rise, fall), 0.0, 1.0)


def _depth_score(depth_m: float, bottom_depth_m: float, sst_c: float | None = None) -> float:
    if bottom_depth_m <= 3 or depth_m >= bottom_depth_m - 2:
        return 0.0
    # First-pass target is a water-column comfort zone, not a rendered sheet.
    if bottom_depth_m < 80:
        ideal = min(24.0, max(5.0, bottom_depth_m * 0.38))
        sigma = max(8.0, bottom_depth_m * 0.28)
    elif bottom_depth_m < 500:
        ideal = 32.0
        sigma = 24.0
    else:
        ideal = 45.0
        sigma = 42.0
    if sst_c is not None and sst_c > 19.5:
        ideal += 10.0
    elif sst_c is not None and sst_c < 13.0:
        ideal = max(5.0, ideal - 8.0)
    near_surface_penalty = 0.78 if depth_m < 2.0 else 1.0
    return _clamp(_gaussian(depth_m, ideal, sigma) * near_surface_penalty, 0.0, 1.0)


def _shelf_structure_score(bottom_depth_m: float) -> float:
    # Shallow shelf and slope receive a modest bonus; deep abyss is not zero.
    if bottom_depth_m < 20:
        return 0.40
    if bottom_depth_m < 120:
        return 0.86
    if bottom_depth_m < 800:
        return 0.72
    if bottom_depth_m < 2200:
        return 0.52
    return 0.36


def _temp_score(sst_c: float | None) -> float:
    if sst_c is None:
        return 0.50
    return _clamp(_gaussian(sst_c, 16.5, 4.4), 0.0, 1.0)


def _salinity_score(salinity: float | None) -> float:
    if salinity is None:
        return 0.55
    return _clamp(_gaussian(salinity, 33.6, 1.3), 0.0, 1.0)


def _chlorophyll_score(chlorophyll_mg_m3: float | None) -> float:
    # Chlorophyll is a late-injected booster. Missing chlorophyll must never
    # suppress immediate bait; once cached it lifts productive bio-water and
    # stays useful for the 8 hour ocean-truth TTL.
    if chlorophyll_mg_m3 is None:
        return 0.0
    ch = max(0.0, float(chlorophyll_mg_m3))
    # Productive coastal water without letting one extreme green cell dominate.
    return _clamp(_gaussian(math.log10(ch + 0.025), math.log10(0.55 + 0.025), 0.62), 0.0, 1.0)


def _u8(v: float) -> int:
    return int(round(_clamp(v, 0.0, 1.0) * 255.0))


def _surface_features(p: dict[str, Any] | None) -> dict[str, Any]:
    p = p or {}
    sst_c = _finite(p.get("sst_c", p.get("water_temp_c", p.get("sst"))))
    if sst_c is not None and sst_c > 150:
        sst_c -= 273.15
    sst_f = _finite(p.get("sst_f", p.get("water_temp_f")))
    if sst_f is None and sst_c is not None:
        sst_f = sst_c * 9.0 / 5.0 + 32.0
    u = _finite(p.get("u_ms", p.get("u", p.get("current_u"))), 0.0) or 0.0
    v = _finite(p.get("v_ms", p.get("v", p.get("current_v"))), 0.0) or 0.0
    speed_kt = _finite(p.get("current_speed_kt", p.get("speed_kt", p.get("speedKt"))))
    if speed_kt is None:
        speed_kt = math.hypot(u, v) * KT_PER_MS
    heading = _finite(p.get("direction_deg", p.get("current_dir_deg", p.get("heading", p.get("dirDeg")))))
    if heading is None:
        heading = (math.degrees(math.atan2(u, v)) + 360.0) % 360.0
    salinity = _finite(p.get("salinity", p.get("sss")))
    return {
        "sst_c": round(sst_c, 3) if sst_c is not None else None,
        "sst_f": round(sst_f, 2) if sst_f is not None else None,
        "salinity": round(salinity, 4) if salinity is not None else None,
        "current_speed_kt": round(float(speed_kt or 0.0), 4),
        "direction_deg": round(float(heading or 0.0), 2),
        "u_ms": round(float(u), 6),
        "v_ms": round(float(v), 6),
        "source_point": p,
    }


def _probability_for(depth_m: float, bottom_depth_m: float, feat: dict[str, Any], water_fraction: float) -> float:
    ds = _depth_score(depth_m, bottom_depth_m, feat.get("sst_c"))
    if ds <= 0:
        return 0.0
    base = (
        0.34 * ds
        + 0.22 * _temp_score(feat.get("sst_c"))
        + 0.16 * _current_score(float(feat.get("current_speed_kt") or 0.0))
        + 0.10 * _salinity_score(feat.get("salinity"))
        + 0.12 * _shelf_structure_score(bottom_depth_m)
        + 0.06 * _clamp(water_fraction, 0.0, 1.0)
    )
    chl = feat.get("chlorophyll_mg_m3")
    if chl is not None:
        # Late chlorophyll only increases or nudges probability; it never blanks
        # or causes the scene to redraw from zero while ERDDAP is loading.
        base = _clamp(base + 0.12 * _chlorophyll_score(chl), 0.0, 1.0)
    return _clamp(base, 0.0, 1.0)


def _select_clouds(
    cells: list[dict[str, Any]],
    depths_m: list[float],
    fields: list[list[int]],
    *,
    max_clouds: int = 36,
    bbox: dict[str, float] | None = None,
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    if not cells or not fields:
        return candidates
    z_count = len(depths_m)
    for i, cell in enumerate(cells):
        # Extra ocean guard for old cache records and edge cases.
        if cell.get("renderable") is False or cell.get("ocean_connected") is False:
            continue
        if bbox and not _bbox_contains_point(bbox, float(cell.get("lat") or 0.0), float(cell.get("lon") or 0.0), pad_deg=0.01):
            continue
        values = [fields[z][i] if i < len(fields[z]) else 0 for z in range(z_count)]
        best_u8 = max(values) if values else 0
        if best_u8 < 108:
            continue
        best_z = values.index(best_u8)
        lo = best_z
        hi = best_z
        while lo > 0 and values[lo - 1] >= 88:
            lo -= 1
        while hi + 1 < z_count and values[hi + 1] >= 88:
            hi += 1
        chosen_depth = _finite(cell.get("bait_depth_m"))
        if chosen_depth is not None and chosen_depth > 0:
            # Native 3-D truth has already chosen an underwater bait sample depth.
            # Keep the cloud shell around that exact sampled depth instead of treating
            # depths_m as visual layers.
            best_depth = float(chosen_depth)
            top = max(1.0, best_depth - max(4.0, best_depth * 0.28))
            bottom = min(float(cell.get("bottom_depth_m", best_depth + 12.0)) - 1.0, best_depth + max(5.0, best_depth * 0.42))
        else:
            best_depth = float(depths_m[best_z])
            top = float(depths_m[lo])
            bottom = float(depths_m[hi])
        if bottom <= top:
            bottom = min(float(cell.get("bottom_depth_m", top + 10.0)) - 1.0, top + 12.0)
        p = best_u8 / 255.0
        bbox_cell = cell.get("bbox") or []
        lon_span = abs(float(bbox_cell[2]) - float(bbox_cell[0])) if len(bbox_cell) >= 4 else 0.035
        lat_span = abs(float(bbox_cell[3]) - float(bbox_cell[1])) if len(bbox_cell) >= 4 else 0.035
        # Prefer high probability but add light structure diversity so deep open
        # ocean does not always outrank every coastal/shelf body.
        depth_bonus = _shelf_structure_score(float(cell.get("bottom_depth_m") or 0.0)) * 0.10
        wf_bonus = _clamp(float(cell.get("water_fraction") or 0.0), 0.0, 1.0) * 0.04
        score = _clamp(p + depth_bonus + wf_bonus, 0.0, 1.0)
        candidates.append({
            "id": f"bait-volume-cloud-{len(candidates)+1:03d}",
            "lat": cell.get("lat"),
            "lon": cell.get("lon"),
            "center": {"lat": cell.get("lat"), "lon": cell.get("lon"), "depth_m": round(float(best_depth), 2)},
            "top_depth_m": round(top, 2),
            "bottom_depth_m": round(max(top + 2.0, bottom), 2),
            "bottom_limit_m": cell.get("bottom_depth_m"),
            "probability": round(p, 3),
            "selection_score": round(score, 3),
            "probability_u8": int(best_u8),
            "particle_density": round(_clamp((p - 0.30) / 0.70, 0.10, 1.0), 3),
            "particle_count_hint": int(round(100 + 520 * p)),
            "radius_lat_deg": round(max(0.005, lat_span * (0.38 + p * 0.24)), 6),
            "radius_lon_deg": round(max(0.005, lon_span * (0.38 + p * 0.24)), 6),
            "drift_heading_deg": cell.get("direction_deg"),
            "drift_speed_kt": cell.get("current_speed_kt"),
            "sst_c": cell.get("sst_c"),
            "sst_f": cell.get("sst_f"),
            "salinity": cell.get("salinity"),
            "chlorophyll_mg_m3": cell.get("chlorophyll_mg_m3"),
            "chlorophyll_status": cell.get("chlorophyll_status"),
            "sample_method": cell.get("sample_method"),
            "surface_sst_c": cell.get("surface_sst_c"),
            "surface_sst_f": cell.get("surface_sst_f"),
            "bait_depth_m": round(float(best_depth), 2),
            "bait_altitude_m": round(-abs(float(best_depth)), 2),
            "bait_sample": cell.get("bait_sample"),
            "source_cell_index": i,
        })

    if not candidates:
        return []

    # Bucket-first selection: rank inside each viewport bucket, then take one
    # strong candidate from each bucket in rounds.  This stops known bait grounds
    # or one high-score corner from swallowing the whole render budget.
    if bbox:
        south = min(float(bbox["south"]), float(bbox["north"]))
        north = max(float(bbox["south"]), float(bbox["north"]))
        west = _norm_lon(float(bbox["west"]))
        lat_span = max(0.001, north - south)
        lon_span = _lon_span_deg(float(bbox["west"]), float(bbox["east"]))
    else:
        lats = [float(c.get("lat") or 0.0) for c in candidates]
        lons = [_norm_lon(float(c.get("lon") or 0.0)) for c in candidates]
        south, north = min(lats), max(lats)
        west = min(lons)
        lat_span = max(0.001, north - south)
        lon_span = max(0.001, max(lons) - west)

    bucket_count = max(4, min(10, int(math.sqrt(max_clouds * 1.6)) or 5))
    buckets: dict[tuple[int, int], list[dict[str, Any]]] = {}
    for cand in candidates:
        lat = float(cand.get("lat") or 0.0)
        lon = _norm_lon(float(cand.get("lon") or 0.0))
        lat_t = _clamp((lat - south) / lat_span, 0.0, 0.9999)
        lon_t = _clamp(_lon_offset_from_west(lon, west) / lon_span, 0.0, 0.9999)
        key = (int(lat_t * bucket_count), int(lon_t * bucket_count))
        buckets.setdefault(key, []).append(cand)
    for stack in buckets.values():
        stack.sort(key=lambda x: float(x.get("selection_score") or x.get("probability") or 0.0), reverse=True)

    selected: list[dict[str, Any]] = []
    min_sep2 = float(os.getenv("GFS_BAIT_3D_CLOUD_MIN_SEP_DEG2", "0.020") or "0.020")
    ordered_keys = sorted(buckets.keys(), key=lambda k: (k[0], k[1]))
    def far_enough(cand: dict[str, Any], relaxed: bool = False) -> bool:
        lat = float(cand.get("lat") or 0.0)
        lon = _norm_lon(float(cand.get("lon") or 0.0))
        sep2 = min_sep2 * (0.45 if relaxed else 1.0)
        return not any(((lat - float(s.get("lat") or 0.0)) ** 2 + (_lon_abs_delta(lon, float(s.get("lon") or 0.0)) * max(0.35, math.cos(math.radians(lat)))) ** 2) < sep2 for s in selected)

    made_progress = True
    while len(selected) < max_clouds and ordered_keys and made_progress:
        made_progress = False
        for key in list(ordered_keys):
            stack = buckets.get(key) or []
            while stack:
                cand = stack.pop(0)
                if far_enough(cand, relaxed=False) or len(selected) < max(4, max_clouds // 3):
                    selected.append(cand)
                    made_progress = True
                    break
            if not stack:
                buckets.pop(key, None)
                if key in ordered_keys:
                    ordered_keys.remove(key)
            if len(selected) >= max_clouds:
                break

    # Relax only after every bucket got a chance.
    if len(selected) < max_clouds:
        remaining = sorted((c for stack in buckets.values() for c in stack), key=lambda x: float(x.get("selection_score") or x.get("probability") or 0.0), reverse=True)
        for cand in remaining:
            if far_enough(cand, relaxed=True):
                selected.append(cand)
            if len(selected) >= max_clouds:
                break

    for idx, cloud in enumerate(selected, start=1):
        cloud["id"] = f"bait-volume-cloud-{idx:03d}"
    return selected


def _field_samples_from_cells(
    cells: list[dict[str, Any]],
    depths_m: list[float],
    fields: list[list[int]],
    *,
    threshold: float = 0.50,
    max_points: int = 7200,
) -> list[dict[str, Any]]:
    """Flatten bait_probability(z, cell) into renderable scalar-field anchors.

    These are not bait objects and not visual depth layers.  They are compact
    samples of the continuous OceanTruth-driven bait probability scalar field for
    frontend rendering.  Only values above threshold are returned so the globe is
    not painted everywhere.
    """
    threshold = _clamp(float(threshold), 0.0, 1.0)
    max_points = max(1, int(max_points or 7200))
    out: list[dict[str, Any]] = []
    if not cells or not fields or not depths_m:
        return out
    for zi, depth_m in enumerate(depths_m):
        if zi >= len(fields):
            continue
        row = fields[zi] or []
        for ci, cell in enumerate(cells):
            if ci >= len(row):
                continue
            u8 = int(row[ci] or 0)
            p = _clamp(u8 / 255.0, 0.0, 1.0)
            if p < threshold:
                continue
            bottom = _finite(cell.get("bottom_depth_m"), 0.0) or 0.0
            d = float(depth_m)
            if bottom <= 1.0 or d >= bottom - 1.0:
                continue
            out.append({
                "id": f"bait-field:{ci}:{zi}",
                "cell_index": ci,
                "depth_index": zi,
                "lat": cell.get("lat"),
                "lon": cell.get("lon"),
                "bbox": cell.get("bbox"),
                "tile_id": cell.get("tile_id"),
                "depth_m": round(d, 3),
                "altitude_m": round(-abs(d), 3),
                "seafloor_depth_m": round(float(bottom), 2),
                "probability": round(p, 4),
                "probability_u8": u8,
                "temperature_c": cell.get("sst_c"),
                "salinity": cell.get("salinity"),
                "current_speed_kt": cell.get("current_speed_kt"),
                "direction_deg": cell.get("direction_deg"),
                "u_ms": cell.get("u_ms"),
                "v_ms": cell.get("v_ms"),
                "chlorophyll_mg_m3": cell.get("chlorophyll_mg_m3"),
                "sample_method": cell.get("sample_method") or "bait_probability_scalar_field_sample",
            })
    # Keep the complete high-probability field as broad as possible.  Sort by
    # probability, but use a deterministic bucket pass so one intense corner does
    # not consume the whole render budget.
    if len(out) <= max_points:
        out.sort(key=lambda x: (float(x.get("depth_m") or 0.0), -float(x.get("probability") or 0.0)))
        return out

    bucket_count = max(6, min(28, int(math.sqrt(max_points) // 2 or 10)))
    lats = [_finite(x.get("lat"), 0.0) or 0.0 for x in out]
    lons = [_norm_lon(_finite(x.get("lon"), 0.0) or 0.0) for x in out]
    depths = [_finite(x.get("depth_m"), 0.0) or 0.0 for x in out]
    south, north = min(lats), max(lats)
    west = min(lons)
    lat_span = max(0.001, north - south)
    lon_span = max(0.001, max(lons) - west)
    max_depth = max(1.0, max(depths))
    buckets: dict[tuple[int, int, int], list[dict[str, Any]]] = {}
    for item in out:
        lat = _finite(item.get("lat"), south) or south
        lon = _norm_lon(_finite(item.get("lon"), west) or west)
        dep = _finite(item.get("depth_m"), 0.0) or 0.0
        key = (
            int(_clamp((lat - south) / lat_span, 0.0, 0.9999) * bucket_count),
            int(_clamp((lon - west) / lon_span, 0.0, 0.9999) * bucket_count),
            int(_clamp(dep / max_depth, 0.0, 0.9999) * 6),
        )
        buckets.setdefault(key, []).append(item)
    for stack in buckets.values():
        stack.sort(key=lambda x: float(x.get("probability") or 0.0), reverse=True)
    selected: list[dict[str, Any]] = []
    keys = sorted(buckets.keys())
    while keys and len(selected) < max_points:
        for key in list(keys):
            stack = buckets.get(key) or []
            if stack:
                selected.append(stack.pop(0))
            if not stack:
                buckets.pop(key, None)
                if key in keys:
                    keys.remove(key)
            if len(selected) >= max_points:
                break
    selected.sort(key=lambda x: (float(x.get("depth_m") or 0.0), -float(x.get("probability") or 0.0)))
    return selected

def _candidate_depth_products(bbox: dict[str, float]) -> list[dict[str, Any]]:
    try:
        from server.gfs.rtofs_source import rtofs_3d_candidates
        return rtofs_3d_candidates(bbox=bbox, limit=8)
    except Exception:
        try:
            from server.gfs.providers import rtofs_noaa as noaa
            return list(noaa._depth_candidate_urls(noaa.BBox(float(bbox["west"]), float(bbox["south"]), float(bbox["east"]), float(bbox["north"]))))[:8]
        except Exception:
            return []


def bait_3d_volume_payload(
    app_root: Path | str | None,
    bbox: Any,
    *,
    depths: Any = None,
    tile_deg: float = 4.0,
    render_grid: int = 16,
    limit: int = 72,
    max_cells: int = 1200,
    max_clouds: int = 36,
    warm: bool = False,
    field_threshold: float = 0.50,
    max_field_points: int = 7200,
    render: str = "particle_cloud",
) -> dict[str, Any]:
    started = time.time()
    bbox_d = _bbox_dict(bbox)
    depths_m = _parse_depths(depths)
    max_cells = max(1, int(max_cells or 1200))
    max_clouds = max(0, int(max_clouds or 36))
    render_mode = str(render or "particle_cloud").strip().lower().replace('-', '_')

    rtofs3d_cache = load_cached_rtofs_3d_truth([bbox_d["west"], bbox_d["south"], bbox_d["east"], bbox_d["north"]])
    rtofs3d_warmer = spawn_rtofs_3d_truth_warmer([bbox_d["west"], bbox_d["south"], bbox_d["east"], bbox_d["north"]]) if warm and not rtofs3d_cache.get("ok") else {"started": False, "reason": "not_requested"}

    use_ocean_truth = str(os.getenv("GFS_BAIT_USE_OCEAN_TRUTH", "1")).lower() not in {"0", "false", "no", "off"}
    truth: dict[str, Any] | None = None
    if use_ocean_truth:
        try:
            truth = ocean_truth_payload(
                app_root,
                bbox_d,
                depths=depths_m,
                tile_deg=tile_deg,
                render_grid=render_grid,
                limit=limit,
                max_samples=max_cells,
                warm_rtofs=warm,
                warm_chlorophyll=True,
                products="bait,boats,ocean",
            )
        except Exception:
            truth = None

    used_ocean_truth = bool(truth and truth.get("samples"))
    if used_ocean_truth:
        bathy = {"ok": True, **(truth.get("bathymetry") or {})}
        rtofs = truth.get("rtofs_surface") or {}
        warmer = (rtofs.get("warmer") or {"started": False, "reason": "handled_by_ocean_truth"})
        points = truth.get("samples") or []
        raw_cell_count_before_clip = int((truth.get("bathymetry") or {}).get("raw_cell_count_before_viewport_clip") or len(points))
        clipped_cells = list(points)
        raw_cells = list(points)
        cells: list[dict[str, Any]] = []
        for sample in raw_cells:
            bait_sample = sample.get("bait_sample") if isinstance(sample.get("bait_sample"), dict) else {}
            bait_temp_c = sample.get("bait_temperature_c") if sample.get("bait_temperature_c") is not None else bait_sample.get("temperature_c")
            bait_speed_kt = sample.get("bait_current_speed_kt") if sample.get("bait_current_speed_kt") is not None else bait_sample.get("current_speed_kt")
            bait_dir = sample.get("bait_direction_deg") if sample.get("bait_direction_deg") is not None else bait_sample.get("direction_deg")
            cells.append({
                "lat": sample.get("lat"),
                "lon": sample.get("lon"),
                "bbox": sample.get("bbox"),
                "tile_id": sample.get("tile_id"),
                "bottom_depth_m": sample.get("bottom_depth_m") or sample.get("seafloor_depth_m"),
                "bottom_depth_ft": sample.get("bottom_depth_ft") or sample.get("seafloor_depth_ft"),
                "water_fraction": sample.get("water_fraction", 1.0),
                # Surface fields remain available for display/boats, but bait scoring
                # prefers the chosen underwater sample from OceanTruth.sample(..., bait_depth_m).
                "surface_sst_c": sample.get("sst_c") or sample.get("water_temp_c"),
                "surface_sst_f": sample.get("sst_f") or sample.get("water_temp_f"),
                "sst_c": bait_temp_c if bait_temp_c is not None else (sample.get("sst_c") or sample.get("water_temp_c")),
                "sst_f": (bait_temp_c * 9.0 / 5.0 + 32.0) if isinstance(bait_temp_c, (int, float)) else (sample.get("sst_f") or sample.get("water_temp_f")),
                "salinity": sample.get("bait_salinity") if sample.get("bait_salinity") is not None else sample.get("salinity"),
                "current_speed_kt": bait_speed_kt if bait_speed_kt is not None else (sample.get("current_speed_kt") or (sample.get("current") or {}).get("speedKt")),
                "direction_deg": bait_dir if bait_dir is not None else (sample.get("direction_deg") or (sample.get("current") or {}).get("dirDeg")),
                "u_ms": sample.get("bait_u_ms") if sample.get("bait_u_ms") is not None else (sample.get("u_ms") or (sample.get("current") or {}).get("u")),
                "v_ms": sample.get("bait_v_ms") if sample.get("bait_v_ms") is not None else (sample.get("v_ms") or (sample.get("current") or {}).get("v")),
                "bait_depth_m": sample.get("bait_depth_m"),
                "bait_altitude_m": sample.get("bait_altitude_m"),
                "bait_sample": bait_sample,
                "sample_method": sample.get("sample_method"),
                "chlorophyll_mg_m3": sample.get("chlorophyll_mg_m3"),
                "chlorophyll_status": sample.get("chlorophyll_status"),
                "surface_source": sample.get("source") or rtofs.get("source") or "ocean_truth_surface_cache_missing",
            })
    else:
        bathy = bathymetry_tiles_payload(app_root, bbox_d, tile_deg=tile_deg, render_grid=render_grid, fetch_missing=False, limit=limit)
        rtofs = load_cached_rtofs_surface([bbox_d["west"], bbox_d["south"], bbox_d["east"], bbox_d["north"]])
        warmer = spawn_rtofs_surface_warmer([bbox_d["west"], bbox_d["south"], bbox_d["east"], bbox_d["north"]], max_points=3000) if warm and not rtofs.get("ok") else {"started": False, "reason": "not_requested"}
        points = rtofs.get("points") or rtofs.get("ocean_points") or rtofs.get("current_points") or []

        raw_cells: list[dict[str, Any]] = []
        for tile in bathy.get("tiles") or []:
            if float(tile.get("water_fraction") or 0.0) <= 0.02:
                continue
            raw_cells.extend(_tile_water_cells(tile))

        raw_cell_count_before_clip = len(raw_cells)
        strict_cells = [cell for cell in raw_cells if _cell_intersects_bbox(cell, bbox_d, pad_deg=0.0)]
        # If the camera bbox is extremely small at a tile edge, allow a tiny cushion.
        clipped_cells = strict_cells or [cell for cell in raw_cells if _cell_intersects_bbox(cell, bbox_d, pad_deg=0.08)]
        raw_cells = _spatially_distributed_cells(clipped_cells, bbox_d, max_cells)

        cells: list[dict[str, Any]] = []
        for cell in raw_cells:
            nearest = _nearest_surface_point(float(cell["lat"]), float(cell["lon"]), points)
            feat = _surface_features(nearest)
            cells.append({
                "lat": cell["lat"],
                "lon": cell["lon"],
                "bbox": cell["bbox"],
                "tile_id": cell.get("tile_id"),
                "bottom_depth_m": cell["bottom_depth_m"],
                "bottom_depth_ft": round(float(cell["bottom_depth_m"]) * FT_PER_M, 1),
                "water_fraction": cell.get("water_fraction", 1.0),
                "sst_c": feat.get("sst_c"),
                "sst_f": feat.get("sst_f"),
                "salinity": feat.get("salinity"),
                "current_speed_kt": feat.get("current_speed_kt"),
                "direction_deg": feat.get("direction_deg"),
                "u_ms": feat.get("u_ms"),
                "v_ms": feat.get("v_ms"),
                "surface_source": (nearest or {}).get("source") or rtofs.get("source") or "surface_cache_missing",
            })

    fields: list[list[int]] = []
    for depth in depths_m:
        layer: list[int] = []
        for cell in cells:
            p = _probability_for(float(depth), float(cell.get("bottom_depth_m") or 0.0), cell, float(cell.get("water_fraction") or 1.0))
            layer.append(_u8(p))
        fields.append(layer)

    clouds = _select_clouds(cells, depths_m, fields, max_clouds=max_clouds, bbox=bbox_d)
    field_samples = _field_samples_from_cells(cells, depths_m, fields, threshold=field_threshold, max_points=max_field_points)
    candidates = _candidate_depth_products(bbox_d)
    has_surface = bool(points)
    return {
        "ok": bool(cells),
        "schema": "lftr_bait_probability_volume_v1",
        "source": "lftr_bait_probability_from_unified_ocean_truth_v1" if used_ocean_truth else ("lftr_bait_probability_volume_surface_seeded_depth_dimension_v1" if has_surface else "lftr_bait_probability_volume_bathymetry_only_warming_v1"),
        "ocean_truth": {
            "enabled": bool(used_ocean_truth),
            "schema": (truth or {}).get("schema"),
            "source": (truth or {}).get("source"),
            "sample_count": (truth or {}).get("sample_count"),
            "query_contract": (truth or {}).get("query_contract"),
            "chlorophyll": (truth or {}).get("chlorophyll"),
            "atmosphere": (truth or {}).get("atmosphere"),
        },
        "bbox": bbox_d,
        "depths_m": depths_m,
        "shape": [len(depths_m), len(cells)],
        "grid_type": "irregular_water_cells_from_etopo_4deg_tiles",
        "cells": cells,
        "fields": {
            "bait_probability_u8": fields,
            "encoding": "uint8_probability_0_to_255",
            "decode": "probability = value / 255",
        },
        "field_samples": field_samples,
        "field_sample_count": len(field_samples),
        "field_render_policy": {
            "mode": "continuous_xyz_particle_cloud" if render_mode in {"particle_cloud", "particles", "cloud"} else "full_scalar_field_thresholded_contoured_cubes",
            "requested_render": render_mode,
            "threshold": round(float(field_threshold), 3),
            "max_points": int(max_field_points),
            "palette": "pastel_yellow_to_neon_yellow_to_pastel_green_to_neon_green",
            "geometry": "one viewport-local probability particle cloud; cube/prism geometry is an opt-in debug renderer" if render_mode in {"particle_cloud", "particles", "cloud"} else "10ft-ish depth-bin contoured cube anchors; touching footprints where bathymetry cells share edges",
            "opacity": f"{round(float(field_threshold) * 100)}% bait probability is the visibility threshold; alpha ramps smoothly above threshold, and hotter points glow" if render_mode in {"particle_cloud", "particles", "cloud"} else "transparency concentrated at threshold; hotter cubes are mostly opaque with glow",
            "visual": "thresholded continuous XYZ bait probability field rendered as particles, not surface sheets and not bait/boat mixed ownership" if render_mode in {"particle_cloud", "particles", "cloud"} else "thresholded negative-depth contoured cubes with outline lines and glow particles; not schools and not surface bait",
        },
        "clouds": clouds,
        "count": len(cells),
        "cloud_count": len(clouds),
        "rtofs_surface": {
            "ok": bool(rtofs.get("ok")),
            "status": rtofs.get("status"),
            "source": rtofs.get("source"),
            "count": int(rtofs.get("count") or 0),
            "cache": rtofs.get("cache") or {"hit": False, "path": rtofs.get("cache_path")},
            "warmer": warmer,
        },
        "rtofs_3d": compact_rtofs_3d_status((truth or {}).get("rtofs_3d") if isinstance((truth or {}).get("rtofs_3d"), dict) and (truth or {}).get("rtofs_3d", {}).get("ok") else rtofs3d_cache, rtofs3d_warmer, candidates),
        "bathymetry": {
            "ok": bool(bathy.get("ok")),
            "source": bathy.get("source"),
            "tile_count": bathy.get("tile_count"),
            "missing_tile_count": bathy.get("missing_tile_count"),
            "cache": bathy.get("cache"),
            "raw_cell_count_before_viewport_clip": raw_cell_count_before_clip,
            "viewport_clipped_cell_count": len(clipped_cells),
            "distributed_cell_count": len(raw_cells),
            "viewport_clip_policy": "clip ocean-connected tile water cells to requested bbox before scoring; preserve low-water-fraction harbor/coastal cells; exclude inland below-sea-level basins; spatially distribute cells before max_cells cap",
        },
        "math_contract": {
            "source_of_truth": "OceanTruth continuous field, not voxels; voxels/samples are only extraction anchors",
            "storage": "native_RTOFS_arrays_then_continuous_XYZ_interpolator",
            "visual_product": "thresholded full bait_probability scalar field as one underwater particle cloud with optional contour-core shell",
            "variables_now": ["ocean_truth_bathymetry_bottom_depth", "rtofs_native_3d_temperature", "rtofs_native_3d_current_u", "rtofs_native_3d_current_v", "rtofs_native_3d_salinity", "chlorophyll_late_cache_optional"],
            "variables_next": ["blue_noise_particle_sampling", "front_detection", "current_shear_sampling", "chlorophyll_gradient_sampling"],
            "clip_rule": "depth cell invalid when depth_m >= bottom_depth_m - safety_margin",
        },
        "continuous_field": {
            "function": "B(lat, lon, depth_m) -> probability_0_to_1",
            "samples_are": "finite extraction anchors from an infinitely sampleable viewport-local model",
            "interpolation_contract": "backend emits z-by-cell scalar samples; frontend maps them into jittered XYZ particles and alpha/size/glow from probability",
            "alpha_threshold": round(float(field_threshold), 3),
            "below_threshold": "not rendered by default",
            "above_threshold": "alpha = smoothstep(threshold, high_confidence, probability)",
        },
        "harbor_water_policy": {
            "respected": True,
            "min_water_fraction": 0.08,
            "min_depth_m": 0.20,
            "rule": "narrow ocean-connected harbor, bay, marina, channel, and shallow coastal water survive bait sampling; land and ocean_connected=false basins do not",
        },
        "policy": "compute bait probability from unified OceanTruth; chlorophyll late-injects as a score booster without blanking bait; frontend renders one thresholded scalar-field particle cloud for the Bait pill",
        "latency_ms": int((time.time() - started) * 1000),
    }

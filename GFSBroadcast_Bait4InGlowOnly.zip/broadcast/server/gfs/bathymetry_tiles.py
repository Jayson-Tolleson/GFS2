from __future__ import annotations

import json
import math
import os
import time
from pathlib import Path
from typing import Any

DEFAULT_TILE_DEG = 4.0
DEFAULT_RENDER_GRID = 8
DEFAULT_SOURCE = "NOAA_ETOPO_2022_60s_bedrock_global_relief"
# Official NOAA/NCEI ETOPO 2022 60 arc-second bedrock elevation netCDF via THREDDS OPeNDAP.
DEFAULT_OPENDAP_URL = (
    "https://www.ngdc.noaa.gov/thredds/dodsC/global/ETOPO2022/60s/"
    "60s_bed_elev_netcdf/ETOPO_2022_v1_60s_N90W180_bed.nc"
)

DEFAULT_SHORELINE_WATER_FRACTION = 0.35
DEFAULT_SKIRT_EXTRA_DEPTH_M = 30.48  # 100 ft; pushes the visual cutout below the bathymetry floor.
DEFAULT_MAX_WATER_CELLS_RETURNED = 1600
DEFAULT_MAX_SHORELINE_EDGES_RETURNED = 2600


def _finite(value: Any, default: float | None = None) -> float | None:
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except Exception:
        return default


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _norm_lon(lon: float) -> float:
    n = ((float(lon) + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
    # Keep -180 as a valid western edge for global/dateline tile math.
    return n


def _bbox_tuple(bbox: dict[str, Any] | None) -> tuple[float, float, float, float]:
    if not isinstance(bbox, dict):
        return (-125.0, 32.0, -117.0, 38.0)
    raw_west = _finite(bbox.get("west"), -125.0) or -125.0
    raw_east = _finite(bbox.get("east"), -117.0) or -117.0
    west = -180.0 if raw_west <= -180.0 else _norm_lon(raw_west)
    east = 180.0 if raw_east >= 180.0 else _norm_lon(raw_east)
    south = _clamp(_finite(bbox.get("south"), 32.0) or 32.0, -89.9, 89.9)
    north = _clamp(_finite(bbox.get("north"), 38.0) or 38.0, -89.9, 89.9)
    if north < south:
        south, north = north, south
    return west, south, east, north


def _bbox_width(west: float, east: float) -> float:
    if east >= west:
        return east - west
    return (180.0 - west) + (east + 180.0)


def _lon_ranges(west: float, east: float) -> list[tuple[float, float]]:
    if east >= west:
        return [(west, east)]
    return [(west, 180.0), (-180.0, east)]


def _tile_floor(value: float, tile_deg: float, minimum: float, maximum: float) -> float:
    idx = math.floor((value - minimum) / tile_deg)
    return _clamp(minimum + idx * tile_deg, minimum, maximum - tile_deg)


def _tile_id(west: float, south: float, tile_deg: float) -> str:
    def fmt(v: float, pos: str, neg: str) -> str:
        hemi = pos if v >= 0 else neg
        return f"{hemi}{abs(int(round(v))):03d}"
    return f"etopo2022_{int(tile_deg)}deg_{fmt(south, 'N', 'S')}_{fmt(west, 'E', 'W')}"


def _tile_bbox(west: float, south: float, tile_deg: float) -> list[float]:
    return [round(west, 6), round(south, 6), round(min(west + tile_deg, 180.0), 6), round(min(south + tile_deg, 90.0), 6)]


def tiles_for_bbox(bbox: dict[str, Any] | None, tile_deg: float = DEFAULT_TILE_DEG, limit: int = 80) -> list[dict[str, Any]]:
    west, south, east, north = _bbox_tuple(bbox)
    tile_deg = _clamp(_finite(tile_deg, DEFAULT_TILE_DEG) or DEFAULT_TILE_DEG, 1.0, 20.0)
    eps = 1e-9
    south0 = _tile_floor(south, tile_deg, -90.0, 90.0)
    north0 = _tile_floor(max(south, north - eps), tile_deg, -90.0, 90.0)
    out: list[dict[str, Any]] = []
    for w0, e0 in _lon_ranges(west, east):
        lon = _tile_floor(w0, tile_deg, -180.0, 180.0)
        edge_stop = max(w0, e0 - eps)
        while lon <= edge_stop and lon < 180.0 and len(out) < limit:
            lat = south0
            while lat <= north0 and lat < 90.0 and len(out) < limit:
                tid = _tile_id(lon, lat, tile_deg)
                out.append({"tile_id": tid, "bbox": _tile_bbox(lon, lat, tile_deg), "tile_deg": tile_deg})
                lat += tile_deg
            lon += tile_deg
    return out



def world_tiles(tile_deg: float = DEFAULT_TILE_DEG, limit: int = 10000) -> list[dict[str, Any]]:
    tile_deg = _clamp(_finite(tile_deg, DEFAULT_TILE_DEG) or DEFAULT_TILE_DEG, 1.0, 20.0)
    out: list[dict[str, Any]] = []
    lon = -180.0
    while lon < 180.0 - 1e-9 and len(out) < limit:
        lat = -90.0
        while lat < 90.0 - 1e-9 and len(out) < limit:
            out.append({"tile_id": _tile_id(lon, lat, tile_deg), "bbox": _tile_bbox(lon, lat, tile_deg), "tile_deg": tile_deg})
            lat += tile_deg
        lon += tile_deg
    return out

def _cache_root(app_root: Path | str | None = None) -> Path:
    root = Path(app_root or os.getcwd())
    return root / "data_sources" / "bathymetry"


def _tile_cache_dir(app_root: Path | str | None = None, tile_deg: float = DEFAULT_TILE_DEG) -> Path:
    return _cache_root(app_root) / f"etopo2022_{int(tile_deg)}deg_tiles"


def _tile_path(app_root: Path | str | None, tile_id: str, tile_deg: float = DEFAULT_TILE_DEG) -> Path:
    return _tile_cache_dir(app_root, tile_deg) / f"{tile_id}.json"



def cache_inventory(app_root: Path | str | None = None, tile_deg: float = DEFAULT_TILE_DEG) -> dict[str, Any]:
    tile_deg = _clamp(_finite(tile_deg, DEFAULT_TILE_DEG) or DEFAULT_TILE_DEG, 1.0, 20.0)
    root = _tile_cache_dir(app_root, tile_deg)
    global_count = int((360.0 / tile_deg) * (180.0 / tile_deg)) if tile_deg > 0 else 0
    files = sorted(root.glob("*.json")) if root.exists() else []
    grid_counts: dict[str, int] = {}
    water_files = 0
    land_files = 0
    for path in files:
        try:
            data = json.loads(path.read_text())
            rg = data.get("render_grid") if isinstance(data, dict) else None
            rows = rg.get("rows") if isinstance(rg, dict) else None
            cols = rg.get("cols") if isinstance(rg, dict) else None
            key = f"{rows}x{cols}" if rows and cols else "unknown"
            grid_counts[key] = grid_counts.get(key, 0) + 1
            wf = _finite(data.get("water_fraction"), 0.0) if isinstance(data, dict) else 0.0
            if wf and wf > 0:
                water_files += 1
            else:
                land_files += 1
        except Exception:
            grid_counts["unreadable"] = grid_counts.get("unreadable", 0) + 1
    return {
        "root": str(root),
        "tile_deg": tile_deg,
        "cached_tile_count": len(files),
        "global_tile_count": global_count,
        "coverage_fraction": round(len(files) / global_count, 4) if global_count else 0.0,
        "water_tile_files": water_files,
        "land_tile_files": land_files,
        "grid_counts": grid_counts,
    }

def _cell_bbox_from_grid(tile_bbox: list[Any], rows: int, cols: int, gy: int, gx: int) -> list[float]:
    west, south, east, north = [float(x) for x in tile_bbox]
    lon_span = east - west
    lat_span = north - south
    cw = west + (gx / cols) * lon_span
    ce = west + ((gx + 1) / cols) * lon_span
    cs = south + (gy / rows) * lat_span
    cn = south + ((gy + 1) / rows) * lat_span
    return [round(cw, 6), round(cs, 6), round(ce, 6), round(cn, 6)]



def _is_known_inland_depression(lat: float, lon: float) -> bool:
    """Reject below-sea-level inland basins that ETOPO can mistake for ocean.

    This is a safety guard until a full vector coastline/ocean polygon mask is
    wired in.  It keeps bait/cutout out of Death Valley and the Salton Sea while
    still allowing the nearby Pacific/Gulf waters.
    """
    try:
        lat = float(lat); lon = float(lon)
    except Exception:
        return False
    boxes = (
        # Death Valley / Badwater basin.
        (-117.65, 35.35, -116.15, 37.15),
        # Salton Sea / Imperial below-sea-level inland basin.
        (-116.45, 32.55, -115.15, 34.15),
        # Great Salt Lake basin guard for western-US views.
        (-113.25, 40.35, -111.65, 41.85),
    )
    for west, south, east, north in boxes:
        if west <= lon <= east and south <= lat <= north:
            return True
    return False

def _shade_name_for_depth(depth_m: float | None) -> str:
    d = _finite(depth_m, 0.0) or 0.0
    if d < 20:
        return "pale_sand"
    if d < 100:
        return "wet_sand"
    if d < 500:
        return "sandy_teal"
    if d < 1500:
        return "blue_gray_slope"
    return "deep_slate"


def _shade_rgba_for_depth(depth_m: float | None) -> str:
    d = _finite(depth_m, 0.0) or 0.0
    if d < 20:
        return "rgba(232,213,160,0.82)"
    if d < 100:
        return "rgba(204,190,138,0.80)"
    if d < 500:
        return "rgba(112,157,145,0.74)"
    if d < 1500:
        return "rgba(75,112,126,0.72)"
    return "rgba(36,64,86,0.72)"


def _derive_water_cells_and_shoreline(
    data: dict[str, Any],
    *,
    shoreline_threshold: float = DEFAULT_SHORELINE_WATER_FRACTION,
    max_water_cells: int = DEFAULT_MAX_WATER_CELLS_RETURNED,
    max_edges: int = DEFAULT_MAX_SHORELINE_EDGES_RETURNED,
) -> dict[str, Any]:
    """Derive render-ready OCEAN cells and 0m shoreline edge segments.

    Important: ETOPO elevation < 0 alone is not a safe ocean mask.  It will
    classify below-sea-level land basins such as Death Valley as "water".  The
    LFTR cutout/bait layers need ocean-connected water only, so this read-time
    upgrade flood-fills renderable water cells from the tile boundary and drops
    isolated inland depressions from `water_cells` and shoreline products.
    """
    try:
        if isinstance(data.get("water_cells"), (int, float)) and "native_water_cells" not in data:
            data["native_water_cells"] = int(data.get("water_cells") or 0)
        bbox = data.get("bbox")
        grid = data.get("render_grid", {}).get("depth_m")
        wf_grid = data.get("render_grid", {}).get("water_fraction")
        if not isinstance(bbox, list) or len(bbox) < 4 or not isinstance(grid, list):
            return data
        rows = len(grid)
        cols = max((len(r) for r in grid if isinstance(r, list)), default=0)
        if rows <= 0 or cols <= 0:
            return data

        threshold = _clamp(_finite(data.get("shoreline_water_fraction_threshold"), shoreline_threshold) or shoreline_threshold, 0.0, 1.0)
        depth_grid: list[list[float | None]] = [[None for _ in range(cols)] for _ in range(rows)]
        wf_clean: list[list[float]] = [[0.0 for _ in range(cols)] for _ in range(rows)]
        raw_water: list[list[bool]] = [[False for _ in range(cols)] for _ in range(rows)]
        renderable_raw: list[list[bool]] = [[False for _ in range(cols)] for _ in range(rows)]
        raw_water_count = 0
        raw_renderable_count = 0

        for gy in range(rows):
            row = grid[gy] if isinstance(grid[gy], list) else []
            wf_row = wf_grid[gy] if isinstance(wf_grid, list) and gy < len(wf_grid) and isinstance(wf_grid[gy], list) else []
            for gx in range(cols):
                depth = _finite(row[gx] if gx < len(row) else None, None)
                wf = _finite(wf_row[gx] if gx < len(wf_row) else None, 1.0 if depth and depth > 0 else 0.0) or 0.0
                depth_grid[gy][gx] = depth
                wf_clean[gy][gx] = float(wf)
                is_water = bool(depth is not None and depth > 0 and wf > 0.0)
                is_renderable = bool(is_water and wf >= threshold)
                if is_renderable:
                    cw, cs, ce, cn = _cell_bbox_from_grid(bbox, rows, cols, gy, gx)
                    if _is_known_inland_depression((cs + cn) / 2.0, (cw + ce) / 2.0):
                        is_renderable = False
                raw_water[gy][gx] = is_water
                renderable_raw[gy][gx] = is_renderable
                if is_water:
                    raw_water_count += 1
                if is_renderable:
                    raw_renderable_count += 1

        # Flood-fill only renderable water connected to the tile boundary.  This
        # keeps open-ocean/coastal cells and removes isolated sub-sea-level land
        # depressions from the ocean cutout and bait math.
        ocean_connected: list[list[bool]] = [[False for _ in range(cols)] for _ in range(rows)]
        stack: list[tuple[int, int]] = []
        for gy in range(rows):
            for gx in range(cols):
                if gy in (0, rows - 1) or gx in (0, cols - 1):
                    if renderable_raw[gy][gx] and not ocean_connected[gy][gx]:
                        ocean_connected[gy][gx] = True
                        stack.append((gy, gx))
        while stack:
            gy, gx = stack.pop()
            for ny, nx in ((gy - 1, gx), (gy + 1, gx), (gy, gx - 1), (gy, gx + 1)):
                if 0 <= ny < rows and 0 <= nx < cols and renderable_raw[ny][nx] and not ocean_connected[ny][nx]:
                    ocean_connected[ny][nx] = True
                    stack.append((ny, nx))

        # A fully cached legacy tile may have a threshold so strict that no edge
        # seed survives.  In a tile that is almost entirely water, keep the raw
        # renderable mask rather than producing an empty ocean tile.
        if not any(any(r) for r in ocean_connected) and (float(data.get("water_fraction") or 0.0) >= 0.90):
            ocean_connected = [row[:] for row in renderable_raw]

        water_cells: list[dict[str, Any]] = []
        renderable_count = 0
        suppressed_inland_count = 0
        for gy in range(rows):
            for gx in range(cols):
                depth = depth_grid[gy][gx]
                wf = wf_clean[gy][gx]
                if renderable_raw[gy][gx] and not ocean_connected[gy][gx]:
                    suppressed_inland_count += 1
                if not ocean_connected[gy][gx]:
                    continue
                renderable_count += 1
                if len(water_cells) < max_water_cells:
                    water_cells.append({
                        "r": gy,
                        "c": gx,
                        "bbox": _cell_bbox_from_grid(bbox, rows, cols, gy, gx),
                        "depth_m": round(float(depth or 0.0), 1),
                        "water_fraction": round(float(wf), 4),
                        "shade": _shade_name_for_depth(depth),
                        "fill_rgba": _shade_rgba_for_depth(depth),
                        "renderable": True,
                        "ocean_connected": True,
                    })

        edges: list[list[dict[str, float]]] = []
        def add_edge(a: tuple[float, float], b: tuple[float, float], gy: int, gx: int, side: str) -> None:
            if len(edges) >= max_edges:
                return
            edges.append([
                {"lat": round(a[0], 6), "lng": round(a[1], 6), "altitude": 0.0, "r": gy, "c": gx, "side": side},
                {"lat": round(b[0], 6), "lng": round(b[1], 6), "altitude": 0.0, "r": gy, "c": gx, "side": side},
            ])

        for gy in range(rows):
            for gx in range(cols):
                if not ocean_connected[gy][gx]:
                    continue
                cw, cs, ce, cn = _cell_bbox_from_grid(bbox, rows, cols, gy, gx)
                north = ((cn, cw), (cn, ce))
                east = ((cn, ce), (cs, ce))
                south = ((cs, ce), (cs, cw))
                west = ((cs, cw), (cn, cw))
                if gy + 1 >= rows or not ocean_connected[gy + 1][gx]:
                    add_edge(*north, gy, gx, "north")
                if gx + 1 >= cols or not ocean_connected[gy][gx + 1]:
                    add_edge(*east, gy, gx, "east")
                if gy - 1 < 0 or not ocean_connected[gy - 1][gx]:
                    add_edge(*south, gy, gx, "south")
                if gx - 1 < 0 or not ocean_connected[gy][gx - 1]:
                    add_edge(*west, gy, gx, "west")

        data["water_cells"] = water_cells
        data["shoreline_edges"] = edges
        data["shoreline"] = {
            "mode": "ocean_connected_zero_meter_waterline_from_etopo_grid_edges_plus_known_inland_basin_reject",
            "threshold_m": 0,
            "water_fraction_threshold": threshold,
            "edge_count": len(edges),
            "edge_count_capped": len(edges) >= max_edges,
            "suppressed_inland_depression_cells": suppressed_inland_count,
            "policy": "derive shoreline from ocean-connected ETOPO water cells only; Death Valley, Salton Sea, and known inland below-sea-level basins are not ocean",
        }
        data["cutaway"] = {
            "surface_altitude_m": 0,
            "skirt_extra_depth_m": DEFAULT_SKIRT_EXTRA_DEPTH_M,
            "skirt_extra_depth_ft": round(DEFAULT_SKIRT_EXTRA_DEPTH_M / 0.3048, 1),
            "policy": "bathymetry floor; visual frame/skirt helpers are debug-only by default",
            "palette": "sand_depth_v1",
            "draw_surface_default": False,
        }
        data["cutaway_mask"] = {
            "mode": "ocean_connected_bathymetry_grid_water_cells_no_inland_depressions_known_basin_reject",
            "grid_rows": rows,
            "grid_cols": cols,
            "water_render_cells": renderable_count,
            "raw_water_cells": raw_water_count,
            "raw_renderable_cells": raw_renderable_count,
            "suppressed_inland_depression_cells": suppressed_inland_count,
            "land_render_cells": max(0, rows * cols - renderable_count),
            "water_cell_records_returned": len(water_cells),
            "shoreline_edge_count": len(edges),
            "water_fraction_threshold": threshold,
            "policy": "mixed/coastal tiles render ocean-connected ETOPO water cells only; Death Valley, Salton Sea, and other inland below-sea-level basins are excluded",
        }
    except Exception:
        pass
    return data

def _annotate_cutaway_mask(data: dict[str, Any]) -> dict[str, Any]:
    """Upgrade cache records with shoreline/cutaway metadata for the renderer."""
    return _derive_water_cells_and_shoreline(data)


def load_cached_tile(app_root: Path | str | None, tile: dict[str, Any]) -> dict[str, Any] | None:
    path = _tile_path(app_root, str(tile.get("tile_id")), float(tile.get("tile_deg") or DEFAULT_TILE_DEG))
    try:
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        if not isinstance(data, dict):
            return None
        data.setdefault("cache", {})["path"] = str(path)
        data.setdefault("cache", {})["hit"] = True
        return _annotate_cutaway_mask(data)
    except Exception:
        return None


def _safe_float_grid(values: Any, max_rows: int = 32, max_cols: int = 32) -> list[list[float | None]]:
    out: list[list[float | None]] = []
    try:
        rows = values.tolist() if hasattr(values, "tolist") else values
        for row in list(rows)[:max_rows]:
            line = []
            for v in list(row)[:max_cols]:
                n = _finite(v, None)
                line.append(round(n, 1) if n is not None else None)
            out.append(line)
    except Exception:
        return []
    return out


def _find_coord_name(ds: Any, names: tuple[str, ...]) -> str | None:
    for name in names:
        if name in getattr(ds, "coords", {}):
            return name
        if name in getattr(ds, "variables", {}):
            return name
    # fuzzy fallback
    for name in list(getattr(ds, "coords", {}).keys()) + list(getattr(ds, "variables", {}).keys()):
        low = str(name).lower()
        if any(low == n or low.endswith(n) for n in names):
            return str(name)
    return None


def _find_var_name(ds: Any) -> str | None:
    candidates = ("z", "elevation", "Band1", "bedrock", "bed_elev", "ETOPO_2022_v1_60s_N90W180_bed")
    for name in candidates:
        if name in getattr(ds, "data_vars", {}):
            return name
        if name in getattr(ds, "variables", {}):
            return name
    for name, var in getattr(ds, "data_vars", {}).items():
        dims = getattr(var, "dims", ())
        if len(dims) >= 2:
            return str(name)
    return None


def _open_etopo_dataset(opendap_url: str | None = None):
    import xarray as xr  # imported lazily so runtime routes are cheap
    url = opendap_url or os.environ.get("ETOPO2022_OPENDAP_URL") or DEFAULT_OPENDAP_URL
    return xr.open_dataset(url, decode_times=False), url


def _reduce_tile_from_etopo(ds: Any, tile: dict[str, Any], render_grid: int = DEFAULT_RENDER_GRID) -> dict[str, Any]:
    import numpy as np

    west, south, east, north = [float(x) for x in tile["bbox"]]
    lat_name = _find_coord_name(ds, ("lat", "latitude", "y"))
    lon_name = _find_coord_name(ds, ("lon", "longitude", "x"))
    var_name = _find_var_name(ds)
    if not lat_name or not lon_name or not var_name:
        raise RuntimeError(f"Unable to locate ETOPO coords/variable lat={lat_name} lon={lon_name} var={var_name}")

    lat_vals = ds[lat_name]
    lon_vals = ds[lon_name]
    lat_asc = bool(float(lat_vals[0]) < float(lat_vals[-1]))
    lon_asc = bool(float(lon_vals[0]) < float(lon_vals[-1]))
    lat_slice = slice(south, north) if lat_asc else slice(north, south)
    lon_slice = slice(west, east) if lon_asc else slice(east, west)
    subset = ds[var_name].sel({lat_name: lat_slice, lon_name: lon_slice})
    # Load only this 4-degree tile. 60 arc-second source is ~240x240 values.
    arr = subset.load().values
    if arr.ndim > 2:
        arr = np.squeeze(arr)
    arr = np.asarray(arr, dtype="float64")
    if arr.size == 0:
        raise RuntimeError(f"ETOPO subset empty for {tile.get('tile_id')} bbox={tile.get('bbox')}")
    arr = np.where(np.isfinite(arr), arr, np.nan)
    water = arr < 0.0
    water_count = int(np.nansum(water))
    total_count = int(arr.size)
    depths = np.where(water, -arr, np.nan)

    def nan_stat(fn, default=0.0):
        try:
            if water_count <= 0:
                return default
            v = float(fn(depths))
            return round(v, 1) if math.isfinite(v) else default
        except Exception:
            return default

    # Produce a tiny render grid of mean depth per cell. Positive values are meters below sea level.
    g = max(2, min(32, int(render_grid or DEFAULT_RENDER_GRID)))
    rows, cols = arr.shape[-2], arr.shape[-1]
    grid = []
    water_fraction_grid = []
    for gy in range(g):
        y0 = int(round(gy * rows / g)); y1 = int(round((gy + 1) * rows / g))
        line = []
        wf_line = []
        for gx in range(g):
            x0 = int(round(gx * cols / g)); x1 = int(round((gx + 1) * cols / g))
            yy1 = max(y1, y0 + 1)
            xx1 = max(x1, x0 + 1)
            cell = depths[y0:yy1, x0:xx1]
            water_cell = water[y0:yy1, x0:xx1]
            cell_total = int(water_cell.size)
            cell_water_count = int(np.nansum(water_cell)) if cell_total else 0
            wf = round(cell_water_count / cell_total, 4) if cell_total else 0.0
            wf_line.append(wf)
            try:
                v = float(np.nanmean(cell))
                line.append(round(v, 1) if math.isfinite(v) and wf > 0 else None)
            except Exception:
                line.append(None)
        grid.append(line)
        water_fraction_grid.append(wf_line)

    tile_out = {
        "ok": True,
        "tile_id": tile.get("tile_id"),
        "bbox": tile.get("bbox"),
        "tile_deg": tile.get("tile_deg", DEFAULT_TILE_DEG),
        "source": DEFAULT_SOURCE,
        "source_url": os.environ.get("ETOPO2022_OPENDAP_URL") or DEFAULT_OPENDAP_URL,
        "source_resolution_arcsec": 60,
        "variable": var_name,
        "coord_names": {"lat": lat_name, "lon": lon_name},
        "native_rows": int(rows),
        "native_cols": int(cols),
        "native_cells": total_count,
        "native_water_cells": water_count,
        "water_fraction": round(water_count / total_count, 4) if total_count else 0.0,
        "depth_min_m": nan_stat(np.nanmin, 0.0),
        "depth_mean_m": nan_stat(np.nanmean, 0.0),
        "depth_max_m": nan_stat(np.nanmax, 0.0),
        "floor_depth_m": nan_stat(np.nanmean, 0.0),
        "render_grid": {"rows": g, "cols": g, "depth_m": grid, "water_fraction": water_fraction_grid},
        "cutaway_mask": {
            "mode": "bathymetry_grid_water_cells",
            "grid_rows": g,
            "grid_cols": g,
            "water_render_cells": sum(1 for row in grid for v in row if v is not None and v > 0),
            "land_render_cells": sum(1 for row in grid for v in row if v is None or v <= 0),
            "policy": "mixed/coastal tiles render only ETOPO water cells; use render_grid.water_fraction for shoreline filtering",
        },
        "shoreline_water_fraction_threshold": DEFAULT_SHORELINE_WATER_FRACTION,
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "cache": {"hit": False, "mode": "fresh_source_fetch"},
    }
    return _derive_water_cells_and_shoreline(tile_out)


def build_tile_from_source(app_root: Path | str | None, tile: dict[str, Any], *, render_grid: int = DEFAULT_RENDER_GRID, dataset: Any = None) -> dict[str, Any]:
    own_ds = False
    if dataset is None:
        dataset, _ = _open_etopo_dataset()
        own_ds = True
    try:
        out = _reduce_tile_from_etopo(dataset, tile, render_grid=render_grid)
        path = _tile_path(app_root, str(tile.get("tile_id")), float(tile.get("tile_deg") or DEFAULT_TILE_DEG))
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(out, separators=(",", ":")))
        tmp.replace(path)
        out.setdefault("cache", {})["path"] = str(path)
        out["cache"]["hit"] = False
        out["cache"]["written"] = True
        return out
    finally:
        if own_ds:
            try:
                dataset.close()
            except Exception:
                pass


def bathymetry_tiles_payload(
    app_root: Path | str | None,
    bbox: dict[str, Any] | None,
    *,
    tile_deg: float = DEFAULT_TILE_DEG,
    render_grid: int = DEFAULT_RENDER_GRID,
    fetch_missing: bool = False,
    limit: int = 40,
) -> dict[str, Any]:
    tile_deg = _clamp(_finite(tile_deg, DEFAULT_TILE_DEG) or DEFAULT_TILE_DEG, 1.0, 20.0)
    limit = int(_clamp(_finite(limit, 40) or 40, 1, 120))
    wanted = tiles_for_bbox(bbox, tile_deg=tile_deg, limit=limit)
    tiles: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []

    dataset = None
    if fetch_missing:
        try:
            dataset, source_url = _open_etopo_dataset()
        except Exception as exc:
            dataset = None
            errors.append({"stage": "open_source", "error": str(exc), "source_url": os.environ.get("ETOPO2022_OPENDAP_URL") or DEFAULT_OPENDAP_URL})

    for tile in wanted:
        cached = load_cached_tile(app_root, tile)
        if cached:
            tiles.append(cached)
            continue
        if fetch_missing and dataset is not None:
            try:
                tiles.append(build_tile_from_source(app_root, tile, render_grid=render_grid, dataset=dataset))
                continue
            except Exception as exc:
                errors.append({"stage": "build_tile", "tile_id": tile.get("tile_id"), "error": str(exc)})
        missing.append(tile)

    try:
        if dataset is not None:
            dataset.close()
    except Exception:
        pass

    bbox_tuple = _bbox_tuple(bbox)
    return {
        "ok": True,
        "schema": "lftr_bathymetry_4deg_tiles_v1",
        "source": DEFAULT_SOURCE,
        "source_url": os.environ.get("ETOPO2022_OPENDAP_URL") or DEFAULT_OPENDAP_URL,
        "bbox": {"west": bbox_tuple[0], "south": bbox_tuple[1], "east": bbox_tuple[2], "north": bbox_tuple[3]},
        "tile_deg": tile_deg,
        "tile_count": len(tiles),
        "requested_tile_count": len(wanted),
        "missing_tile_count": len(missing),
        "tiles": tiles,
        "missing_tiles": missing[:25],
        "errors": errors[:25],
        "cache": {
            "root": str(_tile_cache_dir(app_root, tile_deg)),
            "hit_count": sum(1 for t in tiles if t.get("cache", {}).get("hit")),
            "mode": "cache_read_then_optional_source_fetch" if fetch_missing else "cache_read_only",
            "inventory": cache_inventory(app_root, tile_deg),
        },
        "build_command": f"python3 scripts/build_bathymetry_4deg_cache.py --bbox={bbox_tuple[0]},{bbox_tuple[1]},{bbox_tuple[2]},{bbox_tuple[3]}",
        "cutaway": {
            "surface_altitude_m": 0,
            "skirt_extra_depth_m": DEFAULT_SKIRT_EXTRA_DEPTH_M,
            "skirt_extra_depth_ft": round(DEFAULT_SKIRT_EXTRA_DEPTH_M / 0.3048, 1),
            "palette": "sand_depth_v1",
            "shoreline_source": "ETOPO_0m_contour_grid_edges",
        },
        "policy": "global 4-degree bathymetry tile cache; runtime fetches only padded camera viewport tiles, uses the ETOPO 0m waterline as shoreline mask, and renders floor plus 100ft occlusion skirt.",
    }

from __future__ import annotations

"""Harbor-safe water validity helpers for LFTR bait field rendering.

This module deliberately keeps narrow coastal/harbor water alive.  It is not a
coarse open-ocean mask: low water-fraction cells can still be valid bait water
when the bathymetry cache marks them ocean-connected/renderable.
"""

import math
from typing import Any


def finite(value: Any, default: float | None = None) -> float | None:
    try:
        f = float(value)
        return f if math.isfinite(f) else default
    except Exception:
        return default


def harbor_water_fraction(cell: dict[str, Any] | None) -> float:
    cell = cell or {}
    wf = finite(cell.get("water_fraction"), None)
    if wf is None:
        wf = finite(cell.get("waterFraction"), None)
    if wf is None:
        # If the upstream record survived as a water cell but did not carry a
        # fraction, treat it as valid water rather than erasing a harbor/channel.
        return 1.0
    return max(0.0, min(1.0, wf))


def harbor_water_valid(cell: dict[str, Any] | None, *, min_fraction: float = 0.08, min_depth_m: float = 0.20) -> bool:
    """Return true if this bathy/OceanTruth cell is valid water for bait sampling.

    Rules:
    * land/renderable=false is rejected;
    * explicitly ocean_connected=false is rejected to avoid below-sea-level basins;
    * shallow/narrow harbor water is accepted down to a small water-fraction;
    * min depth is deliberately tiny so marinas, bays, and harbor channels survive.
    """
    cell = cell or {}
    if cell.get("renderable") is False:
        return False
    if cell.get("ocean_connected") is False:
        return False
    depth = finite(cell.get("depth_m", cell.get("bottom_depth_m")), None)
    if depth is not None and depth < float(min_depth_m):
        return False
    return harbor_water_fraction(cell) >= float(min_fraction)


def harbor_water_class(cell: dict[str, Any] | None) -> str:
    wf = harbor_water_fraction(cell)
    depth = finite((cell or {}).get("depth_m", (cell or {}).get("bottom_depth_m")), 0.0) or 0.0
    if wf < 0.18 or depth < 3.0:
        return "harbor_edge_or_shallow_water"
    if wf < 0.45 or depth < 12.0:
        return "coastal_harbor_water"
    return "open_or_shelf_water"

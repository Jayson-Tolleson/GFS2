"""Inland runtime tile cache helpers.

Clean contract for the LFTR Inland Waters layer:

* reads are cache-only and never launch builders
* the only renderable geometry cache is static/data/nhdplus_hr/tiles
* no state-wide sidecar cache and no hidden .cache geometry artifact root
* global/world reads render one largest lake per selected tile + one temp label
* local/lake/harbor reads render full vertices from the same active tile grid
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable


def runtime_tile_roots(static_dir: Path) -> list[Path]:
    root = Path(static_dir).resolve() / "data" / "nhdplus_hr" / "tiles"
    return [root]


def existing_runtime_roots(static_dir: Path) -> list[Path]:
    return [p for p in runtime_tile_roots(static_dir) if p.exists()]


def iter_tile_files(static_dir: Path) -> Iterable[Path]:
    for root in existing_runtime_roots(static_dir):
        yield from root.rglob("*.json.gz")

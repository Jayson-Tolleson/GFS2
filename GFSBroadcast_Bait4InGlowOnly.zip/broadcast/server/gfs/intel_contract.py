"""LFTR canonical intelligence payload contract.

This module is intentionally small and dependency-free.  It gives every
mission/intel payload the same field families so HUDs and renderers do not
have to guess between old provider aliases.

Field families:
  source_*   where data came from
  raw_*      direct provider units
  norm_*     normalized display/logic units
  derived_*  computed facts/masks/labels
  score_*    0..1 intelligence scores
  status_*   ready/warming/stale/unresolved
  reason_*   why status/score happened
  display_*  HUD-ready strings

Legacy aliases are kept by callers during migration, but new panes should read
canonical fields first.
"""
from __future__ import annotations

from typing import Any, Mapping
import math

OCEAN_MISSION_LAYERS = ("bait", "boater", "shark-intel")
LOD_GLOBAL = "global"
LOD_LOCAL = "local"
LOD_LEVELS = (LOD_GLOBAL, LOD_LOCAL)

STATUS_READY = "ready"
STATUS_WARMING = "warming"
STATUS_STALE = "stale"
STATUS_UNRESOLVED = "unresolved"
STATUS_GATED = "gated"

SOURCE_RTOFS_SURFACE = "rtofs_noaa_ncep_surface"
SOURCE_GFS_SURFACE_TEMP = "gfs_tmp_surface"
SOURCE_CACHED_INLAND_TEMP = "cached_inland_feature_temp"

REASON_SST_VALID_WATER = "sst_valid_water_cell"
REASON_SST_INVALID_LAND = "sst_invalid_land_cell"
REASON_GLOBAL_TEMP_GATED = "global_tier_live_temp_decode_disabled"
REASON_LOCAL_DETAIL_ALLOWED = "local_bbox_detail_allowed"


def _num(value: Any, default: float | None = None) -> float | None:
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except Exception:
        return default


def normalize_lod_name(value: Any) -> str:
    raw = str(value or "").strip().lower()
    if raw in {"local", "regional", "coastal", "harbor", "detail", "full", "lake"}:
        return LOD_LOCAL
    return LOD_GLOBAL


def display_temp_f(value: Any) -> str | None:
    temp = _num(value)
    if temp is None:
        return None
    return f"{round(temp):.0f}°F"


def display_current(speed_kt: Any, dir_deg: Any = None) -> str | None:
    spd = _num(speed_kt)
    if spd is None:
        return None
    d = _num(dir_deg)
    return f"{spd:.1f} kt" + (f" @ {d:.0f}°" if d is not None else "")


def normalized_ocean_cell(point: Mapping[str, Any], *, source_provider: str = SOURCE_RTOFS_SURFACE) -> dict[str, Any]:
    lat = _num(point.get("lat"))
    lon = _num(point.get("lng", point.get("lon")))
    sst_c = _num(point.get("sst_c", point.get("sst", point.get("water_temp_c"))))
    sst_f = _num(point.get("water_temp_f"))
    if sst_f is None and sst_c is not None:
        sst_f = (sst_c * 9.0 / 5.0) + 32.0
    u = _num(point.get("current_u", point.get("u_ms", point.get("u"))))
    v = _num(point.get("current_v", point.get("v_ms", point.get("v"))))
    speed_ms = _num(point.get("current_speed_m_s", point.get("speed_ms", point.get("speedMs"))))
    speed_kt = _num(point.get("current_speed_kt", point.get("speedKt")))
    dir_deg = _num(point.get("current_dir_deg", point.get("direction_deg", point.get("heading"))))
    water = bool(point.get("derived_water_mask", point.get("water", point.get("valid", False))))
    bait_score = _num(point.get("score_bait", point.get("baitScore", point.get("bait_score"))), 0.0) or 0.0
    safety_score = _num(point.get("score_boater_safety", point.get("boaterSafetyScore")), None)
    shark_score = _num(point.get("score_shark_activity", point.get("sharkScore")), None)
    return {
        "layer_family": "ocean_mission",
        "source_provider": point.get("source_provider") or source_provider,
        "source_cycle": point.get("source_cycle"),
        "source_time_utc": point.get("source_time_utc") or point.get("resolved_time") or point.get("valid_time"),
        "raw_sst_c": sst_c,
        "raw_u_ms": u,
        "raw_v_ms": v,
        "norm_sst_f": round(sst_f, 2) if sst_f is not None else None,
        "norm_current_speed_m_s": round(speed_ms, 5) if speed_ms is not None else None,
        "norm_current_speed_kt": round(speed_kt, 4) if speed_kt is not None else None,
        "norm_current_dir_deg": round(dir_deg, 2) if dir_deg is not None else None,
        "derived_water_mask": water,
        "derived_land_mask": not water,
        "derived_mask_method": point.get("mask") or (REASON_SST_VALID_WATER if water else REASON_SST_INVALID_LAND),
        "derived_current_label": display_current(speed_kt, dir_deg),
        "derived_temp_band": point.get("derived_temp_band") or ("cold" if sst_c is not None and sst_c < 13 else "warm" if sst_c is not None and sst_c > 22 else "temperate" if sst_c is not None else None),
        "score_bait": round(max(0.0, min(1.0, bait_score)), 4),
        "score_boater_safety": safety_score,
        "score_shark_activity": shark_score,
        "status_ocean": STATUS_READY if water else STATUS_UNRESOLVED,
        "status_mask": STATUS_READY if water else STATUS_UNRESOLVED,
        "reason_mask": REASON_SST_VALID_WATER if water else REASON_SST_INVALID_LAND,
        "display_temp": display_temp_f(sst_f),
        "display_current": display_current(speed_kt, dir_deg),
        "display_summary": point.get("display_summary") or "Ocean intel cell ready" if water else "Ocean cell unresolved",
    }


def apply_ocean_contract(point: dict[str, Any], *, source_provider: str = SOURCE_RTOFS_SURFACE) -> dict[str, Any]:
    point.update(normalized_ocean_cell(point, source_provider=source_provider))
    return point


def normalized_inland_temp(point: Mapping[str, Any]) -> dict[str, Any]:
    temp_f = _num(point.get("norm_temp_f", point.get("water_temp_f", point.get("temp_f", point.get("temperature_f")))))
    temp_c = _num(point.get("raw_temp_c", point.get("water_temp_c", point.get("temp_c"))))
    if temp_f is None and temp_c is not None:
        temp_f = (temp_c * 9.0 / 5.0) + 32.0
    source = point.get("source_temp") or point.get("temp_source") or point.get("source") or SOURCE_CACHED_INLAND_TEMP
    status = point.get("status_temp") or point.get("temp_status") or (STATUS_READY if temp_f is not None else STATUS_UNRESOLVED)
    reason = point.get("reason_temp") or point.get("temp_reason") or ("temp_available" if temp_f is not None else STATUS_UNRESOLVED)
    return {
        "layer_family": "inland_water",
        "source_temp": source,
        "source_temp_level": point.get("source_temp_level") or point.get("temp_level"),
        "source_time_utc": point.get("source_time_utc") or point.get("resolved_time") or point.get("valid_time"),
        "raw_temp_k": point.get("raw_temp_k") or point.get("temp_k"),
        "norm_temp_f": round(temp_f, 2) if temp_f is not None else None,
        "derived_temp_band": point.get("derived_temp_band") or ("cold" if temp_f is not None and temp_f < 55 else "warm" if temp_f is not None and temp_f > 75 else "mild" if temp_f is not None else None),
        "status_temp": status,
        "reason_temp": reason,
        "display_temp": display_temp_f(temp_f),
        "display_name": point.get("display_name") or point.get("name") or point.get("lake_name"),
        "display_summary": point.get("display_summary") or ("Lake temp ready" if temp_f is not None else "Lake temp unresolved"),
    }


def apply_inland_temp_contract(point: dict[str, Any]) -> dict[str, Any]:
    point.update(normalized_inland_temp(point))
    return point

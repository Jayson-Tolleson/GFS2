from __future__ import annotations

"""Live-first /gfs frame contract.

This is the cleanup bridge away from scene-cache as product state.  It keeps a
small HTTP request/inflight guard outside this module, but the payload truth is
live provider execution for the requested layers/bbox.  The old scene-cache and
cache-refresh routes may remain as manual compatibility while the browser moves
onto /gfs/api/live-frame.
"""

import time
from typing import Any

from server.gfs.pipeline import normalize_scene_layers


def _empty_layer(name: str, bbox: dict[str, float] | None, reason: str, exc: BaseException | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {
        "ok": False,
        "source": f"live_frame_{name}_unavailable",
        "payload_state": "error" if exc else "empty",
        "status": "unavailable",
        "reason": reason,
        "bbox": bbox,
        "items": [],
        "features": [],
        "points": [],
        "polygons": [],
        "boats": [],
        "cache": {"hit": False, "mode": "live_frame_no_product_cache"},
    }
    if exc is not None:
        out["error"] = str(exc)[:1200]
    if name == "bait":
        out["bait"] = {"status": "unavailable", "source": out["source"], "polygons": []}
        out["bait_score"] = []
        out["advanced_bait_rows"] = []
    return out


def _has_ocean(layers: list[str]) -> bool:
    return any(x in {"bait", "boater", "boats", "current", "ocean", "shark-intel"} for x in layers)


def _layer_counts(payload: dict[str, Any]) -> dict[str, Any]:
    layers = payload.get("layers") if isinstance(payload.get("layers"), dict) else {}
    out: dict[str, Any] = {}
    for name, layer in layers.items():
        if not isinstance(layer, dict):
            continue
        bait = layer.get("bait") if isinstance(layer.get("bait"), dict) else {}
        out[name] = {
            "source": layer.get("source"),
            "payload_state": layer.get("payload_state") or layer.get("status") or layer.get("mode"),
            "cache_hit": ((layer.get("cache") or {}).get("hit") if isinstance(layer.get("cache"), dict) else None),
            "items": len(layer.get("items") or layer.get("features") or []),
            "points": len(layer.get("points") or layer.get("current_points") or layer.get("ocean_points") or []),
            "polygons": len(layer.get("polygons") or bait.get("polygons") or layer.get("zones") or []),
            "boats": len(layer.get("boats") or []),
        }
    return out


def live_frame_payload(
    svc: Any,
    bbox: dict[str, float] | None,
    visible_bbox: dict[str, float] | None,
    layers: list[str] | tuple[str, ...] | None,
    *,
    reason: str = "live_frame",
    timeout_hint_ms: int | None = None,
) -> dict[str, Any]:
    started = time.time()
    selected_layers = normalize_scene_layers(layers)
    b = svc._normalize_bbox(bbox) if hasattr(svc, "_normalize_bbox") else bbox
    vis = visible_bbox or b
    out: dict[str, Any] = {
        "ok": True,
        "schema": "lftr_gfs_live_frame_v1",
        "source": "live_first_provider_frame_no_scene_cache_truth",
        "mode": "live_provider_truth",
        "reason": reason,
        "bbox": b,
        "visible_bbox": vis,
        "selected_layers": selected_layers,
        "layers": {},
        "cache": {"hit": False, "mode": "no_product_scene_cache", "allowed_guard": "inflight_dedupe_short_runtime_only"},
        "pipeline": {
            "get_data": "/gfs/api/live-frame",
            "save_data": "none_for_product_truth",
            "compile_data": "live_provider_payload_normalization",
            "draw_data": "browser layer engine consumes frame.layers",
            "request_policy": "provider truth is live; cache is not product state",
        },
    }

    # One live NCSS/GFS draw can feed clouds, rain, lightning hints, and
    # jetstream balloons.  Do it at most once for this request.
    weather_payload: dict[str, Any] | None = None
    if any(x in selected_layers for x in ("clouds", "rain", "jetstream")):
        try:
            if hasattr(svc, "_cloud_tiles_payload_heavy"):
                weather_payload = svc._cloud_tiles_payload_heavy(b, vis, force_live=True)
            else:
                weather_payload = svc.generate_weather_payload(b, force_live=True)
            weather_payload.setdefault("cache", {"hit": False})
            weather_payload.setdefault("source", weather_payload.get("source") or "live_ncss_gfs")
            weather_payload["live_frame_source"] = "/gfs/api/live-frame"
            weather_payload.setdefault("cache", {})["mode"] = "live_frame_no_scene_cache"
        except BaseException as exc:
            weather_payload = _empty_layer("clouds", b, "live_ncss_failed", exc)

    if "clouds" in selected_layers:
        out["layers"]["clouds"] = weather_payload or _empty_layer("clouds", b, "not_requested")
    if "rain" in selected_layers:
        rain = dict(weather_payload or {})
        rain.setdefault("source", "live_ncss_gfs_precip")
        rain.setdefault("precip_columns", (weather_payload or {}).get("precip_columns") or [])
        rain.setdefault("rain", (weather_payload or {}).get("rain") or {"items": [], "count": 0})
        rain.setdefault("cache", {})["mode"] = "live_frame_no_scene_cache"
        out["layers"]["rain"] = rain
    if "jetstream" in selected_layers:
        jet = dict((weather_payload or {}).get("balloons") if isinstance((weather_payload or {}).get("balloons"), dict) else {})
        if not jet:
            jet = {"ok": False, "items": [], "count": 0, "source": "live_frame_no_jetstream_vectors"}
        jet.setdefault("cache", {"hit": False, "mode": "live_frame_no_scene_cache"})
        out["layers"]["jetstream"] = jet

    if "lightning" in selected_layers:
        # Lightning is a standalone, opt-in layer. It is not requested on first
        # paint, but when the pill asks for it we call the GLM cache-first
        # contract. The GLM NetCDF reader remains disabled/deferred by default
        # unless the environment explicitly enables it, so the web process does
        # not block clouds/rain or crash first paint.
        try:
            if hasattr(svc, "lightning_payload"):
                lightning = svc.lightning_payload(b, vis, 20)
            else:
                lightning = {"ok": False, "schema": "lftr_lightning_v1", "source": "live_frame_no_lightning_provider", "payload_state": "unavailable", "flashes": [], "items": [], "regions": [], "count": 0}
            if isinstance(lightning, dict):
                lightning.setdefault("schema", "lftr_lightning_v1")
                lightning.setdefault("source", "goes_glm_l2_lcfa_cache_first")
                lightning.setdefault("flashes", lightning.get("items") or [])
                lightning.setdefault("items", lightning.get("flashes") or [])
                lightning.setdefault("regions", [])
                lightning.setdefault("count", len(lightning.get("flashes") or lightning.get("items") or []))
                lightning.setdefault("cache", {"hit": False, "mode": "glm_cache_first_no_scene_cache_truth"})
                lightning["live_frame_source"] = "/gfs/api/live-frame"
                lightning["layer_policy"] = "standalone_opt_in_not_first_render_block"
                out["layers"]["lightning"] = lightning
            else:
                out["layers"]["lightning"] = {"ok": False, "schema": "lftr_lightning_v1", "source": "live_frame_bad_lightning_payload", "payload_state": "bad_payload", "flashes": [], "items": [], "regions": [], "count": 0}
        except BaseException as exc:
            out["layers"]["lightning"] = {
                "ok": False,
                "schema": "lftr_lightning_v1",
                "source": "live_frame_lightning_error",
                "payload_state": "error",
                "error": str(exc)[:1200],
                "flashes": [],
                "items": [],
                "regions": [],
                "count": 0,
                "cache": {"hit": False, "mode": "glm_cache_first_no_scene_cache_truth"},
                "layer_policy": "standalone_opt_in_not_first_render_block",
            }

    # RTOFS ocean mission.  Bait uses its own live solve.  Boater/current share a
    # single live ocean payload where possible; no scene-cache bridge is required.
    ocean_payload: dict[str, Any] | None = None
    if any(x in selected_layers for x in ("boater", "boats", "current", "ocean", "shark-intel")):
        try:
            if hasattr(svc, "_ocean_payload_heavy"):
                ocean_payload = svc._ocean_payload_heavy(b, vis)
            else:
                ocean_payload = svc.ocean_payload(b, vis)
            ocean_payload.setdefault("cache", {"hit": False})["mode"] = "live_frame_no_scene_cache"
        except BaseException as exc:
            ocean_payload = _empty_layer("ocean", b, "live_rtofs_ocean_failed", exc)

    if "bait" in selected_layers:
        try:
            bait = svc._bait_advanced_payload_heavy(b, vis) if hasattr(svc, "_bait_advanced_payload_heavy") else svc.bait_advanced_payload(b, vis)
            bait.setdefault("cache", {"hit": False})["mode"] = "live_frame_no_scene_cache"
            out["layers"]["bait"] = bait
        except BaseException as exc:
            out["layers"]["bait"] = _empty_layer("bait", b, "live_rtofs_bait_failed", exc)

    if any(x in selected_layers for x in ("boater", "boats")):
        try:
            ocean = ocean_payload or {}
            boats = ocean.get("boats") or []
            derived_diag: dict[str, Any] = {}
            if not boats and hasattr(svc, "_boats_from_ocean_points"):
                boats, derived_diag = svc._boats_from_ocean_points(ocean, limit=12)
            boater = {
                "ok": bool(boats or ocean.get("points") or ocean.get("current_points")),
                "source": ocean.get("source") or "live_rtofs_ocean_boater",
                "mode": "live_frame_boater_from_rtofs",
                "bbox": ocean.get("bbox") or b,
                "visible_bbox": vis,
                "boats": boats or [],
                "points": ocean.get("points") or ocean.get("current_points") or [],
                "ocean_points": ocean.get("ocean_points") or ocean.get("points") or [],
                "current_points": ocean.get("current_points") or ocean.get("points") or [],
                "oceanPoints": {"ok": bool(ocean.get("points") or ocean.get("current_points")), "points": ocean.get("points") or ocean.get("current_points") or [], "count": len(ocean.get("points") or ocean.get("current_points") or [])},
                "oceanAnalysisPoints": {"ok": bool(ocean.get("points") or ocean.get("current_points")), "points": ocean.get("points") or ocean.get("current_points") or [], "count": len(ocean.get("points") or ocean.get("current_points") or [])},
                "count": len(boats or []),
                "diagnostics": {**(ocean.get("diagnostics") or {}), "boater": derived_diag},
                "cache": {"hit": False, "mode": "live_frame_no_scene_cache"},
                "payload_state": ocean.get("payload_state") or "live",
            }
            out["layers"]["boater"] = boater
        except BaseException as exc:
            out["layers"]["boater"] = _empty_layer("boater", b, "live_boater_failed", exc)

    if "current" in selected_layers:
        current = dict(ocean_payload or {})
        current.setdefault("source", "live_rtofs_current")
        current.setdefault("points", current.get("current_points") or current.get("points") or [])
        current.setdefault("current_points", current.get("points") or [])
        current.setdefault("cache", {})["mode"] = "live_frame_no_scene_cache"
        out["layers"]["current"] = current

    if "shark-intel" in selected_layers:
        # Keep shark intel non-blocking during this cleanup pass.  It can read the
        # bait/ocean layer result on the client/server once live-frame stabilizes.
        shark = dict(out["layers"].get("bait") or ocean_payload or {})
        shark.setdefault("source", "live_frame_shark_intel_from_ocean_bait_context")
        shark.setdefault("cache", {})["mode"] = "live_frame_no_scene_cache"
        out["layers"]["shark-intel"] = shark

    out["latency_ms"] = int((time.time() - started) * 1000)
    out["render_debug"] = {
        "schema": "lftr_live_frame_debug_v1",
        "selected_layers": selected_layers,
        "layer_count": len(selected_layers),
        "ocean_requested": _has_ocean(selected_layers),
        "layers": _layer_counts(out),
        "timeout_hint_ms": timeout_hint_ms,
        "policy": "live_provider_truth_no_scene_cache_no_cache_refresh_train",
    }
    return out

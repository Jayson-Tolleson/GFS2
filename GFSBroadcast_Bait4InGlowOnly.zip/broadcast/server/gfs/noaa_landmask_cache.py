from __future__ import annotations

"""Long-lived NOAA shoreline/landmask artifact cache.

This module intentionally separates the expensive/stable coastline artifact from
RTOFS physics.  It downloads/stores a NOAA/NCEI GSHHG archive at most once per
long TTL and exposes small metadata that ocean renderers/providers can inspect
on boot.  The first use is a cache contract rail; polygon clipping can then be
wired against the saved artifact without re-fetching a stable land dataset on
every server start.
"""

import json
import os
import time
from pathlib import Path
from typing import Any

try:
    import requests
except Exception:  # pragma: no cover
    requests = None

DEFAULT_TTL_SECONDS = int(os.getenv("GFS_NOAA_LANDMASK_TTL_SECONDS", str(3650 * 24 * 3600)) or str(3650 * 24 * 3600))
DEFAULT_TIMEOUT_SECONDS = float(os.getenv("GFS_NOAA_LANDMASK_TIMEOUT_SECONDS", "15") or "15")
# Stable land/island geometry should be fetched once, cached for years, then reused.
# Try explicit env first, NOAA/NCEI versioned GSHHG next, then public mirrors/fallbacks.
DEFAULT_URLS = [
    os.getenv("GFS_NOAA_LANDMASK_URL", "").strip(),
    "https://www.ngdc.noaa.gov/mgg/shorelines/data/gshhg/latest/gshhg-shp-2.3.7.zip",
    "https://www.soest.hawaii.edu/pwessel/gshhg/gshhg-shp-2.3.7.zip",
    # Fallback rail: not NOAA, but stable global land polygons if NOAA is down.
    "https://naturalearth.s3.amazonaws.com/10m_physical/ne_10m_land.zip",
]


def _now() -> int:
    return int(time.time())


def _json_read(path: Path) -> dict[str, Any]:
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception:
        pass
    return {}


def _json_write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True))


def landmask_cache_dir(base_dir: str | Path | None = None) -> Path:
    root = Path(base_dir) if base_dir else Path.cwd()
    # If caller passes static dir (/app/static), use app root sibling cache.
    if root.name == "static":
        root = root.parent
    return root / ".cache" / "ocean_landmask" / "noaa_gshhg"


def ensure_noaa_landmask_cache(base_dir: str | Path | None = None, *, force: bool = False, fetch: bool = True) -> dict[str, Any]:
    """Ensure the long-lived NOAA/GSHHG artifact exists or is intentionally stubbed.

    Returns metadata only; it never parses shapefiles.  The download is skipped
    when a non-empty archive exists and is younger than TTL.  On network failure,
    a status file is still written so boot diagnostics can show that the cache
    check happened without blocking app startup.
    """
    cdir = landmask_cache_dir(base_dir)
    cdir.mkdir(parents=True, exist_ok=True)
    archive = cdir / "gshhg-shp-latest.zip"
    meta_path = cdir / "metadata.json"
    meta = _json_read(meta_path)
    now = _now()
    age = now - int(meta.get("checked_at", 0) or 0)
    archive_ok = archive.exists() and archive.stat().st_size > 100_000
    if archive_ok and not force and age < DEFAULT_TTL_SECONDS:
        meta.update({
            "ok": True,
            "status": "cached",
            "cache_hit": True,
            "archive": str(archive),
            "archive_bytes": archive.stat().st_size,
            "age_sec": age,
            "ttl_sec": DEFAULT_TTL_SECONDS,
            "contract": "noaa_gshhg_landmask_artifact_cached_long_ttl_boot_checked_once",
        })
        _json_write(meta_path, meta)
        return meta

    if not fetch or requests is None:
        out = {
            "ok": bool(archive_ok),
            "status": "cached" if archive_ok else "not_fetched",
            "cache_hit": bool(archive_ok),
            "archive": str(archive),
            "archive_bytes": archive.stat().st_size if archive.exists() else 0,
            "checked_at": now,
            "ttl_sec": DEFAULT_TTL_SECONDS,
            "source": "NOAA_NCEI_GSHHG",
            "policy": "boot_check_only_no_fetch; set GFS_NOAA_LANDMASK_URL or call with fetch=true to materialize",
            "contract": "noaa_gshhg_landmask_artifact_cached_long_ttl_boot_checked_once",
        }
        _json_write(meta_path, out)
        return out

    last_error = None
    attempted_urls: list[str] = []
    for url in [u for u in DEFAULT_URLS if u]:
        attempted_urls.append(url)
        try:
            headers = {"User-Agent": "LFTR-GFS/1.0 (+https://lftr.biz)"}
            with requests.get(url, timeout=DEFAULT_TIMEOUT_SECONDS, stream=True, headers=headers) as r:
                r.raise_for_status()
                tmp = archive.with_suffix(".zip.tmp")
                total = 0
                with tmp.open("wb") as f:
                    for chunk in r.iter_content(chunk_size=1024 * 512):
                        if not chunk:
                            continue
                        total += len(chunk)
                        f.write(chunk)
                        if total > int(os.getenv("GFS_NOAA_LANDMASK_MAX_BYTES", "120000000")):
                            raise RuntimeError("NOAA landmask archive exceeded max byte guard")
                if total < 100_000:
                    raise RuntimeError(f"NOAA landmask archive too small: {total}")
                tmp.replace(archive)
                out = {
                    "ok": True,
                    "status": "downloaded",
                    "cache_hit": False,
                    "archive": str(archive),
                    "archive_bytes": archive.stat().st_size,
                    "checked_at": now,
                    "ttl_sec": DEFAULT_TTL_SECONDS,
                    "url": url,
                    "source": "NOAA_NCEI_GSHHG" if "gshhg" in url.lower() or "ngdc" in url.lower() else "NATURAL_EARTH_FALLBACK",
                    "attempted_urls": attempted_urls,
                    "policy": "download_once_then_reuse_long_ttl; ocean clipping should read this artifact rather than refetching coastline",
                    "contract": "noaa_gshhg_landmask_artifact_cached_long_ttl_boot_checked_once",
                }
                _json_write(meta_path, out)
                return out
        except Exception as exc:  # pragma: no cover - network-dependent
            last_error = str(exc)
            continue

    out = {
        "ok": bool(archive_ok),
        "status": "cached_stale" if archive_ok else "download_failed",
        "cache_hit": bool(archive_ok),
        "archive": str(archive),
        "archive_bytes": archive.stat().st_size if archive.exists() else 0,
        "checked_at": now,
        "ttl_sec": DEFAULT_TTL_SECONDS,
        "source": "NOAA_NCEI_GSHHG",
        "attempted_urls": attempted_urls,
        "error": last_error,
        "policy": "do_not_block_boot; retry after TTL/force; RTOFS finite-cell mask remains active until coastline artifact is present",
        "contract": "noaa_gshhg_landmask_artifact_cached_long_ttl_boot_checked_once",
    }
    _json_write(meta_path, out)
    return out

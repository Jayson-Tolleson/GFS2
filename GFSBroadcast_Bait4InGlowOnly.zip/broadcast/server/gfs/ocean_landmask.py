from __future__ import annotations

import math
from typing import Any


def finite_num(value: Any) -> float:
    try:
        v = float(value)
        return v if math.isfinite(v) else float('nan')
    except Exception:
        return float('nan')


def plausible_sst_c(value: Any) -> float:
    """Return SST in Celsius only when it is physically plausible ocean water.

    The old mask treated every finite SST value as water.  Some products expose
    fill/sentinel values, Kelvin values, or decoded land cells as finite numbers;
    that can invert bait onto land.  This guard accepts normal Celsius SST and
    converts plausible Kelvin SST, rejecting land/fill sentinels.
    """
    v = finite_num(value)
    if not math.isfinite(v):
        return float('nan')
    # Common fill/missing sentinels decoded as finite numbers.
    if abs(v) >= 9.0e3 or v in {-999.0, -9999.0, 999.0, 9999.0}:
        return float('nan')
    # Kelvin products: convert only physically plausible ocean surface range.
    if 250.0 <= v <= 330.0:
        v = v - 273.15
    # Celsius ocean surface sanity range.  Keep polar water, reject impossible
    # land/fill/atmospheric values.
    if -3.0 <= v <= 45.0:
        return v
    return float('nan')


def plausible_current_ms(value: Any) -> float:
    v = finite_num(value)
    if not math.isfinite(v) or abs(v) >= 9.0e3:
        return float('nan')
    # RTOFS surface currents should be small; allow storm/strait extremes but
    # reject fill values masquerading as finite water.
    return v if abs(v) <= 8.0 else float('nan')


def grid_shape(grid: list[list[Any]] | None) -> tuple[int, int]:
    if not grid:
        return 0, 0
    return len(grid), len(grid[0]) if grid and grid[0] else 0


def ocean_mask_from_grids(
    *,
    sst: list[list[Any]] | None = None,
    current_u: list[list[Any]] | None = None,
    current_v: list[list[Any]] | None = None,
    salinity: list[list[Any]] | None = None,
) -> tuple[list[list[bool]], dict[str, Any]]:
    """Build the shared ocean/land gate for SST, currents, bait, boats, and shark intel.

    Policy:
    - finite SST is the highest-trust water mask;
    - when SST is unavailable, finite paired current U/V can keep a strict live-current mask;
    - salinity is only a last supporting signal, never enough to override an SST NaN.
    """
    grids = [g for g in (sst, current_u, current_v, salinity) if g]
    if not grids:
        return [], {"enabled": True, "method": "no_source_grid", "shape": [0, 0], "water_cells": 0, "land_cells": 0}
    ny = max(grid_shape(g)[0] for g in grids)
    nx = max(grid_shape(g)[1] for g in grids)
    out: list[list[bool]] = []
    water = 0
    land = 0
    used_sst = bool(sst)
    used_current = bool(current_u and current_v)
    used_salinity = bool(salinity)

    def val(grid: list[list[Any]] | None, y: int, x: int) -> float:
        if not grid or y >= len(grid) or y < 0:
            return float('nan')
        row = grid[y]
        if not row or x >= len(row) or x < 0:
            return float('nan')
        return finite_num(row[x])

    for y in range(ny):
        row: list[bool] = []
        for x in range(nx):
            s = plausible_sst_c(val(sst, y, x))
            if used_sst:
                ok = math.isfinite(s)
            else:
                u = plausible_current_ms(val(current_u, y, x))
                v = plausible_current_ms(val(current_v, y, x))
                sal = val(salinity, y, x)
                # Salinity is support only.  Never let salinity alone create bait
                # water; paired plausible U/V is the only fallback when SST is absent.
                ok = (used_current and math.isfinite(u) and math.isfinite(v))
            row.append(bool(ok))
            if ok:
                water += 1
            else:
                land += 1
        out.append(row)
    total = water + land
    return out, {
        "enabled": True,
        "method": "plausible_sst_c_primary_paired_current_secondary",
        "shape": [ny, nx],
        "water_cells": water,
        "land_cells": land,
        "water_fraction": round(water / total, 4) if total else 0.0,
        "sst_primary": used_sst,
        "current_secondary": used_current,
        "salinity_support": used_salinity,
    }


def mask_grid(grid: list[list[Any]] | None, mask: list[list[bool]] | None, *, fill: float = float('nan')) -> list[list[float]]:
    if not grid:
        return []
    if not mask:
        return [[finite_num(v) for v in row] for row in grid]
    out: list[list[float]] = []
    for y, row in enumerate(grid):
        mrow = mask[y] if y < len(mask) else []
        new: list[float] = []
        for x, value in enumerate(row):
            ok = bool(mrow[x]) if x < len(mrow) else False
            new.append(finite_num(value) if ok else fill)
        out.append(new)
    return out


def resample_mask_nearest(mask: list[list[bool]] | None, ny: int, nx: int) -> list[list[bool]]:
    src_ny = len(mask or [])
    src_nx = len(mask[0]) if src_ny and mask and mask[0] else 0
    if src_ny < 1 or src_nx < 1 or ny < 1 or nx < 1:
        return [[False for _ in range(max(0, nx))] for __ in range(max(0, ny))]
    out: list[list[bool]] = []
    for y in range(ny):
        sy = min(src_ny - 1, max(0, int(y * src_ny / ny)))
        row: list[bool] = []
        for x in range(nx):
            sx = min(src_nx - 1, max(0, int(x * src_nx / nx)))
            row.append(bool(mask[sy][sx]))
        out.append(row)
    return out


def mask_stats(mask: list[list[bool]] | None) -> dict[str, Any]:
    ny = len(mask or [])
    nx = len(mask[0]) if ny and mask and mask[0] else 0
    water = sum(1 for row in (mask or []) for v in row if v)
    total = ny * nx
    return {"shape": [ny, nx], "water_cells": water, "land_cells": max(0, total - water), "water_fraction": round(water / total, 4) if total else 0.0}


def erode_ocean_mask(mask: list[list[bool]] | None, cells: int = 1) -> tuple[list[list[bool]], dict[str, Any]]:
    """Shrink water mask inward so render layers do not use shoreline/land-adjacent cells.

    RTOFS/OISST SST is coarser than Google 3D coastline. Finite SST is good
    water truth, but a finite coastal cell can visually overlap land. Eroding
    the mask by one cell gives downstream renderers an interior-water gate.
    """
    src = mask or []
    ny = len(src)
    nx = len(src[0]) if ny and src[0] else 0
    if ny < 1 or nx < 1 or int(cells or 0) <= 0:
        water = sum(1 for row in src for v in row if v)
        total = ny * nx
        return [[bool(v) for v in row] for row in src], {
            "enabled": bool(src), "cells": 0, "shape": [ny, nx],
            "water_cells_before": water, "water_cells_after": water,
            "rejected_edge_cells": 0, "water_fraction_after": round(water / total, 4) if total else 0.0,
        }
    cur = [[bool(v) for v in row] for row in src]
    before = sum(1 for row in cur for v in row if v)
    for _ in range(max(1, int(cells or 1))):
        out = [[False for _ in range(nx)] for __ in range(ny)]
        for y in range(ny):
            for x in range(nx):
                if not cur[y][x]:
                    continue
                ok = True
                for yy in range(max(0, y - 1), min(ny, y + 2)):
                    for xx in range(max(0, x - 1), min(nx, x + 2)):
                        if not cur[yy][xx]:
                            ok = False
                            break
                    if not ok:
                        break
                out[y][x] = ok
        cur = out
    after = sum(1 for row in cur for v in row if v)
    total = ny * nx
    return cur, {
        "enabled": True,
        "cells": max(1, int(cells or 1)),
        "shape": [ny, nx],
        "water_cells_before": before,
        "water_cells_after": after,
        "rejected_edge_cells": max(0, before - after),
        "water_fraction_after": round(after / total, 4) if total else 0.0,
        "contract": "finite_sst_mask_eroded_to_interior_water_before_any_render_layer",
    }


def _lon180(value: Any) -> float:
    v = finite_num(value)
    if not math.isfinite(v):
        return v
    # Normalize 0..360 products back into the LFTR -180..180 viewport domain.
    return ((v + 180.0) % 360.0) - 180.0


def mask_water_fraction_for_bbox(
    mask: list[list[bool]] | None,
    lat_values: list[Any] | None,
    lon_values: list[Any] | None,
    bbox: dict[str, Any] | list[Any] | tuple[Any, ...],
) -> dict[str, Any]:
    """Return SST-valid water coverage for one tile bbox.

    This is intentionally small and data-shaped: it treats finite/true SST mask
    cells as ocean evidence and never invents water over land.  It supports the
    regular 1-D lat/lon coordinate arrays emitted by the RTOFS warmer.
    """
    src = mask or []
    ny = len(src)
    nx = len(src[0]) if ny and src[0] else 0
    lats = list(lat_values or [])
    lons = list(lon_values or [])
    if not (ny and nx and len(lats) >= ny and len(lons) >= nx):
        return {"ok": False, "reason": "mask_or_coords_missing", "cells": 0, "water_cells": 0, "water_fraction": 0.0}
    if isinstance(bbox, dict):
        west = finite_num(bbox.get("west", bbox.get("minLon")))
        south = finite_num(bbox.get("south", bbox.get("minLat")))
        east = finite_num(bbox.get("east", bbox.get("maxLon")))
        north = finite_num(bbox.get("north", bbox.get("maxLat")))
    else:
        west, south, east, north = [finite_num(x) for x in list(bbox)[:4]]
    if not all(math.isfinite(x) for x in (west, south, east, north)):
        return {"ok": False, "reason": "invalid_bbox", "cells": 0, "water_cells": 0, "water_fraction": 0.0}
    lo_lat, hi_lat = min(south, north), max(south, north)
    lo_lon, hi_lon = min(_lon180(west), _lon180(east)), max(_lon180(west), _lon180(east))
    total = 0
    water = 0
    for y in range(ny):
        lat = finite_num(lats[y])
        if not math.isfinite(lat) or lat < lo_lat or lat > hi_lat:
            continue
        row = src[y]
        for x in range(nx):
            lon = _lon180(lons[x])
            if not math.isfinite(lon) or lon < lo_lon or lon > hi_lon:
                continue
            total += 1
            if x < len(row) and row[x]:
                water += 1
    return {
        "ok": True,
        "method": "sst_valid_mask_cells_inside_tile_bbox",
        "cells": total,
        "water_cells": water,
        "land_or_missing_cells": max(0, total - water),
        "water_fraction": round((water / total), 4) if total else 0.0,
    }


def annotate_tiles_with_ocean_mask(
    tiles: list[dict[str, Any]] | None,
    mask_payload: dict[str, Any] | None,
    *,
    min_water_fraction: float = 0.0,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Attach SST-mask water_fraction to provider tiles and skip land-only tiles.

    The fixed 6x6 plan remains the contract.  This only changes which of those
    possible tiles deserve an RTOFS/RTOFS provider request after an SST-valid
    ocean mask exists for the same viewport/cycle.
    """
    in_tiles = list(tiles or [])
    mp = mask_payload or {}
    mask = mp.get("mask") or mp.get("ocean_mask") or []
    lats = mp.get("lat_values") or []
    lons = mp.get("lon_values") or []
    if not (mask and lats and lons):
        return in_tiles, {
            "enabled": False,
            "reason": "sst_mask_cache_missing",
            "tiles_total": len(in_tiles),
            "tiles_requested_ocean": len(in_tiles),
            "tiles_skipped_land": 0,
            "policy": "no_quality_reduction_without_mask",
        }
    requested: list[dict[str, Any]] = []
    skipped = 0
    annotated: list[dict[str, Any]] = []
    for tile in in_tiles:
        stats = mask_water_fraction_for_bbox(mask, lats, lons, tile)
        t = dict(tile)
        wf = float(stats.get("water_fraction") or 0.0)
        t["ocean_mask"] = stats
        t["water_fraction"] = wf
        if stats.get("ok") and wf <= float(min_water_fraction):
            t["request"] = False
            t["skip_reason"] = "sst_mask_no_water"
            skipped += 1
            annotated.append(t)
            continue
        t["request"] = True
        t["skip_reason"] = None
        requested.append(t)
        annotated.append(t)
    return requested, {
        "enabled": True,
        "method": "rtofs_sst_validity_mask_ocean_only_provider_tile_plan",
        "mask_source": mp.get("mask_source") or mp.get("source") or "rtofs_sst_validity",
        "mask_cycle": mp.get("cycle") or mp.get("resolved_time"),
        "mask_bbox": mp.get("bbox"),
        "mask_grid_shape": mp.get("grid_shape") or mask_stats(mask).get("shape"),
        "min_water_fraction": float(min_water_fraction),
        "tiles_total": len(in_tiles),
        "tiles_requested_ocean": len(requested),
        "tiles_skipped_land": skipped,
        "tiles_annotated_preview": annotated[: min(len(annotated), 12)],
        "contract": "fixed_36_possible_tiles_sst_mask_skips_land_only_tiles_without_lowering_ocean_quality",
    }

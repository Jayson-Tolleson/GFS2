from __future__ import annotations

"""LFTR Unified Ocean Truth Interpolator.

This module is the marine source-of-truth layer.  It deliberately does not
make bait fish or boat glyphs.  It assembles ocean-connected bathymetry,
RTOFS surface/3D candidate metadata, and late-arriving chlorophyll into a
continuous query contract:

    OceanTruth.sample(lon, lat, depth_m, time)

The HTTP payload is still compact sampled evidence because browsers and APIs
need finite transport.  Those samples are *not* the truth; they are anchors for
renderers and marching-cubes/adaptive sampling products.
"""

import json
import math
import os
import threading
import time
from pathlib import Path
from typing import Any

from server.gfs.bathymetry_tiles import bathymetry_tiles_payload
from server.gfs.models import BBox
from server.gfs.rtofs_source import load_cached_rtofs_surface, spawn_rtofs_surface_warmer
from server.gfs.rtofs_3d_truth import (
    compact_rtofs_3d_status,
    load_cached_rtofs_3d_truth,
    sample_cached_rtofs_3d,
    spawn_rtofs_3d_truth_warmer,
)

FT_PER_M = 3.280839895
KT_PER_MS = 1.9438444924406
CHL_TTL_S = int(float(os.getenv("GFS_OCEAN_TRUTH_CHL_TTL_S", str(8 * 3600))) or 8 * 3600)
_CHL_JOBS: dict[str, dict[str, Any]] = {}
_CHL_LOCK = threading.Lock()


def _finite(value: Any, default: float | None = None) -> float | None:
    try:
        f = float(value)
        return f if math.isfinite(f) else default
    except Exception:
        return default


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _norm_lon(lon: Any) -> float:
    n = _finite(lon, 0.0) or 0.0
    return ((float(n) + 180.0) % 360.0) - 180.0


def _bbox_dict(bbox: Any) -> dict[str, float]:
    if isinstance(bbox, dict):
        return {
            "west": float(bbox.get("west", bbox.get("minLon", -125))),
            "south": float(bbox.get("south", bbox.get("minLat", 32))),
            "east": float(bbox.get("east", bbox.get("maxLon", -117))),
            "north": float(bbox.get("north", bbox.get("maxLat", 38))),
        }
    if isinstance(bbox, str):
        parts = [float(x.strip()) for x in bbox.split(",") if x.strip()]
        if len(parts) >= 4:
            return {"west": parts[0], "south": parts[1], "east": parts[2], "north": parts[3]}
    if isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
        return {"west": float(bbox[0]), "south": float(bbox[1]), "east": float(bbox[2]), "north": float(bbox[3])}
    return {"west": -125.0, "south": 32.0, "east": -117.0, "north": 38.0}


def _bbox_list(b: dict[str, float]) -> list[float]:
    return [float(b["west"]), float(b["south"]), float(b["east"]), float(b["north"])]


def _bbox_key(b: dict[str, float]) -> str:
    vals = [round(float(b[k]), 2) for k in ("west", "south", "east", "north")]
    return "_".join(f"{v:+07.2f}".replace("+", "p").replace("-", "m").replace(".", "d") for v in vals)


def _lon_span_deg(west: float, east: float) -> float:
    west_n = _norm_lon(west)
    east_n = _norm_lon(east)
    if east_n >= west_n:
        return max(0.001, east_n - west_n)
    return max(0.001, (180.0 - west_n) + (east_n + 180.0))


def _lon_offset_from_west(lon: float, west: float) -> float:
    x = _norm_lon(lon)
    w = _norm_lon(west)
    d = x - w
    if d < 0:
        d += 360.0
    return d


def _bbox_contains_point(bbox: dict[str, float], lat: float, lon: float, *, pad_deg: float = 0.0) -> bool:
    south = min(float(bbox["south"]), float(bbox["north"])) - pad_deg
    north = max(float(bbox["south"]), float(bbox["north"])) + pad_deg
    if lat < south or lat > north:
        return False
    west = _norm_lon(float(bbox["west"]) - pad_deg)
    east = _norm_lon(float(bbox["east"]) + pad_deg)
    x = _norm_lon(lon)
    if west <= east:
        return west <= x <= east
    return x >= west or x <= east


def _cell_center_from_bbox(cb: list[Any]) -> tuple[float, float] | None:
    if not (isinstance(cb, list) and len(cb) >= 4):
        return None
    west, south, east, north = [float(x) for x in cb[:4]]
    return ((south + north) / 2.0, _norm_lon((west + east) / 2.0))


def _cell_intersects_bbox(cell: dict[str, Any], bbox: dict[str, float], *, pad_deg: float = 0.0) -> bool:
    cb = cell.get("bbox") or []
    center = _cell_center_from_bbox(cb)
    if center:
        lat, lon = center
    else:
        lat = float(cell.get("lat") or 0.0)
        lon = _norm_lon(cell.get("lon") or 0.0)
    if _bbox_contains_point(bbox, lat, lon, pad_deg=pad_deg):
        return True
    if isinstance(cb, list) and len(cb) >= 4:
        west, south, east, north = [float(x) for x in cb[:4]]
        for la in (south, north):
            for lo in (west, east):
                if _bbox_contains_point(bbox, la, lo, pad_deg=pad_deg):
                    return True
    return False


def _is_known_inland_ocean_exclusion(lat: float, lon: float) -> bool:
    boxes = (
        (-117.65, 35.35, -116.15, 37.15),  # Death Valley
        (-116.45, 32.55, -115.15, 34.15),  # Salton Sea / Imperial basin
        (-113.25, 40.35, -111.65, 41.85),  # Great Salt Lake basin guard
    )
    return any(w <= lon <= e and s <= lat <= n for w, s, e, n in boxes)


def _tile_water_cells(tile: dict[str, Any], *, min_water_fraction: float = 0.35, min_depth_m: float = 1.0) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for cell in tile.get("water_cells") or []:
        cb = cell.get("bbox")
        center = _cell_center_from_bbox(cb)
        if not center:
            continue
        depth = _finite(cell.get("depth_m"))
        wf = _finite(cell.get("water_fraction"), 1.0) or 1.0
        if depth is None or depth < min_depth_m or wf < min_water_fraction:
            continue
        if cell.get("renderable") is False or cell.get("ocean_connected") is False:
            continue
        lat, lon = center
        if _is_known_inland_ocean_exclusion(lat, lon):
            continue
        out.append({
            "tile_id": tile.get("tile_id"),
            "r": int(cell.get("r", cell.get("gy", 0)) or 0),
            "c": int(cell.get("c", cell.get("gx", 0)) or 0),
            "bbox": [float(x) for x in cb[:4]],
            "lat": round(lat, 6),
            "lon": round(lon, 6),
            "seafloor_depth_m": round(float(depth), 2),
            "bottom_depth_m": round(float(depth), 2),
            "water_fraction": round(float(wf), 3),
            "ocean_connected": True,
            "renderable": True,
        })
    return out


def _spatially_distribute(cells: list[dict[str, Any]], bbox: dict[str, float], max_samples: int) -> list[dict[str, Any]]:
    if len(cells) <= max_samples:
        return cells
    bucket_count = max(4, min(36, int(math.sqrt(max_samples) or 12)))
    south = min(float(bbox["south"]), float(bbox["north"]))
    north = max(float(bbox["south"]), float(bbox["north"]))
    west = _norm_lon(bbox["west"])
    lat_span = max(0.001, north - south)
    lon_span = _lon_span_deg(float(bbox["west"]), float(bbox["east"]))
    buckets: dict[tuple[int, int], list[dict[str, Any]]] = {}
    for cell in cells:
        lat = float(cell.get("lat") or 0.0)
        lon = _norm_lon(cell.get("lon") or 0.0)
        lat_t = _clamp((lat - south) / lat_span, 0.0, 0.9999)
        lon_t = _clamp(_lon_offset_from_west(lon, west) / lon_span, 0.0, 0.9999)
        key = (int(lat_t * bucket_count), int(lon_t * bucket_count))
        buckets.setdefault(key, []).append(cell)
    for stack in buckets.values():
        stack.sort(key=lambda c: (float(c.get("water_fraction") or 0), float(c.get("seafloor_depth_m") or 0)), reverse=True)
    out: list[dict[str, Any]] = []
    keys = sorted(buckets.keys(), key=lambda k: (k[0], k[1]))
    cursor = 0
    while len(out) < max_samples and keys:
        key = keys[cursor % len(keys)]
        stack = buckets.get(key) or []
        if stack:
            out.append(stack.pop(0))
        if not stack:
            buckets.pop(key, None)
            keys = [k for k in keys if k in buckets]
            cursor = 0
        else:
            cursor += 1
    return out


def _point_lat_lon(p: dict[str, Any]) -> tuple[float | None, float | None]:
    lat = _finite(p.get("lat", p.get("latitude")))
    lon = _finite(p.get("lon", p.get("lng", p.get("longitude"))))
    return lat, lon


def _nearest_surface_point(lat: float, lon: float, points: list[dict[str, Any]]) -> dict[str, Any] | None:
    best: tuple[float, dict[str, Any]] | None = None
    mean_lat = math.radians(lat)
    for p in points or []:
        plat, plon = _point_lat_lon(p)
        if plat is None or plon is None:
            continue
        dx = (_norm_lon(plon) - _norm_lon(lon)) * max(0.25, math.cos(mean_lat))
        dy = float(plat) - lat
        d2 = dx * dx + dy * dy
        if best is None or d2 < best[0]:
            best = (d2, p)
    return best[1] if best else None


def _surface_features(p: dict[str, Any] | None) -> dict[str, Any]:
    p = p or {}
    sst_c = _finite(p.get("sst_c", p.get("water_temp_c", p.get("sst"))))
    if sst_c is not None and sst_c > 150:
        sst_c -= 273.15
    sst_f = _finite(p.get("sst_f", p.get("water_temp_f")))
    if sst_f is None and sst_c is not None:
        sst_f = sst_c * 9.0 / 5.0 + 32.0
    u = _finite(p.get("u_ms", p.get("u", p.get("current_u"))), 0.0) or 0.0
    v = _finite(p.get("v_ms", p.get("v", p.get("current_v"))), 0.0) or 0.0
    speed_kt = _finite(p.get("current_speed_kt", p.get("speed_kt", p.get("speedKt"))))
    if speed_kt is None:
        speed_kt = math.hypot(u, v) * KT_PER_MS
    heading = _finite(p.get("direction_deg", p.get("current_dir_deg", p.get("heading", p.get("dirDeg")))))
    if heading is None:
        heading = (math.degrees(math.atan2(u, v)) + 360.0) % 360.0
    salinity = _finite(p.get("salinity", p.get("sss")))
    return {
        "sst_c": round(sst_c, 3) if sst_c is not None else None,
        "sst_f": round(sst_f, 2) if sst_f is not None else None,
        "salinity": round(salinity, 4) if salinity is not None else None,
        "current_speed_kt": round(float(speed_kt or 0.0), 4),
        "direction_deg": round(float(heading or 0.0), 2),
        "u_ms": round(float(u), 6),
        "v_ms": round(float(v), 6),
        "source_point": p,
    }


def _cache_root(app_root: Path | str | None) -> Path:
    root = Path(app_root or Path.cwd())
    return root / "data_sources" / "ocean_truth" / "chlorophyll_cache"


def _chl_cache_path(app_root: Path | str | None, bbox: dict[str, float]) -> Path:
    return _cache_root(app_root) / f"chl_{_bbox_key(bbox)}.json"


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, separators=(",", ":")))
    tmp.replace(path)


def _load_chlorophyll_cache(app_root: Path | str | None, bbox: dict[str, float]) -> dict[str, Any]:
    path = _chl_cache_path(app_root, bbox)
    data = _read_json(path)
    now = time.time()
    if not isinstance(data, dict):
        return {"status": "missing", "ready": False, "cache_path": str(path), "ttl_s": CHL_TTL_S}
    fetched_at = float(data.get("fetched_at_epoch") or 0.0)
    age = max(0.0, now - fetched_at) if fetched_at else float("inf")
    if age <= CHL_TTL_S and ((data.get("payload") or {}).get("chlorophyll") or []):
        return {"status": "ready", "ready": True, "age_s": int(age), "cache_path": str(path), "ttl_s": CHL_TTL_S, "payload": data.get("payload") or {}}
    if ((data.get("payload") or {}).get("chlorophyll") or []):
        return {"status": "stale", "ready": True, "age_s": int(age), "cache_path": str(path), "ttl_s": CHL_TTL_S, "payload": data.get("payload") or {}}
    return {"status": "empty", "ready": False, "age_s": int(age) if math.isfinite(age) else None, "cache_path": str(path), "ttl_s": CHL_TTL_S}


def _fetch_chlorophyll_worker(app_root: str, bbox: dict[str, float], stride: int, path_text: str, job_key: str) -> None:
    with _CHL_LOCK:
        _CHL_JOBS[job_key] = {"running": True, "started_at": time.time(), "bbox": _bbox_list(bbox)}
    payload: dict[str, Any]
    try:
        from server.gfs.providers.coastwatch import CoastwatchProvider
        provider = CoastwatchProvider()
        payload, _valid_time = provider._fetch_subset_sync(
            bbox=BBox(float(bbox["west"]), float(bbox["south"]), float(bbox["east"]), float(bbox["north"])),
            stride=max(1, int(stride or 6)),
            valid_time=None,
        )
        payload = dict(payload or {})
        payload.setdefault("source_meta", {})["late_injection_cache_ttl_s"] = CHL_TTL_S
        _write_json_atomic(Path(path_text), {"fetched_at_epoch": time.time(), "bbox": _bbox_list(bbox), "payload": payload})
        status = "ready" if payload.get("chlorophyll") else "empty"
        with _CHL_LOCK:
            _CHL_JOBS[job_key] = {"running": False, "completed_at": time.time(), "status": status, "bbox": _bbox_list(bbox), "cache_path": path_text}
    except Exception as exc:
        with _CHL_LOCK:
            _CHL_JOBS[job_key] = {"running": False, "completed_at": time.time(), "status": "error", "error": str(exc), "bbox": _bbox_list(bbox), "cache_path": path_text}


def _spawn_chlorophyll_fetch(app_root: Path | str | None, bbox: dict[str, float], *, stride: int = 6) -> dict[str, Any]:
    path = _chl_cache_path(app_root, bbox)
    key = str(path)
    with _CHL_LOCK:
        job = _CHL_JOBS.get(key)
        if job and job.get("running"):
            return {"started": False, "running": True, "reason": "already_running", **job}
        _CHL_JOBS[key] = {"running": True, "started_at": time.time(), "bbox": _bbox_list(bbox), "cache_path": str(path)}
    thread = threading.Thread(target=_fetch_chlorophyll_worker, args=(str(app_root or Path.cwd()), dict(bbox), stride, str(path), key), daemon=True)
    thread.start()
    return {"started": True, "running": True, "cache_path": str(path), "ttl_s": CHL_TTL_S, "policy": "late chlorophyll warms in background; cached result is reused for 8 hours"}


def _chlorophyll_at(lat: float, lon: float, chl_payload: dict[str, Any] | None, bbox: dict[str, float]) -> float | None:
    grid = (chl_payload or {}).get("chlorophyll") or []
    if not grid or not isinstance(grid, list) or not isinstance(grid[0], list):
        return None
    ny = len(grid)
    nx = len(grid[0]) if ny else 0
    if ny < 1 or nx < 1:
        return None
    south = min(float(bbox["south"]), float(bbox["north"]))
    north = max(float(bbox["south"]), float(bbox["north"]))
    west = _norm_lon(float(bbox["west"]))
    lat_t = _clamp((float(lat) - south) / max(1e-9, north - south), 0.0, 1.0)
    lon_t = _clamp(_lon_offset_from_west(_norm_lon(lon), west) / _lon_span_deg(float(bbox["west"]), float(bbox["east"])), 0.0, 1.0)
    # Most ERDDAP grids return north-to-south when lat_descending=True.
    lat_desc = bool(((chl_payload or {}).get("source_meta") or {}).get("lat_descending", True))
    y = (1.0 - lat_t if lat_desc else lat_t) * (ny - 1)
    x = lon_t * (nx - 1)
    y0 = int(math.floor(y)); x0 = int(math.floor(x))
    y1 = min(ny - 1, y0 + 1); x1 = min(nx - 1, x0 + 1)
    fy = y - y0; fx = x - x0
    vals: list[tuple[float, float]] = []
    for yy, wy in ((y0, 1.0 - fy), (y1, fy)):
        for xx, wx in ((x0, 1.0 - fx), (x1, fx)):
            try:
                v = float(grid[yy][xx])
                if math.isfinite(v) and v >= 0:
                    vals.append((v, wy * wx))
            except Exception:
                pass
    denom = sum(w for _v, w in vals)
    if denom <= 0:
        return None
    return round(sum(v * w for v, w in vals) / denom, 5)


def _depths(depths: Any) -> list[float]:
    if isinstance(depths, str) and depths.strip():
        raw = depths.replace(";", ",").split(",")
    elif isinstance(depths, (list, tuple)):
        raw = depths
    else:
        raw = [0, 5, 10, 20, 35, 50, 75, 100, 150, 200]
    out: list[float] = []
    for d in raw:
        f = abs(_finite(d, float("nan")) or float("nan"))
        if math.isfinite(f) and f not in out:
            out.append(round(_clamp(f, 0, 3000), 3))
    return out or [0, 5, 10, 20, 35, 50, 75, 100]


def _choose_bait_depth_m(bottom_depth_m: float, surface_or_3d: dict[str, Any], chl: float | None) -> float:
    """Pick one bait render anchor depth; this is a sampling decision, not a layer."""
    if bottom_depth_m <= 4.0:
        return max(0.5, bottom_depth_m * 0.45)
    temp = _finite(surface_or_3d.get("temperature_c", surface_or_3d.get("water_temp_c", surface_or_3d.get("sst_c"))))
    speed = _finite(surface_or_3d.get("current_speed_kt", (surface_or_3d.get("current") or {}).get("speedKt")), 0.0) or 0.0
    if bottom_depth_m < 80:
        ideal = _clamp(bottom_depth_m * 0.38, 4.0, 28.0)
    elif bottom_depth_m < 500:
        ideal = 32.0
    else:
        ideal = 44.0
    if temp is not None and temp > 19.5:
        ideal += 8.0
    elif temp is not None and temp < 13.0:
        ideal = max(5.0, ideal - 7.0)
    if chl is not None and chl > 0.75:
        ideal = max(4.0, ideal - 6.0)
    if speed > 1.2:
        ideal += 5.0
    return round(_clamp(ideal, 1.5, max(1.5, bottom_depth_m - 2.0)), 3)


def _truth_sample_from_cell(
    cell: dict[str, Any],
    nearest: dict[str, Any] | None,
    chl: float | None,
    chl_status: str,
    depths_m: list[float],
    rtofs3d_cache: dict[str, Any] | None = None,
) -> dict[str, Any]:
    lat = float(cell.get("lat") or 0.0)
    lon = float(cell.get("lon") or 0.0)
    bottom = float(cell.get("seafloor_depth_m") or cell.get("bottom_depth_m") or 0.0)

    surface_3d = sample_cached_rtofs_3d(rtofs3d_cache or {}, lon, lat, 0.0) if (rtofs3d_cache or {}).get("ok") else {"ok": False}
    if surface_3d.get("ok"):
        feat = {
            "sst_c": surface_3d.get("temperature_c", surface_3d.get("water_temp_c")),
            "sst_f": surface_3d.get("temperature_f", surface_3d.get("water_temp_f")),
            "salinity": surface_3d.get("salinity"),
            "current_speed_kt": surface_3d.get("current_speed_kt"),
            "direction_deg": surface_3d.get("direction_deg"),
            "u_ms": surface_3d.get("u_ms"),
            "v_ms": surface_3d.get("v_ms"),
            "source_point": surface_3d,
        }
        surface_source = "rtofs_native_3d_trilinear_surface"
        interpolation_basis = "bathymetry_cell_center_plus_native_rtofs_3d_trilinear_xyz; surface_is_sample_depth_0"
    else:
        feat = _surface_features(nearest)
        surface_source = (nearest or {}).get("source") or "ocean_truth_3d_cache_missing_surface_fallback"
        interpolation_basis = "bathymetry_cell_center; native_rtofs_3d_cache_pending; surface_fallback_nearest_rtofs_when_available"

    bait_depth_m = _choose_bait_depth_m(bottom, surface_3d if surface_3d.get("ok") else feat, chl)
    bait_3d = sample_cached_rtofs_3d(rtofs3d_cache or {}, lon, lat, bait_depth_m) if (rtofs3d_cache or {}).get("ok") else {"ok": False, "status": "cache_pending"}
    valid_depths = [d for d in depths_m if d < max(0.0, bottom - 1.0)]
    sample = {
        "id": f"truth:{cell.get('tile_id','tile')}:{cell.get('r',0)}:{cell.get('c',0)}",
        "lat": cell.get("lat"),
        "lon": cell.get("lon"),
        "bbox": cell.get("bbox"),
        "tile_id": cell.get("tile_id"),
        "water": True,
        "ocean_connected": True,
        "renderable": True,
        "mask": "ocean_connected_bathymetry_rtofs_truth",
        "seafloor_depth_m": round(bottom, 2),
        "bottom_depth_m": round(bottom, 2),
        "seafloor_depth_ft": round(bottom * FT_PER_M, 1),
        "water_fraction": cell.get("water_fraction", 1.0),
        "depth_m": 0.0,
        "sample_depth_m": 0.0,
        "altitude_m": 0.0,
        "valid_depths_m": valid_depths,
        "depth_candidates_m": valid_depths,
        "depth_contract": "depth_candidates_m are optional probes only; truth is OceanTruth.sample(lon,lat,depth_m,time)",
        "interpolation_basis": interpolation_basis,
        "sample_method": "rtofs_native_3d_trilinear" if surface_3d.get("ok") else "bathymetry_anchor_rtofs_3d_pending",
        "sst_c": feat.get("sst_c"),
        "sst_f": feat.get("sst_f"),
        "water_temp_c": feat.get("sst_c"),
        "water_temp_f": feat.get("sst_f"),
        "temperature_c": feat.get("sst_c"),
        "temperature_f": feat.get("sst_f"),
        "salinity": feat.get("salinity"),
        "current_speed_kt": feat.get("current_speed_kt"),
        "direction_deg": feat.get("direction_deg"),
        "u_ms": feat.get("u_ms"),
        "v_ms": feat.get("v_ms"),
        "current": {"speedKt": feat.get("current_speed_kt"), "dirDeg": feat.get("direction_deg"), "u": feat.get("u_ms"), "v": feat.get("v_ms")},
        "surface_sample": surface_3d if surface_3d.get("ok") else None,
        "bait_depth_m": bait_depth_m,
        "bait_altitude_m": -abs(float(bait_depth_m)),
        "bait_sample": bait_3d if bait_3d.get("ok") else {"ok": False, "status": bait_3d.get("status"), "depth_m": bait_depth_m, "altitude_m": -abs(float(bait_depth_m))},
        "bait_temperature_c": bait_3d.get("temperature_c") if bait_3d.get("ok") else None,
        "bait_salinity": bait_3d.get("salinity") if bait_3d.get("ok") else None,
        "bait_current_speed_kt": bait_3d.get("current_speed_kt") if bait_3d.get("ok") else None,
        "bait_direction_deg": bait_3d.get("direction_deg") if bait_3d.get("ok") else None,
        "bait_u_ms": bait_3d.get("u_ms") if bait_3d.get("ok") else None,
        "bait_v_ms": bait_3d.get("v_ms") if bait_3d.get("ok") else None,
        "water_vars": {"sst_c": feat.get("sst_c"), "sst_f": feat.get("sst_f"), "salinity": feat.get("salinity"), "surface_from_3d": bool(surface_3d.get("ok"))},
        "cell": {"validNeighbors": 9, "possibleNeighbors": 9, "mask": "ocean_truth", "placement": "ocean_truth_cell_center", "dLat": 0.018, "dLon": 0.018},
        "source": surface_source,
        "chlorophyll_mg_m3": chl,
        "chlorophyll_status": chl_status,
    }
    return sample


def ocean_truth_payload(
    app_root: Path | str | None,
    bbox: Any,
    *,
    depths: Any = None,
    tile_deg: float = 4.0,
    render_grid: int = 16,
    limit: int = 72,
    max_samples: int = 1800,
    warm_rtofs: bool = False,
    warm_chlorophyll: bool = False,
    chlorophyll_stride: int = 6,
    products: str | list[str] | tuple[str, ...] = "bait,boats,ocean",
) -> dict[str, Any]:
    started = time.time()
    bbox_d = _bbox_dict(bbox)
    depths_m = _depths(depths)
    product_set = {str(p).strip().lower() for p in (products.split(",") if isinstance(products, str) else products) if str(p).strip()}

    bathy = bathymetry_tiles_payload(app_root, bbox_d, tile_deg=tile_deg, render_grid=render_grid, fetch_missing=False, limit=limit)
    rtofs3d = load_cached_rtofs_3d_truth(_bbox_list(bbox_d))
    rtofs3d_warmer = spawn_rtofs_3d_truth_warmer(_bbox_list(bbox_d)) if warm_rtofs and not rtofs3d.get("ok") else {"started": False, "reason": "not_requested"}
    rtofs = load_cached_rtofs_surface(_bbox_list(bbox_d))
    warmer = spawn_rtofs_surface_warmer(_bbox_list(bbox_d), max_points=3000) if warm_rtofs and not rtofs.get("ok") else {"started": False, "reason": "not_requested"}
    surface_points = rtofs.get("points") or rtofs.get("ocean_points") or rtofs.get("current_points") or []

    raw_cells: list[dict[str, Any]] = []
    for tile in bathy.get("tiles") or []:
        if float(tile.get("water_fraction") or 0.0) <= 0.02:
            continue
        raw_cells.extend(_tile_water_cells(tile))
    raw_before_clip = len(raw_cells)
    strict = [cell for cell in raw_cells if _cell_intersects_bbox(cell, bbox_d, pad_deg=0.0)]
    clipped = strict or [cell for cell in raw_cells if _cell_intersects_bbox(cell, bbox_d, pad_deg=0.08)]
    distributed = _spatially_distribute(clipped, bbox_d, max(1, int(max_samples or 1800)))

    chl_cache = _load_chlorophyll_cache(app_root, bbox_d)
    chl_job = {"started": False, "reason": "fresh_or_not_requested"}
    if warm_chlorophyll and not chl_cache.get("ready"):
        chl_job = _spawn_chlorophyll_fetch(app_root, bbox_d, stride=chlorophyll_stride)
        chl_cache = {**chl_cache, "status": "loading", "ready": False}
    chl_payload = chl_cache.get("payload") if chl_cache.get("ready") else None
    chl_status = "ready" if chl_cache.get("ready") else ("loading" if chl_job.get("running") or chl_job.get("started") else str(chl_cache.get("status") or "missing"))

    samples: list[dict[str, Any]] = []
    for cell in distributed:
        nearest = _nearest_surface_point(float(cell["lat"]), float(cell["lon"]), surface_points)
        chl = _chlorophyll_at(float(cell["lat"]), float(cell["lon"]), chl_payload, bbox_d) if chl_payload else None
        samples.append(_truth_sample_from_cell(cell, nearest, chl, chl_status, depths_m, rtofs3d))

    # Compatible object for boat renderer.  Boats get the same truth samples as bait/ocean.
    ocean_points = {
        "points": samples,
        "count": len(samples),
        "source": "lftr_ocean_truth_native_3d_trilinear_samples" if rtofs3d.get("ok") else ("lftr_ocean_truth_rtofs_surface_samples" if surface_points else "lftr_ocean_truth_bathymetry_only_rtofs_warming"),
        "bbox": bbox_d,
        "bbox_object": bbox_d,
    }
    boats_payload = {
        "ok": bool(samples and surface_points),
        "source": ocean_points["source"],
        "bbox": bbox_d,
        "bbox_object": bbox_d,
        "oceanPoints": ocean_points,
        "points": samples,
        "count": len(samples),
        "landmask_contract": "ocean_truth_ocean_connected_bathymetry_plus_rtofs_sst_mask",
        "sst_landmask": {"method": "ocean_truth_ocean_connected_bathymetry_plus_rtofs_sst_mask", "water_cells": len(samples)},
        "source_meta": {"sst_landmask": {"method": "ocean_truth_ocean_connected_bathymetry_plus_rtofs_sst_mask", "water_cells": len(samples)}},
    }

    try:
        from server.gfs.rtofs_source import rtofs_3d_candidates
        candidates = rtofs_3d_candidates(bbox=bbox_d, limit=8)
    except Exception:
        candidates = []

    payload = {
        "ok": bool(samples),
        "schema": "lftr_ocean_truth_interpolator_v1",
        "source": "lftr_unified_ocean_truth_rtofs_bathymetry_atmos_chlorophyll_late_injection_v1",
        "bbox": bbox_d,
        "depths_m": depths_m,
        "samples": samples,
        "sample_count": len(samples),
        "surface_points": samples,
        "oceanPoints": ocean_points,
        "products": {},
        "query_contract": {
            "name": "OceanTruth.sample(lon, lat, depth_m, time)",
            "truth_is_not_voxels": True,
            "continuous_field": True,
            "interpolation": "RTOFS native x/y/depth arrays are exposed as continuous XYZ by trilinear interpolation; transported samples are just render anchors",
            "surface_policy": "surface = OceanTruth.sample(lon,lat,0,time) from the same 3D field when rtofs_3d.ok",
            "sampling_strategy": "stable bathymetry-distributed anchors now; renderer may request gridded, jittered, blue-noise, or adaptive smart samples later",
            "variables": [
                "bathymetry.seafloor_depth(lon,lat)",
                "rtofs.temperature(lon,lat,depth,time)",
                "rtofs.salinity(lon,lat,depth,time)",
                "rtofs.u(lon,lat,depth,time)",
                "rtofs.v(lon,lat,depth,time)",
                "gfs_atmosphere.surface(lon,lat,time)",
                "chlorophyll(lon,lat,time) late cached",
            ],
            "marching_cubes_role": "consumer/extractor only; samples bait_probability from OceanTruth and extracts iso-clouds, but does not define source truth",
        },
        "chlorophyll": {
            "status": chl_status,
            "ready": bool(chl_cache.get("ready")),
            "ttl_s": CHL_TTL_S,
            "cache_path": chl_cache.get("cache_path"),
            "age_s": chl_cache.get("age_s"),
            "job": chl_job,
            "policy": "does not block ocean/bait/boats; when ready, remains for 8 hours and raises bait probability score",
            "source_meta": (chl_payload or {}).get("source_meta") if chl_payload else None,
        },
        "rtofs_surface": {
            "ok": bool(rtofs.get("ok")),
            "status": rtofs.get("status"),
            "source": rtofs.get("source"),
            "count": int(rtofs.get("count") or 0),
            "cache": rtofs.get("cache") or {"hit": False, "path": rtofs.get("cache_path")},
            "warmer": warmer,
        },
        "rtofs_3d": compact_rtofs_3d_status(rtofs3d, rtofs3d_warmer, candidates),
        "bathymetry": {
            "ok": bool(bathy.get("ok")),
            "source": bathy.get("source"),
            "tile_count": bathy.get("tile_count"),
            "missing_tile_count": bathy.get("missing_tile_count"),
            "cache": bathy.get("cache"),
            "raw_cell_count_before_viewport_clip": raw_before_clip,
            "viewport_clipped_cell_count": len(clipped),
            "distributed_sample_count": len(distributed),
            "mask": "ocean_connected_bathymetry_no_inland_below_sea_level_basins",
        },
        "atmosphere": {
            "status": "scene_frame_ncss_surface_companion",
            "contract": "surface atmosphere stays a cousin field attached to OceanTruth at z=0; clouds remain separate because they are atmospheric and not land-masked",
        },
        "latency_ms": int((time.time() - started) * 1000),
    }
    if not product_set or "boats" in product_set or "boater" in product_set:
        payload["products"]["boats"] = boats_payload
    if not product_set or "bait" in product_set:
        payload["products"]["bait"] = {
            "input": "OceanTruth.sample -> bait_probability(lon,lat,depth,time)",
            "chlorophyll_bonus_state": chl_status,
            "depth_candidates_m": depths_m,
            "sample_count": len(samples),
            "sampling_contract": "depth candidates are probes only; bait depth is chosen per anchor and sampled by OceanTruth.sample",
        }
    if not product_set or "ocean" in product_set:
        payload["products"]["ocean"] = {"oceanPoints": ocean_points, "bathymetry": payload["bathymetry"]}
    return payload

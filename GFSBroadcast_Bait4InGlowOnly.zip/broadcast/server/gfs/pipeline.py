from __future__ import annotations

from typing import Any
import logging
import os

log = logging.getLogger(__name__)

from server.gfs.tile_contract import DEFAULT_VIEWPORT_GRID, provider_jobs

LAYER_PROVIDER_MAP: dict[str, tuple[str, ...]] = {
    "clouds": ("ncss_gfs",),
    "rain": ("ncss_gfs",),
    "lightning": ("ncss_gfs",),
    "jetstream": ("ncss_gfs",),
    "boater": ("rtofs_ocean",),
    "bait": ("rtofs_ocean",),
    "shark-intel": ("rtofs_ocean",),
    "inland-water": ("inland_geometry", "shoreline"),
    "inland_water_temp": ("lake_environment", "usgs_waterflow"),
}




OCEAN_LEVEL_CONTRACT: dict[str, Any] = {
    "schema": "lftr_ocean_level_contract_v1",
    "depth_unit_contract": "feet_universal_intelligence",
    "depth_levels_ft": [0, -5, -10, -25, -50, -100, -150],
    "below_water_is_negative_ft": True,
    "render_height_is_positive_ft": True,
    "z_axis_policy": "negative_ft_below_water_positive_ft_render_extrusion",
    "surface": {
        "rtofs_sst": "surface",
        "rtofs_current": "surface",
        "gfs_lake_water_temp": "Temperature_surface_only",
        "gfs_location_intel_air_temp": "2m_height_above_ground_context_only",
    },
}

def _attach_ocean_level_contract(payload: Any) -> Any:
    if not isinstance(payload, dict):
        return payload
    payload.setdefault("level_contract", dict(OCEAN_LEVEL_CONTRACT))
    payload.setdefault("depth_unit_contract", "feet_universal_intelligence")
    payload.setdefault("depth_levels_ft", [0, -5, -10, -25, -50, -100, -150])
    payload.setdefault("z_axis_policy", "negative_ft_below_water_positive_ft_render_extrusion")
    payload.setdefault("render_height_policy", "positive_ft_visual_extrusion_only")
    return payload

def _ocean_points_from_layer(payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    op = payload.get("oceanPoints") if isinstance(payload.get("oceanPoints"), dict) else {}
    for raw in (op.get("points"), payload.get("ocean_points"), payload.get("current_points"), payload.get("points")):
        if isinstance(raw, list) and raw:
            return [x for x in raw if isinstance(x, dict)]
    return []

def _repair_ocean_layers_from_rtofs_bridge(svc: Any, frame: dict[str, Any], bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None, selected_layers: list[str]) -> dict[str, Any]:
    """All-pill repair: keep Bait/Boater/Shark separate controls, but let them
    share the warmed RTOFS carrier.  This is cache-only: it does not wake NOAA
    itself and it does not require the NOAA/GSHHG landmask to be ready.
    """
    if not isinstance(frame, dict):
        return {"applied": False, "reason": "frame_not_dict"}
    layers = frame.setdefault("layers", {})
    if not isinstance(layers, dict):
        return {"applied": False, "reason": "layers_not_dict"}
    meta: dict[str, Any] = {"applied": False, "policy": "ocean_pills_separate_html_shared_rtofs_cache"}
    ocean_requested = any(x in selected_layers for x in ("bait", "boater", "shark-intel"))
    if not ocean_requested:
        return {"applied": False, "reason": "no_ocean_layers_requested"}
    # Bait and boater should each be able to read their own RTOFS bridge even
    # when the all-pill frame previously found an empty split-cache slot.
    for layer in ("bait", "boater"):
        if layer in selected_layers and not _layer_has_ocean_content(layers.get(layer), layer):
            try:
                bridged = svc._scene_cache_rtofs_bridge_layer(layer, bbox, visible_bbox)
            except Exception as exc:
                meta[f"{layer}_bridge_error"] = str(exc)
                bridged = None
            if isinstance(bridged, dict) and _layer_has_ocean_content(bridged, layer):
                layers[layer] = _attach_ocean_level_contract(bridged)
                meta[f"{layer}_repaired"] = True
                meta["applied"] = True
    # Shark can be derived from the same RTOFS points carried by boater or bait.
    if "shark-intel" in selected_layers and not _layer_has_ocean_content(layers.get("shark-intel"), "bait"):
        carrier = layers.get("boater") if _ocean_points_from_layer(layers.get("boater")) else layers.get("bait")
        points = _ocean_points_from_layer(carrier)
        if points:
            try:
                from server.gfs.shark_intel import shark_intel_payload
                shark = shark_intel_payload(bbox, visible_bbox, ocean_payload={"oceanPoints": {"points": points}, "points": points})
                shark["source"] = "scene_frame_shark_from_shared_rtofs_ocean_points_bridge"
                shark["bridge_contract"] = "shark_intel_reuses_boater_bait_rtofs_ocean_points_same_frame"
                layers["shark-intel"] = _attach_ocean_level_contract(shark)
                meta["shark_repaired"] = True
                meta["applied"] = True
            except Exception as exc:
                meta["shark_bridge_error"] = str(exc)
    # Attach contract to any ocean layer that exists, including ready layers.
    for layer in ("bait", "boater", "shark-intel"):
        if isinstance(layers.get(layer), dict):
            layers[layer] = _attach_ocean_level_contract(layers[layer])
    return meta

def _layer_has_ocean_content(payload: Any, layer: str) -> bool:
    if not isinstance(payload, dict):
        return False
    if payload.get("ok") and str(payload.get("status") or payload.get("payload_state") or "").lower() in {"ok", "ready", "live"}:
        if layer == "boater":
            boats = payload.get("boats") or payload.get("items") or []
            op = payload.get("oceanPoints") if isinstance(payload.get("oceanPoints"), dict) else {}
            points = op.get("points") or payload.get("ocean_points") or payload.get("points") or []
            return bool(boats or points or int(op.get("count") or 0) > 0)
        if layer == "bait":
            polys = payload.get("polygons") or payload.get("zones") or []
            bait = payload.get("bait") if isinstance(payload.get("bait"), dict) else {}
            bpolys = bait.get("polygons") or bait.get("inner_polygons") or bait.get("outer_polygons") or []
            return bool(polys or bpolys or int(payload.get("polygon_count") or 0) > 0)
    return False


def _layer_has_atmosphere_content(payload: Any, layer: str) -> bool:
    if not isinstance(payload, dict):
        return False
    layer_key = str(layer or "").strip().lower().replace("-", "_")
    if layer_key == "clouds":
        return bool(
            (isinstance(payload.get("items"), list) and len(payload.get("items") or []) > 0)
            or (isinstance(payload.get("features"), list) and len(payload.get("features") or []) > 0)
            or (isinstance(payload.get("cloud_layers"), list) and len(payload.get("cloud_layers") or []) > 0)
            or (isinstance(payload.get("cloud_regions"), list) and len(payload.get("cloud_regions") or []) > 0)
            or (isinstance(payload.get("scene"), dict) and isinstance(payload.get("scene", {}).get("clouds"), list) and len(payload.get("scene", {}).get("clouds") or []) > 0)
        )
    if layer_key == "rain":
        rain_obj = payload.get("rain") if isinstance(payload.get("rain"), dict) else {}
        return bool(
            (isinstance(payload.get("precip_columns"), list) and len(payload.get("precip_columns") or []) > 0)
            or (isinstance(payload.get("features"), list) and len(payload.get("features") or []) > 0)
            or (isinstance(rain_obj.get("items"), list) and len(rain_obj.get("items") or []) > 0)
            or (isinstance(payload.get("scene"), dict) and isinstance(payload.get("scene", {}).get("precip"), list) and len(payload.get("scene", {}).get("precip") or []) > 0)
        )
    return False


def _status_text(payload: Any) -> str:
    if not isinstance(payload, dict):
        return "unavailable"
    status = payload.get("status")
    if isinstance(status, str) and status:
        return status
    if isinstance(status, dict):
        if status.get("ok") is True:
            return "ok"
        if status.get("ok") is False:
            return "degraded"
    return str(payload.get("payload_state") or payload.get("display_state") or payload.get("source_state") or "ok")


def _rain_layer_from_weather_payload(weather_payload: dict[str, Any], bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None) -> dict[str, Any]:
    out = dict(weather_payload or {})
    precip = out.get("precip_columns")
    if not isinstance(precip, list) or not precip:
        scene = out.get("scene") if isinstance(out.get("scene"), dict) else {}
        precip = scene.get("precip") if isinstance(scene.get("precip"), list) else []
    rain_obj = out.get("rain") if isinstance(out.get("rain"), dict) else {}
    rain_items = rain_obj.get("items") if isinstance(rain_obj.get("items"), list) else []
    features = precip or rain_items or []
    out["source_layer"] = "rain_from_shared_cloud_weather_payload"
    out["source"] = "scene_frame_live_cloud_bridge_rain"
    out["items"] = []
    out["features"] = features
    out["precip_columns"] = precip or []
    out["rain"] = {**rain_obj, "items": rain_items, "count": len(rain_items)}
    out["count"] = len(features)
    out["bbox"] = bbox or out.get("bbox")
    out["visible_bbox"] = visible_bbox or out.get("visible_bbox")
    out.setdefault("render_bbox", visible_bbox or out.get("render_bbox"))
    out.setdefault("fetch_bbox", bbox or out.get("fetch_bbox"))
    if not isinstance(out.get("cache"), dict):
        out["cache"] = {}
    out["cache"].update({"scene_frame_bridge": True, "shared_weather_payload": True})
    out["payload_state"] = "ok" if features else _status_text(out)
    out["status"] = "ok" if features else _status_text(out)
    return out


def _repair_atmosphere_layers_from_live_cloud_bridge(svc: Any, frame: dict[str, Any], bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None, selected_layers: list[str]) -> dict[str, Any]:
    """Scene-frame atmosphere repair.

    The clean frontend reads /gfs/api/scene-frame only.  Older provider/debug
    endpoints are intentionally blocked, and scene-cache read mode can legally
    return scene_cache_empty_clouds/rain.  For the original core layers, bridge
    scene-frame to the live-first cloud tile contract once per request, fail
    soft, and leave marine/RTOFS payloads untouched.
    """
    meta: dict[str, Any] = {"applied": False, "policy": "scene_frame_cloud_rain_live_first_bridge_fail_soft"}
    if not isinstance(frame, dict):
        return {**meta, "reason": "frame_not_dict"}
    layers_payload = frame.setdefault("layers", {})
    if not isinstance(layers_payload, dict):
        return {**meta, "reason": "layers_not_dict"}
    requested = [x for x in selected_layers if x in {"clouds", "rain"}]
    if not requested:
        return {**meta, "reason": "no_atmosphere_layers_requested"}

    needs = []
    for layer in requested:
        current = layers_payload.get(layer)
        try:
            has_content = bool(svc._scene_cache_layer_has_renderable_content(layer, current)) if hasattr(svc, "_scene_cache_layer_has_renderable_content") else _layer_has_atmosphere_content(current, layer)
        except Exception:
            has_content = _layer_has_atmosphere_content(current, layer)
        if not has_content:
            needs.append(layer)
    if not needs:
        return {**meta, "reason": "atmosphere_layers_already_renderable"}

    try:
        if hasattr(svc, "cloud_tiles_payload"):
            weather_payload = svc.cloud_tiles_payload(bbox, visible_bbox)
            source_method = "cloud_tiles_payload_live_first"
        elif hasattr(svc, "_cloud_tiles_payload_heavy"):
            weather_payload = svc._cloud_tiles_payload_heavy(bbox, visible_bbox, force_live=True)
            source_method = "cloud_tiles_payload_heavy_force_live"
        else:
            return {**meta, "reason": "no_cloud_provider_method"}
    except Exception as exc:
        log.exception("scene-frame atmosphere live bridge failed")
        return {**meta, "reason": "cloud_provider_exception", "error": str(exc)[:1000]}

    if not isinstance(weather_payload, dict):
        return {**meta, "reason": "cloud_provider_bad_payload", "payload_type": type(weather_payload).__name__}

    weather_payload = dict(weather_payload)
    weather_payload.setdefault("source", "scene_frame_live_cloud_bridge")
    if not isinstance(weather_payload.get("cache"), dict):
        weather_payload["cache"] = {}
    weather_payload["cache"].update({"scene_frame_bridge": True, "source_method": source_method})
    weather_payload["scene_frame_bridge"] = True
    weather_payload.setdefault("bbox", bbox)
    weather_payload.setdefault("visible_bbox", visible_bbox)
    weather_payload.setdefault("render_bbox", visible_bbox or weather_payload.get("render_bbox"))
    weather_payload.setdefault("fetch_bbox", bbox or weather_payload.get("fetch_bbox"))

    if "clouds" in needs:
        cloud_layer = dict(weather_payload)
        cloud_layer["source_layer"] = "clouds_from_live_first_weather_payload"
        if _layer_has_atmosphere_content(cloud_layer, "clouds"):
            cloud_layer["payload_state"] = "ok"
            cloud_layer["status"] = "ok"
            cloud_layer["count"] = len(cloud_layer.get("items") or cloud_layer.get("features") or cloud_layer.get("cloud_regions") or [])
        layers_payload["clouds"] = cloud_layer
        meta["clouds_repaired"] = True
        meta["applied"] = True
        try:
            if hasattr(svc, "_scene_cache_write_layer") and _layer_has_atmosphere_content(cloud_layer, "clouds"):
                q = svc._scene_cache_quality_rank("clouds", bbox, visible_bbox) if hasattr(svc, "_scene_cache_quality_rank") else 70
                svc._scene_cache_write_layer("clouds", bbox, cloud_layer, visible_bbox, quality_rank=q)
                meta["clouds_cache_promoted"] = True
        except Exception as exc:
            meta["clouds_cache_promote_error"] = str(exc)[:500]

    if "rain" in needs:
        rain_layer = _rain_layer_from_weather_payload(weather_payload, bbox, visible_bbox)
        layers_payload["rain"] = rain_layer
        meta["rain_repaired"] = True
        meta["applied"] = True
        try:
            if hasattr(svc, "_scene_cache_write_layer") and _layer_has_atmosphere_content(rain_layer, "rain"):
                q = svc._scene_cache_quality_rank("rain", bbox, visible_bbox) if hasattr(svc, "_scene_cache_quality_rank") else 70
                svc._scene_cache_write_layer("rain", bbox, rain_layer, visible_bbox, quality_rank=q)
                meta["rain_cache_promoted"] = True
        except Exception as exc:
            meta["rain_cache_promote_error"] = str(exc)[:500]

    meta["source_method"] = source_method
    meta["provider_source"] = weather_payload.get("source")
    meta["provider_state"] = _status_text(weather_payload)
    meta["cloud_items"] = len(weather_payload.get("items") or weather_payload.get("features") or weather_payload.get("cloud_regions") or [])
    meta["precip_columns"] = len(weather_payload.get("precip_columns") or [])
    return meta


def _explicit_visible_bbox(bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None) -> bool:
    if not isinstance(bbox, dict) or not isinstance(visible_bbox, dict):
        return False
    try:
        return all(k in visible_bbox for k in ("west", "south", "east", "north"))
    except Exception:
        return False


def _viewport_bbox_reason(bbox: dict[str, float] | None) -> tuple[bool, str, dict[str, Any]]:
    if not isinstance(bbox, dict):
        return False, "missing_visible_bbox", {}
    try:
        w = abs(float(bbox["east"]) - float(bbox["west"]))
        h = abs(float(bbox["north"]) - float(bbox["south"]))
        area = w * h
        max_w = float(os.getenv("GFS_RTOFS_WAKE_MAX_WIDTH_DEG", "18") or "18")
        max_h = float(os.getenv("GFS_RTOFS_WAKE_MAX_HEIGHT_DEG", "14") or "14")
        max_area = float(os.getenv("GFS_RTOFS_WAKE_MAX_AREA_DEG2", "180") or "180")
        meta = {"width_deg": w, "height_deg": h, "area_deg2": area, "max_width_deg": max_w, "max_height_deg": max_h, "max_area_deg2": max_area}
        if w <= 0 or h <= 0:
            return False, "invalid_visible_bbox", meta
        if w > max_w or h > max_h or area > max_area:
            return False, "visible_bbox_too_large_for_rtofs_wake", meta
        return True, "ok", meta
    except Exception as exc:
        return False, "visible_bbox_parse_failed", {"error": str(exc)}

def _maybe_enqueue_rtofs_ocean_wake(svc: Any, frame: dict[str, Any], bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None, selected_layers: list[str]) -> dict[str, Any]:
    """Narrow bridge: scene-frame stays cache-read, but explicit boater/bait
    requests must wake the RTOFS cache warmer once when the cache is empty.

    This does not call the legacy scene-tile RTOFS/CoastWatch provider and does
    not schedule child bboxes. It only spawns scripts/warm_rtofs_surface_cache.py
    for the authoritative visible viewport; the lock inside rtofs_source dedupes
    repeated requests.
    """
    ocean_layers = [x for x in selected_layers if x in {"boater", "bait", "shark-intel"}]
    if not ocean_layers or not _explicit_visible_bbox(bbox, visible_bbox):
        return {"started": False, "reason": "not_explicit_ocean_viewport"}
    allowed_vp, vp_reason, vp_meta = _viewport_bbox_reason(visible_bbox)
    if not allowed_vp:
        try:
            log.info("rtofs/ocean-wake-skipped source=scene-frame reason=%s layers=%s bbox=%s visible_bbox=%s policy=%s", vp_reason, ','.join(ocean_layers), bbox, visible_bbox, vp_meta)
        except Exception:
            pass
        return {"started": False, "reason": vp_reason, "bbox_policy": vp_meta, "bbox": bbox, "visible_bbox": visible_bbox}
    layers_payload = frame.get("layers") if isinstance(frame, dict) else None
    missing = []
    if isinstance(layers_payload, dict):
        for layer in ocean_layers:
            if layer == "shark-intel":
                continue
            if not _layer_has_ocean_content(layers_payload.get(layer), layer):
                missing.append(layer)
    else:
        missing = [x for x in ocean_layers if x != "shark-intel"]
    if not missing:
        return {"started": False, "reason": "ocean_scene_cache_has_content"}
    try:
        from server.gfs.rtofs_source import spawn_rtofs_surface_warmer
        max_points = int(os.getenv("GFS_RTOFS_WARM_MAX_POINTS", "3000") or "3000")
        # Use the explicit visible viewport as the cache truth envelope. The bbox
        # is usually equal; visible_bbox makes the intent unambiguous and avoids
        # old child tile bboxes.
        warmer = spawn_rtofs_surface_warmer(visible_bbox, max_points=max_points)
        try:
            log.info(
                "rtofs/ocean-wake-enqueued source=scene-frame explicit_visible_bbox=1 layers=%s missing=%s bbox=%s visible_bbox=%s started=%s reason=%s",
                ','.join(ocean_layers), ','.join(missing), bbox, visible_bbox, warmer.get("started"), warmer.get("reason"),
            )
        except Exception:
            pass
        return {"started": bool(warmer.get("started")), "reason": warmer.get("reason") or "spawned", "warmer": warmer, "missing_layers": missing, "bbox": bbox, "visible_bbox": visible_bbox}
    except Exception as exc:
        try:
            log.exception("rtofs/ocean-wake failed source=scene-frame")
        except Exception:
            pass
        return {"started": False, "reason": "spawn_exception", "error": str(exc), "missing_layers": missing}


def normalize_scene_layers(layers: list[str] | tuple[str, ...] | None) -> list[str]:
    """Return pill layers in the same compact names the browser renders."""
    aliases = {
        "boats": "boater",
        "boater_awareness": "boater",
        "shark_intel": "shark-intel",
        "sharkintel": "shark-intel",
        "inland_water": "inland-water",
        "inland_waterways": "inland-water",
    }
    out: list[str] = []
    for raw in layers or []:
        layer = aliases.get(str(raw).strip().lower(), str(raw).strip().lower())
        if layer and layer not in out:
            out.append(layer)
    # Ocean mission layers are a shared SST/current/mask bundle. If any of
    # bait, boater, or shark-intel is requested, keep all three in the selected
    # scene layer list. Also make ocean resolve before inland so the RTOFS
    # cache/readback has first paint priority when both missions are enabled.
    ocean_mission = ["bait", "shark-intel", "boater"]
    if any(layer in out for layer in ocean_mission):
        non_ocean_non_inland = [layer for layer in out if layer not in ocean_mission and layer not in {"inland-water", "inland_water_temp"}]
        inland_layers = [layer for layer in out if layer in {"inland-water", "inland_water_temp"}]
        out = non_ocean_non_inland + ocean_mission + inland_layers
    return list(dict.fromkeys(out))


def providers_for_layers(layers: list[str] | tuple[str, ...] | None) -> list[str]:
    """Map selected pills to the minimum provider set for manual/debug plans."""
    providers: list[str] = []
    for layer in normalize_scene_layers(layers):
        for provider in LAYER_PROVIDER_MAP.get(layer, ()):  # unknown/debug layers stay cache-only
            if provider not in providers:
                providers.append(provider)
    return providers


def scene_frame_payload(
    svc: Any,
    bbox: dict[str, float] | None,
    visible_bbox: dict[str, float] | None,
    layers: list[str] | tuple[str, ...] | None,
    *,
    mode: str = "read",
    refresh: bool = False,
    include_provider_jobs: bool = False,
    job_limit: int | None = None,
) -> dict[str, Any]:
    """Single /gfs frame contract: get/cache, compile, draw metadata.

    Provider job plans are OFF by default. Normal rendering must read the scene
    cache only, then explicitly nudge /gfs/api/cache/refresh. The approved provider scheduler always uses the same 6x6 / 36-tile viewport grid.  The old provider-specific
    provider job contract is retained only for manual/debug inspection via
    provider_jobs=1 so the browser cannot accidentally fan out provider work.
    """
    selected_layers = normalize_scene_layers(layers)
    mode_l = str(mode or "read").lower()
    fast = mode_l in {"fast", "first_paint", "cache", "cache_only"}
    frame = svc.scene_cache_fast_payload(bbox, visible_bbox, selected_layers, mode=mode_l) if fast else svc.scene_cache_payload(bbox, visible_bbox, selected_layers, refresh=False, mode=mode_l)

    ocean_merge_repair = _repair_ocean_layers_from_rtofs_bridge(svc, frame, bbox, visible_bbox, selected_layers)
    if isinstance(frame, dict):
        frame.setdefault("diagnostics", {})["ocean_pill_merge_repair"] = ocean_merge_repair
        frame.setdefault("cache", {})["ocean_pill_merge_repair"] = {k: v for k, v in ocean_merge_repair.items() if not str(k).endswith("_error")}

    # Cache-read remains the scene-frame rule, but an explicit boater/bait viewport
    # must nudge the RTOFS warmer when the scene cache is empty. This is the small
    # missing bridge between stable atmosphere boot and downstream marching squares.
    ocean_wake = _maybe_enqueue_rtofs_ocean_wake(svc, frame, bbox, visible_bbox, selected_layers)
    if isinstance(frame, dict):
        frame.setdefault("diagnostics", {})["rtofs_ocean_wake"] = ocean_wake
        frame.setdefault("cache", {})["rtofs_ocean_wake"] = {k: v for k, v in ocean_wake.items() if k not in {"warmer"}}

    atmosphere_bridge = _repair_atmosphere_layers_from_live_cloud_bridge(svc, frame, bbox, visible_bbox, selected_layers)
    if isinstance(frame, dict):
        frame.setdefault("diagnostics", {})["atmosphere_live_bridge"] = atmosphere_bridge
        frame.setdefault("cache", {})["atmosphere_live_bridge"] = {k: v for k, v in atmosphere_bridge.items() if not str(k).endswith("_error")}

    providers = providers_for_layers(selected_layers)
    frame["schema"] = "lftr_gfs_scene_frame_v1"
    frame["source"] = "single_scene_frame_cache_read_compile_draw_contract"
    frame["selected_layers"] = selected_layers
    layer_counts: dict[str, dict[str, Any]] = {}
    for _name, _payload in (frame.get("layers") or {}).items():
        if isinstance(_payload, dict):
            _bait = _payload.get("bait") if isinstance(_payload.get("bait"), dict) else {}
            layer_counts[_name] = {
                "status": _payload.get("status") or _payload.get("payload_state") or _payload.get("mode"),
                "source": _payload.get("source") or _payload.get("provider"),
                "cache_hit": (_payload.get("cache") or {}).get("hit") if isinstance(_payload.get("cache"), dict) else _payload.get("cache_hit"),
                "items": len(_payload.get("items") or _payload.get("features") or _payload.get("tiles") or []),
                "points": len(_payload.get("points") or _payload.get("samples") or _payload.get("score_points") or []),
                "polygons": len(_payload.get("polygons") or _bait.get("polygons") or _payload.get("contours") or []),
                "boats": len(_payload.get("boats") or []),
                "temp_points": len(_payload.get("temperature_points") or _payload.get("temp_points") or []),
            }
    layer_counts = {k: {kk: vv for kk, vv in v.items() if vv not in (None, "", 0, False)} for k, v in layer_counts.items()}
    frame["pipeline"] = {
        "get_data": "/gfs/api/scene-frame",
        "save_data": "scene cache + provider tile cache",
        "compile_data": "server-side layer frame",
        "draw_data": "browser layer engine consumes frame.layers",
        "update_map": "pill-selected layers only",
        "request_policy": "scene-frame is cache-read/compile only; provider job plans are manual-debug only with provider_jobs=1",
    }
    frame["render_debug"] = {
        "schema": "lftr_render_debug_v1",
        "stage": "server_scene_frame_compiled",
        "mode": mode_l,
        "selected_layers": selected_layers,
        "layer_count": len(selected_layers),
        "bbox": bbox,
        "visible_bbox": visible_bbox,
        "cache_mode": "fast" if fast else "normal",
        "provider_jobs_requested": bool(include_provider_jobs),
        "provider_count": len(providers),
        "layers": layer_counts,
        "ocean_wake": {k: v for k, v in ocean_wake.items() if k not in {"warmer"}} if isinstance(ocean_wake, dict) else ocean_wake,
        "ocean_pill_merge_repair": ocean_merge_repair if isinstance(ocean_merge_repair, dict) else None,
        "level_contract": OCEAN_LEVEL_CONTRACT,
        "policy": "clean_stage_totals_for_frontend_debug_panel",
    }
    frame["provider_tiles"] = provider_jobs(bbox, providers=providers, grid=DEFAULT_VIEWPORT_GRID, limit=job_limit) if include_provider_jobs and providers else {
        "ok": True,
        "schema": "lftr_provider_tile_contract_v1",
        "grid": {"rows": DEFAULT_VIEWPORT_GRID, "cols": DEFAULT_VIEWPORT_GRID, "count": DEFAULT_VIEWPORT_GRID * DEFAULT_VIEWPORT_GRID},
        "providers": providers,
        "jobs": [],
        "job_count": 0,
    }
    if refresh:
        frame["refresh"] = svc.scene_cache_refresh_payload(bbox, visible_bbox, selected_layers, reason=f"scene_frame_{mode_l}")
    return frame

from __future__ import annotations

"""Boot-light RTOFS ocean provider contract.

Tandem goals:
1. The web app must boot and answer /health without importing native ocean
   decoding stacks.
2. RTOFS remains the only ocean mission provider, but it runs after boot from a
   bounded visible_bbox wake.

This file is intentionally a contract/facade only.  It does not import xarray,
netCDF4, h5netcdf, cfgrib, scipy, or the NOAA adapter at module import time.
The default execution model runs the NOAA adapter in a short-lived child Python
process so a native-level RTOFS crash cannot take down Hypercorn.
"""

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from server.gfs.models import BBox


class RtofsProvider:
    provider_name = "rtofs"
    provider_contract = "rtofs_noaa_ncep_native_3d_trilinear_ocean_truth_contract"
    capabilities = ("sst", "current_u", "current_v", "current_speed", "salinity", "ocean_mask", "native_3d_trilinear", "OceanTruth.sample")
    boot_policy = "contract_only_no_native_ocean_imports"
    wake_policy = "explicit_small_visible_bbox_only"

    def _empty_payload(self, *, bbox: BBox, reason: str, detail: str | None = None) -> dict[str, Any]:
        meta: dict[str, Any] = {
            "provider": self.provider_name,
            "provider_ledger_family": "rtofs_ocean_bundle",
            "coordinate_bounded_request": True,
            "whole_file_request": False,
            "real_subset": False,
            "live_ocean_truth_ok": False,
            "has_sst": False,
            "has_current": False,
            "quality_gate": {"live_ncss_ok": False, "live_ocean_truth_ok": False, "blocking_reasons": [reason]},
            "blocking_reasons": [reason],
            "grid_shape": [0, 0],
            "mode": "rtofs_boot_safe_worker_empty",
            "selected_attempt": None,
            "selected_dataset": None,
            "depth_slice_status": "not_attempted_without_surface_bundle",
            "boot_policy": self.boot_policy,
            "wake_policy": self.wake_policy,
            "bbox": {"west": bbox.west, "south": bbox.south, "east": bbox.east, "north": bbox.north},
        }
        if detail:
            meta["error"] = str(detail)[:2000]
        return {
            "sst": [],
            "current_u": [],
            "current_v": [],
            "current_speed": [],
            "salinity": [],
            "lat_values": [],
            "lon_values": [],
            "ocean_mask": [],
            "source_meta": meta,
        }

    @staticmethod
    def _parse_valid_time(value: Any) -> datetime | None:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        try:
            text = str(value).strip()
            if not text:
                return None
            if text.endswith("Z"):
                text = text[:-1] + "+00:00"
            dt = datetime.fromisoformat(text)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except Exception:
            return None

    def _fetch_in_process(self, *, bbox: BBox, stride: int, valid_time: datetime | None) -> tuple[dict[str, Any], datetime | None]:
        # Developer/debug mode only.  Default is child-process isolation.
        from server.gfs.providers.rtofs_noaa import fetch_rtofs_subset_sync

        return fetch_rtofs_subset_sync(bbox=bbox, stride=max(1, int(stride or 1)), valid_time=valid_time)

    def _fetch_in_worker(self, *, bbox: BBox, stride: int, valid_time: datetime | None) -> tuple[dict[str, Any], datetime | None]:
        app_dir = Path(__file__).resolve().parents[3]
        worker = app_dir / "scripts" / "rtofs_fetch_worker.py"
        if not worker.exists():
            return self._empty_payload(bbox=bbox, reason="rtofs_worker_missing", detail=str(worker)), valid_time
        timeout_s = float(os.getenv("GFS_RTOFS_WORKER_TIMEOUT_SECONDS", "90") or "90")
        req = {
            "bbox": {"west": bbox.west, "south": bbox.south, "east": bbox.east, "north": bbox.north},
            "stride": max(1, int(stride or 1)),
            "valid_time": valid_time.isoformat() if isinstance(valid_time, datetime) else None,
        }
        env = os.environ.copy()
        env.setdefault("PYTHONUNBUFFERED", "1")
        proc = subprocess.run(
            [sys.executable, str(worker)],
            input=json.dumps(req),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(app_dir),
            env=env,
            timeout=timeout_s,
            check=False,
        )
        if proc.returncode != 0:
            return self._empty_payload(
                bbox=bbox,
                reason="rtofs_worker_failed",
                detail=f"code={proc.returncode} stderr={proc.stderr[-2000:]}",
            ), valid_time
        try:
            msg = json.loads(proc.stdout or "{}")
        except Exception as exc:
            return self._empty_payload(bbox=bbox, reason="rtofs_worker_bad_json", detail=f"{exc}; stdout={proc.stdout[-1000:]}") , valid_time
        if not msg.get("ok"):
            return self._empty_payload(bbox=bbox, reason=str(msg.get("reason") or "rtofs_worker_not_ok"), detail=str(msg.get("error") or "")), valid_time
        payload = msg.get("payload") if isinstance(msg.get("payload"), dict) else self._empty_payload(bbox=bbox, reason="rtofs_worker_missing_payload")
        vt = self._parse_valid_time(msg.get("valid_time")) or valid_time
        try:
            payload.setdefault("source_meta", {}).setdefault("provider", "rtofs")
            payload.setdefault("source_meta", {}).setdefault("process_model", "isolated_rtofs_fetch_worker")
            payload.setdefault("source_meta", {}).setdefault("boot_policy", self.boot_policy)
        except Exception:
            pass
        return payload, vt

    def _fetch_subset_sync(
        self,
        bbox: BBox,
        stride: int = 1,
        valid_time: datetime | None = None,
        **_: Any,
    ) -> tuple[dict[str, Any], datetime | None]:
        if os.getenv("GFS_RTOFS_IN_PROCESS", "false").strip().lower() in {"1", "true", "yes", "on"}:
            return self._fetch_in_process(bbox=bbox, stride=stride, valid_time=valid_time)
        return self._fetch_in_worker(bbox=bbox, stride=stride, valid_time=valid_time)

    def subset(
        self,
        *,
        bbox: BBox,
        stride: int = 1,
        valid_time: datetime | None = None,
        **kwargs: Any,
    ) -> tuple[dict[str, Any], datetime | None]:
        return self._fetch_subset_sync(bbox=bbox, stride=stride, valid_time=valid_time, **kwargs)


OceanProvider = RtofsProvider

from __future__ import annotations

"""NOAA/NCEP RTOFS ocean provider for LFTR's fixed 36-tile ocean bundle.

This module is intentionally small and adapter-shaped.  The rest of /gfs should
not care whether the ocean bundle came from RTOFS NCSS or RTOFS.  It only needs
normal grids named sst/current_u/current_v/salinity plus lat/lon coordinate
arrays and source_meta.

RTOFS notes:
- NOAA publishes Global RTOFS products operationally through NCEP/NOMADS.
- LFTR does not download whole RTOFS world products.  The viewport/provider
  network supplies one tile bbox at a time; this adapter sends that bbox as
  NOMADS grib-filter subregion coordinates.
- Primary live path: filter_rtofs.pl + GRIB2 + variables/levels + bbox.
- NetCDF/RTOFS archive candidates are fallback/debug only.
- Provider ledger diagnostics mark every RTOFS request as coordinate_bounded.
"""

import hashlib
import json
import logging
import math
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import xarray as xr
try:
    import cfgrib  # type: ignore
except Exception:  # pragma: no cover - optional until GRIB path is exercised
    cfgrib = None

from server.gfs.models import BBox
from server.gfs.ocean_landmask import ocean_mask_from_grids, mask_grid, erode_ocean_mask, plausible_sst_c
from server.gfs.serializers import iso_utc

log = logging.getLogger("server.gfs.provider.rtofs")

RTOFS_NOMADS_BASE = os.getenv(
    "GFS_RTOFS_NOMADS_BASE",
    "https://nomads.ncep.noaa.gov/pub/data/nccf/com/rtofs/prod",
).rstrip("/")
RTOFS_CACHE_TTL_SECONDS = int(os.getenv("GFS_RTOFS_CACHE_TTL_SECONDS", "21600") or "21600")
_DEFAULT_RTOFS_CACHE_DIR = Path(__file__).resolve().parents[3] / ".cache" / "rtofs"
_DEFAULT_RTOFS_FILE_CACHE_DIR = _DEFAULT_RTOFS_CACHE_DIR / "files"
RTOFS_FILE_CACHE_DIR = Path(os.getenv("GFS_RTOFS_FILE_CACHE_DIR", str(_DEFAULT_RTOFS_FILE_CACHE_DIR)))
RTOFS_ENABLE_DIRECT_NETCDF = os.getenv("GFS_RTOFS_ENABLE_DIRECT_NETCDF", "true").strip().lower() in {"1", "true", "yes", "on"}
RTOFS_ENABLE_GRIB2_FILTER = os.getenv("GFS_RTOFS_ENABLE_GRIB2_FILTER", "false").strip().lower() in {"1", "true", "yes", "on"}
RTOFS_FILTER_BASE = os.getenv("GFS_RTOFS_FILTER_BASE", "https://nomads.ncep.noaa.gov/cgi-bin/filter_rtofs.pl").strip()
RTOFS_GRIB2_FILES = [x.strip() for x in os.getenv("GFS_RTOFS_GRIB2_FILES", "rtofs_glo_3dz_f006.grib2,rtofs_glo_3dz_f003.grib2,rtofs_glo_3dz_f000.grib2,rtofs_glo_3dz_n000.grib2,rtofs_glo.t00z.f006_west_conus_std.grb2,rtofs_glo.t00z.f003_west_conus_std.grb2").split(",") if x.strip()]
RTOFS_MAX_SOURCE_DOWNLOAD_MB = float(os.getenv("GFS_RTOFS_MAX_SOURCE_DOWNLOAD_MB", "450") or "450")
RTOFS_LOCAL_FILE_FIRST = os.getenv("GFS_RTOFS_LOCAL_FILE_FIRST", "true").strip().lower() in {"1", "true", "yes", "on"}
RTOFS_FALLBACK_LOOKBACK_DAYS = int(os.getenv("GFS_RTOFS_LOOKBACK_DAYS", "3") or "3")
RTOFS_NOWCAST_HOURS = [int(x) for x in os.getenv("GFS_RTOFS_NOWCAST_HOURS", "0,3,6,9,12,15,18,21,24").replace(" ", "").split(",") if x != ""]
RTOFS_CYCLE_HOURS = [int(x) for x in os.getenv("GFS_RTOFS_CYCLES", "0").replace(" ", "").split(",") if x != ""]
RTOFS_ENABLE_DEPTH_SLICES = os.getenv("GFS_RTOFS_ENABLE_DEPTH_SLICES", "true").strip().lower() in {"1", "true", "yes", "on"}
RTOFS_DEPTH_REGIONS = [x.strip() for x in os.getenv("GFS_RTOFS_DEPTH_REGIONS", "US_west,US_east,alaska").split(",") if x.strip()]
RTOFS_DEPTH_NOWCAST_HOURS = [int(x) for x in os.getenv("GFS_RTOFS_DEPTH_NOWCAST_HOURS", "0,6,12,18,24").replace(" ", "").split(",") if x != ""]
RTOFS_DEPTH_FORECAST_HOURS = [int(x) for x in os.getenv("GFS_RTOFS_DEPTH_FORECAST_HOURS", "0,6,12,18,24").replace(" ", "").split(",") if x != ""]
RTOFS_DEPTH_MAX_SLICES = int(os.getenv("GFS_RTOFS_DEPTH_MAX_SLICES", "7") or "7")
RTOFS_FT_PER_M = 3.280839895
RTOFS_DEPTH_TARGETS_FT = [
    float(x) for x in os.getenv("GFS_RTOFS_DEPTH_TARGETS_FT", "0,5,10,25,50,100,150").replace(" ", "").split(",")
    if x != ""
]


# Flexible variable aliases seen across RTOFS/ERDDAP/NetCDF products.
SST_NAMES = (
    "sst", "sea_surface_temperature", "water_temp", "temperature", "Temperature",
    "sea_water_temperature", "sea_water_potential_temperature", "potemp", "thetao",
    "t", "tmp", "wtmp", "WTMP", "TMP",
)
U_NAMES = (
    "u", "u_velocity", "water_u", "u_current", "eastward_sea_water_velocity",
    "sea_water_x_velocity", "uo", "uvel", "uocn", "u_velocity_at_surface", "u_barotropic_velocity",
    "uogrd", "UOGRD", "ugrd", "UGRD",
)
V_NAMES = (
    "v", "v_velocity", "water_v", "v_current", "northward_sea_water_velocity",
    "sea_water_y_velocity", "vo", "vvel", "vocn", "v_velocity_at_surface", "v_barotropic_velocity",
    "vogrd", "VOGRD", "vgrd", "VGRD",
)
SALINITY_NAMES = (
    "salinity", "sss", "sea_water_salinity", "so", "salt", "salin",
    "salty", "SALTY",
)
LAT_NAMES = ("lat", "latitude", "Latitude", "y")
LON_NAMES = ("lon", "longitude", "Longitude", "x")
DEPTH_NAMES = ("depth", "Depth", "depths", "deptho", "lev", "level", "z", "Z", "depthBelowSea", "depthBelowSeaLayer", "isobaricInhPa")



def _safe_float(value: Any, default: float = float("nan")) -> float:
    try:
        f = float(value)
        return f if math.isfinite(f) else default
    except Exception:
        return default


def _cache_dir() -> Path:
    try:
        RTOFS_FILE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        return RTOFS_FILE_CACHE_DIR
    except Exception:
        root = Path(__file__).resolve().parents[3] / ".cache" / "rtofs_fallback"
        root.mkdir(parents=True, exist_ok=True)
        return root


def _candidate_dates(now: datetime | None = None) -> list[datetime]:
    now = now or datetime.now(timezone.utc)
    today = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    return [today - timedelta(days=i) for i in range(max(1, RTOFS_FALLBACK_LOOKBACK_DAYS))]


def _candidate_date_strings() -> list[str]:
    """Return newest live RTOFS directories first, with date fallback.

    NOMADS sometimes keeps only the latest operational directories and direct
    missing-product requests can return HTTP 403 instead of a useful 404.  Read
    the product index when possible so the provider follows the actual live
    directory set, then append local clock fallbacks.
    """
    dates: list[str] = []
    try:
        req = urllib.request.Request(f"{RTOFS_NOMADS_BASE}/", headers={"User-Agent": "LFTR-GFS-RTOFS/1.1"})
        with urllib.request.urlopen(req, timeout=float(os.getenv("GFS_RTOFS_INDEX_TIMEOUT_S", "8"))) as res:
            html = res.read(512_000).decode("utf-8", "ignore")
        found = sorted(set(re.findall(r"rtofs\.(\d{8})/", html)), reverse=True)
        dates.extend(found[: max(1, RTOFS_FALLBACK_LOOKBACK_DAYS)])
    except Exception:
        pass
    for day in _candidate_dates():
        ymd = day.strftime("%Y%m%d")
        if ymd not in dates:
            dates.append(ymd)
    return dates



def _lon_to_0360(value: float) -> float:
    v = float(value)
    if v < 0.0:
        v = (v + 360.0) % 360.0
    return v


def _filter_bbox_params(bbox: BBox) -> dict[str, str]:
    """Return NOMADS-compatible bbox parameters for one LFTR tile.

    RTOFS global products use the same ocean-world convention we have seen in
    RTOFS: longitudes are safest as 0..360.  The viewport/tiler owns the bbox;
    this adapter only serializes the supplied tile coordinates.
    """
    west = _lon_to_0360(float(bbox.west))
    east = _lon_to_0360(float(bbox.east))
    # Most LFTR viewports do not cross the dateline.  If they do, provider
    # network should split before calling a provider.  Keep the request bounded.
    if east < west:
        east += 360.0
    return {
        "subregion": "",
        "leftlon": f"{west:.6f}",
        "rightlon": f"{east:.6f}",
        "toplat": f"{max(float(bbox.south), float(bbox.north)):.6f}",
        "bottomlat": f"{min(float(bbox.south), float(bbox.north)):.6f}",
    }


def _rtofs_filter_url(*, ymd: str, filename: str, bbox: BBox) -> str:
    params: list[tuple[str, str]] = [
        ("file", filename),
        # Surface bundle only. Vertical/depth intelligence is fetched separately
        # from 3dz NetCDF and represented as negative sample_z_m below water.
        ("lev_surface", "on"),
        # Ocean temperature/salinity/current candidates.  NOMADS ignores absent
        # variables only by returning an error page; diagnostics keep the exact
        # URL so we can adjust names from live inventory quickly.
        ("var_WTMP", "on"),
        ("var_TMP", "on"),
        ("var_SALTY", "on"),
        ("var_SALIN", "on"),
        ("var_UOGRD", "on"),
        ("var_UGRD", "on"),
        ("var_VOGRD", "on"),
        ("var_VGRD", "on"),
        ("var_SSHG", "on"),
    ]
    params.extend(_filter_bbox_params(bbox).items())
    params.append(("dir", f"/rtofs.{ymd}"))
    return RTOFS_FILTER_BASE + "?" + urllib.parse.urlencode(params)


def _grib2_filter_candidate_urls(bbox: BBox) -> list[dict[str, Any]]:
    if not RTOFS_ENABLE_GRIB2_FILTER:
        return []
    override = os.getenv("GFS_RTOFS_FILTER_URL", "").strip()
    if override:
        return [{"url": override, "cycle": "override", "product": "filter_env_override", "source_kind": "grib2_filter", "coordinate_bounded": True}]
    out: list[dict[str, Any]] = []
    for ymd in _candidate_date_strings():
        for filename in RTOFS_GRIB2_FILES:
            out.append({
                "url": _rtofs_filter_url(ymd=ymd, filename=filename, bbox=bbox),
                "cycle": f"{ymd}00",
                "product": filename,
                "source_kind": "grib2_filter",
                "coordinate_bounded": True,
                "bbox_request": _filter_bbox_params(bbox),
            })
    return out

def _candidate_urls() -> list[dict[str, Any]]:
    # Optional exact URL override is useful while testing a new NOAA path without
    # repackaging the app.
    override = os.getenv("GFS_RTOFS_SOURCE_URL", "").strip()
    if override:
        return [{"url": override, "cycle": "override", "product": "env_override"}]

    out: list[dict[str, Any]] = []
    if not RTOFS_ENABLE_DIRECT_NETCDF:
        return out
    for ymd in _candidate_date_strings():
        for cycle in RTOFS_CYCLE_HOURS:
            cc = f"{cycle:02d}"
            for hour in RTOFS_NOWCAST_HOURS:
                hhh = f"{hour:03d}"
                # 2026 NCO/NOMADS live inventory exposes compact 2ds names
                # (rtofs_glo_2ds_n000_diag.nc / prog.nc) as well as older
                # 3hrly variants on some cycles.  Try compact names first so
                # /field?field=current can recover from RTOFS zero-point cache
                # misses using today's operational RTOFS products.
                for kind in ("prog", "diag"):
                    for filename in (
                        f"rtofs_glo_2ds_n{hhh}_{kind}.nc",
                        f"rtofs_glo_2ds_n{hhh}_3hrly_{kind}.nc",
                        f"rtofs_glo_2ds_f{hhh}_{kind}.nc",
                        f"rtofs_glo_2ds_f{hhh}_3hrly_{kind}.nc",
                    ):
                        url = f"{RTOFS_NOMADS_BASE}/rtofs.{ymd}/{filename}"
                        out.append({"url": url, "cycle": f"{ymd}{cc}", "forecast_hour": hour, "product": filename, "source_kind": "2ds_surface"})
    return out


def _download_cached(url: str) -> tuple[str | None, dict[str, Any]]:
    started = time.time()
    digest = hashlib.sha256(url.encode("utf-8")).hexdigest()
    suffix = ".grib2" if ("filter_rtofs" in url or url.lower().endswith((".grb2", ".grib2"))) else ".nc"
    path = _cache_dir() / f"{digest}{suffix}"
    meta_path = _cache_dir() / f"{digest}.json"
    diag: dict[str, Any] = {"url": url, "cache_path": str(path), "provider": "rtofs", "download_method": "curl_or_urllib"}
    try:
        if path.exists() and path.stat().st_size > 0 and (time.time() - path.stat().st_mtime) < RTOFS_CACHE_TTL_SECONDS:
            diag.update({"ok": True, "status": "file_cache_hit", "bytes": path.stat().st_size, "latency_ms": int((time.time() - started) * 1000)})
            return str(path), diag
    except Exception:
        pass

    tmp = path.with_suffix(".tmp")
    if tmp.exists():
        try: tmp.unlink()
        except Exception: pass

    curl = shutil.which("curl")
    if curl:
        max_time = str(os.getenv("GFS_RTOFS_CURL_MAX_TIME_S", "240"))
        cmd = [
            curl, "-L", "--fail", "--silent", "--show-error",
            "-A", os.getenv("GFS_RTOFS_USER_AGENT", "LFTR-GFS-RTOFS/2.0"),
            "--connect-timeout", os.getenv("GFS_RTOFS_CURL_CONNECT_TIMEOUT_S", "10"),
            "--max-time", max_time,
            "-o", str(tmp),
            "-w", "HTTP=%{http_code} SIZE=%{size_download} TIME=%{time_total}",
            url,
        ]
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=float(max_time) + 8.0, check=False)
        size = tmp.stat().st_size if tmp.exists() else 0
        diag.update({"returncode": proc.returncode, "stdout": (proc.stdout or "")[-300:], "stderr": (proc.stderr or "")[-500:], "bytes": size})
        if proc.returncode == 0 and size > 0:
            # NOMADS may return an HTML error page to libraries that attempt
            # remote NetCDF access.  The provider is local-file-first, so reject
            # HTML/error bodies before xarray ever sees them.
            try:
                head = tmp.read_bytes()[:256].lstrip().lower()
            except Exception:
                head = b""
            if head.startswith(b"<!doctype") or head.startswith(b"<html") or b"403 forbidden" in head[:180]:
                try: tmp.unlink()
                except Exception: pass
                diag.update({"ok": False, "status": "download_returned_html_error", "html_guard": True, "latency_ms": int((time.time() - started) * 1000)})
                return None, diag
            max_bytes = int(RTOFS_MAX_SOURCE_DOWNLOAD_MB * 1024 * 1024)
            if size > max_bytes:
                try: tmp.unlink()
                except Exception: pass
                diag.update({"ok": False, "status": "source_file_too_large", "max_mb": RTOFS_MAX_SOURCE_DOWNLOAD_MB, "latency_ms": int((time.time() - started) * 1000)})
                return None, diag
            tmp.replace(path)
            try:
                meta_path.write_text(json.dumps({"url": url, "bytes": size, "ts": time.time()}, separators=(",", ":")))
            except Exception:
                pass
            diag.update({"ok": True, "status": "downloaded", "latency_ms": int((time.time() - started) * 1000)})
            return str(path), diag
        try: tmp.unlink()
        except Exception: pass

    # urllib fallback, mostly for systems without curl.
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "LFTR-GFS-RTOFS/1.0"})
        with urllib.request.urlopen(req, timeout=float(os.getenv("GFS_RTOFS_HTTP_TIMEOUT_S", "90"))) as res:
            payload = res.read()
        if payload:
            if len(payload) > int(RTOFS_MAX_SOURCE_DOWNLOAD_MB * 1024 * 1024):
                diag.update({"ok": False, "status": "source_file_too_large", "bytes": len(payload), "latency_ms": int((time.time() - started) * 1000)})
                return None, diag
            path.write_bytes(payload)
            diag.update({"ok": True, "status": "downloaded_urllib", "bytes": len(payload), "latency_ms": int((time.time() - started) * 1000)})
            return str(path), diag
    except Exception as exc:
        diag.update({"urllib_error": str(exc)})

    diag.setdefault("status", "download_failed")
    diag.update({"ok": False, "latency_ms": int((time.time() - started) * 1000)})
    return None, diag


def _open_dataset(path: str) -> tuple[xr.Dataset | None, str | None, str | None]:
    lower = str(path).lower()
    if lower.endswith((".grb2", ".grib2")):
        try:
            datasets = cfgrib.open_datasets(path, indexpath="") if cfgrib is not None else []
            if datasets:
                if len(datasets) == 1:
                    return datasets[0], "cfgrib", None
                # Merge compatible GRIB hypercubes for filtered multi-var tiles.
                ds = xr.merge(datasets, compat="override", join="outer")
                try:
                    for extra in datasets:
                        if extra is not ds:
                            extra.close()
                except Exception:
                    pass
                return ds, "cfgrib_multi", None
        except Exception as exc:
            return None, None, f"cfgrib_open_failed: {exc}"
    engines = ["netcdf4", "h5netcdf", "scipy", None]
    last = None
    for engine in engines:
        try:
            ds = xr.open_dataset(path, engine=engine) if engine else xr.open_dataset(path)
            return ds, engine or "default", None
        except Exception as exc:
            last = exc
    return None, None, str(last) if last else "open_failed"


def _find_var(ds: xr.Dataset, names: tuple[str, ...]):
    lower = {str(k).lower(): k for k in ds.variables.keys()}
    # 1) exact / case-insensitive exact matches only.  RTOFS uses names like
    #    u_velocity, v_velocity, sst, u_barotropic_velocity, v_barotropic_velocity.
    for name in names:
        if name in ds.variables:
            return ds[name], name
        real = lower.get(str(name).lower())
        if real and real in ds.variables:
            return ds[real], real
    # 2) controlled loose fallback.  Do NOT allow one-letter aliases such as
    #    "t", "u", or "v" to match arbitrary words like velocity; that was
    #    mapping sst/current_v to u_barotropic_velocity in live diagnostics.
    loose_names = [str(n).lower() for n in names if len(str(n)) >= 3]
    for key in ds.variables.keys():
        lk = str(key).lower()
        for name in loose_names:
            if name in lk:
                return ds[key], key
    return None, None

def _squeeze_to_2d(arr):
    if arr is None:
        return None
    try:
        arr = arr.squeeze(drop=True)
        while getattr(arr, "ndim", 0) > 2:
            arr = arr.isel({arr.dims[0]: 0}, drop=True)
        if getattr(arr, "ndim", 0) == 2:
            return arr
        if getattr(arr, "ndim", 0) == 1:
            return arr
    except Exception:
        return None
    return None


def _coord_values(ds: xr.Dataset, names: tuple[str, ...]):
    for name in names:
        if name in ds.coords:
            return ds.coords[name], name
        if name in ds.variables:
            return ds[name], name
    lower = {str(k).lower(): k for k in list(ds.coords.keys()) + list(ds.variables.keys())}
    for name in names:
        real = lower.get(name.lower())
        if real:
            return (ds.coords[real] if real in ds.coords else ds[real]), real
    return None, None


def _subset_1d_grid(ds: xr.Dataset, bbox: BBox, varnames: dict[str, str]) -> tuple[dict[str, list[list[float]]], list[float], list[float], dict[str, Any]]:
    """Subset either rectilinear 1-D lat/lon grids or RTOFS curvilinear 2-D grids.

    Live RTOFS 2ds NetCDF files expose Latitude(Y,X) and Longitude(Y,X).  The
    older sampler only accepted 1-D coordinates, so the warmer downloaded valid
    files but returned grid_subset_empty.  This function keeps the old 1-D path
    and adds a 2-D bbox mask/window for curvilinear RTOFS grids.
    """
    lat_arr, lat_name = _coord_values(ds, LAT_NAMES)
    lon_arr, lon_name = _coord_values(ds, LON_NAMES)
    diag: dict[str, Any] = {"lat_name": lat_name, "lon_name": lon_name}
    if lat_arr is None or lon_arr is None:
        return {}, [], [], {**diag, "reason": "missing_lat_lon"}
    lat_s = _squeeze_to_2d(lat_arr)
    lon_s = _squeeze_to_2d(lon_arr)
    if lat_s is None or lon_s is None:
        return {}, [], [], {**diag, "reason": "lat_lon_unreadable", "lat_dims": list(getattr(lat_arr, "dims", [])), "lon_dims": list(getattr(lon_arr, "dims", []))}

    # RTOFS curvilinear grid: Latitude(Y,X), Longitude(Y,X).
    if getattr(lat_s, "ndim", 0) == 2 and getattr(lon_s, "ndim", 0) == 2:
        try:
            import numpy as _np
            lat2 = _np.asarray(lat_s.values, dtype="float64")
            lon2_raw = _np.asarray(lon_s.values, dtype="float64")
            lon2 = ((lon2_raw + 180.0) % 360.0) - 180.0
        except Exception as exc:
            return {}, [], [], {**diag, "reason": "2d_lat_lon_values_unreadable", "error": str(exc)}
        south, north = min(float(bbox.south), float(bbox.north)), max(float(bbox.south), float(bbox.north))
        west, east = float(bbox.west), float(bbox.east)
        if west <= east:
            lon_mask = (lon2 >= west) & (lon2 <= east)
        else:
            lon_mask = (lon2 >= west) | (lon2 <= east)
        mask = _np.isfinite(lat2) & _np.isfinite(lon2) & (lat2 >= south) & (lat2 <= north) & lon_mask
        ys, xs = _np.where(mask)
        if ys.size == 0 or xs.size == 0:
            try:
                lat_range = [float(_np.nanmin(lat2)), float(_np.nanmax(lat2))]
                lon_range = [float(_np.nanmin(lon2)), float(_np.nanmax(lon2))]
            except Exception:
                lat_range, lon_range = None, None
            return {}, [], [], {**diag, "reason": "bbox_no_2d_coord_overlap", "lat_dims": list(lat_s.dims), "lon_dims": list(lon_s.dims), "lat_range": lat_range, "lon_range": lon_range, "bbox": bbox.as_list()}
        iy0, iy1 = int(ys.min()), int(ys.max()) + 1
        ix0, ix1 = int(xs.min()), int(xs.max()) + 1
        win_mask = mask[iy0:iy1, ix0:ix1]
        lat_win = lat2[iy0:iy1, ix0:ix1]
        lon_win = lon2[iy0:iy1, ix0:ix1]
        out: dict[str, list[list[float]]] = {}
        for out_name, ds_var_name in varnames.items():
            if ds_var_name not in ds.variables:
                continue
            arr = _squeeze_to_2d(ds[ds_var_name])
            if arr is None or getattr(arr, "ndim", 0) != 2:
                continue
            dims = list(arr.dims)
            # RTOFS variables generally use Y,X; otherwise fall back to last two dims.
            ydim = "Y" if "Y" in dims else dims[-2]
            xdim = "X" if "X" in dims else dims[-1]
            try:
                vals = _np.asarray(arr.isel({ydim: slice(iy0, iy1), xdim: slice(ix0, ix1)}).values, dtype="float64")
                vals = _np.where(win_mask, vals, _np.nan)
                out[out_name] = [[_safe_float(vals[i, j]) for j in range(vals.shape[1])] for i in range(vals.shape[0])]
            except Exception:
                continue
        # Attach true curvilinear coordinates for point sampling.  Keep return
        # signature unchanged by carrying these in subset diagnostics; caller
        # promotes them into payload.
        lat_grid = [[_safe_float(lat_win[i, j]) if bool(win_mask[i, j]) else float("nan") for j in range(lat_win.shape[1])] for i in range(lat_win.shape[0])]
        lon_grid = [[_safe_float(lon_win[i, j]) if bool(win_mask[i, j]) else float("nan") for j in range(lon_win.shape[1])] for i in range(lon_win.shape[0])]
        center_lats = [_safe_float(v) for v in _np.nanmean(_np.where(win_mask, lat_win, _np.nan), axis=1).tolist()]
        center_lons = [_safe_float(v) for v in _np.nanmean(_np.where(win_mask, lon_win, _np.nan), axis=0).tolist()]
        return out, center_lats, center_lons, {**diag, "reason": "ok", "grid_kind": "2d_curvilinear", "index_window": [iy0, iy1, ix0, ix1], "matched_cells": int(ys.size), "lat_dims": list(lat_s.dims), "lon_dims": list(lon_s.dims), "lat_grid": lat_grid, "lon_grid": lon_grid}

    # Legacy rectilinear path.
    if getattr(lat_s, "ndim", 0) != 1 or getattr(lon_s, "ndim", 0) != 1:
        return {}, [], [], {**diag, "reason": "not_1d_or_2d_coords", "lat_dims": list(getattr(lat_arr, "dims", [])), "lon_dims": list(getattr(lon_arr, "dims", []))}
    lats = [_safe_float(v) for v in lat_s.values.tolist()]
    lons_raw = [_safe_float(v) for v in lon_s.values.tolist()]
    lons_pm = [((v + 180.0) % 360.0) - 180.0 if math.isfinite(v) else v for v in lons_raw]
    lat_idx = [i for i, v in enumerate(lats) if math.isfinite(v) and min(bbox.south, bbox.north) <= v <= max(bbox.south, bbox.north)]
    lon_idx = [j for j, v in enumerate(lons_pm) if math.isfinite(v) and min(bbox.west, bbox.east) <= v <= max(bbox.west, bbox.east)]
    if not lat_idx or not lon_idx:
        return {}, [], [], {**diag, "reason": "bbox_no_coord_overlap", "lat_range": [min(lats or [0]), max(lats or [0])], "lon_range": [min(lons_pm or [0]), max(lons_pm or [0])], "bbox": bbox.as_list()}
    iy0, iy1 = min(lat_idx), max(lat_idx) + 1
    ix0, ix1 = min(lon_idx), max(lon_idx) + 1
    out: dict[str, list[list[float]]] = {}
    for out_name, ds_var_name in varnames.items():
        arr = _squeeze_to_2d(ds[ds_var_name])
        if arr is None or getattr(arr, "ndim", 0) != 2:
            continue
        dims = list(arr.dims)
        indexers = {}
        if lat_name in dims:
            indexers[lat_name] = slice(iy0, iy1)
        else:
            indexers[dims[-2]] = slice(iy0, iy1)
        if lon_name in dims:
            indexers[lon_name] = slice(ix0, ix1)
        else:
            indexers[dims[-1]] = slice(ix0, ix1)
        sub = arr.isel(indexers)
        vals = sub.values
        out[out_name] = [[_safe_float(vals[i][j]) for j in range(vals.shape[1])] for i in range(vals.shape[0])]
    return out, lats[iy0:iy1], lons_pm[ix0:ix1], {**diag, "reason": "ok", "grid_kind": "1d_rectilinear", "index_window": [iy0, iy1, ix0, ix1]}



def _ft_to_m(ft: Any) -> float:
    try:
        return float(ft) / RTOFS_FT_PER_M
    except Exception:
        return float("nan")


def _m_to_ft(m: Any) -> float:
    try:
        return float(m) * RTOFS_FT_PER_M
    except Exception:
        return float("nan")


def _depth_targets_for_stride(stride: int) -> list[dict[str, float]]:
    """LOD density policy for vertical ocean intelligence.

    LFTR's public ocean-depth contract is feet. RTOFS model coordinates are meters,
    so targets are declared in feet, converted to meters for nearest-model-level
    selection, then exported back as negative-feet keys. This keeps the map/HUD
    language universal: below-water truth is negative feet; visual extrusion is
    positive feet.
    """
    targets_ft = [x for x in RTOFS_DEPTH_TARGETS_FT if math.isfinite(float(x)) and float(x) >= 0.0]
    if not targets_ft:
        targets_ft = [0.0, 5.0, 10.0, 25.0, 50.0, 100.0, 150.0]
    step = max(1, int(stride or 1))
    if step >= 12:      # global, roughly 1 degree surface field
        selected_ft = [0.0]
    elif step >= 6:     # regional, roughly 0.5 degree
        selected_ft = [x for x in targets_ft if x in {0.0, 25.0, 50.0, 100.0, 150.0}]
    else:               # local/native detail: full universal feet ladder
        selected_ft = targets_ft[:max(1, RTOFS_DEPTH_MAX_SLICES)]
    if 150.0 in targets_ft and 150.0 not in selected_ft and step < 12:
        selected_ft = (selected_ft + [150.0])[:max(1, max(RTOFS_DEPTH_MAX_SLICES, len(selected_ft) + 1))]
    out = []
    for ft in selected_ft[:max(1, RTOFS_DEPTH_MAX_SLICES)]:
        out.append({"target_depth_ft": float(ft), "target_depth_m": _ft_to_m(ft)})
    return out



def _as_negative_ocean_depth_m(depth_value: Any) -> float:
    """Return LFTR ocean sample depth convention: 0 at surface, negative below water."""
    d = _safe_float(depth_value, 0.0)
    if not math.isfinite(d):
        return float("nan")
    if abs(d) <= 1.0e-9:
        return 0.0
    return -abs(float(d))

def _depth_key_from_sample_z(sample_z_m: float) -> str:
    if not math.isfinite(sample_z_m) or abs(sample_z_m) <= 1.0e-9:
        return "0ft"
    return f"-{int(round(abs(_m_to_ft(sample_z_m))))}ft"


def _depth_key_from_target_ft(target_ft: Any) -> str:
    ft = _safe_float(target_ft, 0.0)
    if not math.isfinite(ft) or abs(ft) <= 1.0e-9:
        return "0ft"
    return f"-{int(round(abs(float(ft))))}ft"

def _depth_region_for_bbox(bbox: BBox) -> str | None:
    west, east = float(bbox.west), float(bbox.east)
    south, north = float(bbox.south), float(bbox.north)
    mid_lon = (west + east) / 2.0
    mid_lat = (south + north) / 2.0
    # NOAA/NCO publishes regional high-vertical-resolution RTOFS files.  Start
    # with broad routing; if a file is missing it simply fails and the next
    # candidate is tried.  SoCal should route to US_west.
    enabled = {x.lower() for x in RTOFS_DEPTH_REGIONS}
    if "us_west" in enabled and -135.0 <= mid_lon <= -104.0 and 18.0 <= mid_lat <= 55.0:
        return "US_west"
    if "us_east" in enabled and -100.0 <= mid_lon <= -45.0 and 15.0 <= mid_lat <= 55.0:
        return "US_east"
    if "alaska" in enabled and -180.0 <= mid_lon <= -120.0 and 50.0 <= mid_lat <= 75.0:
        return "alaska"
    return None


def _depth_candidate_urls(bbox: BBox) -> list[dict[str, Any]]:
    if not (RTOFS_ENABLE_DIRECT_NETCDF and RTOFS_ENABLE_DEPTH_SLICES):
        return []
    override = os.getenv("GFS_RTOFS_DEPTH_SOURCE_URL", "").strip()
    if override:
        return [{"url": override, "cycle": "override", "product": "depth_env_override", "depth_region": "override", "source_kind": "3dz"}]
    region = _depth_region_for_bbox(bbox)
    if not region:
        return []
    out: list[dict[str, Any]] = []
    for ymd in _candidate_date_strings():
        for cycle in RTOFS_CYCLE_HOURS:
            cc = f"{cycle:02d}"
            # Prefer nowcast first; then forecast F000.. as fallback.  NCO lists
            # rtofs_glo_3dz_(f|n)xxx_6hrly_hvr_US_west.nc and sibling regional
            # files for high-vertical-resolution volume products.
            for hour in RTOFS_DEPTH_NOWCAST_HOURS:
                hhh = f"{hour:03d}"
                filename = f"rtofs_glo_3dz_n{hhh}_6hrly_hvr_{region}.nc"
                out.append({"url": f"{RTOFS_NOMADS_BASE}/rtofs.{ymd}/{filename}", "cycle": f"{ymd}{cc}", "forecast_hour": hour, "product": filename, "depth_region": region, "source_kind": "3dz_nowcast"})
            for hour in RTOFS_DEPTH_FORECAST_HOURS:
                hhh = f"{hour:03d}"
                filename = f"rtofs_glo_3dz_f{hhh}_6hrly_hvr_{region}.nc"
                out.append({"url": f"{RTOFS_NOMADS_BASE}/rtofs.{ymd}/{filename}", "cycle": f"{ymd}{cc}", "forecast_hour": hour, "product": filename, "depth_region": region, "source_kind": "3dz_forecast"})
    return out


def _reduce_to_2d_at_depth(arr, *, depth_name: str | None, depth_index: int | None, lat_name: str | None, lon_name: str | None):
    if arr is None:
        return None
    try:
        arr = arr.squeeze(drop=True)
        if depth_name and depth_name in getattr(arr, "dims", ()) and depth_index is not None:
            arr = arr.isel({depth_name: int(depth_index)}, drop=True)
        # Drop leftover non-spatial singleton/time/member dimensions, but keep
        # lat/lon dimensions intact when possible.
        while getattr(arr, "ndim", 0) > 2:
            dims = list(arr.dims)
            drop_dim = next((d for d in dims if d not in {lat_name, lon_name}), dims[0])
            arr = arr.isel({drop_dim: 0}, drop=True)
        return arr if getattr(arr, "ndim", 0) == 2 else None
    except Exception:
        return None


def _subset_depth_slices_from_dataset(ds: xr.Dataset, bbox: BBox, varnames: dict[str, str], stride: int) -> tuple[dict[str, Any], dict[str, Any]]:
    lat_arr, lat_name = _coord_values(ds, LAT_NAMES)
    lon_arr, lon_name = _coord_values(ds, LON_NAMES)
    depth_arr, depth_name = _coord_values(ds, DEPTH_NAMES)
    target_specs_for_diag = _depth_targets_for_stride(stride)
    diag: dict[str, Any] = {
        "lat_name": lat_name,
        "lon_name": lon_name,
        "depth_name": depth_name,
        "requested_depths_ft": [round(float(t.get("target_depth_ft", 0.0)), 3) for t in target_specs_for_diag],
        "requested_depths_m_internal": [round(float(t.get("target_depth_m", 0.0)), 3) for t in target_specs_for_diag],
        "depth_unit_contract": "feet_universal_negative_below_water",
    }
    if lat_arr is None or lon_arr is None or depth_arr is None:
        return {}, {**diag, "reason": "missing_lat_lon_or_depth"}
    lat_s = _squeeze_to_2d(lat_arr)
    lon_s = _squeeze_to_2d(lon_arr)
    depth_s = depth_arr.squeeze(drop=True)
    if lat_s is None or lon_s is None or getattr(lat_s, "ndim", 0) != 1 or getattr(lon_s, "ndim", 0) != 1:
        return {}, {**diag, "reason": "not_1d_lat_lon"}
    try:
        depth_values = [_safe_float(v) for v in depth_s.values.tolist()]
    except Exception:
        return {}, {**diag, "reason": "depth_values_unreadable"}
    lats = [_safe_float(v) for v in lat_s.values.tolist()]
    lons_raw = [_safe_float(v) for v in lon_s.values.tolist()]
    lons_pm = [((v + 180.0) % 360.0) - 180.0 if math.isfinite(v) else v for v in lons_raw]
    lat_idx = [i for i, v in enumerate(lats) if math.isfinite(v) and min(bbox.south, bbox.north) <= v <= max(bbox.south, bbox.north)]
    lon_idx = [j for j, v in enumerate(lons_pm) if math.isfinite(v) and min(bbox.west, bbox.east) <= v <= max(bbox.west, bbox.east)]
    if not lat_idx or not lon_idx:
        return {}, {**diag, "reason": "bbox_no_coord_overlap"}
    iy0, iy1 = min(lat_idx), max(lat_idx) + 1
    ix0, ix1 = min(lon_idx), max(lon_idx) + 1
    step = max(1, int(stride or 1))
    target_specs = _depth_targets_for_stride(step)
    selected: dict[str, Any] = {}
    used_indexes: set[int] = set()
    for target_spec in target_specs:
        target_ft = _safe_float(target_spec.get("target_depth_ft"), 0.0)
        target_m = _safe_float(target_spec.get("target_depth_m"), _ft_to_m(target_ft))
        finite_depths = [(i, d) for i, d in enumerate(depth_values) if math.isfinite(d)]
        if not finite_depths:
            continue
        # RTOFS depth coordinates are commonly positive-down. LFTR stores ocean
        # sample z as negative below water while keeping render extrusion positive.
        di, actual_depth = min(finite_depths, key=lambda x: abs(abs(float(x[1])) - abs(float(target_m))))
        if di in used_indexes and target_ft != 0.0:
            continue
        used_indexes.add(di)
        grids: dict[str, list[list[float]]] = {}
        for out_name, ds_var_name in varnames.items():
            if ds_var_name not in ds.variables:
                continue
            arr2 = _reduce_to_2d_at_depth(ds[ds_var_name], depth_name=depth_name, depth_index=di, lat_name=lat_name, lon_name=lon_name)
            if arr2 is None:
                continue
            dims = list(arr2.dims)
            indexers = {}
            indexers[lat_name if lat_name in dims else dims[-2]] = slice(iy0, iy1)
            indexers[lon_name if lon_name in dims else dims[-1]] = slice(ix0, ix1)
            vals = arr2.isel(indexers).values
            if step > 1:
                vals = vals[::step, ::step]
            grids[out_name] = [[_safe_float(vals[i][j]) for j in range(vals.shape[1])] for i in range(vals.shape[0])]
        if grids:
            sample_z_m = _as_negative_ocean_depth_m(actual_depth)
            target_z_m = _as_negative_ocean_depth_m(target_m)
            water_depth_m = abs(float(sample_z_m)) if math.isfinite(sample_z_m) else None
            key = _depth_key_from_target_ft(target_ft)
            selected[key] = {
                "depth_m": round(float(sample_z_m), 3),
                "sample_z_m": round(float(sample_z_m), 3),
                "water_depth_m": round(float(water_depth_m), 3) if water_depth_m is not None else None,
                "depth_ft": round(-abs(_m_to_ft(water_depth_m or 0.0)), 1),
                "sample_z_ft": round(-abs(_m_to_ft(water_depth_m or 0.0)), 1),
                "water_depth_ft": round(abs(_m_to_ft(water_depth_m or 0.0)), 1),
                "actual_depth_key_ft": _depth_key_from_sample_z(sample_z_m),
                "target_depth_m": round(float(target_z_m), 3),
                "target_water_depth_m": abs(float(target_z_m)),
                "target_depth_ft": round(-abs(float(target_ft)), 1),
                "target_water_depth_ft": round(abs(float(target_ft)), 1),
                "render_altitude_m": 0.0,
                "render_altitude_ft": 0.0,
                "render_extrusion_m": round(float(water_depth_m or 0.0), 3),
                "render_extrusion_ft": round(abs(_m_to_ft(water_depth_m or 0.0)), 1),
                "depth_unit_contract": "feet_universal_negative_below_water",
                "z_axis_policy": "sample_z_ft_negative_below_water_render_extrusion_ft_positive",
                **grids,
            }
    if not selected:
        return {}, {**diag, "reason": "no_depth_slices_extracted", "available_depths_sample": depth_values[:12]}
    return selected, {**diag, "reason": "ok", "depth_keys": list(selected.keys()), "available_depths_sample": depth_values[:12], "index_window": [iy0, iy1, ix0, ix1]}


def _bait_depth_intel_from_slices(depth_slices: dict[str, Any]) -> dict[str, Any]:
    scores: dict[str, Any] = {}
    best_key = None
    best_score = -1.0
    for key, sl in (depth_slices or {}).items():
        temp_grid = sl.get("sst") or sl.get("temperature") or []
        u_grid = sl.get("current_u") or []
        v_grid = sl.get("current_v") or []
        temps = [float(x) for row in temp_grid for x in row if isinstance(x, (int, float)) and math.isfinite(float(x))]
        speeds = []
        for ur, vr in zip(u_grid, v_grid):
            for uu, vv in zip(ur, vr):
                if isinstance(uu, (int, float)) and isinstance(vv, (int, float)) and math.isfinite(float(uu)) and math.isfinite(float(vv)):
                    speeds.append(math.hypot(float(uu), float(vv)) * 1.9438444924)
        mean_temp = sum(temps) / len(temps) if temps else None
        mean_speed = sum(speeds) / len(speeds) if speeds else 0.0
        temp_score = 0.5 if mean_temp is None else max(0.0, min(1.0, 1.0 - abs(float(mean_temp) - 17.5) / 8.5))
        current_score = max(0.0, min(1.0, mean_speed / 2.0))
        # Slightly favor upper/mid water for bait, but let conditions dominate.
        sample_z_m = _safe_float(sl.get("sample_z_m", sl.get("depth_m")), 0.0)
        water_depth_m = _safe_float(sl.get("water_depth_m"), abs(sample_z_m))
        vertical_bias = max(0.25, 1.0 - max(0.0, water_depth_m - 25.0) / 125.0)
        score = max(0.0, min(1.0, temp_score * 0.58 + current_score * 0.24 + vertical_bias * 0.18))
        scores[key] = {
            "depth_m": sample_z_m,
            "sample_z_m": sample_z_m,
            "water_depth_m": water_depth_m,
            "depth_ft": round(-abs(_m_to_ft(water_depth_m)), 1),
            "sample_z_ft": round(-abs(_m_to_ft(water_depth_m)), 1),
            "water_depth_ft": round(abs(_m_to_ft(water_depth_m)), 1),
            "render_extrusion_m": water_depth_m,
            "render_extrusion_ft": round(abs(_m_to_ft(water_depth_m)), 1),
            "score": round(score, 4),
            "mean_temp_c": round(mean_temp, 3) if mean_temp is not None else None,
            "mean_current_kt": round(mean_speed, 4),
            "sample_count": len(temps),
        }
        if score > best_score:
            best_key, best_score = key, score
    if not scores:
        return {"source": "rtofs_depth_slices", "available": False, "reason": "no_depth_slice_scores"}
    best = scores.get(best_key or "") or {}
    return {
        "source": "rtofs_depth_slices",
        "available": True,
        "depth_unit_contract": "feet_universal_negative_below_water",
        "z_axis_policy": "sample_z_ft_negative_below_water_render_extrusion_ft_positive",
        "best_depth_key": best_key,
        "best_sample_z_m": best.get("sample_z_m", best.get("depth_m")),
        "best_depth_m": best.get("sample_z_m", best.get("depth_m")),
        "best_water_depth_m": best.get("water_depth_m"),
        "best_sample_z_ft": best.get("sample_z_ft", best.get("depth_ft")),
        "best_depth_ft": best.get("sample_z_ft", best.get("depth_ft")),
        "best_water_depth_ft": best.get("water_depth_ft"),
        "best_render_extrusion_m": best.get("render_extrusion_m"),
        "best_render_extrusion_ft": best.get("render_extrusion_ft"),
        "best_score": best.get("score"),
        "score_by_depth": scores,
        "fishing_style": _fishing_style_from_depth(best.get("water_depth_m", abs(_safe_float(best.get("depth_m"), 0.0))), best.get("score")),
    }


def _fishing_style_from_depth(depth_m: Any, score: Any = None) -> dict[str, Any]:
    d = _safe_float(depth_m, float("nan"))
    s = _safe_float(score, float("nan"))
    if not math.isfinite(d):
        return {"mode": "surface-search", "summary": "surface current/SST search until depth slices are available"}
    if d <= 8:
        mode = "surface-foamline-casting"
        gear = "light surface iron, small swimbait, flylined bait"
    elif d <= 25:
        mode = "midwater-metered-retrieve"
        gear = "slow-trolled bait, casting metal, mid-depth swimbait"
    elif d <= 60:
        mode = "deep-metered-bait-school"
        gear = "yo-yo iron, dropper loop, sonar-marked bait depth"
    else:
        mode = "deep-structure-or-canyon-edge"
        gear = "heavy dropper/vertical jig; verify legal/safety conditions"
    return {"mode": mode, "gear_hint": gear, "confidence": round(s, 3) if math.isfinite(s) else None, "summary": f"best bait signal near {round(d * 3.28084,1)} ft", "depth_display_ft": round(d * 3.28084, 1), "depth_unit_contract": "feet_universal"}


def _attach_depth_slices(payload: dict[str, Any], bbox: BBox, stride: int, diagnostics: list[dict[str, Any]]) -> None:
    if not RTOFS_ENABLE_DEPTH_SLICES:
        payload.setdefault("source_meta", {})["depth_slice_status"] = "disabled"
        return
    names = {}
    for key, candidates in (("sst", SST_NAMES), ("current_u", U_NAMES), ("current_v", V_NAMES), ("salinity", SALINITY_NAMES)):
        names[key] = None
    for cand in _depth_candidate_urls(bbox):
        url = cand["url"]
        path, dldiag = _download_cached(url)
        diagnostics.append({**dldiag, "candidate": cand, "depth_probe": True})
        if not path:
            continue
        ds = None
        try:
            ds, engine, open_error = _open_dataset(path)
            if ds is None:
                diagnostics.append({"url": url, "status": "depth_open_failed", "error": open_error, "candidate": cand})
                continue
            varnames: dict[str, str] = {}
            for key, candidates in (("sst", SST_NAMES), ("current_u", U_NAMES), ("current_v", V_NAMES), ("salinity", SALINITY_NAMES)):
                arr, name = _find_var(ds, candidates)
                if arr is not None and name:
                    varnames[key] = str(name)
            if not {"sst", "current_u", "current_v"}.issubset(varnames):
                diagnostics.append({"url": url, "status": "depth_required_vars_missing", "selected_names": varnames, "candidate": cand})
                continue
            slices, diag = _subset_depth_slices_from_dataset(ds, bbox, varnames, stride)
            diagnostics.append({"url": url, "status": "depth_parsed", "engine": engine, "parse": diag, "candidate": cand})
            if slices:
                payload["depth_slices"] = slices
                payload["bait_depth_intel"] = _bait_depth_intel_from_slices(slices)
                meta = payload.setdefault("source_meta", {})
                meta.update({
                    "depth_slice_status": "ready",
                    "depth_source": "rtofs_noaa_3dz_hvr",
                    "z_axis_policy": "sample_z_ft_negative_below_water_render_extrusion_ft_positive",
                    "depth_selected_dataset": url,
                    "depth_selected_vars": list(varnames.values()),
                    "depth_keys": list(slices.keys()),
                    "depth_region": cand.get("depth_region"),
                    "bait_depth_intel": payload.get("bait_depth_intel"),
                    "depth_unit_contract": "feet_universal_negative_below_water",
                    "mode": "rtofs_noaa_surface_plus_depth_slices_ocean_bundle_v3_ft_depth",
                })
                return
        except Exception as exc:
            diagnostics.append({"url": url, "status": "depth_exception", "error": str(exc), "candidate": cand})
        finally:
            if ds is not None:
                try: ds.close()
                except Exception: pass
    payload.setdefault("source_meta", {})["depth_slice_status"] = "empty_or_unavailable"


def _payload_from_dataset(ds: xr.Dataset, bbox: BBox, stride: int, source_url: str, cycle: Any, attempt_kind: str = "rtofs_surface_netcdf") -> tuple[dict[str, Any] | None, dict[str, Any]]:
    found = {}
    names = {}
    for key, candidates in (("sst", SST_NAMES), ("current_u", U_NAMES), ("current_v", V_NAMES), ("salinity", SALINITY_NAMES)):
        arr, name = _find_var(ds, candidates)
        if arr is not None and name:
            found[key] = arr
            names[key] = name
    diag: dict[str, Any] = {
        "dims": {k: int(v) for k, v in ds.sizes.items()},
        "vars": list(ds.variables)[:40],
        "selected_names": names,
        "stride": max(1, int(stride or 1)),
    }
    if "sst" not in names or "current_u" not in names or "current_v" not in names:
        return None, {**diag, "reason": "required_vars_missing"}
    # Downsample after slicing to keep output payloads sane.
    grids, lat_values, lon_values, subset_diag = _subset_1d_grid(ds, bbox, names)
    diag["subset"] = subset_diag
    if not grids.get("sst") or not grids.get("current_u") or not grids.get("current_v"):
        return None, {**diag, "reason": "grid_subset_empty"}
    step = max(1, int(stride or 1))
    lat_grid = subset_diag.get("lat_grid") if isinstance(subset_diag, dict) else None
    lon_grid = subset_diag.get("lon_grid") if isinstance(subset_diag, dict) else None
    if step > 1:
        for k, g in list(grids.items()):
            grids[k] = [row[::step] for row in g[::step]]
        lat_values = lat_values[::step]
        lon_values = lon_values[::step]
        if lat_grid:
            lat_grid = [row[::step] for row in lat_grid[::step]]
        if lon_grid:
            lon_grid = [row[::step] for row in lon_grid[::step]]
    sst = grids.get("sst") or []
    u = grids.get("current_u") or []
    v = grids.get("current_v") or []
    sal = grids.get("salinity") or []
    mask_raw, landmask_meta = ocean_mask_from_grids(sst=sst, current_u=u, current_v=v, salinity=sal)
    mask, erode_meta = erode_ocean_mask(mask_raw, int(os.getenv("GFS_RTOFS_LANDMASK_ERODE_CELLS", "1") or "1"))
    if mask:
        sst = [[plausible_sst_c(v) for v in row] for row in mask_grid(sst, mask)]
        u = mask_grid(u, mask)
        v = mask_grid(v, mask)
        sal = mask_grid(sal, mask)
    speed: list[list[float]] = []
    for ur, vr in zip(u, v):
        row = []
        for uu, vv in zip(ur, vr):
            row.append(math.sqrt(uu * uu + vv * vv) if math.isfinite(uu) and math.isfinite(vv) else float("nan"))
        speed.append(row)
    has_sst = any(math.isfinite(x) for row in sst for x in row if isinstance(x, (int, float)))
    has_current = any(math.isfinite(uu) and math.isfinite(vv) for ur, vr in zip(u, v) for uu, vv in zip(ur, vr) if isinstance(uu, (int, float)) and isinstance(vv, (int, float)))
    if not (has_sst and has_current):
        return None, {**diag, "reason": "quality_gate_empty_after_mask", "has_sst": has_sst, "has_current": has_current}
    ny = len(sst)
    nx = len(sst[0]) if sst and sst[0] else 0
    quality_gate = {
        "live_ncss_ok": True,
        "live_ocean_truth_ok": True,
        "has_rtofs_sst": True,
        "has_rtofs_current": True,
        "rtofs_sst_status": "ready",
        "rtofs_current_status": "ready",
        "blocking_reasons": [],
        "rule": "rtofs_surface_sst_current_required",
    }
    payload = {
        "sst": sst,
        "current_u": u,
        "current_v": v,
        "current_speed": speed,
        "salinity": sal,
        "ocean_mask": mask,
        "lat_values": lat_values,
        "lon_values": lon_values,
        "lat_grid": lat_grid or [],
        "lon_grid": lon_grid or [],
        "source_meta": {
            "provider": "rtofs",
            "provider_ledger_family": "rtofs_ocean_bundle",
            "coordinate_bounded_request": True,
            "whole_file_request": False,
            "ocean_source": "rtofs_noaa_ncep_surface",
            "current_source": "rtofs_noaa_ncep_surface",
            "sst_source": "rtofs_noaa_ncep_surface",
            "real_subset": True,
            "live_ocean_truth_ok": True,
            "quality_gate": quality_gate,
            "has_sst": True,
            "has_current": True,
            "blocking_reasons": [],
            "grid_shape": [ny, nx],
            "lat_values_len": len(lat_values),
            "lon_values_len": len(lon_values),
            "selected_dataset": source_url,
            "selected_vars": [names.get("sst"), names.get("current_u"), names.get("current_v"), names.get("salinity")],
            "selected_attempt": attempt_kind,
            "diagnostics": [{**diag, "status": "opened", "bytes_received": None}],
            "opened_urls": [source_url],
            "rtofs_cycle": cycle,
            "effective_stride": step,
            "lod_stride_policy": "global_12_regional_6_local_3_density_only_tile_count_36",
            "sst_landmask": {**landmask_meta, "strict_interior_water_gate": erode_meta, "mask_stage": "finite_rtofs_sst_current_then_eroded_interior_water"},
            "mode": "rtofs_noaa_coordinate_bounded_grib2_or_surface_ocean_bundle_v4",
            "depth_slice_status": "pending_attach",
        },
    }
    return payload, {**diag, "reason": "ok", "grid_shape": [ny, nx]}


def fetch_rtofs_subset_sync(*, bbox: BBox, stride: int, valid_time: datetime | None = None) -> tuple[dict[str, Any], datetime | None]:
    started = time.time()
    diagnostics: list[dict[str, Any]] = []
    # Local-file-first is the frozen ocean tile model.  Do not ask xarray/netCDF4
    # to stream/open NOMADS HTTPS URLs directly; curl/download the 2-D surface
    # NetCDF once, open the local .nc, then slice many viewport tiles from it.
    # GRIB/depth candidates remain optional fallbacks behind env flags.
    if RTOFS_LOCAL_FILE_FIRST:
        candidate_plan = _candidate_urls() + _grib2_filter_candidate_urls(bbox) + _depth_candidate_urls(bbox)
    else:
        candidate_plan = _grib2_filter_candidate_urls(bbox) + _depth_candidate_urls(bbox) + _candidate_urls()
    seen_urls: set[str] = set()
    for cand in candidate_plan:
        url = cand["url"]
        if url in seen_urls:
            continue
        seen_urls.add(url)
        path, dldiag = _download_cached(url)
        diagnostics.append({**dldiag, "candidate": cand})
        if not path:
            continue
        ds = None
        try:
            ds, engine, open_error = _open_dataset(path)
            if ds is None:
                diagnostics.append({"url": url, "status": "open_failed", "error": open_error, "candidate": cand})
                continue
            payload, parse_diag = _payload_from_dataset(ds, bbox, stride, url, cand.get("cycle"), cand.get("source_kind") or "rtofs_2ds_surface_fallback")
            diagnostics.append({"url": url, "status": "parsed", "engine": engine, "parse": parse_diag, "candidate": cand})
            if payload:
                # If the surface bundle came from a 3-D regional file, extract
                # depth slices from the already-open dataset before falling back
                # to a second candidate pass.
                if str(cand.get("source_kind") or "").startswith("3dz"):
                    try:
                        varnames = {}
                        for key, candidates in (("sst", SST_NAMES), ("current_u", U_NAMES), ("current_v", V_NAMES), ("salinity", SALINITY_NAMES)):
                            arr, name = _find_var(ds, candidates)
                            if arr is not None and name:
                                varnames[key] = str(name)
                        slices, depth_diag = _subset_depth_slices_from_dataset(ds, bbox, varnames, stride)
                        diagnostics.append({"url": url, "status": "depth_parsed_from_primary_surface_file", "parse": depth_diag, "candidate": cand})
                        if slices:
                            payload["depth_slices"] = slices
                            payload["bait_depth_intel"] = _bait_depth_intel_from_slices(slices)
                            payload.setdefault("source_meta", {}).update({
                                "depth_slice_status": "ready",
                                "depth_source": "rtofs_noaa_3dz_hvr_primary",
                                "depth_selected_dataset": url,
                                "depth_selected_vars": list(varnames.values()),
                                "depth_keys": list(slices.keys()),
                                "depth_region": cand.get("depth_region"),
                                "bait_depth_intel": payload.get("bait_depth_intel"),
                                "mode": "rtofs_noaa_3dz_surface_plus_depth_slices_ocean_bundle_v3",
                            })
                    except Exception as exc:
                        diagnostics.append({"url": url, "status": "primary_depth_extract_exception", "error": str(exc), "candidate": cand})
                try:
                    if payload.setdefault("source_meta", {}).get("depth_slice_status") != "ready":
                        _attach_depth_slices(payload, bbox, stride, diagnostics)
                except Exception as exc:
                    payload.setdefault("source_meta", {})["depth_slice_status"] = "attach_exception"
                    payload.setdefault("source_meta", {})["depth_slice_error"] = str(exc)
                payload["source_meta"]["diagnostics"] = diagnostics[-12:]
                payload["source_meta"]["latency_ms"] = int((time.time() - started) * 1000)
                return payload, valid_time
        except Exception as exc:
            diagnostics.append({"url": url, "status": "exception", "error": str(exc), "candidate": cand})
        finally:
            if ds is not None:
                try: ds.close()
                except Exception: pass
    return {
        "sst": [],
        "current_u": [],
        "current_v": [],
        "current_speed": [],
        "salinity": [],
        "lat_values": [],
        "lon_values": [],
        "source_meta": {
            "provider": "rtofs",
            "provider_ledger_family": "rtofs_ocean_bundle",
            "coordinate_bounded_request": True,
            "whole_file_request": False,
            "ocean_source": "rtofs_noaa_ncep_surface",
            "current_source": "rtofs_noaa_ncep_surface_empty",
            "sst_source": "rtofs_noaa_ncep_surface_empty",
            "real_subset": False,
            "live_ocean_truth_ok": False,
            "has_sst": False,
            "has_current": False,
            "quality_gate": {"live_ncss_ok": False, "live_ocean_truth_ok": False, "blocking_reasons": ["rtofs_source_empty_or_unparsed"]},
            "blocking_reasons": ["rtofs_source_empty_or_unparsed"],
            "grid_shape": [0, 0],
            "diagnostics": diagnostics[-16:],
            "opened_urls": [d.get("url") for d in diagnostics if d.get("url")],
            "selected_attempt": None,
            "selected_dataset": None,
            "selected_vars": [],
            "mode": "rtofs_noaa_surface_plus_depth_slices_ocean_bundle_v2_empty",
            "depth_slice_status": "not_attempted_without_surface_bundle",
            "latency_ms": int((time.time() - started) * 1000),
        },
    }, valid_time

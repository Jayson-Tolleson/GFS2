from __future__ import annotations

"""Native RTOFS 3-D ocean truth cache + trilinear sampler.

Request handlers must not open remote NetCDF files.  This module separates the
heavy mission into a warmer that downloads/opens one regional RTOFS 3DZ product
and serializes a compact native x/y/z field cache, then exposes a pure JSON
consumer path:

    sample(lon, lat, depth_m, time)

Surface is not a separate truth.  Surface values are just sample(..., depth_m=0)
from the same 3-D field whenever the cache is ready.
"""

import hashlib
import json
import math
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from server.gfs.models import BBox
from server.gfs.providers import rtofs_noaa as noaa

KT_PER_MS = 1.9438444924406
FT_PER_M = 3.280839895
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_RTOFS_CACHE_ROOT = Path(os.getenv("GFS_RTOFS_CACHE_DIR", str(_PROJECT_ROOT / ".cache" / "rtofs")))
_RTOFS_3D_DIR = Path(os.getenv("GFS_RTOFS_3D_TRUTH_CACHE_DIR", str(_RTOFS_CACHE_ROOT / "truth3d")))
_RTOFS_SAMPLE_STALE_SECONDS = int(os.getenv("GFS_RTOFS_3D_TRUTH_STALE_SECONDS", os.getenv("GFS_RTOFS_SAMPLE_STALE_SECONDS", "21600")) or "21600")
_RTOFS_3D_LOCK_SECONDS = int(os.getenv("GFS_RTOFS_3D_WARM_LOCK_SECONDS", "600") or "600")
_RTOFS_3D_LOCK_STALE_SECONDS = int(os.getenv("GFS_RTOFS_3D_WARM_LOCK_STALE_SECONDS", "900") or "900")


def _ensure_dirs() -> None:
    _RTOFS_3D_DIR.mkdir(parents=True, exist_ok=True)


def _finite(value: Any, default: float | None = None) -> float | None:
    try:
        f = float(value)
        return f if math.isfinite(f) else default
    except Exception:
        return default


def _norm_lon(lon: Any) -> float:
    n = _finite(lon, 0.0) or 0.0
    return ((float(n) + 180.0) % 360.0) - 180.0


def _bbox_from_any(bbox: Any) -> BBox:
    if isinstance(bbox, BBox):
        return bbox
    if isinstance(bbox, dict):
        return BBox(float(bbox.get("west", bbox.get("minLon"))), float(bbox.get("south", bbox.get("minLat"))), float(bbox.get("east", bbox.get("maxLon"))), float(bbox.get("north", bbox.get("maxLat"))))
    if isinstance(bbox, str):
        parts = [float(x.strip()) for x in bbox.split(",") if x.strip()]
        if len(parts) >= 4:
            return BBox(parts[0], parts[1], parts[2], parts[3])
    if isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
        return BBox(float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3]))
    raise ValueError("bbox must be west,south,east,north")


def _quantize_bbox(b: BBox) -> BBox:
    try:
        q = float(os.getenv("GFS_RTOFS_3D_TILE_QUANTIZE_DEG", os.getenv("GFS_RTOFS_TILE_QUANTIZE_DEG", "0.25")) or "0.25")
    except Exception:
        q = 0.25
    if not math.isfinite(q) or q <= 0:
        return b
    return BBox(
        round(math.floor(float(b.west) / q) * q, 6),
        round(math.floor(float(b.south) / q) * q, 6),
        round(math.ceil(float(b.east) / q) * q, 6),
        round(math.ceil(float(b.north) / q) * q, 6),
    )


def _bbox_key(bbox: Any) -> tuple[BBox, str]:
    b = _quantize_bbox(_bbox_from_any(bbox))
    key_src = f"{b.west:.4f},{b.south:.4f},{b.east:.4f},{b.north:.4f}"
    return b, hashlib.sha256(key_src.encode("utf-8")).hexdigest()[:18]


def rtofs_3d_truth_cache_path(bbox: Any) -> str:
    _ensure_dirs()
    _b, digest = _bbox_key(bbox)
    return str(_RTOFS_3D_DIR / f"native_xyz_{digest}.json")


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, separators=(",", ":")))
    tmp.replace(path)


def _lat_lon_depth(ds: Any) -> tuple[Any, str | None, Any, str | None, Any, str | None]:
    lat_arr, lat_name = noaa._coord_values(ds, noaa.LAT_NAMES)
    lon_arr, lon_name = noaa._coord_values(ds, noaa.LON_NAMES)
    depth_arr, depth_name = noaa._coord_values(ds, noaa.DEPTH_NAMES)
    return lat_arr, lat_name, lon_arr, lon_name, depth_arr, depth_name


def _coord_list_1d(arr: Any) -> list[float]:
    if arr is None:
        return []
    try:
        squeezed = arr.squeeze(drop=True)
        if getattr(squeezed, "ndim", 0) != 1:
            return []
        return [float(x) if math.isfinite(float(x)) else float("nan") for x in squeezed.values.tolist()]
    except Exception:
        return []


def _coord_grid_2d(arr: Any) -> list[list[float]]:
    """Return a 2-D curvilinear coord grid from RTOFS HVR Latitude/Longitude.

    The RTOFS regional 3DZ HVR products commonly expose Latitude/Longitude as
    2-D Y/X arrays, not 1-D axes.  The first native-3D warmer rejected those
    files as ``missing_or_not_1d``.  For a compact web cache we retain the
    native Y/X array subset and derive local mean axes for fast request-path
    sampling.
    """
    if arr is None:
        return []
    try:
        squeezed = arr.squeeze(drop=True)
        if getattr(squeezed, "ndim", 0) < 2:
            return []
        vals = squeezed.values
        # Use the final two dims as Y/X if an auxiliary time dim survived.
        if getattr(vals, "ndim", 0) > 2:
            while vals.ndim > 2:
                vals = vals[0]
        out: list[list[float]] = []
        for row in vals.tolist():
            out.append([float(x) if math.isfinite(float(x)) else float("nan") for x in row])
        return out
    except Exception:
        return []


def _grid_shape(grid: list[list[float]]) -> tuple[int, int]:
    ny = len(grid or [])
    nx = max((len(r) for r in grid), default=0)
    return ny, nx


def _lon_in_span(lon: float, west: float, east: float, pad: float = 0.0) -> bool:
    lon = _norm_lon(lon)
    west = _norm_lon(west - pad)
    east = _norm_lon(east + pad)
    if west <= east:
        return west <= lon <= east
    return lon >= west or lon <= east


def _bbox_index_window_2d(lat_grid: list[list[float]], lon_grid: list[list[float]], b: BBox, *, pad: float = 0.0) -> tuple[tuple[int, int], tuple[int, int]] | None:
    ny, nx = _grid_shape(lat_grid)
    ny2, nx2 = _grid_shape(lon_grid)
    ny = min(ny, ny2)
    nx = min(nx, nx2)
    if ny <= 0 or nx <= 0:
        return None
    south = min(float(b.south), float(b.north)) - pad
    north = max(float(b.south), float(b.north)) + pad
    hits_y: list[int] = []
    hits_x: list[int] = []
    center_lat = (float(b.south) + float(b.north)) / 2.0
    center_lon = _norm_lon((float(b.west) + float(b.east)) / 2.0)
    nearest: tuple[float, int, int] | None = None
    for y in range(ny):
        lat_row = lat_grid[y]
        lon_row = lon_grid[y]
        for x in range(min(nx, len(lat_row), len(lon_row))):
            lat = _finite(lat_row[x])
            lon = _finite(lon_row[x])
            if lat is None or lon is None:
                continue
            d2 = (lat - center_lat) ** 2 + (_norm_lon(lon - center_lon) * max(0.25, math.cos(math.radians(lat)))) ** 2
            if nearest is None or d2 < nearest[0]:
                nearest = (d2, y, x)
            if south <= lat <= north and _lon_in_span(lon, float(b.west), float(b.east), pad):
                hits_y.append(y)
                hits_x.append(x)
    if not hits_y or not hits_x:
        if nearest is None:
            return None
        half = max(2, int(os.getenv("GFS_RTOFS_3D_MIN_EDGE_CELLS", "3") or "3"))
        _d, cy, cx = nearest
        return (max(0, cy - half), min(ny, cy + half + 1)), (max(0, cx - half), min(nx, cx + half + 1))
    return (max(0, min(hits_y)), min(ny, max(hits_y) + 1)), (max(0, min(hits_x)), min(nx, max(hits_x) + 1))


def _axis_from_2d(grid: list[list[float]], y_idx: list[int], x_idx: list[int], *, axis: str) -> list[float]:
    out: list[float] = []
    if axis == "lat":
        for y in y_idx:
            vals = []
            for x in x_idx:
                try:
                    v = float(grid[y][x])
                    if math.isfinite(v):
                        vals.append(v)
                except Exception:
                    pass
            out.append(round(sum(vals) / len(vals), 6) if vals else float("nan"))
    else:
        for x in x_idx:
            vals = []
            for y in y_idx:
                try:
                    v = _norm_lon(float(grid[y][x]))
                    if math.isfinite(v):
                        vals.append(v)
                except Exception:
                    pass
            out.append(round(sum(vals) / len(vals), 6) if vals else float("nan"))
    return out


def _bbox_index_window(values: list[float], lo: float, hi: float, *, pad: float = 0.0) -> tuple[int, int] | None:
    if not values:
        return None
    lo2, hi2 = min(lo, hi) - pad, max(lo, hi) + pad
    idx = [i for i, v in enumerate(values) if math.isfinite(v) and lo2 <= v <= hi2]
    if not idx:
        # fall back to nearest endpoints so tiny edge viewports can still build a field
        finite = [(i, v) for i, v in enumerate(values) if math.isfinite(v)]
        if not finite:
            return None
        mid = (lo2 + hi2) / 2.0
        center_i = min(finite, key=lambda pair: abs(pair[1] - mid))[0]
        half = max(2, int(os.getenv("GFS_RTOFS_3D_MIN_EDGE_CELLS", "3") or "3"))
        return max(0, center_i - half), min(len(values), center_i + half + 1)
    return max(0, min(idx)), min(len(values), max(idx) + 1)


def _downsample_indices(n: int, max_n: int) -> list[int]:
    if n <= 0:
        return []
    if n <= max_n:
        return list(range(n))
    step = max(1, int(math.ceil(n / max(1, max_n))))
    out = list(range(0, n, step))
    if out[-1] != n - 1:
        out.append(n - 1)
    return out


def _depth_indices(depth_values_raw: list[float], max_depth_m: float, max_levels: int) -> tuple[list[int], list[float]]:
    finite = [(i, abs(float(v))) for i, v in enumerate(depth_values_raw) if math.isfinite(v)]
    if not finite:
        return [], []
    capped = [(i, d) for i, d in finite if d <= max_depth_m]
    if not capped:
        capped = finite[:1]
    capped.sort(key=lambda pair: pair[1])
    if len(capped) > max_levels:
        # Keep the surface/near-surface and distribute the remaining vertical support.
        keep_pos = _downsample_indices(len(capped), max_levels)
        capped = [capped[i] for i in keep_pos]
    idx = [i for i, _d in capped]
    depths = [round(float(d), 4) for _i, d in capped]
    return idx, depths


def _find_varnames(ds: Any) -> dict[str, str]:
    names: dict[str, str] = {}
    for key, candidates in (("temperature_c", noaa.SST_NAMES), ("u_ms", noaa.U_NAMES), ("v_ms", noaa.V_NAMES), ("salinity", noaa.SALINITY_NAMES)):
        arr, name = noaa._find_var(ds, candidates)
        if arr is not None and name:
            names[key] = str(name)
    return names


def _array_to_zyx(ds: Any, var_name: str, *, depth_name: str, lat_name: str, lon_name: str, depth_idx: list[int], y_idx: list[int], x_idx: list[int]) -> list[list[list[float]]]:
    arr = ds[var_name]
    try:
        arr = arr.squeeze(drop=True)
    except Exception:
        pass
    dims = list(getattr(arr, "dims", ()))
    if len(dims) < 3:
        return []
    # RTOFS products are not perfectly uniform about coordinate names vs dimension
    # names. Prefer named dims, but fall back to the conventional final y/x dims
    # and first remaining vertical dim just like the legacy slice extractor did.
    lon_dim = lon_name if lon_name in dims else dims[-1]
    lat_dim = lat_name if lat_name in dims else dims[-2]
    depth_dim = depth_name if depth_name in dims else next((d for d in dims if d not in {lat_dim, lon_dim}), None)
    if not depth_dim:
        return []
    keep = {depth_dim, lat_dim, lon_dim}
    for dim in list(getattr(arr, "dims", ())):
        if dim not in keep:
            arr = arr.isel({dim: 0}, drop=True)
    if not keep.issubset(set(getattr(arr, "dims", ()))):
        return []
    arr = arr.transpose(depth_dim, lat_dim, lon_dim)
    arr = arr.isel({depth_dim: depth_idx, lat_dim: y_idx, lon_dim: x_idx})
    values = arr.values
    out: list[list[list[float]]] = []
    try:
        shape = values.shape
        for z in range(shape[0]):
            plane: list[list[float]] = []
            for y in range(shape[1]):
                row: list[float] = []
                for x in range(shape[2]):
                    v = _finite(values[z][y][x], float("nan"))
                    row.append(float(v) if v is not None else float("nan"))
                plane.append(row)
            out.append(plane)
    except Exception:
        return []
    if var_name and out and ("temp" in var_name.lower() or var_name.lower() in {"t", "tmp", "wtmp", "temperature"}):
        # RTOFS may be Celsius or Kelvin depending on product/decoder. Convert cellwise
        # so mixed missing values do not spoil the entire plane.
        converted: list[list[list[float]]] = []
        for plane in out:
            converted_plane: list[list[float]] = []
            for row in plane:
                converted_plane.append([round(v - 273.15, 4) if math.isfinite(v) and v > 150 else (round(v, 4) if math.isfinite(v) else float("nan")) for v in row])
            converted.append(converted_plane)
        return converted
    return [[[round(v, 7) if math.isfinite(v) else float("nan") for v in row] for row in plane] for plane in out]


def _grid_has_required_values(fields: dict[str, Any]) -> bool:
    for key in ("temperature_c", "u_ms", "v_ms"):
        grid = fields.get(key) or []
        found = False
        for plane in grid:
            for row in plane:
                if any(isinstance(v, (int, float)) and math.isfinite(float(v)) for v in row):
                    found = True
                    break
            if found:
                break
        if not found:
            return False
    return True


def build_rtofs_3d_truth_cache(bbox: Any, *, candidate_limit: int = 8, max_xy: int | None = None, max_depth_m: float | None = None, max_depth_levels: int | None = None) -> dict[str, Any]:
    """Download/open a regional RTOFS 3DZ file and write a compact native field cache."""
    _ensure_dirs()
    b, _digest = _bbox_key(bbox)
    path = Path(rtofs_3d_truth_cache_path(b))
    started = time.time()
    diagnostics: list[dict[str, Any]] = []
    max_xy = int(max_xy if max_xy is not None else os.getenv("GFS_RTOFS_3D_MAX_XY", "96") or "96")
    max_depth_m = float(max_depth_m if max_depth_m is not None else os.getenv("GFS_RTOFS_3D_MAX_DEPTH_M", "250") or "250")
    max_depth_levels = int(max_depth_levels if max_depth_levels is not None else os.getenv("GFS_RTOFS_3D_MAX_DEPTH_LEVELS", "36") or "36")

    candidates = []
    try:
        candidates = list(noaa._depth_candidate_urls(b))[:max(1, int(candidate_limit or 8))]
    except Exception as exc:
        diagnostics.append({"stage": "candidate_discovery", "status": "error", "error": str(exc)})

    for cand in candidates:
        url = cand.get("url")
        if not url:
            continue
        ds = None
        try:
            local_path, dldiag = noaa._download_cached(url)
            diagnostics.append({"stage": "download", "candidate": cand, **(dldiag or {})})
            if not local_path:
                continue
            ds, engine, open_error = noaa._open_dataset(local_path)
            if ds is None:
                diagnostics.append({"stage": "open", "status": "open_failed", "candidate": cand, "error": open_error, "path": local_path})
                continue
            lat_arr, lat_name, lon_arr, lon_name, depth_arr, depth_name = _lat_lon_depth(ds)
            lats_raw = _coord_list_1d(lat_arr)
            lons_raw = _coord_list_1d(lon_arr)
            lat_grid = _coord_grid_2d(lat_arr)
            lon_grid = _coord_grid_2d(lon_arr)
            depths_raw = _coord_list_1d(depth_arr)
            if not (lat_name and lon_name and depth_name and depths_raw):
                diagnostics.append({"stage": "coords", "status": "missing_required_coordinates", "candidate": cand, "lat_name": lat_name, "lon_name": lon_name, "depth_name": depth_name, "lat_ndim": getattr(getattr(lat_arr, "squeeze", lambda **_: lat_arr)(drop=True), "ndim", None) if lat_arr is not None else None, "lon_ndim": getattr(getattr(lon_arr, "squeeze", lambda **_: lon_arr)(drop=True), "ndim", None) if lon_arr is not None else None})
                continue
            pad = float(os.getenv("GFS_RTOFS_3D_BBOX_PAD_DEG", "0.08") or "0.08")
            coord_mode = "rectilinear_1d"
            if lats_raw and lons_raw:
                lons_pm = [_norm_lon(v) if math.isfinite(v) else float("nan") for v in lons_raw]
                ywin = _bbox_index_window(lats_raw, b.south, b.north, pad=pad)
                xwin = _bbox_index_window(lons_pm, b.west, b.east, pad=pad)
                if not ywin or not xwin:
                    diagnostics.append({"stage": "coords", "status": "bbox_no_overlap_1d", "candidate": cand, "bbox": b.as_list(), "lat_range": [min(lats_raw), max(lats_raw)], "lon_range": [min(lons_pm), max(lons_pm)]})
                    continue
            elif lat_grid and lon_grid:
                coord_mode = "curvilinear_2d_mean_axes"
                windows = _bbox_index_window_2d(lat_grid, lon_grid, b, pad=pad)
                if not windows:
                    diagnostics.append({"stage": "coords", "status": "bbox_no_overlap_2d", "candidate": cand, "bbox": b.as_list(), "lat_grid_shape": _grid_shape(lat_grid), "lon_grid_shape": _grid_shape(lon_grid)})
                    continue
                ywin, xwin = windows
            else:
                diagnostics.append({"stage": "coords", "status": "missing_or_unusable_lat_lon", "candidate": cand, "lat_name": lat_name, "lon_name": lon_name, "depth_name": depth_name, "lat_grid_shape": _grid_shape(lat_grid), "lon_grid_shape": _grid_shape(lon_grid)})
                continue

            y_all = list(range(ywin[0], ywin[1]))
            x_all = list(range(xwin[0], xwin[1]))
            y_local = _downsample_indices(len(y_all), max(2, max_xy))
            x_local = _downsample_indices(len(x_all), max(2, max_xy))
            y_idx = [y_all[i] for i in y_local]
            x_idx = [x_all[i] for i in x_local]
            z_idx, depth_values_m = _depth_indices(depths_raw, max_depth_m=max_depth_m, max_levels=max_depth_levels)
            if not (y_idx and x_idx and z_idx):
                diagnostics.append({"stage": "coords", "status": "empty_indices", "candidate": cand})
                continue
            varnames = _find_varnames(ds)
            if not {"temperature_c", "u_ms", "v_ms"}.issubset(varnames):
                diagnostics.append({"stage": "vars", "status": "required_vars_missing", "candidate": cand, "varnames": varnames})
                continue
            fields: dict[str, Any] = {}
            for out_name, var_name in varnames.items():
                cube = _array_to_zyx(ds, var_name, depth_name=depth_name, lat_name=lat_name, lon_name=lon_name, depth_idx=z_idx, y_idx=y_idx, x_idx=x_idx)
                if cube:
                    fields[out_name] = cube
            if not _grid_has_required_values(fields):
                diagnostics.append({"stage": "quality", "status": "required_fields_empty", "candidate": cand, "varnames": varnames})
                continue
            if coord_mode == "curvilinear_2d_mean_axes":
                lat_values = _axis_from_2d(lat_grid, y_idx, x_idx, axis="lat")
                lon_values = _axis_from_2d(lon_grid, y_idx, x_idx, axis="lon")
            else:
                lat_values = [round(float(lats_raw[i]), 6) for i in y_idx]
                lon_values = [round(float(lons_pm[i]), 6) for i in x_idx]
            payload = {
                "ok": True,
                "status": "ready",
                "schema": "lftr_rtofs_native_3d_trilinear_cache_v1",
                "source": "ncep_nomads_rtofs_native_3d_trilinear_cache",
                "bbox": b.as_list(),
                "bbox_object": {"west": b.west, "south": b.south, "east": b.east, "north": b.north},
                "created_at_epoch": time.time(),
                "created_at_utc": datetime.now(timezone.utc).isoformat(),
                "selected_candidate": cand,
                "selected_dataset": url,
                "local_file": str(local_path),
                "engine": engine,
                "coordinate_names": {"lat": lat_name, "lon": lon_name, "depth": depth_name},
                "coordinate_mode": coord_mode,
                "selected_vars": varnames,
                "lat_values": lat_values,
                "lon_values": lon_values,
                "depth_values_m": depth_values_m,
                "depth_convention": "positive water depth in meters; render altitude is negative depth_m",
                "surface_policy": "surface values are OceanTruth.sample(lon,lat,0,time) from this same native 3D field",
                "interpolation": "trilinear_x_y_depth_from_native_rtofs_field_cache",
                "field_shape": [len(depth_values_m), len(lat_values), len(lon_values)],
                "fields": fields,
                "diagnostics": {
                    "latency_ms": int((time.time() - started) * 1000),
                    "attempts": diagnostics[-12:],
                    "max_xy": max_xy,
                    "max_depth_m": max_depth_m,
                    "max_depth_levels": max_depth_levels,
                    "horizontal_index_window": [ywin[0], ywin[1], xwin[0], xwin[1]],
                    "coordinate_mode": coord_mode,
                    "selected_index_counts": {"z": len(z_idx), "y": len(y_idx), "x": len(x_idx)},
                },
            }
            _atomic_write_json(path, payload)
            return {**payload, "cache_path": str(path), "fields": {k: "<omitted>" for k in fields}}
        except Exception as exc:
            diagnostics.append({"stage": "exception", "candidate": cand, "error": str(exc)})
        finally:
            if ds is not None:
                try:
                    ds.close()
                except Exception:
                    pass

    out = {
        "ok": False,
        "status": "not_ready",
        "schema": "lftr_rtofs_native_3d_trilinear_cache_v1",
        "source": "ncep_nomads_rtofs_native_3d_trilinear_cache",
        "bbox": b.as_list(),
        "cache_path": str(path),
        "candidate_count": len(candidates),
        "selected_candidate": candidates[0] if candidates else None,
        "diagnostics": {"latency_ms": int((time.time() - started) * 1000), "attempts": diagnostics[-18:]},
    }
    return out


def load_cached_rtofs_3d_truth(bbox: Any, max_age_seconds: int | None = None) -> dict[str, Any]:
    _ensure_dirs()
    b, _digest = _bbox_key(bbox)
    path = Path(rtofs_3d_truth_cache_path(b))
    max_age = int(max_age_seconds if max_age_seconds is not None else _RTOFS_SAMPLE_STALE_SECONDS)
    if not path.exists():
        return {"ok": False, "status": "cache_miss", "source": "ncep_nomads_rtofs_native_3d_trilinear_cache", "cache_path": str(path), "bbox": b.as_list()}
    try:
        age = max(0, int(time.time() - path.stat().st_mtime))
        data = json.loads(path.read_text())
        stale = bool(age > max_age)
        data.update({
            "ok": bool(data.get("fields") and data.get("lat_values") and data.get("lon_values") and data.get("depth_values_m")) and not stale,
            "status": "ready" if not stale and data.get("fields") else ("stale" if data.get("fields") else "empty"),
            "cache": {"hit": True, "age_seconds": age, "max_age_seconds": max_age, "stale": stale, "path": str(path)},
            "cache_path": str(path),
        })
        return data
    except Exception as exc:
        return {"ok": False, "status": "cache_read_error", "source": "ncep_nomads_rtofs_native_3d_trilinear_cache", "cache_path": str(path), "error": str(exc), "bbox": b.as_list()}


def _lock_age_seconds(path: Path) -> float | None:
    try:
        return max(0.0, time.time() - path.stat().st_mtime)
    except Exception:
        return None


def _pid_alive(lock: Path) -> bool | None:
    try:
        data = json.loads(lock.read_text() or "{}")
        pid = int(data.get("pid") or 0)
        if pid <= 0:
            return None
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return None


def _unlink_stale_lock(lock: Path) -> bool:
    age = _lock_age_seconds(lock)
    dead_pid = _pid_alive(lock) is False
    if not dead_pid and (age is None or age < _RTOFS_3D_LOCK_STALE_SECONDS):
        return False
    try:
        lock.unlink()
        return True
    except Exception:
        return False


def spawn_rtofs_3d_truth_warmer(bbox: Any, *, candidate_limit: int = 8) -> dict[str, Any]:
    _ensure_dirs()
    b, digest = _bbox_key(bbox)
    cached = load_cached_rtofs_3d_truth(b)
    if cached.get("ok"):
        return {"started": False, "reason": "cache_ready", "cache_path": cached.get("cache_path"), "field_shape": cached.get("field_shape"), "bbox": b.as_list()}
    script = _PROJECT_ROOT / "scripts" / "warm_rtofs_3d_truth_cache.py"
    if not script.exists():
        return {"started": False, "reason": "warmer_script_missing", "script": str(script)}
    lock = _RTOFS_3D_DIR / f"warm3d_{digest}.lock"
    removed_stale = False
    if lock.exists():
        removed_stale = _unlink_stale_lock(lock)
    if lock.exists() and (_lock_age_seconds(lock) or 0) < _RTOFS_3D_LOCK_SECONDS:
        return {"started": False, "reason": "already_warming", "lock": str(lock), "lock_age_seconds": int(_lock_age_seconds(lock) or 0), "lock_pid_alive": _pid_alive(lock), "bbox": b.as_list()}
    try:
        lock.write_text(json.dumps({"started_at": time.time(), "bbox": b.as_list(), "pid": None, "contract": "self_clearing_rtofs_3d_warm_lock_v1"}))
    except Exception:
        pass
    cmd = [sys.executable, str(script), f"--bbox={b.west},{b.south},{b.east},{b.north}", "--candidate-limit", str(int(candidate_limit or 8)), "--lock", str(lock)]
    try:
        proc = subprocess.Popen(cmd, cwd=str(_PROJECT_ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        try:
            lock.write_text(json.dumps({"started_at": time.time(), "bbox": b.as_list(), "pid": proc.pid, "contract": "self_clearing_rtofs_3d_warm_lock_v1"}))
        except Exception:
            pass
        return {"started": True, "pid": proc.pid, "pid_mode": "detached", "cmd": cmd, "lock": str(lock), "removed_stale_lock": removed_stale, "bbox": b.as_list()}
    except Exception as exc:
        try:
            if lock.exists():
                lock.unlink()
        except Exception:
            pass
        return {"started": False, "reason": "spawn_failed", "error": str(exc), "bbox": b.as_list(), "lock": str(lock)}


def _locate_axis(values: list[float], target: float) -> tuple[int, int, float] | None:
    finite = [(i, float(v)) for i, v in enumerate(values) if math.isfinite(float(v))]
    if not finite:
        return None
    ascending = finite[-1][1] >= finite[0][1]
    vals = [v for _i, v in finite]
    idxs = [i for i, _v in finite]
    if not ascending:
        vals = list(reversed(vals))
        idxs = list(reversed(idxs))
    if target <= vals[0]:
        return idxs[0], idxs[0], 0.0
    if target >= vals[-1]:
        return idxs[-1], idxs[-1], 0.0
    lo = 0
    hi = len(vals) - 1
    while hi - lo > 1:
        mid = (hi + lo) // 2
        if vals[mid] <= target:
            lo = mid
        else:
            hi = mid
    denom = vals[hi] - vals[lo]
    f = 0.0 if abs(denom) < 1e-12 else (target - vals[lo]) / denom
    return idxs[lo], idxs[hi], max(0.0, min(1.0, f))


def _grid_value(grid: Any, z: int, y: int, x: int) -> float:
    try:
        v = float(grid[z][y][x])
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")


def _trilinear(grid: Any, zloc: tuple[int, int, float], yloc: tuple[int, int, float], xloc: tuple[int, int, float]) -> float | None:
    z0, z1, fz = zloc
    y0, y1, fy = yloc
    x0, x1, fx = xloc
    total = 0.0
    weight_sum = 0.0
    for zi, wz in ((z0, 1.0 - fz), (z1, fz)):
        for yi, wy in ((y0, 1.0 - fy), (y1, fy)):
            for xi, wx in ((x0, 1.0 - fx), (x1, fx)):
                w = wz * wy * wx
                if w <= 0:
                    continue
                v = _grid_value(grid, zi, yi, xi)
                if math.isfinite(v):
                    total += v * w
                    weight_sum += w
    if weight_sum <= 0:
        return None
    return total / weight_sum


def sample_cached_rtofs_3d(cache: dict[str, Any], lon: float, lat: float, depth_m: float = 0.0) -> dict[str, Any]:
    if not (cache or {}).get("ok"):
        return {"ok": False, "status": cache.get("status") if isinstance(cache, dict) else "missing_cache", "source": "rtofs_native_3d_trilinear"}
    lats = [float(x) for x in cache.get("lat_values") or []]
    lons = [_norm_lon(x) for x in cache.get("lon_values") or []]
    depths = [abs(float(x)) for x in cache.get("depth_values_m") or []]
    if not (lats and lons and depths):
        return {"ok": False, "status": "empty_axes", "source": "rtofs_native_3d_trilinear"}
    yloc = _locate_axis(lats, float(lat))
    xloc = _locate_axis(lons, _norm_lon(lon))
    zloc = _locate_axis(depths, abs(float(depth_m or 0.0)))
    if not (yloc and xloc and zloc):
        return {"ok": False, "status": "outside_field_axes", "source": "rtofs_native_3d_trilinear"}
    fields = cache.get("fields") or {}
    out: dict[str, Any] = {
        "ok": True,
        "status": "ready",
        "source": "rtofs_native_3d_trilinear",
        "sample_method": "rtofs_native_3d_trilinear",
        "lon": round(_norm_lon(lon), 6),
        "lat": round(float(lat), 6),
        "depth_m": round(abs(float(depth_m or 0.0)), 3),
        "altitude_m": round(-abs(float(depth_m or 0.0)), 3),
    }
    temp = _trilinear(fields.get("temperature_c"), zloc, yloc, xloc) if fields.get("temperature_c") else None
    sal = _trilinear(fields.get("salinity"), zloc, yloc, xloc) if fields.get("salinity") else None
    u = _trilinear(fields.get("u_ms"), zloc, yloc, xloc) if fields.get("u_ms") else None
    v = _trilinear(fields.get("v_ms"), zloc, yloc, xloc) if fields.get("v_ms") else None
    if temp is not None:
        out["temperature_c"] = round(float(temp), 4)
        out["water_temp_c"] = round(float(temp), 4)
        out["sst_c"] = round(float(temp), 4) if abs(float(depth_m or 0.0)) <= 0.25 else None
        out["temperature_f"] = round(float(temp) * 9.0 / 5.0 + 32.0, 3)
        out["water_temp_f"] = out["temperature_f"]
        out["sst_f"] = out["temperature_f"] if abs(float(depth_m or 0.0)) <= 0.25 else None
    if sal is not None:
        out["salinity"] = round(float(sal), 5)
    if u is not None:
        out["u_ms"] = round(float(u), 7)
    if v is not None:
        out["v_ms"] = round(float(v), 7)
    if u is not None and v is not None:
        speed_ms = math.hypot(float(u), float(v))
        out["current_speed_m_s"] = round(speed_ms, 7)
        out["current_speed_kt"] = round(speed_ms * KT_PER_MS, 5)
        out["direction_deg"] = round((math.degrees(math.atan2(float(u), float(v))) + 360.0) % 360.0, 3)
        out["current"] = {"speedKt": out["current_speed_kt"], "dirDeg": out["direction_deg"], "u": out.get("u_ms"), "v": out.get("v_ms")}
    out["axis_indices"] = {"z": [zloc[0], zloc[1], round(zloc[2], 5)], "y": [yloc[0], yloc[1], round(yloc[2], 5)], "x": [xloc[0], xloc[1], round(xloc[2], 5)]}
    out["field_shape"] = cache.get("field_shape")
    out["selected_dataset"] = cache.get("selected_dataset")
    return out


def compact_rtofs_3d_status(cache: dict[str, Any], warmer: dict[str, Any] | None = None, candidates: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    return {
        "ok": bool(cache.get("ok")),
        "status": cache.get("status"),
        "source": cache.get("source") or "ncep_nomads_rtofs_native_3d_trilinear_cache",
        "schema": cache.get("schema"),
        "cache": cache.get("cache") or {"hit": False, "path": cache.get("cache_path")},
        "cache_path": cache.get("cache_path"),
        "field_shape": cache.get("field_shape"),
        "depth_values_m": cache.get("depth_values_m"),
        "surface_policy": cache.get("surface_policy") or "surface = OceanTruth.sample(lon,lat,0,time) from native 3D field when ready",
        "interpolation": cache.get("interpolation") or "trilinear_x_y_depth_from_native_rtofs_field_cache",
        "selected_candidate": cache.get("selected_candidate") or ((candidates or [None])[0] if candidates else None),
        "candidate_count": len(candidates or []),
        "candidates": candidates or [],
        "warmer": warmer or {"started": False, "reason": "not_requested"},
        "contract": "background worker installs native RTOFS 3D arrays; request path samples continuous XYZ by trilinear algebra",
    }

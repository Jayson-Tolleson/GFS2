from __future__ import annotations

"""Friendly RTOFS diagnostics and sampling helpers for LFTR.

This is a thin public wrapper around server.gfs.providers.rtofs_noaa.  The
provider stays responsible for NOAA/NCEP/NOMADS file discovery and parsing; this
module exposes stable functions for routes, scripts, and Codex diagnostics.
"""

import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

from server.gfs.models import BBox
from server.gfs.providers import rtofs_noaa as noaa
from server.gfs.serializers import iso_utc
from server.gfs.ocean_landmask import mask_stats


def _bbox_from_any(bbox: Any) -> BBox:
    if isinstance(bbox, BBox):
        return bbox
    if isinstance(bbox, dict):
        return BBox(float(bbox.get("west", bbox.get("minLon"))), float(bbox.get("south", bbox.get("minLat"))), float(bbox.get("east", bbox.get("maxLon"))), float(bbox.get("north", bbox.get("maxLat"))))
    if isinstance(bbox, str):
        parts = [float(x.strip()) for x in bbox.split(",") if x.strip()]
        if len(parts) >= 4:
            return BBox(parts[0], parts[1], parts[2], parts[3])
    if isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
        return BBox(float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3]))
    raise ValueError("bbox must be west,south,east,north")



# ---------------------------------------------------------------------------
# RTOFS consumption cache
# ---------------------------------------------------------------------------
# Runtime request paths must never block while xarray opens a remote NOMADS
# NetCDF.  The warmer downloads/open/parses once, writes a small JSON point
# cache, and HTTP/current/boater/bait consumers read only that JSON.

_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_RTOFS_CACHE_ROOT = Path(os.getenv("GFS_RTOFS_CACHE_DIR", str(_PROJECT_ROOT / ".cache" / "rtofs")))
_RTOFS_SAMPLE_DIR = Path(os.getenv("GFS_RTOFS_SAMPLE_CACHE_DIR", str(_RTOFS_CACHE_ROOT / "samples")))
_RTOFS_FILE_DIR = Path(os.getenv("GFS_RTOFS_FILE_CACHE_DIR", str(_RTOFS_CACHE_ROOT / "files")))
os.environ.setdefault("GFS_RTOFS_FILE_CACHE_DIR", str(_RTOFS_FILE_DIR))


def _ensure_rtofs_dirs() -> None:
    _RTOFS_SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    _RTOFS_FILE_DIR.mkdir(parents=True, exist_ok=True)


def _quantize_rtofs_tile_bbox(b: BBox) -> BBox:
    """Stable ocean tile key: nearby viewports share one warm SST/current tile.

    The app should feel like clouds/rain: while the viewport remains on a tile,
    render from last-good cache and refresh only that stable tile.  Quantizing
    the cache envelope avoids creating a brand-new RTOFS warm lock for every
    tiny camera move.
    """
    try:
        q = float(os.getenv("GFS_RTOFS_TILE_QUANTIZE_DEG", "0.25") or "0.25")
    except Exception:
        q = 0.25
    if not math.isfinite(q) or q <= 0:
        return b
    west = math.floor(float(b.west) / q) * q
    south = math.floor(float(b.south) / q) * q
    east = math.ceil(float(b.east) / q) * q
    north = math.ceil(float(b.north) / q) * q
    # Do not accidentally turn a local viewport into a huge/global envelope.
    return BBox(round(west, 6), round(south, 6), round(east, 6), round(north, 6))


def _bbox_key(bbox: BBox | dict[str, Any] | list[Any] | tuple[Any, ...] | str) -> tuple[BBox, str]:
    b0 = _bbox_from_any(bbox)
    b = _quantize_rtofs_tile_bbox(b0)
    key_src = f"{b.west:.4f},{b.south:.4f},{b.east:.4f},{b.north:.4f}"
    digest = hashlib.sha256(key_src.encode("utf-8")).hexdigest()[:18]
    return b, digest


def _bbox_span_area(b: BBox) -> tuple[float, float, float]:
    width = abs(float(b.east) - float(b.west))
    height = abs(float(b.north) - float(b.south))
    return width, height, width * height


def _rtofs_wake_bbox_allowed(b: BBox) -> tuple[bool, str, dict[str, Any]]:
    """Keep scene-frame RTOFS wakes on real viewports, not global/legacy boot boxes."""
    width, height, area = _bbox_span_area(b)
    max_width = float(os.getenv("GFS_RTOFS_WAKE_MAX_WIDTH_DEG", "18") or "18")
    max_height = float(os.getenv("GFS_RTOFS_WAKE_MAX_HEIGHT_DEG", "14") or "14")
    max_area = float(os.getenv("GFS_RTOFS_WAKE_MAX_AREA_DEG2", "180") or "180")
    meta = {"width_deg": width, "height_deg": height, "area_deg2": area, "max_width_deg": max_width, "max_height_deg": max_height, "max_area_deg2": max_area}
    if width <= 0 or height <= 0:
        return False, "invalid_bbox", meta
    if width > max_width or height > max_height or area > max_area:
        return False, "viewport_too_large_for_rtofs_wake", meta
    return True, "ok", meta


def _lock_age_seconds(path: Path) -> float | None:
    try:
        return max(0.0, time.time() - path.stat().st_mtime)
    except Exception:
        return None


def _rtofs_lock_pid_is_alive(lock: Path) -> bool | None:
    """Return False for a known-dead child warmer lock.

    Old locks were sometimes left behind after a failed/terminated warmer.
    Treating those as active caused local bait/boats/sharks to stay stuck at
    already_warming forever.
    """
    try:
        data = json.loads(lock.read_text() or '{}')
        pid = int(data.get('pid') or 0)
        if pid <= 0:
            return None
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return None


def _unlink_stale_rtofs_lock(lock: Path, stale_seconds: int) -> bool:
    age = _lock_age_seconds(lock)
    dead_pid = _rtofs_lock_pid_is_alive(lock) is False
    if not dead_pid and (age is None or age < stale_seconds):
        return False
    try:
        lock.unlink()
        return True
    except Exception:
        return False


def rtofs_sample_cache_path(bbox: Any) -> str:
    _ensure_rtofs_dirs()
    _b, digest = _bbox_key(bbox)
    return str(_RTOFS_SAMPLE_DIR / f"surface_current_{digest}.json")


def load_cached_rtofs_surface(bbox: Any, max_age_seconds: int | None = None) -> dict[str, Any]:
    """Read lightweight sampled RTOFS JSON for a bbox.

    This is the consumption path used by /field, boater, bait, and diagnostics.
    It intentionally performs no network I/O and no xarray work.
    """
    _ensure_rtofs_dirs()
    b, _digest = _bbox_key(bbox)
    path = Path(rtofs_sample_cache_path(b))
    max_age = int(max_age_seconds if max_age_seconds is not None else os.getenv("GFS_RTOFS_SAMPLE_STALE_SECONDS", "21600") or "21600")
    if not path.exists():
        return {"ok": False, "status": "cache_miss", "source": "rtofs_surface_sample_cache", "cache_path": str(path), "points": [], "count": 0, "bbox": b.as_list()}
    try:
        age = max(0, int(time.time() - path.stat().st_mtime))
        data = json.loads(path.read_text())
        points = data.get("points") or data.get("current_points") or []
        stale = bool(age > max_age)
        data.update({
            "ok": bool(points) and not stale,
            "status": "ready" if points and not stale else ("stale" if points else "empty"),
            "source": data.get("source") or "ncep_nomads_rtofs_cached_surface",
            "cache": {"hit": True, "age_seconds": age, "max_age_seconds": max_age, "stale": stale, "path": str(path)},
            "cache_path": str(path),
            "points": points,
            "current_points": points,
            "ocean_points": points,
            "count": len(points),
        })
        return data
    except Exception as exc:
        return {"ok": False, "status": "cache_read_error", "source": "rtofs_surface_sample_cache", "cache_path": str(path), "error": str(exc), "points": [], "count": 0, "bbox": b.as_list()}


def _surface_candidate_plan(limit: int = 12) -> list[dict[str, Any]]:
    out = []
    seen = set()
    for cand in noaa._candidate_urls():
        url = cand.get("url")
        if not url or url in seen:
            continue
        seen.add(url)
        out.append(cand)
        if len(out) >= max(1, int(limit or 12)):
            break
    return out



def rtofs_ocean_mask_cache_path(bbox: Any) -> str:
    """Sidecar cache for the SST-valid ocean mask derived by the warmer."""
    _ensure_rtofs_dirs()
    b, digest = _bbox_key(bbox)
    return str(_RTOFS_SAMPLE_DIR / f"sst_ocean_mask_{digest}.json")


def _save_rtofs_ocean_mask_cache(raw: dict[str, Any] | None, bbox: BBox, *, resolved_time: Any = None) -> dict[str, Any]:
    """Persist raw-SST-valid water truth for later ocean-only tile planning."""
    if not isinstance(raw, dict):
        return {"ok": False, "reason": "raw_missing"}
    mask = raw.get("ocean_mask") or []
    lats = raw.get("lat_values") or []
    lons = raw.get("lon_values") or []
    if not (mask and lats and lons):
        return {"ok": False, "reason": "mask_or_coords_missing"}
    meta = raw.get("source_meta") if isinstance(raw.get("source_meta"), dict) else {}
    out = {
        "ok": True,
        "schema": "lftr_rtofs_sst_valid_ocean_mask_v1",
        "source": "rtofs_sst_validity_mask",
        "mask_source": "rtofs_sst_validity",
        "bbox": bbox.as_list(),
        "bbox_object": {"west": bbox.west, "south": bbox.south, "east": bbox.east, "north": bbox.north},
        "cycle": meta.get("rtofs_cycle"),
        "resolved_time": iso_utc(resolved_time) if resolved_time else datetime.now(timezone.utc).isoformat(),
        "selected_dataset": meta.get("selected_dataset"),
        "selected_vars": meta.get("selected_vars"),
        "grid_shape": mask_stats(mask).get("shape"),
        "stats": mask_stats(mask),
        "lat_values": lats,
        "lon_values": lons,
        "mask": mask,
        "contract": "raw_finite_rtofs_sst_current_mask_saved_before_bait_boater_current_tile_planning",
    }
    path = Path(rtofs_ocean_mask_cache_path(bbox))
    path.write_text(json.dumps(out, separators=(",", ":")))
    return {"ok": True, "path": str(path), "stats": out.get("stats"), "mask_source": out.get("mask_source")}


def load_cached_rtofs_ocean_mask(bbox: Any, max_age_seconds: int | None = None) -> dict[str, Any]:
    _ensure_rtofs_dirs()
    b, _digest = _bbox_key(bbox)
    path = Path(rtofs_ocean_mask_cache_path(b))
    max_age = int(max_age_seconds if max_age_seconds is not None else os.getenv("GFS_RTOFS_MASK_STALE_SECONDS", os.getenv("GFS_RTOFS_SAMPLE_STALE_SECONDS", "21600")) or "21600")
    if not path.exists():
        return {"ok": False, "status": "cache_miss", "source": "rtofs_sst_validity_mask", "cache_path": str(path), "bbox": b.as_list()}
    try:
        age = max(0, int(time.time() - path.stat().st_mtime))
        data = json.loads(path.read_text())
        stale = bool(age > max_age)
        data.update({
            "ok": bool(data.get("mask")) and not stale,
            "status": "ready" if data.get("mask") and not stale else ("stale" if data.get("mask") else "empty"),
            "cache": {"hit": True, "age_seconds": age, "max_age_seconds": max_age, "stale": stale, "path": str(path)},
            "cache_path": str(path),
        })
        return data
    except Exception as exc:
        return {"ok": False, "status": "cache_read_error", "source": "rtofs_sst_validity_mask", "cache_path": str(path), "error": str(exc), "bbox": b.as_list()}


def _grid_value(grid: list[list[Any]], y: int, x: int) -> float:
    try:
        v = float(grid[y][x])
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")


def _points_from_raw(raw: dict[str, Any], bbox: BBox, max_points: int = 3000) -> dict[str, Any]:
    """Convert provider grids into compact JSON points for request-time consumers."""
    if not isinstance(raw, dict):
        return {"points": [], "reason": "raw_not_dict"}
    sst = raw.get("sst") or []
    u = raw.get("current_u") or []
    v = raw.get("current_v") or []
    sal = raw.get("salinity") or []
    lats = raw.get("lat_values") or []
    lons = raw.get("lon_values") or []
    if not (sst and u and v and lats and lons):
        return {"points": [], "reason": "required_grids_missing"}
    ny = min(len(sst), len(u), len(v), len(lats))
    nx = min(len(sst[0]) if sst and sst[0] else 0, len(u[0]) if u and u[0] else 0, len(v[0]) if v and v[0] else 0, len(lons))
    if ny < 1 or nx < 1:
        return {"points": [], "reason": "empty_grid"}
    candidates: list[tuple[int, int]] = []
    for y in range(ny):
        for x in range(nx):
            tv = _grid_value(sst, y, x)
            uu = _grid_value(u, y, x)
            vv = _grid_value(v, y, x)
            if math.isfinite(tv) and math.isfinite(uu) and math.isfinite(vv):
                candidates.append((y, x))
    if not candidates:
        return {"points": [], "reason": "no_finite_sst_current_cells", "grid_shape": [ny, nx]}
    limit = max(1, int(max_points or 3000))
    step = max(1, math.ceil(len(candidates) / limit))
    selected = candidates[::step][:limit]
    points: list[dict[str, Any]] = []
    for y, x in selected:
        lat = _grid_value([lats], 0, y)
        lon = _grid_value([lons], 0, x)
        if math.isfinite(lon):
            lon = ((lon + 180.0) % 360.0) - 180.0
        tv = _grid_value(sst, y, x)
        uu = _grid_value(u, y, x)
        vv = _grid_value(v, y, x)
        if not (math.isfinite(lat) and math.isfinite(lon) and math.isfinite(tv) and math.isfinite(uu) and math.isfinite(vv)):
            continue
        speed_ms = math.sqrt(uu * uu + vv * vv)
        speed_kt = speed_ms * 1.9438444924406
        # Direction current is flowing toward, degrees clockwise from north.
        heading = (math.degrees(math.atan2(uu, vv)) + 360.0) % 360.0
        temp_c = tv - 273.15 if tv > 150.0 else tv
        temp_f = temp_c * 9.0 / 5.0 + 32.0
        ss = _grid_value(sal, y, x) if sal else float("nan")
        p = {
            "lat": round(lat, 6), "lon": round(lon, 6),
            "sst": round(temp_c, 4), "sst_c": round(temp_c, 4), "water_temp_c": round(temp_c, 4), "water_temp_f": round(temp_f, 3),
            "u": uu, "v": vv, "u_ms": uu, "v_ms": vv, "current_u": uu, "current_v": vv,
            "speedMs": speed_ms, "speed_ms": speed_ms, "current_speed_m_s": speed_ms,
            "speedKt": speed_kt, "current_speed_kt": speed_kt,
            "heading": heading, "dirDeg": heading, "direction_deg": heading, "current_dir_deg": heading,
            "source": "rtofs_sst_valid_ocean_point",
        }
        if math.isfinite(ss):
            p["sss"] = ss; p["salinity"] = ss
        points.append(p)
    return {"points": points, "reason": "ok", "grid_shape": [ny, nx], "matched_cells": len(candidates), "sample_step": step}

def warm_rtofs_surface_cache(bbox: Any, step: int = 1, max_points: int = 3000, candidate_limit: int = 8) -> dict[str, Any]:
    """Warm the lightweight RTOFS JSON cache using the proven ocean provider path.

    Keep the CLI warmer and scene-frame/provider contract identical: use
    noaa.fetch_rtofs_subset_sync(), which is the path that produced the known-good
    rtofs_noaa_coordinate_bounded_grib2_or_surface_ocean_bundle_v4 payload with
    sst/u_velocity/v_velocity/sss.  The warmer only serializes that payload into
    .cache/rtofs/samples so /field, boater, bait, and scene-cache bridge consume
    JSON and never open NetCDF on the request path.
    """
    _ensure_rtofs_dirs()
    b, _digest = _bbox_key(bbox)
    started = time.time()
    cache_path = rtofs_sample_cache_path(b)
    diagnostics: list[dict[str, Any]] = []

    try:
        raw, vt = noaa.fetch_rtofs_subset_sync(bbox=b, stride=max(1, int(step or 1)), valid_time=None)
        meta = raw.get("source_meta") if isinstance(raw, dict) else {}
        diagnostics.append({
            "stage": "provider_fetch",
            "status": "ready" if meta.get("live_ocean_truth_ok") else "not_ready",
            "mode": meta.get("mode"),
            "selected_dataset": meta.get("selected_dataset"),
            "selected_attempt": meta.get("selected_attempt"),
            "selected_vars": meta.get("selected_vars"),
            "grid_shape": meta.get("grid_shape"),
            "quality_gate": meta.get("quality_gate"),
        })
        mask_cache = _save_rtofs_ocean_mask_cache(raw, b, resolved_time=vt)
        diagnostics.append({"stage": "sst_ocean_mask_cache", **(mask_cache or {})})
        sample = _points_from_raw(raw, b, max_points=max_points)
        points = sample.get("points") or []
        if points:
            out = {
                "ok": True,
                "status": "ready",
                "source": "ncep_nomads_rtofs_cached_surface",
                "schema": "rtofs_surface_current_sample_cache_v2_provider_path",
                "bbox": b.as_list(),
                "bbox_object": {"west": b.west, "south": b.south, "east": b.east, "north": b.north},
                "url": meta.get("selected_dataset"),
                "selected_surface": {
                    "url": meta.get("selected_dataset"),
                    "product": meta.get("selected_attempt"),
                    "cycle": meta.get("rtofs_cycle"),
                    "source_kind": "provider_path",
                },
                "resolved_time": iso_utc(vt) if vt else datetime.now(timezone.utc).isoformat(),
                "points": points,
                "current_points": points,
                "ocean_points": points,
                "count": len(points),
                "cache_path": cache_path,
                "source_meta": meta,
                "diagnostics": {
                    "latency_ms": int((time.time() - started) * 1000),
                    "attempts": diagnostics,
                    "warmer_contract": "same_provider_path_as_scene_frame_rtofs_bundle_then_json_cache",
                    "communication_contract": "field_boater_bait_scene_bridge_read_load_cached_rtofs_surface",
                    "sst_ocean_mask_cache": mask_cache,
                },
            }
            Path(cache_path).write_text(json.dumps(out, separators=(",", ":")))
            return out
        diagnostics.append({"stage": "points", "status": "empty_points", "reason": sample.get("reason")})
    except Exception as exc:
        diagnostics.append({"stage": "provider_exception", "status": "failed", "error": str(exc)})

    # Compatibility fallback: keep the older direct candidate loop available for
    # diagnostics if the provider path regresses, but mark it as fallback.
    selected = None
    for cand in _surface_candidate_plan(candidate_limit):
        url = cand.get("url")
        if not url:
            continue
        path = None
        ds = None
        try:
            path, dldiag = noaa._download_cached(url)
            diagnostics.append({"stage": "fallback_download", "candidate": cand, **(dldiag or {})})
            if not path:
                continue
            ds, engine, open_error = noaa._open_dataset(path)
            if ds is None:
                diagnostics.append({"stage": "fallback_open", "status": "open_failed", "engine": engine, "error": open_error, "candidate": cand, "path": path})
                continue
            raw, parse_diag = noaa._payload_from_dataset(ds, b, max(1, int(step or 1)), url, cand.get("cycle"), cand.get("source_kind") or "2ds_surface_cache_warmer_fallback")
            diagnostics.append({"stage": "fallback_parse", "status": "parsed" if raw else "parse_empty", "engine": engine, "parse": parse_diag, "candidate": cand, "path": path})
            if not raw:
                continue
            sample = _points_from_raw(raw, b, max_points=max_points)
            points = sample.get("points") or []
            if not points:
                continue
            meta = raw.get("source_meta") if isinstance(raw, dict) else {}
            selected = cand
            out = {
                "ok": True, "status": "ready", "source": "ncep_nomads_rtofs_cached_surface",
                "schema": "rtofs_surface_current_sample_cache_v2_fallback_direct_open",
                "bbox": b.as_list(), "bbox_object": {"west": b.west, "south": b.south, "east": b.east, "north": b.north},
                "url": url, "selected_surface": cand,
                "resolved_time": datetime.now(timezone.utc).isoformat(),
                "points": points, "current_points": points, "ocean_points": points, "count": len(points),
                "cache_path": cache_path, "source_meta": meta,
                "diagnostics": {"latency_ms": int((time.time() - started) * 1000), "attempts": diagnostics[-12:], "file_path": path},
            }
            Path(cache_path).write_text(json.dumps(out, separators=(",", ":")))
            return out
        except Exception as exc:
            diagnostics.append({"stage": "fallback_exception", "candidate": cand, "error": str(exc)})
        finally:
            if ds is not None:
                try: ds.close()
                except Exception: pass

    return {
        "ok": False, "status": "not_ready", "source": "ncep_nomads_rtofs_cached_surface",
        "bbox": b.as_list(), "cache_path": cache_path, "selected_surface": selected,
        "points": [], "current_points": [], "ocean_points": [], "count": 0,
        "diagnostics": {"latency_ms": int((time.time() - started) * 1000), "attempts": diagnostics[-16:]},
    }


def spawn_rtofs_surface_warmer(bbox: Any, max_points: int = 3000) -> dict[str, Any]:
    """Fire a background-safe warmer process from HTTP without blocking.

    This is now self-healing:
    * rejects global/legacy boot bboxes so they cannot own the RTOFS warmer;
    * deletes stale warm_*.lock files;
    * passes the lock path to the child warmer so successful/failed exits clear it.
    """
    _ensure_rtofs_dirs()
    b, _digest = _bbox_key(bbox)
    allowed, reason, bbox_meta = _rtofs_wake_bbox_allowed(b)
    if not allowed:
        return {"started": False, "reason": reason, "bbox": b.as_list(), "bbox_policy": bbox_meta}
    script = _PROJECT_ROOT / "scripts" / "warm_rtofs_surface_cache.py"
    if not script.exists():
        return {"started": False, "reason": "warmer_script_missing", "script": str(script)}

    # If the exact JSON cache is already warm, don't spawn another process.
    try:
        cached = load_cached_rtofs_surface(b, max_age_seconds=int(os.getenv("GFS_RTOFS_SAMPLE_STALE_SECONDS", "21600") or "21600"))
        if cached.get("ok") and int(cached.get("count") or 0) > 0:
            return {"started": False, "reason": "cache_ready", "cache_path": cached.get("cache_path"), "count": cached.get("count"), "bbox": b.as_list()}
    except Exception:
        pass

    lock = _RTOFS_SAMPLE_DIR / f"warm_{_digest}.lock"
    # Local/lake/harbor wakes should self-heal quickly. A stale exact-bbox lock
    # blocks the shared ocean mission group (bait + sharks + boats).
    stale_seconds = int(os.getenv("GFS_RTOFS_WARM_LOCK_STALE_SECONDS", os.getenv("GFS_RTOFS_WARM_LOCK_SECONDS", "180")) or "180")
    lock_seconds = int(os.getenv("GFS_RTOFS_WARM_LOCK_SECONDS", "240") or "240")
    removed_stale = False
    if lock.exists():
        removed_stale = _unlink_stale_rtofs_lock(lock, stale_seconds)
    if lock.exists() and (_lock_age_seconds(lock) or 0) < lock_seconds:
        return {"started": False, "reason": "already_warming", "lock": str(lock), "lock_age_seconds": int(_lock_age_seconds(lock) or 0), "stale_seconds": stale_seconds, "lock_pid_alive": _rtofs_lock_pid_is_alive(lock), "bbox": b.as_list(), "bbox_policy": bbox_meta}
    try:
        lock.write_text(json.dumps({"started_at": time.time(), "bbox": b.as_list(), "max_points": int(max_points or 3000), "pid": None, "contract": "self_clearing_rtofs_warm_lock_v2"}))
    except Exception:
        pass
    cmd = [sys.executable, str(script), f"--bbox={b.west},{b.south},{b.east},{b.north}", "--max-points", str(int(max_points or 3000)), "--lock", str(lock)]
    try:
        proc = subprocess.Popen(cmd, cwd=str(_PROJECT_ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        try:
            lock.write_text(json.dumps({"started_at": time.time(), "bbox": b.as_list(), "max_points": int(max_points or 3000), "pid": proc.pid, "contract": "self_clearing_rtofs_warm_lock_v2"}))
        except Exception:
            pass
        return {"started": True, "pid": proc.pid, "pid_mode": "detached", "cmd": cmd, "lock": str(lock), "removed_stale_lock": removed_stale, "bbox": b.as_list(), "bbox_policy": bbox_meta}
    except Exception as exc:
        try:
            if lock.exists():
                lock.unlink()
        except Exception:
            pass
        return {"started": False, "reason": "spawn_failed", "error": str(exc), "lock": str(lock), "bbox": b.as_list(), "bbox_policy": bbox_meta}



def find_latest_rtofs_cycle() -> dict[str, Any]:
    """Lightweight public wrapper for RTOFS candidate date/cycle diagnostics."""
    try:
        ymds = noaa._candidate_date_strings()
    except Exception as exc:
        return {"ok": False, "error": str(exc), "ymd": None}
    ymd = ymds[0] if ymds else None
    return {"ok": bool(ymd), "ymd": ymd, "candidate_dates": ymds[:6], "source": "ncep_nomads_rtofs_index"}


def rtofs_surface_candidates(limit: int = 12) -> list[dict[str, Any]]:
    """Expose the current surface candidate plan without opening remote files."""
    try:
        return _surface_candidate_plan(limit)[:max(1, int(limit or 12))]
    except Exception:
        return []


def rtofs_3d_candidates(bbox: Any = None, limit: int = 12) -> list[dict[str, Any]]:
    """Expose candidate RTOFS 3D volume files for a bbox without downloading/opening them."""
    try:
        b = _bbox_from_any(bbox or [-125, 32, -117, 38])
        return list(noaa._depth_candidate_urls(b))[:max(1, int(limit or 12))]
    except Exception:
        return []

from __future__ import annotations

"""LFTR clean viewport/tile architecture.

This module is intentionally small and boring.  It is the new architecture
spine for provider/cache work:

* one camera-aware viewport bbox contract
* always 6 x 6 = 36 congruent viewport tiles
* every provider/layer uses the same tile grid
* LOD changes density/detail only, never tile count

Older files may still contain historical names such as world/regional/coastal/harbor;
adapters should normalize those into global/local at the boundary.
"""

import math
import os
from typing import Any

VIEWPORT_TILE_ROWS = 6
VIEWPORT_TILE_COLS = 6
VIEWPORT_TILE_GRID = 6
VIEWPORT_TILE_COUNT = 36

LOD_GLOBAL = "global"
LOD_LOCAL = "local"
LOD_LEVELS = (LOD_GLOBAL, LOD_LOCAL)

LOD_ALIASES = {
    "world": LOD_GLOBAL,
    "overview": LOD_GLOBAL,
    "global": LOD_GLOBAL,
    "regional": LOD_LOCAL,
    "coastal": LOD_LOCAL,
    "harbor": LOD_LOCAL,
    "local": LOD_LOCAL,
    "full": LOD_LOCAL,
}

def normalize_lod(value: Any) -> str:
    return LOD_ALIASES.get(str(value or "").strip().lower(), LOD_GLOBAL)

def bbox_span_area(bbox: dict[str, Any] | None) -> tuple[float, float, float]:
    b = bbox or {}
    try:
        west = float(b.get("west", -180.0)); east = float(b.get("east", 180.0))
        south = float(b.get("south", -80.0)); north = float(b.get("north", 80.0))
    except Exception:
        west, south, east, north = -180.0, -80.0, 180.0, 80.0
    width = abs(east - west)
    if width > 180.0:
        width = 360.0 - width
    height = abs(north - south)
    return width, height, max(0.0, width * height)

def lod_for_bbox(bbox: dict[str, Any] | None) -> str:
    width, height, area = bbox_span_area(bbox)
    # Two levels only. Tile count stays 36. Only lake/harbor/nearshore detail
    # becomes local; weather/cloud/rain visuals remain stable across tiers.
    if width <= 8.0 and height <= 6.0 and area <= 36.0:
        return LOD_LOCAL
    return LOD_GLOBAL

def lod_density(lod: Any) -> dict[str, Any]:
    l = normalize_lod(lod)
    table = {
        LOD_GLOBAL: {
            "sample_stride": int(os.getenv("GFS_GLOBAL_SAMPLE_STRIDE", "8") or "8"),
            "target_cells": 64000,
            "provider_target_cells": 160000,
            "solve_dx_deg": 0.25,
            "render_dx_deg": 0.50,
            "max_cloud_shells": 220,
            "max_cloud_particles": 1800,
            "max_boats": 10,
            "max_bait_polygons": 60,
        },
        LOD_LOCAL: {
            "sample_stride": int(os.getenv("GFS_LOCAL_SAMPLE_STRIDE", "1") or "1"),
            "target_cells": 90000,
            "provider_target_cells": 240000,
            "solve_dx_deg": 0.015,
            "render_dx_deg": 0.03,
            "max_cloud_shells": 220,
            "max_cloud_particles": 1800,
            "max_boats": 18,
            "max_bait_polygons": 220,
        },
    }
    out = dict(table.get(l, table[LOD_GLOBAL]))
    out.update({
        "tier": l,
        "lod": l,
        "tile_rows": VIEWPORT_TILE_ROWS,
        "tile_cols": VIEWPORT_TILE_COLS,
        "tile_count": VIEWPORT_TILE_COUNT,
        "max_ocean_refresh_tiles": VIEWPORT_TILE_COUNT,
        "max_weather_refresh_tiles": VIEWPORT_TILE_COUNT,
        "tile_policy": "fixed_6x6_36_tiles_two_level_global_local",
    })
    return out

def expand_bbox_for_camera(
    bbox: dict[str, Any] | None,
    *,
    tilt: Any = None,
    pitch: Any = None,
    heading: Any = None,
    max_factor: float | None = None,
) -> dict[str, float] | None:
    """Conservative view-footprint padding for tilted 3D camera views.

    The frontend should ideally send an exact visible footprint.  When it only
    sends center/viewport bbox plus camera angle, expand that bbox a little so
    the provider/cache tiles cover the far edge of the tilted view.
    """
    if not isinstance(bbox, dict):
        return bbox
    try:
        west = float(bbox["west"]); east = float(bbox["east"])
        south = float(bbox["south"]); north = float(bbox["north"])
    except Exception:
        return bbox
    try:
        t = float(tilt if tilt is not None else (pitch if pitch is not None else 0.0))
        if not math.isfinite(t):
            t = 0.0
    except Exception:
        t = 0.0
    try:
        h = float(heading) if heading is not None else 0.0
        heading_known = math.isfinite(h)
    except Exception:
        heading_known = False
    t = max(0.0, min(85.0, abs(t)))
    # 0° = no extra; 60–70° tilt gets meaningful far-edge coverage.
    factor = 1.0 + (t / 85.0) * 0.75 + (0.08 if heading_known and t > 5.0 else 0.0)
    factor = min(float(max_factor or os.getenv("GFS_CAMERA_VIEW_BBOX_MAX_FACTOR", "1.9") or "1.9"), factor)
    if factor <= 1.001:
        return {"west": west, "south": south, "east": east, "north": north}
    cx = (west + east) / 2.0; cy = (south + north) / 2.0
    half_w = max(0.005, (east - west) * factor / 2.0)
    half_h = max(0.005, (north - south) * factor / 2.0)
    return {
        "west": max(-180.0, cx - half_w),
        "south": max(-89.9, cy - half_h),
        "east": min(180.0, cx + half_w),
        "north": min(89.9, cy + half_h),
    }

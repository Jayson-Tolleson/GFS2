from __future__ import annotations

# GLMLightning owns the true lightning provider behavior only:
# GOES GLM flash cache, short-lived viewport flashes, and 2-minute TTL expiry.
# It must not orchestrate NCSS/GFS weather warmers or RTOFS/ocean warmers.
import os

import server.gfs_service as _svc
globals().update({k: v for k, v in vars(_svc).items() if not k.startswith("__")})


class GLMLightningMixin:
    def _lightning_cache_root(self) -> Path:
        root = Path(getattr(self, "runtime_gfs_cache_dir", DEFAULT_GFS_CACHE_DIR)) / "lightning"
        try:
            root.mkdir(parents=True, exist_ok=True)
            probe = root / ".write_probe"
            probe.write_text("ok")
            probe.unlink(missing_ok=True)
            return root
        except Exception as exc:
            fallback = Path(os.getenv("LFTR_RUNTIME_CACHE_FALLBACK", "/tmp/lftr_broadcast_cache")) / "gfs_nomads" / "lightning"
            fallback.mkdir(parents=True, exist_ok=True)
            log.warning("[gfs lightning] cache root fallback path=%s fallback=%s err=%s", root, fallback, exc)
            return fallback

    def _lightning_cache_path(self, bbox: dict[str, float] | None = None, product: str = "goes_glm") -> Path:
        b = self._normalize_bbox(bbox)
        sig = f"{b.get('west',0):.2f}_{b.get('south',0):.2f}_{b.get('east',0):.2f}_{b.get('north',0):.2f}"
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", sig)[:96]
        path = self._lightning_cache_root()
        return path / f"{product}_{safe}.json.gz"

    def _lightning_event_ttl_seconds(self) -> int:
        # Viewport flashes are near-real-time particles.  Keep them short-lived;
        # the scene cache reload cadence is about 2 minutes.
        return max(15, int(os.getenv("GFS_GLM_FLASH_TTL_SECONDS", "120") or "120"))

    def _glm_event_time_from_path(self, path: Path, fallback: datetime) -> datetime:
        # NOAA GLM filenames include _sYYYYJJJHHMMSS...; use it so particles
        # expire by event time rather than by cache write time.
        try:
            m = re.search(r"_s(\d{4})(\d{3})(\d{2})(\d{2})(\d{2})", path.name)
            if m:
                year, jday, hh, mm, ss = [int(x) for x in m.groups()]
                base = datetime(year, 1, 1, tzinfo=timezone.utc) + timedelta(days=jday - 1)
                return base.replace(hour=hh, minute=mm, second=ss, microsecond=0)
        except Exception:
            pass
        return fallback

    def _filter_recent_lightning_payload(self, payload: dict[str, Any], *, cache_age_seconds: float = 0.0, now: datetime | None = None) -> dict[str, Any]:
        now = now or datetime.now(timezone.utc)
        ttl = self._lightning_event_ttl_seconds()
        rows = payload.get("flashes") or payload.get("items") or []
        kept: list[dict[str, Any]] = []
        expired = 0
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            try:
                age = float(row.get("age_seconds") or 0.0) + max(0.0, float(cache_age_seconds or 0.0))
            except Exception:
                age = max(0.0, float(cache_age_seconds or 0.0))
            if age > ttl:
                expired += 1
                continue
            item = dict(row)
            item["age_seconds"] = round(age, 3)
            item["event_ttl_seconds"] = ttl
            item["expires_in_seconds"] = max(0.0, round(ttl - age, 3))
            kept.append(item)
        out = dict(payload)
        out["flashes"] = kept
        out["items"] = kept
        out["regions"] = self._cluster_lightning_regions(kept)
        out["count"] = len(kept)
        out["event_ttl_seconds"] = ttl
        out["particle_ttl_seconds"] = ttl
        out["event_particle_contract"] = "lightning_flashes_are_short_ttl_event_particles_expired_flashes_removed_without_clearing_other_layers"
        out.setdefault("diagnostics", {})
        if isinstance(out["diagnostics"], dict):
            out["diagnostics"].update({
                "event_ttl_seconds": ttl,
                "expired_flashes_removed": expired,
                "flashes_after_ttl_filter": len(kept),
                "particle_contract": out["event_particle_contract"],
            })
        if not kept and rows:
            out["payload_state"] = "expired_no_recent_lightning"
            out.setdefault("quality", {})["live_goes_glm"] = False
        return out

    def _read_lightning_cache(self, bbox: dict[str, float] | None = None, ttl_seconds: int = 90) -> dict[str, Any] | None:
        path = self._lightning_cache_path(bbox)
        if not path.exists():
            return None
        try:
            age = time.time() - path.stat().st_mtime
            if ttl_seconds >= 0 and age > ttl_seconds:
                return None
            import gzip
            with gzip.open(path, "rt", encoding="utf-8") as fh:
                payload = json.load(fh)
            if isinstance(payload, dict):
                payload = self._filter_recent_lightning_payload(payload, cache_age_seconds=age)
                payload.setdefault("cache", {})
                payload["cache"].update({"hit": True, "age_seconds": round(age, 3), "path": str(path)})
                payload.setdefault("payload_state", "cache_hit")
                return payload
        except Exception as exc:
            log.debug("lightning cache read skipped err=%s", exc)
        return None

    def _write_lightning_cache(self, bbox: dict[str, float] | None, payload: dict[str, Any]) -> dict[str, Any]:
        path = self._lightning_cache_path(bbox)
        tmp = path.with_suffix(path.suffix + ".tmp")
        try:
            import gzip
            safe_payload = self._json_safe_for_tile_cache(payload)
            with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as fh:
                json.dump(safe_payload, fh, separators=(",", ":"), ensure_ascii=False)
            tmp.replace(path)
        except Exception as exc:
            log.debug("lightning cache write skipped err=%s", exc)
        return payload

    def _goes_glm_s3_bases(self) -> list[tuple[str, str]]:
        # GOES-19 is current GOES-East; GOES-18 is current GOES-West.  These
        # buckets are public NOAA Open Data buckets.  Override with
        # GFS_GLM_SATELLITES="19,18" if needed.
        sats = os.getenv("GFS_GLM_SATELLITES", "19,18").replace("GOES", "").replace("goes", "")
        out: list[tuple[str, str]] = []
        for raw in re.split(r"[,;\s]+", sats):
            sat = raw.strip().lstrip("0")
            if not sat:
                continue
            if sat not in {"16", "17", "18", "19"}:
                continue
            out.append((f"GOES-{sat}", f"https://noaa-goes{sat}.s3.amazonaws.com"))
        return out or [("GOES-19", "https://noaa-goes19.s3.amazonaws.com"), ("GOES-18", "https://noaa-goes18.s3.amazonaws.com")]

    def _list_goes_glm_keys(self, base: str, when: datetime, limit: int = 12) -> list[str]:
        # NOAA S3 prefix example: GLM-L2-LCFA/2026/152/05/
        prefix = f"GLM-L2-LCFA/{when:%Y}/{when.timetuple().tm_yday:03d}/{when:%H}/"
        url = f"{base}/?list-type=2&prefix={prefix}"
        try:
            r = requests.get(url, timeout=(4, 12), headers={"User-Agent": DEFAULT_UA})
            if r.status_code != 200:
                return []
            import xml.etree.ElementTree as ET
            ns = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
            root = ET.fromstring(r.text)
            keys = []
            for node in root.findall(".//s3:Key", ns):
                txt = (node.text or "").strip()
                if txt.endswith(".nc") and "GLM-L2-LCFA" in txt:
                    keys.append(txt)
            return sorted(keys)[-max(1, int(limit)):]
        except Exception as exc:
            log.debug("GOES GLM list skipped url=%s err=%s", url, exc)
            return []

    def _download_goes_glm_nc(self, base: str, key: str) -> Path | None:
        cache_dir = self._lightning_cache_root() / "glm_nc"
        cache_dir.mkdir(parents=True, exist_ok=True)
        name = re.sub(r"[^A-Za-z0-9_.-]+", "_", key)[-160:]
        path = cache_dir / name
        if path.exists() and path.stat().st_size > 0:
            return path
        try:
            url = f"{base}/{key}"
            r = requests.get(url, timeout=(5, 30), headers={"User-Agent": DEFAULT_UA})
            if r.status_code != 200 or not r.content:
                return None
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_bytes(r.content)
            tmp.replace(path)
            return path
        except Exception as exc:
            log.debug("GOES GLM download skipped key=%s err=%s", key, exc)
            return None

    def _read_goes_glm_flashes(self, path: Path, platform: str, bbox: dict[str, float], now: datetime) -> list[dict[str, Any]]:
        if xr is None:
            return []
        try:
            ds = xr.open_dataset(path, engine="netcdf4")
        except Exception:
            try:
                ds = xr.open_dataset(path)
            except Exception as exc:
                log.debug("GOES GLM nc open skipped path=%s err=%s", path, exc)
                return []
        try:
            file_event_time = self._glm_event_time_from_path(path, now)
            lat_name = "flash_lat" if "flash_lat" in ds.variables else None
            lon_name = "flash_lon" if "flash_lon" in ds.variables else None
            if not lat_name or not lon_name:
                return []
            lats = ds[lat_name].values
            lons = ds[lon_name].values
            energies = ds["flash_energy"].values if "flash_energy" in ds.variables else [None] * len(lats)
            areas = ds["flash_area"].values if "flash_area" in ds.variables else [None] * len(lats)
            times = None
            for tname in ("flash_time_offset_of_first_event", "flash_time_offset_of_last_event", "flash_time_offset_of_first_event"):
                if tname in ds.variables:
                    times = ds[tname].values
                    break
            out = []
            west, south, east, north = [float(bbox[k]) for k in ("west", "south", "east", "north")]
            for i in range(min(len(lats), int(os.getenv("GFS_GLM_MAX_FLASHES_PER_FILE", "1200")))):
                try:
                    lat = float(lats[i]); lon = float(lons[i])
                    if not (south <= lat <= north and west <= lon <= east):
                        continue
                    energy = float(energies[i]) if energies is not None and energies[i] is not None else None
                    area = float(areas[i]) if areas is not None and areas[i] is not None else None
                    # GLM time variable is seconds relative to dataset epoch; xarray
                    # often decodes it to timedelta64. Keep a safe string if possible.
                    tstr = file_event_time.isoformat(); age = max(0.0, (now - file_event_time).total_seconds())
                    try:
                        tv = times[i] if times is not None else None
                        if tv is not None:
                            tstr = str(tv)
                    except Exception:
                        pass
                    out.append({
                        "lat": round(lat, 5), "lon": round(lon, 5),
                        "energy_j": energy, "area_m2": area,
                        "time": tstr, "valid_time": tstr,
                        "age_seconds": age if age is not None else 0,
                        "satellite": platform, "platform": platform,
                        "source": "goes_glm_l2_lcfa", "product": "GLM-L2-LCFA",
                    })
                except Exception:
                    continue
            return out
        finally:
            try: ds.close()
            except Exception: pass

    def _cluster_lightning_regions(self, flashes: list[dict[str, Any]]) -> list[dict[str, Any]]:
        buckets: dict[tuple[int, int], list[dict[str, Any]]] = {}
        for f in flashes:
            try:
                key = (int(float(f.get("lat")) * 2), int(float(f.get("lon")) * 2))  # ~0.5 degree cells
                buckets.setdefault(key, []).append(f)
            except Exception:
                continue
        regions = []
        for _key, items in buckets.items():
            if not items:
                continue
            lat = sum(float(x.get("lat")) for x in items) / len(items)
            lon = sum(float(x.get("lon")) for x in items) / len(items)
            energy = sum(float(x.get("energy_j") or 0.0) for x in items)
            regions.append({
                "center": {"lat": round(lat, 5), "lon": round(lon, 5)},
                "flash_count": len(items),
                "energy_j_sum": energy,
                "age_seconds": min(float(x.get("age_seconds") or 0.0) for x in items),
                "source": "goes_glm_l2_lcfa",
            })
        return sorted(regions, key=lambda r: int(r.get("flash_count") or 0), reverse=True)[:80]

    def _lightning_cache_shell(self, visible: dict[str, float], scene: dict[str, Any], minutes: int, reason: str = "queued_background_warm") -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        event_ttl = self._lightning_event_ttl_seconds()
        return self._attach_scene_plan({
            "ok": True,
            "schema": "lftr_lightning_v1",
            "source": "goes_glm_l2_lcfa_cache_first",
            "payload_state": "warming",
            "mode": "stale_while_revalidate_no_direct_provider_block",
            "valid_window_minutes": minutes,
            "event_ttl_seconds": event_ttl,
            "particle_ttl_seconds": event_ttl,
            "event_particle_contract": "lightning_flashes_are_short_ttl_event_particles_expired_flashes_removed_without_clearing_other_layers",
            "bbox": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "bbox_used": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "flashes": [],
            "items": [],
            "regions": [],
            "count": 0,
            "fallback_used": False,
            "mock": False,
            "proxy": False,
            "quality": {"live_goes_glm": False, "fallback_used": False, "mock": False, "proxy": False},
            "cache": {"hit": False, "mode": "cache_only_glm_deferred_warm_disabled", "ttl_seconds": int(os.getenv("GFS_GLM_CACHE_TTL_SECONDS", "180") or "180"), "reason": reason},
            "diagnostics": {"note": "Lightning is cache-first. In-process GOES/GLM NetCDF deferred warm is disabled unless GFS_ENABLE_GLM_DEFERRED_WARM=1; expired flashes fade independently."},
            "generated_at": now.isoformat(),
        }, scene)

    def _schedule_lightning_warm(self, requested: dict[str, float], visible: dict[str, float], minutes: int, scene: dict[str, Any]) -> None:
        # Keep lightning cache-visible but do not run the GLM NetCDF/HDF reader inside
        # the web process by default.  Some NetCDF/HDF failures can abort Python
        # below the exception layer; opt in only after the provider is isolated.
        if os.getenv("GFS_ENABLE_GLM_DEFERRED_WARM", "false").strip().lower() not in {"1", "true", "yes", "on"}:
            return
        if os.getenv("GFS_DISABLE_GLM", "false").strip().lower() in {"1", "true", "yes", "on"}:
            return
        if not hasattr(self, "_lightning_warm_inflight"):
            self._lightning_warm_inflight = set()
        key = self._bbox_cache_key("lightning", visible) + f":{int(minutes or 20)}"
        if key in self._lightning_warm_inflight:
            return
        self._lightning_warm_inflight.add(key)

        def _run() -> None:
            try:
                self._lightning_payload_live(requested, visible, minutes)
            except Exception as exc:
                log.warning("[gfs lightning] deferred warm failed key=%s err=%s", key, exc)
            finally:
                try:
                    self._lightning_warm_inflight.discard(key)
                except Exception:
                    pass

        threading.Thread(target=_run, name="gfs-lightning-warm", daemon=True).start()

    def lightning_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, minutes: int = 20) -> dict[str, Any]:
        requested = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or requested)
        scene = self.build_scene_plan(requested, visible, layer="lightning")
        ttl = int(os.getenv("GFS_GLM_CACHE_TTL_SECONDS", "180") or "180")
        cached = self._read_lightning_cache(visible, ttl_seconds=ttl)
        if cached:
            cached["payload_state"] = "cache_hit_live_recent" if int(cached.get("count") or 0) > 0 else "cache_hit_no_recent_lightning"
            cached["cache"] = {"hit": True, "mode": "fresh_lightning_cache", "ttl_seconds": ttl}
            cached["scene_plan"] = scene
            return cached
        stale = self._read_lightning_cache(visible, ttl_seconds=-1)
        self._schedule_lightning_warm(requested, visible, minutes, scene)
        if stale:
            stale["payload_state"] = "stale_while_revalidate" if int(stale.get("count") or 0) > 0 else "stale_cache_no_recent_lightning"
            stale["cache"] = {"hit": True, "mode": "stale_while_revalidate", "ttl_seconds": ttl}
            stale["scene_plan"] = scene
            return stale
        return self._lightning_cache_shell(visible, scene, minutes)

    def _lightning_payload_live(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, minutes: int = 20) -> dict[str, Any]:
        requested = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or requested)
        scene = self.build_scene_plan(requested, visible, layer="lightning")
        ttl = int(os.getenv("GFS_GLM_CACHE_TTL_SECONDS", "60"))
        cached = self._read_lightning_cache(visible, ttl_seconds=ttl)
        if cached:
            cached["payload_state"] = "cache_hit_live_recent" if int(cached.get("count") or 0) > 0 else "cache_hit_no_recent_lightning"
            cached["scene_plan"] = scene
            return cached
        if os.getenv("GFS_DISABLE_GLM", "false").strip().lower() in {"1", "true", "yes", "on"}:
            return self._attach_scene_plan({
                "ok": False, "schema": "lftr_lightning_v1", "source": "goes_glm_disabled",
                "payload_state": "disabled", "flashes": [], "items": [], "regions": [],
                "fallback_used": False, "mock": False, "proxy": False,
            }, scene)
        now = datetime.now(timezone.utc)
        flashes: list[dict[str, Any]] = []
        diagnostics: list[dict[str, Any]] = []
        hours = [now - timedelta(hours=h) for h in range(0, max(1, int(math.ceil(max(1, minutes) / 60)) + 2))]
        per_hour_keys = int(os.getenv("GFS_GLM_KEYS_PER_HOUR", "8"))
        for platform, base in self._goes_glm_s3_bases():
            before = len(flashes)
            for wh in hours:
                keys = self._list_goes_glm_keys(base, wh, limit=per_hour_keys)
                diagnostics.append({"platform": platform, "hour": wh.strftime("%Y-%j-%H"), "keys": len(keys)})
                for key in keys:
                    path = self._download_goes_glm_nc(base, key)
                    if not path:
                        continue
                    flashes.extend(self._read_goes_glm_flashes(path, platform, visible, now))
                    if len(flashes) >= int(os.getenv("GFS_GLM_MAX_FLASHES", "1500")):
                        break
                if len(flashes) >= int(os.getenv("GFS_GLM_MAX_FLASHES", "1500")):
                    break
            diagnostics[-1:]
            diagnostics.append({"platform": platform, "flashes_added": len(flashes) - before})
        # De-duplicate near-identical flashes.
        seen = set(); unique = []
        for f in flashes:
            key = (round(float(f.get("lat") or 0), 3), round(float(f.get("lon") or 0), 3), str(f.get("satellite")))
            if key in seen:
                continue
            seen.add(key); unique.append(f)
        unique = unique[: int(os.getenv("GFS_GLM_MAX_FLASHES", "1500"))]
        event_ttl = self._lightning_event_ttl_seconds()
        unique = [dict(f, event_ttl_seconds=event_ttl, expires_in_seconds=max(0.0, event_ttl - float(f.get("age_seconds") or 0.0))) for f in unique if float(f.get("age_seconds") or 0.0) <= event_ttl]
        payload = {
            "ok": True,
            "schema": "lftr_lightning_v1",
            "source": "goes_glm_l2_lcfa",
            "payload_state": "live" if unique else "provider_empty",
            "valid_window_minutes": minutes,
            "event_ttl_seconds": event_ttl,
            "particle_ttl_seconds": event_ttl,
            "event_particle_contract": "lightning_flashes_are_short_ttl_event_particles_expired_flashes_removed_without_clearing_other_layers",
            "bbox": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "bbox_used": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "flashes": unique,
            "items": unique,
            "regions": self._cluster_lightning_regions(unique),
            "count": len(unique),
            "fallback_used": False, "mock": False, "proxy": False,
            "quality": {"live_goes_glm": bool(unique), "fallback_used": False, "mock": False, "proxy": False},
            "diagnostics": {"providers": diagnostics, "satellites": [p for p, _ in self._goes_glm_s3_bases()], "event_ttl_seconds": event_ttl, "flashes_after_ttl_filter": len(unique), "particle_contract": "short_ttl_event_particles", "note": "GOES GLM Level 2 LCFA flash_lat/flash_lon filtered to visible bbox"},
            "generated_at": now.isoformat(),
        }
        payload = self._attach_scene_plan(payload, scene)
        # Cache both positive and provider-empty GLM results.  Empty-but-fresh is
        # still valuable; without this, every browser refresh can re-trigger a
        # slow GOES/GLM scan that returns no flashes after tens of seconds.
        self._write_lightning_cache(visible, payload)
        return payload

    def note_viewport_priority(self, bbox: dict[str, float] | None = None, reason: str = "viewport") -> dict[str, Any]:
        """Remember a browser viewport as high priority without blocking."""
        b = self._normalize_bbox(bbox)
        b["noted_at"] = self._now_ms()
        b["reason"] = reason
        # Do not let giant boot/default projected boxes become the first always-on
        # ocean priority.  The browser may briefly report a broad fallback camera
        # footprint before the real Maps 3D camera settles.  Those are useful for
        # weather overview, but they must not poison recent_viewports for ocean.
        try:
            width = abs(float(b.get("east")) - float(b.get("west")))
            height = abs(float(b.get("north")) - float(b.get("south")))
            area = width * height
            if area > float(os.getenv("GFS_RECENT_VIEWPORT_MAX_PRIORITY_AREA_DEG2", "550") or "550"):
                return {"ok": True, "viewport_bbox": self._normalize_bbox(b), "cache_bbox": self._bounded_work_bbox(b), "reason": reason, "noted": False, "skip_reason": "viewport_too_large_for_recent_ocean_priority", "area_deg2": area}
        except Exception:
            pass
        recent = [x for x in getattr(self, "_recent_viewports", []) if isinstance(x, dict)]
        sig = tuple(round(float(b[k]), 2) for k in ("west", "south", "east", "north"))
        filtered = []
        for old in recent:
            try:
                old_sig = tuple(round(float(old[k]), 2) for k in ("west", "south", "east", "north"))
                if old_sig == sig:
                    continue
            except Exception:
                pass
            filtered.append(old)
        self._recent_viewports = [b] + filtered[:11]
        return {"ok": True, "viewport_bbox": self._normalize_bbox(b), "cache_bbox": self._bounded_work_bbox(b), "reason": reason}

    def _default_boot_bboxes(self) -> list[dict[str, float]]:
        """Priority bboxes for no-browser always-on warming."""
        env = os.getenv("GFS_ALWAYS_ON_BOOT_BBOXES", "").strip()
        out: list[dict[str, float]] = []
        if env:
            for chunk in env.split(";"):
                try:
                    w, s, e, n = [float(x.strip()) for x in chunk.split(",")[:4]]
                    out.append({"west": w, "south": s, "east": e, "north": n})
                except Exception:
                    continue
        if out:
            return out[:12]
        try:
            points, _ = self.load_fish()
            pts = []
            for p in points[:80]:
                lat = safe_float(p.get("lat"), 999)
                lon = safe_float(p.get("lon"), 999)
                if -80 <= lat <= 80 and -180 <= lon <= 180:
                    pts.append((lat, lon))
            if pts:
                lats = [p[0] for p in pts]
                lons = [p[1] for p in pts]
                out.append({"west": max(-180, min(lons) - 1.0), "south": max(-80, min(lats) - 1.0), "east": min(180, max(lons) + 1.0), "north": min(80, max(lats) + 1.0)})
        except Exception:
            pass
        out.append({"west": -121.0, "south": 31.5, "east": -116.0, "north": 35.5})
        return out[:6]



from __future__ import annotations

from server.gfs.viewport36 import VIEWPORT_TILE_COUNT, VIEWPORT_TILE_GRID, normalize_lod
import os

import server.gfs_service as _svc
globals().update({k: v for k, v in vars(_svc).items() if not k.startswith("__")})

from .GLMLightning import GLMLightningMixin
from server.gfs.intel_contract import apply_inland_temp_contract, normalize_lod_name, OCEAN_MISSION_LAYERS


class LightningCacheMediaMixin(GLMLightningMixin):
    def start_always_on_cache(self) -> dict[str, Any]:
        """Start the server-resident 5-minute cache warmer daemon."""
        state = getattr(self, "_always_on_cache_state", {})
        if not state.get("enabled", True):
            return {"ok": True, "started": False, "reason": "disabled", "cache": state}
        if self._always_on_cache_started:
            return {"ok": True, "started": False, "reason": "already_started", "cache": state}
        self._always_on_cache_started = True
        state["running"] = True
        state["started_at"] = self._now_ms()
        def _loop() -> None:
            interval = max(60, int(state.get("interval_sec") or 300))
            max_tiles = max(1, min(int(os.getenv("GFS_ALWAYS_ON_MAX_TILES", "96") or "96"), 256))
            while True:
                try:
                    state["last_tick"] = self._now_ms()
                    candidates = list(getattr(self, "_recent_viewports", []) or [])[:4] + self._default_boot_bboxes()
                    scheduled = []
                    for i, bbox in enumerate(candidates[:6]):
                        # Always-on warming should keep the map responsive, not hammer every remote provider.
                        # Ocean/bait/boats warm only when the browser explicitly asks for those layers.
                        base_layers = ["clouds", "rain", "lightning"]
                        result = self.schedule_globe_cache_warm(bbox, max_tiles=max_tiles, reason="always_on_5min" if i == 0 else "always_on_background", layers=base_layers)
                        scheduled.append({"bbox": self._normalize_bbox(bbox), "scheduled": bool(result.get("scheduled")), "reason": result.get("reason")})
                        if result.get("scheduled"):
                            break
                    state["last_scheduled"] = scheduled
                    state["last_error"] = None
                except Exception as exc:
                    state["last_error"] = str(exc)
                    log.warning("[gfs/cache] always-on loop error: %s", exc)
                time.sleep(interval)
        t = threading.Thread(target=_loop, name="gfs-always-on-cache", daemon=True)
        self._always_on_cache_thread = t
        t.start()
        log.info("[gfs/cache] always-on cache daemon started interval=%ss pad_factor=%s", state.get("interval_sec"), state.get("pad_factor"))
        return {"ok": True, "started": True, "cache": state}

    def cache_status_payload(self) -> dict[str, Any]:
        root = self._tile_cache_root()
        files = list(root.glob("*.intel.json")) if root.exists() else []
        ages = []
        now = time.time()
        for p in files[:5000]:
            try:
                ages.append(max(0, int(now - p.stat().st_mtime)))
            except Exception:
                pass
        warm = self._cache_warm_status_payload()
        return {
            "ok": True,
            "schema": "lftr_cache_first_status_v1",
            "server_time": datetime.now(timezone.utc).isoformat(),
            "cache": {
                "enabled": True,
                "running": bool((getattr(self, "_always_on_cache_state", {}) or {}).get("running")),
                "cache_path": str(root),
                "tiles_total": len(files),
                "fresh_target_sec": int(os.getenv("GFS_CACHE_FRESH_TARGET_SEC", "240") or "240"),
                "newest_age_sec": min(ages) if ages else None,
                "oldest_age_sec_sample": max(ages) if ages else None,
                "clients_connected": "tracked_by_ws",
                "warm": warm,
                "always_on": getattr(self, "_always_on_cache_state", {}),
                "recent_viewports": list(getattr(self, "_recent_viewports", []) or [])[:6],
                "bounds_policy": {"mode": "padded_viewport", "factor": float(os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25") or "1.25")},
            },
        }

    def contours_payload(self) -> Dict[str, Any]:
        return {"ok": True, "features": [], "ts": self._now_ms()}

    def overlay_payload(self) -> Dict[str, Any]:
        return {"ok": True, "layers": [], "ts": self._now_ms()}

    def legend_payload(self) -> Dict[str, Any]:
        return {
            "ok": True,
            "legend": [
                {"name": "Low", "color": "#1f77b4"},
                {"name": "Medium", "color": "#ff7f0e"},
                {"name": "High", "color": "#d62728"},
            ],
            "ts": self._now_ms(),
        }

    def tile_png_bytes(self, z: int, x: int, y: int) -> bytes:
        _ = (z, x, y)
        return base64.b64decode(_TRANSPARENT_PNG_BASE64)

    def location_media(self, location_key: str) -> Dict[str, Any]:
        return self._location_media_payload(location_key)

    def upsert_report(self, location_key: str, report_text: str) -> Dict[str, Any]:
        key = self._normalize_location_key(location_key)
        if not key:
            return {"ok": False, "error": "missing location_key"}
        store = self._load_store()
        rec = self._ensure_location_record(store, key)
        rec["report_text"] = (report_text or "").strip()
        rec["report_updated_at"] = self._now_ms()
        self._save_store(store)
        return {"ok": True, **self._location_media_payload(key)}

    def upsert_live(self, location_key: str, active: bool, stream_url: str) -> Dict[str, Any]:
        key = self._normalize_location_key(location_key)
        if not key:
            return {"ok": False, "error": "missing location_key"}
        store = self._load_store()
        rec = self._ensure_location_record(store, key)
        rec["live"] = {
            "active": bool(active),
            "stream_url": (stream_url or "").strip(),
            "updated_at": self._now_ms(),
        }
        self._save_store(store)
        return {"ok": True, **self._location_media_payload(key)}

    def save_upload_video(self, location_key: str, filename: str, raw: bytes) -> Dict[str, Any]:
        key = self._normalize_location_key(location_key)
        if not key:
            return {"ok": False, "error": "missing location_key"}
        if not raw:
            return {"ok": False, "error": "empty upload"}

        safe_name = secure_filename(filename or "upload.mp4")
        ext = Path(safe_name).suffix.lower()
        if ext not in _ALLOWED_VIDEO_EXTS:
            return {"ok": False, "error": f"unsupported file type: {ext or 'none'}"}

        saved_name = f"{key}-{self._now_ms()}{ext}"
        out_path = self.fishvid_dir / saved_name
        out_path.write_bytes(raw)
        media_url = f"/static/fishvid/{saved_name}"

        store = self._load_store()
        rec = self._ensure_location_record(store, key)
        uploads = rec.setdefault("uploads", [])
        uploads.insert(
            0,
            {
                "url": media_url,
                "filename": saved_name,
                "mime": f"video/{ext.lstrip('.') if ext != '.mov' else 'quicktime'}",
                "uploaded_at": self._now_ms(),
            },
        )
        rec["uploads"] = uploads[:20]
        self._save_store(store)
        return {"ok": True, "location_key": key, "media_url": media_url, **self._location_media_payload(key)}



    # ------------------------------------------------------------------
    # LFTR scene-cache subscription spine
    # ------------------------------------------------------------------
    def _scene_cache_resolution_deg(self, bbox: dict[str, float] | None) -> float:
        """Return the cache-grid degree bucket for the current viewport span.

        This keeps the main scene cache simple: three-ish practical LOD buckets,
        quantized so camera jitter does not create endless duplicate cache rows.
        The resolver still prefers better/current cached payloads and low LOD only
        fills gaps or serves fast boot/global views.
        """
        b = self._normalize_bbox(bbox)
        span = max(abs(float(b.get("east", 0)) - float(b.get("west", 0))), abs(float(b.get("north", 0)) - float(b.get("south", 0))))
        if span <= 1.2:
            return 0.05
        if span <= 3.5:
            return 0.10
        if span <= 8.0:
            return 0.25
        if span <= 18.0:
            return 0.50
        return 1.00

    def _scene_cache_quantize_bbox(self, bbox: dict[str, float] | None, resolution_deg: float | None = None) -> dict[str, float]:
        b = self._normalize_bbox(bbox)
        r = float(resolution_deg or self._scene_cache_resolution_deg(b))
        if r <= 0:
            r = 0.25
        def q_floor(v: float) -> float:
            return math.floor(float(v) / r) * r
        def q_ceil(v: float) -> float:
            return math.ceil(float(v) / r) * r
        return {
            "west": round(q_floor(b["west"]), 4),
            "south": round(q_floor(b["south"]), 4),
            "east": round(q_ceil(b["east"]), 4),
            "north": round(q_ceil(b["north"]), 4),
        }

    def _scene_cache_bbox_contract(self, bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None = None, layer: str | None = None, role: str = "scene-cache") -> dict[str, Any]:
        requested = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or requested)
        layer_key = str(layer or "").strip().lower().replace("-", "_")
        weather_layers = {"clouds", "rain", "lightning", "jetstream", "inland_water_temp", "inland_temp"}
        ocean_layers = {"bait", "boater", "boats", "boater_awareness", "shark-intel", "shark_intel", "shark", "sharkintel"}
        static_layers = {"inland_water", "inland_waterways", "locations"}
        try:
            scene_plan = self.build_scene_plan(requested, visible, layer=layer_key or role)
            scene_tier = str(scene_plan.get("tier") or "global").lower()
            if scene_tier == "world":
                scene_tier = "global"
        except Exception:
            scene_tier = "global"
        if layer_key in weather_layers:
            cache_read = requested
            provider = None if scene_tier == "global" else requested
            provider_role = "weather_cache_read_bbox" if scene_tier == "global" else "weather_fetch_bbox"
        elif layer_key in ocean_layers or layer_key in static_layers:
            cache_read = visible
            provider = visible
            provider_role = "visible_bbox"
        else:
            cache_read = requested
            provider = requested
            provider_role = "requested_bbox"
        return {
            "version": "bbox_contract_v3_layer_specific_cache_read_vs_provider_fetch",
            "role": role,
            "layer": layer_key or None,
            "policy": "visible_bbox_is_render_box_world_weather_uses_cache_read_bbox_not_provider_fetch",
            "scene_tier": scene_tier,
            "requested_bbox": requested,
            "fetch_bbox": provider,
            "visible_bbox": visible,
            "render_bbox": visible,
            "weather_cache_read_bbox": cache_read if layer_key in weather_layers else requested,
            "weather_fetch_bbox": provider if layer_key in weather_layers else None,
            "ocean_fetch_bbox": visible,
            "shoreline_bbox": visible,
            "jetstream_bbox": visible,
            "jetstream_cache_read_bbox": cache_read if layer_key in weather_layers else visible,
            "jetstream_fetch_bbox": provider if layer_key == "jetstream" else (provider if layer_key in weather_layers and scene_tier != "global" else None),
            "provider_bbox": provider,
            "provider_role": provider_role,
            "cache_only": bool(provider is None),
        }

    def _scene_cache_layer_key(self, layer: str, bbox: dict[str, float], visible_bbox: dict[str, float] | None = None) -> str:
        vis = self._normalize_bbox(visible_bbox or bbox)
        resolution = self._scene_cache_resolution_deg(vis)
        qvis = self._scene_cache_quantize_bbox(vis, resolution)
        # One simple scene-cache scheme: layer + quantized visible tile/bbox + LOD.
        # This avoids hoarding near-identical scene snapshots while still letting
        # high-detail viewport cache rows beat low-detail/global rows.
        return "scene_cache:%s:lod%.2f:%s" % (str(layer).replace('-', '_'), resolution, self._bbox_key_fragment(qvis))

    def _scene_cache_first_paint_key(self, layer: str) -> str:
        # Tiny latest-good drawable for instant pill paint. It is not a full scene
        # snapshot and must never become the only cache source; it only bridges the
        # first animation frame while visible-bbox tiles warm in the background.
        return "scene_first_paint:%s" % str(layer).replace('-', '_')

    def _scene_cache_payload_version(self, layer: str, payload: dict[str, Any], quality_rank: int = 50) -> str:
        import hashlib
        now_hint = payload.get("resolved_time") or payload.get("valid_time") or payload.get("source_time") or payload.get("generated_at") or payload.get("ts") or self._now_ms()
        count_bits = [
            len(payload.get("items") or []) if isinstance(payload.get("items"), list) else 0,
            len(payload.get("features") or []) if isinstance(payload.get("features"), list) else 0,
            len(payload.get("precip_columns") or []) if isinstance(payload.get("precip_columns"), list) else 0,
            len(payload.get("flashes") or []) if isinstance(payload.get("flashes"), list) else 0,
            len(payload.get("boats") or []) if isinstance(payload.get("boats"), list) else 0,
            len(payload.get("polygons") or []) if isinstance(payload.get("polygons"), list) else 0,
            len((payload.get("bait") or {}).get("polygons") or []) if isinstance(payload.get("bait"), dict) else 0,
            len(payload.get("tempLabels") or []) if isinstance(payload.get("tempLabels"), list) else 0,
        ]
        base = "%s|%s|%s|%s|%s" % (layer, now_hint, quality_rank, payload.get("source"), ":".join(map(str, count_bits)))
        return "%s_q%s_%s" % (str(now_hint).replace(':', '').replace('-', '')[:18], int(quality_rank or 0), hashlib.sha1(base.encode("utf-8", "ignore")).hexdigest()[:10])

    def _scene_cache_empty_layer(self, layer: str, bbox: dict[str, float], reason: str = "warming") -> dict[str, Any]:
        now = self._now_ms()
        base = {
            "ok": True,
            "status": "warming",
            "payload_state": "warming",
            "source": "scene_cache_empty_%s" % layer,
            "bbox": bbox,
            "bbox_used": bbox,
            "cache": {"hit": False, "mode": reason, "ts": now},
            "ts": now,
        }
        key = str(layer).replace('-', '_')
        if key in {"clouds", "rain"}:
            base.update({"items": [], "features": [], "precip_columns": [], "scene": {}, "fields": {}})
        elif key == "lightning":
            base.update({"flashes": [], "items": [], "regions": []})
        elif key in {"boater", "boats", "boater_awareness"}:
            base.update({"boats": [], "items": [], "count": 0})
        elif key == "bait":
            base.update({"bait": {"status": "warming", "source": "scene_cache", "polygons": [], "outer_polygons": [], "inner_polygons": [], "core_polygons": []}, "bait_score": [], "polygons": []})
        elif key in {"shark_intel", "sharkintel", "shark"}:
            base.update({"schema": "lftr_shark_intel_v1", "contours": [], "polygons": [], "score_points": [], "species": {}, "target": {"primary_species": "leopard", "primary_size_in": [36, 42]}, "legal_caution": {"summary": "warming"}})
        elif key in {"inland_water", "inland_waterways"}:
            base.update({"polygons": [], "lines": [], "tempLabels": [], "temperature_points": [], "count": 0})
        elif key in {"inland_water_temp", "inland_temp", "inland-temp"}:
            base.update({"temperature_points": [], "tempLabels": [], "points": [], "count": 0, "one_largest_lake_per_tile": True})
        elif key == "locations":
            base.update({"items": [], "locations": []})
        return base

    def _scene_cache_layer_has_renderable_content(self, layer: str, payload: dict[str, Any] | None) -> bool:
        if not isinstance(payload, dict):
            return False
        layer = str(layer or "").lower()
        if layer == "bait":
            bait = payload.get("bait") if isinstance(payload.get("bait"), dict) else {}
            ocean_points_obj = payload.get("oceanPoints")
            ocean_points_list = ocean_points_obj.get("points") if isinstance(ocean_points_obj, dict) else ocean_points_obj
            return bool(
                (isinstance(bait.get("polygons"), list) and len(bait.get("polygons")) > 0)
                or (isinstance(payload.get("bait_score"), list) and len(payload.get("bait_score")) > 0)
                or (isinstance(payload.get("ocean_points"), list) and len(payload.get("ocean_points")) > 0)
                or (isinstance(ocean_points_list, list) and len(ocean_points_list) > 0)
            )
        if layer == "boater":
            return bool(
                (isinstance(payload.get("boats"), list) and len(payload.get("boats")) > 0)
                or (isinstance(payload.get("points"), list) and len(payload.get("points")) > 0)
                or (isinstance(payload.get("ocean_points"), list) and len(payload.get("ocean_points")) > 0)
                or (isinstance(payload.get("oceanPoints"), list) and len(payload.get("oceanPoints")) > 0)
            )
        if layer in {"shark-intel", "shark_intel", "sharkintel", "shark"}:
            ocean_mask = payload.get("ocean_mask_source") if isinstance(payload.get("ocean_mask_source"), dict) else {}
            ocean_points_obj = payload.get("oceanPoints")
            ocean_points_list = ocean_points_obj.get("points") if isinstance(ocean_points_obj, dict) else ocean_points_obj
            return bool(
                (isinstance(payload.get("contours"), list) and len(payload.get("contours")) > 0)
                or (isinstance(payload.get("polygons"), list) and len(payload.get("polygons")) > 0)
                or (isinstance(payload.get("score_points"), list) and len(payload.get("score_points")) > 0)
                or int(ocean_mask.get("points") or 0) > 0
                or (isinstance(ocean_points_list, list) and len(ocean_points_list) > 0)
            )
        if layer == "inland_water_temp":
            return bool(
                (isinstance(payload.get("temperature_points"), list) and len(payload.get("temperature_points")) > 0)
                or (isinstance(payload.get("tempLabels"), list) and len(payload.get("tempLabels")) > 0)
            )
        if layer == "clouds":
            return bool(
                (isinstance(payload.get("features"), list) and len(payload.get("features")) > 0)
                or (isinstance(payload.get("items"), list) and len(payload.get("items")) > 0)
                or (isinstance(payload.get("cloud_layers"), list) and len(payload.get("cloud_layers")) > 0)
            )
        if layer == "rain":
            return bool(
                (isinstance(payload.get("rain"), list) and len(payload.get("rain")) > 0)
                or (isinstance(payload.get("precip_columns"), list) and len(payload.get("precip_columns")) > 0)
                or (isinstance(payload.get("features"), list) and len(payload.get("features")) > 0)
            )
        if layer == "lightning":
            return bool(
                (isinstance(payload.get("flashes"), list) and len(payload.get("flashes")) > 0)
                or (isinstance(payload.get("regions"), list) and len(payload.get("regions")) > 0)
                or (isinstance(payload.get("markers"), list) and len(payload.get("markers")) > 0)
            )
        return True

    def _scene_cache_layer_is_placeholder(self, layer: str, payload: dict[str, Any] | None) -> bool:
        if not isinstance(payload, dict):
            return True
        status = str(payload.get("status") or payload.get("payload_state") or "").lower()
        source = str(payload.get("source") or "").lower()
        mode = str(payload.get("mode") or "").lower()
        ocean_backed = layer in {"bait", "boater", "boats", "boater_awareness", "shark-intel", "shark_intel", "sharkintel", "shark"}
        unavailable_tokens = (
            "live_required_unavailable",
            "ocean_live_required_unavailable",
            "bait_live_required_unavailable",
            "provider_empty",
            "waiting_for_sst_points",
            "rtofs_ocean_points_empty",
            "quality_gate_failed",
            "large_bbox_cache_only_no_live_ncss",
        )
        if status in {"warming", "fetching_fresh", "unavailable", "provider_empty", "waiting_for_sst_points"} or "warming" in mode:
            return not self._scene_cache_layer_has_renderable_content(layer, payload)
        if source in {"deferred_tile_cache", "cache_first", "cache_first_queued"}:
            return not self._scene_cache_layer_has_renderable_content(layer, payload)
        if ocean_backed and any(tok in source or tok in status or tok in mode for tok in unavailable_tokens):
            return not self._scene_cache_layer_has_renderable_content(layer, payload)
        return False

    def _scene_cache_peek_layer(self, layer: str, bbox: dict[str, float], visible_bbox: dict[str, float] | None = None, *, max_age_sec: int = 86400, allow_first_paint: bool = True) -> dict[str, Any] | None:
        key = self._scene_cache_layer_key(layer, bbox, visible_bbox)
        payload = self._split_cache_peek(key)
        mode = "scene_cache"
        age = self._split_cache_age_seconds(key) if isinstance(payload, dict) else 999999999.0
        # If the exact viewport tile is missing, use the tiny latest-good
        # first-paint cache so pill clicks can animate immediately while a better
        # visible-bbox tile warms.
        if not isinstance(payload, dict) and allow_first_paint:
            fp_key = self._scene_cache_first_paint_key(layer)
            fp = self._split_cache_peek(fp_key)
            fp_age = self._split_cache_age_seconds(fp_key) if isinstance(fp, dict) else 999999999.0
            if isinstance(fp, dict) and fp_age <= SCENE_CACHE_FIRST_PAINT_MAX_AGE_SECONDS:
                payload = fp
                key = fp_key
                age = fp_age
                mode = "first_paint_cache"
        if not isinstance(payload, dict):
            return None
        if max_age_sec > 0 and age > max_age_sec:
            return None
        out = dict(payload)
        out.setdefault("cache", {})["hit"] = True
        is_placeholder = self._scene_cache_layer_is_placeholder(layer, out)
        out["cache"].update({"mode": mode, "age_sec": age, "key": key, "first_paint": mode == "first_paint_cache", "placeholder": bool(is_placeholder)})
        if is_placeholder:
            # A cache-first shell is not a drawable cache hit. Keep it visible in
            # diagnostics, but do not let fast reads/reporting pretend polygons are ready.
            out["cache"]["hit"] = False
        return out

    def _scene_cache_write_layer(self, layer: str, bbox: dict[str, float], payload: dict[str, Any], visible_bbox: dict[str, float] | None = None, *, quality_rank: int = 50) -> dict[str, Any]:
        key = self._scene_cache_layer_key(layer, bbox, visible_bbox)
        existing = self._split_cache_peek(key)
        existing_quality = 0
        try:
            existing_quality = int((existing or {}).get("cache_quality", {}).get("quality_rank") or (existing or {}).get("quality_rank") or 0)
        except Exception:
            existing_quality = 0
        incoming_quality = int(quality_rank or 0)
        # Never let a low-detail/global refresh downgrade a sharper local/shore tile.
        if isinstance(existing, dict) and existing_quality > incoming_quality:
            out = dict(existing)
            out.setdefault("cache", {})["write_policy"] = "kept_existing_higher_quality"
            out["cache"].update({"existing_quality_rank": existing_quality, "incoming_quality_rank": incoming_quality, "key": key})
            return out
        incoming_renderable = self._scene_cache_layer_has_renderable_content(layer, payload if isinstance(payload, dict) else None)
        existing_renderable = self._scene_cache_layer_has_renderable_content(layer, existing if isinstance(existing, dict) else None)
        incoming_placeholder = self._scene_cache_layer_is_placeholder(layer, payload if isinstance(payload, dict) else None)
        if incoming_placeholder and not incoming_renderable and str(layer).lower() in {"bait", "boater", "boats", "boater_awareness", "shark-intel", "shark_intel", "sharkintel", "shark"}:
            # Ocean-backed layers must not promote points=0/provider-empty RTOFS rows as
            # latest-good scene cache. Return a diagnostic shell for this request only;
            # keep cache empty (or keep existing last-good below) until points/polygons exist.
            if not isinstance(existing, dict) or not existing_renderable:
                out = dict(payload or self._scene_cache_empty_layer(layer, bbox, "ocean_provider_warming_no_points"))
                out.setdefault("cache", {}).update({"hit": False, "write_policy": "rejected_empty_ocean_provider_not_promoted", "empty_write_rejected": True, "key": key})
                out["payload_state"] = out.get("payload_state") or "provider_empty_not_promoted"
                out["display_state"] = "waiting_for_first_ocean_points"
                return out
        if isinstance(existing, dict) and existing_renderable and not incoming_renderable:
            # Provider errors, empty RTOFS timeouts, and cache-first warming shells must
            # not erase a proven drawable scene-cache row. Preserve last-good until
            # a new drawable equal-or-better payload arrives.
            out = dict(existing)
            out.setdefault("cache", {})["write_policy"] = "kept_existing_renderable_over_empty"
            out["cache"].update({"incoming_quality_rank": incoming_quality, "key": key, "empty_write_rejected": True})
            return out
        now = self._now_ms()
        out = dict(payload or {})
        out.setdefault("ok", True)
        out.setdefault("bbox", bbox)
        out.setdefault("bbox_used", bbox)
        vis = self._normalize_bbox(visible_bbox or bbox)
        out.setdefault("visible_bbox", vis)
        out.setdefault("render_bbox", vis)
        out.setdefault("fetch_bbox", bbox)
        out.setdefault("bbox_contract", self._scene_cache_bbox_contract(bbox, vis, layer, role="scene-cache-layer-write"))
        version = self._scene_cache_payload_version(layer, out, incoming_quality)
        out["cache_quality"] = {
            "quality_rank": incoming_quality,
            "policy": "current_equal_or_better_replaces_lower_quality_never_downgrade_detail",
            "resolution_deg": self._scene_cache_resolution_deg(vis),
            "quantized_visible_bbox": self._scene_cache_quantize_bbox(vis),
            "updated_at": now,
            "version": version,
        }
        out["version"] = out.get("version") or version
        out.setdefault("cache", {})["hit"] = False
        out["cache"].update({"mode": "scene_cache_write", "key": key, "quality_rank": incoming_quality, "ts": now, "version": version})
        self._split_cache_set(key, out)
        if str(layer).strip().lower().replace("-", "_") in {"boater", "boats", "boater_awareness"}:
            try:
                self._promote_boater_scene_ocean_points_to_direct_cache(out, bbox, visible_bbox)
            except Exception as exc:
                try:
                    log.debug("scene-cache/boater ocean-points promotion skipped err=%s", exc)
                except Exception:
                    pass
        # Per-layer first paint: overwrite only with drawable equal-or-better payloads.
        # Never store a warming shell as first-paint, because that makes later fast
        # reads look like cache hits while drawing zero polygons.
        fp_key = self._scene_cache_first_paint_key(layer)
        try:
            fp_existing = self._split_cache_peek(fp_key)
            fp_q = int((fp_existing or {}).get("cache_quality", {}).get("quality_rank") or 0) if isinstance(fp_existing, dict) else 0
            if incoming_renderable and (incoming_quality >= fp_q or not isinstance(fp_existing, dict)):
                fp = dict(out)
                fp.setdefault("cache", {}).update({"mode": "first_paint_write", "key": fp_key, "source_scene_key": key, "ts": now, "version": version})
                self._split_cache_set(fp_key, fp)
        except Exception:
            pass
        return out

    def _scene_cache_quality_rank(self, layer: str, bbox: dict[str, float], visible_bbox: dict[str, float] | None = None) -> int:
        b = self._normalize_bbox(visible_bbox or bbox)
        span = max(abs(float(b.get("east", 0)) - float(b.get("west", 0))), abs(float(b.get("north", 0)) - float(b.get("south", 0))))
        layer = str(layer).replace('-', '_')
        if span <= 1.2:
            q = 95
        elif span <= 3.5:
            q = 85
        elif span <= 8.0:
            q = 70
        elif span <= 18.0:
            q = 55
        else:
            q = 35
        if layer in {"inland_water", "inland_waterways", "bait", "shark_intel", "shark-intel"} and span <= 8.0:
            q += 5
        return min(100, q)

    def _scene_cache_build_layer(self, layer: str, bbox: dict[str, float], visible_bbox: dict[str, float] | None = None) -> dict[str, Any]:
        layer_key = str(layer or '').strip().lower().replace('-', '_')
        if layer_key == "locations":
            payload = self.fish_payload()
            items = payload.get("items") if isinstance(payload, dict) else []
            if isinstance(payload, dict) and isinstance(items, list):
                payload = dict(payload)
                payload.setdefault("locations", items)
            return payload
        requested_bbox = self._normalize_bbox(bbox)
        visible_provider_bbox = self._normalize_bbox(visible_bbox or requested_bbox)
        weather_provider_bbox = requested_bbox
        provider_bbox = visible_provider_bbox
        if layer_key in {"clouds", "rain", "lightning", "jetstream", "inland_water_temp", "inland_temp"}:
            provider_bbox = weather_provider_bbox
        bbox_contract = self._scene_cache_bbox_contract(requested_bbox, visible_provider_bbox, layer_key, role="scene-cache-build-layer")

        ocean_legacy_layers = {"bait", "boater", "boats", "boater_awareness", "shark_intel", "shark-intel", "sharkintel", "shark", "ocean", "oceanpoints", "current", "currents"}
        if layer_key in ocean_legacy_layers:
            # Hard boundary: the scene-cache/legacy tile warmer may read RTOFS
            # cache bridges, but it must never execute legacy RTOFS/CoastWatch
            # child-bbox ocean provider work.  RTOFS/oceanPoints owns ocean;
            # bait marching squares and boater awareness are consumers.
            bridge_layer = "boater" if layer_key in {"boater", "boats", "boater_awareness"} else ("bait" if layer_key == "bait" else None)
            if bridge_layer:
                try:
                    bridged = self._scene_cache_rtofs_bridge_layer(bridge_layer, requested_bbox, visible_provider_bbox)
                    if isinstance(bridged, dict) and self._scene_cache_layer_has_renderable_content(bridge_layer, bridged):
                        bridged.setdefault("cache", {}).update({
                            "hit": False,
                            "mode": "rtofs_bridge_read_only_from_scene_cache_build",
                            "provider_fetch_allowed": False,
                            "legacy_scene_tile_ocean_blocked": True,
                        })
                        bridged.setdefault("bbox_contract", bbox_contract)
                        return bridged
                except Exception as exc:
                    shell = self._scene_cache_empty_layer(bridge_layer, requested_bbox, "rtofs_bridge_read_failed")
                    shell.setdefault("diagnostics", {})["rtofs_bridge_error"] = str(exc)
                    return shell
            shell = self._scene_cache_empty_layer(layer_key, requested_bbox, "rtofs_ocean_provider_owned_elsewhere")
            shell.setdefault("cache", {}).update({
                "provider_fetch_allowed": False,
                "legacy_scene_tile_ocean_blocked": True,
                "ttl_policy": "rtofs_ocean_not_scene_cache_child_bbox",
                "requested_tiles_total": 36,
                "scheduled_tiles": 0,
                "tiles_scheduled": 0,
            })
            shell.setdefault("bbox_contract", bbox_contract)
            return shell

        if layer_key == "clouds":
            # Clouds/rain may use the padded weather fetch bbox, but render/debug
            # still carries the exact visible_bbox so edge padding never leaks into
            # bait/boats/shoreline placement.
            out = self._cloud_tiles_payload_heavy(provider_bbox, visible_provider_bbox, force_live=GFS_CLOUDS_FORCE_LIVE_FETCH)
            if isinstance(out, dict):
                out.setdefault("bbox_contract", bbox_contract)
                out.setdefault("visible_bbox", visible_provider_bbox)
                out.setdefault("render_bbox", visible_provider_bbox)
                out.setdefault("fetch_bbox", provider_bbox)
            return out
        if layer_key == "rain":
            payload = self._cloud_tiles_payload_heavy(provider_bbox, visible_provider_bbox, force_live=GFS_CLOUDS_FORCE_LIVE_FETCH)
            if isinstance(payload, dict):
                out = dict(payload)
                out["source_layer"] = "rain_from_precip_only_scene_cache"
                out["cloud_items"] = 0
                out["items"] = []
                out["features"] = out.get("precip_columns") or out.get("features") or []
                out.setdefault("bbox_contract", bbox_contract)
                out.setdefault("visible_bbox", visible_provider_bbox)
                out.setdefault("render_bbox", visible_provider_bbox)
                out.setdefault("fetch_bbox", provider_bbox)
                return out
            return payload
        if layer_key == "lightning":
            return self.lightning_payload(bbox, visible_bbox, 20)
        if layer_key == "jetstream":
            # Jetstream balloons need real GFS u/v. Build from the visible viewport
            # in the background; do not use the huge tilted weather cache bbox.
            try:
                scene = self.get_scene_payload(provider_bbox)
                wind_items = []
                if isinstance(scene, dict):
                    wind_items = (((scene.get("scene") or {}).get("wind")) if isinstance(scene.get("scene"), dict) else []) or []
                jet_orbs = []
                for w in wind_items or []:
                    if not isinstance(w, dict):
                        continue
                    c = w.get("center") if isinstance(w.get("center"), dict) else {}
                    lat = safe_float(c.get("lat"), float("nan"))
                    lon = safe_float(c.get("lon"), float("nan"))
                    u = safe_float(w.get("vector_u"), 0.0)
                    v = safe_float(w.get("vector_v"), 0.0)
                    if not (math.isfinite(lat) and math.isfinite(lon) and -90.0 <= lat <= 90.0):
                        continue
                    mph = safe_float(w.get("speed_mps"), math.hypot(u, v)) * 2.23694
                    jet_orbs.append({
                        "lat": round(lat, 5),
                        "lon": round(self._wrap_lon(lon), 5),
                        "u": u,
                        "v": v,
                        "mph": round(mph, 2),
                        "direction_deg": safe_float(w.get("direction_deg"), ((math.atan2(u, v) * 180.0 / math.pi) + 360.0) % 360.0),
                        "altitude_m": 3048.0,
                        "source": "gfs_uv_direction_scene_cache",
                        "source_level": w.get("altitude_band") or w.get("source_level") or "gfs_uv",
                    })
                return {
                    "ok": True,
                    "status": "ok" if jet_orbs else "warming",
                    "payload_state": "live_or_cached_gfs_uv" if jet_orbs else "warming",
                    "source": "gfs_uv_direction_scene_cache",
                    "items": jet_orbs,
                    "jet_orbs": jet_orbs,
                    "count": len(jet_orbs),
                    "bbox": provider_bbox,
                    "bbox_used": provider_bbox,
                    "visible_bbox": visible_provider_bbox,
                    "render_bbox": visible_provider_bbox,
                    "fetch_bbox": provider_bbox,
                    "bbox_contract": bbox_contract,
                    "bbox_policy": "jetstream_spawns_in_visible_bbox_samples_padded_weather_fetch_bbox",
                    "jetstream": {
                        "ok": bool(wind_items),
                        "source": "gfs_uv_direction_scene_cache",
                        "count": len(wind_items),
                        "fallback_used": False,
                        "mock": False,
                        "proxy": False,
                    },
                }
            except Exception as exc:
                out = self._scene_cache_empty_layer(layer_key, bbox, "jetstream_gfs_uv_pending")
                out.update({"source": "gfs_uv_direction_scene_cache_error", "error": str(exc), "jet_orbs": [], "items": [], "jetstream": {"ok": False, "source": "gfs_uv_direction_pending", "count": 0}})
                return out
        if layer_key in {"boater", "boats", "boater_awareness"}:
            scene = self.build_scene_plan(provider_bbox, provider_bbox, layer="boats")
            ocean = self._ocean_payload_heavy(provider_bbox, provider_bbox)
            boats = ocean.get("boats", []) or [] if isinstance(ocean, dict) else []
            source = str((ocean or {}).get("source") or "")
            mode = str((ocean or {}).get("mode") or "")
            is_fallback = ("fallback" in source.lower()) or ("marker_ocean_solve" in source.lower()) or ("fallback" in mode.lower()) or ("proxy" in mode.lower())
            ocean_points = (ocean or {}).get("oceanPoints", {}).get("points") if isinstance((ocean or {}).get("oceanPoints"), dict) else None
            ocean_points = ocean_points or (ocean or {}).get("ocean_points") or (ocean or {}).get("points") or (ocean or {}).get("current_points") or []
            return {
                "ok": bool((ocean or {}).get("ok")),
                "source": (ocean or {}).get("source"),
                "mode": (ocean or {}).get("mode"),
                "engine": (ocean or {}).get("engine"),
                "bbox": (ocean or {}).get("bbox") or provider_bbox,
                "scene_plan": scene,
                "visible_bbox": provider_bbox,
                "fetch_bbox": provider_bbox,
                "render_budget": scene.get("render_budget"),
                "valid_time": (ocean or {}).get("valid_time") or (ocean or {}).get("resolved_time"),
                "validTime": (ocean or {}).get("valid_time") or (ocean or {}).get("resolved_time"),
                "sourceTime": (ocean or {}).get("valid_time") or (ocean or {}).get("resolved_time"),
                "boats": boats[:int(os.getenv("GFS_BOAT_COUNT_MAX", "10") or "10")],
                "points": ocean_points,
                "ocean_points": ocean_points,
                "oceanAnalysisPoints": {"ok": bool(ocean_points), "source": "rtofs_provider_ocean_analysis_points_embedded_in_boater_scene_cache", "points": ocean_points, "count": len(ocean_points), "contract": "large_finite_sst_current_data_field_not_visual_boat_count"},
                "ocean_analysis_point_count": len(ocean_points),
                "oceanPoints": {"ok": bool(ocean_points), "source": "rtofs_provider_ocean_points_embedded_in_boater_scene_cache", "points": ocean_points, "count": len(ocean_points), "contract": "finite_sst_current_points_are_boat_squares_and_sea_mask"},
                "ocean_point_count": len(ocean_points),
                "current_points": ocean_points,
                "current_zone_points_count": len(ocean_points),
                "current_zone_grid": (ocean or {}).get("current_zone_grid"),
                "count": min(len(boats), int(os.getenv("GFS_BOAT_COUNT_MAX", "10") or "10")),
                "renderable_count_hint": (min(len(boats), int(os.getenv("GFS_BOAT_COUNT_MAX", "10") or "10")) if (not is_fallback and len(ocean_points) >= int(os.getenv("GFS_BOATER_MIN_OCEAN_POINTS", "48") or "48")) else 0),
                "fallback_rejected_count_hint": len(boats) if is_fallback else 0,
                "render_contract": "glb_boats_require_live_rtofs_provider_sst_current_samples_and_ocean_points",
                "min_ocean_points_to_render": int(os.getenv("GFS_BOATER_MIN_OCEAN_POINTS", "48") or "96"),
                "rejection_counts": (((ocean or {}).get("grid") or {}).get("rejection_counts") or {}),
                "grid": (ocean or {}).get("grid"),
                "swell_components": (ocean or {}).get("swell_components", []),
                "source_meta": (ocean or {}).get("source_meta") or {},
                "sst_landmask": (((ocean or {}).get("source_meta") or {}).get("sst_landmask") or {}),
                "landmask_contract": (((ocean or {}).get("source_meta") or {}).get("landmask_contract") or "finite_sst_is_shared_water_gate_for_boater"),
                "diagnostics": (ocean or {}).get("diagnostics"),
                "cache": (ocean or {}).get("cache"),
                "quality_policy": (ocean or {}).get("quality_policy") or self._live_payload_policy(),
                "payload_state": (ocean or {}).get("payload_state") or ("live" if not is_fallback and boats else "provider_empty"),
                "fallback": (ocean or {}).get("fallback") or {"used": bool(is_fallback)},
                "bbox_contract": bbox_contract,
                "bbox_policy": "boats_current_use_visible_bbox_not_padded_weather_bbox",
                "ts": self._now_ms(),
            }
        if layer_key == "bait":
            scene = self.build_scene_plan(provider_bbox, provider_bbox, layer="bait")
            qb = self._quantize_bait_bbox(scene.get("fetch_bbox") or provider_bbox)
            boater_bridge = self._find_boater_scene_cache_ocean_points(provider_bbox, provider_bbox)
            out = self._bait_advanced_payload_heavy(qb, scene.get("visible_bbox"))
            if isinstance(out, dict):
                out = self._attach_boater_bridge_to_ocean_consumer_payload(out, boater_bridge, role="bait")
                out.setdefault("bbox_contract", bbox_contract)
                out.setdefault("bbox_policy", "bait_uses_visible_bbox_not_padded_weather_bbox")
                out.setdefault("visible_bbox", visible_provider_bbox)
                out.setdefault("render_bbox", visible_provider_bbox)
            return out
        if layer_key in {"shark_intel", "shark-intel", "sharkintel", "shark"}:
            ocean_mask_payload = None
            boater_bridge = self._find_boater_scene_cache_ocean_points(provider_bbox, provider_bbox)
            try:
                scene = self.build_scene_plan(provider_bbox, provider_bbox, layer="shark-intel")
                if isinstance(boater_bridge, dict) and boater_bridge.get("ok") and boater_bridge.get("points"):
                    ocean_mask_payload = self._ocean_points_payload_from_boater_bridge(boater_bridge, provider_bbox, "auto", scene.get("visible_bbox") or provider_bbox)
                else:
                    ocean_mask_payload = self._ocean_points_payload_heavy(provider_bbox, "auto", scene.get("visible_bbox") or provider_bbox)
            except Exception as exc:
                ocean_mask_payload = {"ok": False, "source": "shark_intel_ocean_mask_fetch_failed", "error": str(exc), "points": []}
            out = shark_intel_payload(provider_bbox, provider_bbox, ocean_payload=ocean_mask_payload)
            if isinstance(out, dict):
                out = self._attach_boater_bridge_to_ocean_consumer_payload(out, boater_bridge, role="shark-intel")
                out.setdefault("bbox_contract", bbox_contract)
                out.setdefault("bbox_policy", "shark_intel_uses_visible_bbox_not_padded_weather_bbox")
            try:
                out["ocean_mask_source"] = {
                    "source": (ocean_mask_payload or {}).get("source"),
                    "ok": bool((ocean_mask_payload or {}).get("ok")),
                    "points": len((ocean_mask_payload or {}).get("points") or []),
                    "mask": (ocean_mask_payload or {}).get("mask"),
                    "grid": (ocean_mask_payload or {}).get("grid"),
                    "boater_bridge_used": bool(isinstance(boater_bridge, dict) and boater_bridge.get("ok") and boater_bridge.get("points")),
                }
            except Exception:
                pass
            return out
        if layer_key in {"inland_water", "inland_waterways"}:
            try:
                from server.gfs.viewport36 import lod_for_bbox
                _tier = str(lod_for_bbox(self._normalize_bbox(visible_bbox or bbox)) or "global").lower()
                _tier = "local" if _tier == "local" else "global"
            except Exception:
                _tier = "global"
            return self.inland_water_tiles_payload(bbox, 96, visible_bbox, source="auto", geometry="vector", lod=("auto" if _tier == "local" else "overview"), scene_tier=_tier)
        if layer_key in {"inland_water_temp", "inland_temp"}:
            return self.inland_water_temp_payload(bbox, visible_bbox)
        return self._scene_cache_empty_layer(layer_key, bbox, "unknown_layer")

    def _scene_cache_schedule_layer_refresh(self, layer: str, bbox: dict[str, float], visible_bbox: dict[str, float] | None = None, *, explicit_visible_bbox: bool | None = None) -> bool:
        canonical = str(layer or "").strip().lower().replace("_", "-")
        ocean_heavy = canonical in {"bait", "boater", "boats", "shark-intel", "ocean", "oceanpoints", "current", "currents"}
        if ocean_heavy and explicit_visible_bbox is False:
            try:
                log.info(
                    "scene-cache/ocean-refresh-skipped layer=%s policy=explicit_visible_bbox_required requested_tiles_total=36 scheduled_tiles=0",
                    canonical,
                )
            except Exception:
                pass
            return False
        try:
            scene_plan = self.build_scene_plan(bbox, visible_bbox, layer=f"scene-cache-refresh-{canonical}")
            scene_tier = str(scene_plan.get("tier") or "global").lower()
            if scene_tier == "world":
                scene_tier = "global"
        except Exception:
            scene_plan = {}
            scene_tier = "global"
        if False and ocean_heavy and scene_tier in {"world", "global"}:
            try:
                log.info(
                    "scene-cache/ocean-refresh-skipped layer=%s scene_tier=%s policy=world_cache_only_no_empty_live_repair requested_tiles_total=0 scheduled_tiles=0",
                    canonical, scene_tier,
                )
            except Exception:
                pass
            return False
        key = self._scene_cache_layer_key(layer, bbox, visible_bbox)
        q = self._scene_cache_quality_rank(layer, bbox, visible_bbox)
        def _builder():
            payload = self._scene_cache_build_layer(layer, bbox, visible_bbox)
            return self._scene_cache_write_layer(layer, bbox, payload, visible_bbox, quality_rank=q)
        return self._schedule_split_warm(key, "scene-cache-%s" % layer, _builder)



    def _scene_cache_rtofs_bridge_layer(self, layer: str, bbox: dict[str, float], visible_bbox: dict[str, float] | None = None) -> dict[str, Any] | None:
        """Cache-only RTOFS bridge for scene-frame/scene-cache boater + bait.

        This method is intentionally request-safe: it reads the lightweight
        .cache/rtofs/samples JSON written by scripts/warm_rtofs_surface_cache.py.
        It never opens NOAA/NOMADS NetCDF and never starts an xarray remote open.
        On every viewport move it can cheaply filter/reshape the cached points
        to the requested bbox so scene-frame does not stay stuck at
        scene_cache_empty_boater / scene_cache_empty_bait.
        """
        canonical = str(layer or "").strip().lower().replace("_", "-")
        if canonical not in {"boater", "boats", "boater-awareness", "bait"}:
            return None
        try:
            b = self._normalize_bbox(bbox)
            vis = self._normalize_bbox(visible_bbox or b)
            ocean = self._rtofs_cached_current_payload(b, "auto", vis, role=f"scene_cache_{canonical}_bridge")
            points = (ocean or {}).get("points") or (ocean or {}).get("current_points") or (ocean or {}).get("ocean_points") or []
            if not points:
                return None
            if canonical in {"boater", "boats", "boater-awareness"}:
                out = dict(ocean)
                out.update({
                    "ok": True,
                    "source": "ncep_nomads_rtofs_cached_surface_scene_boater_bridge",
                    "payload_state": "ready",
                    "status": "ok",
                    "mode": "scene_frame_cache_empty_fell_through_to_rtofs_json",
                    "bbox": b,
                    "bbox_used": b,
                    "visible_bbox": vis,
                    "render_bbox": vis,
                    "fetch_bbox": b,
                    "scene_frame_bridge": True,
                    "bridge_contract": "scene_frame_boater_consumes_warmed_rtofs_json_on_each_viewport_request",
                    "render_contract": "rtofs_cached_current_points_spawn_glb_boats_and_boater_analysis",
                    "count": len((ocean or {}).get("boats") or []),
                    "ocean_point_count": len(points),
                    "ocean_analysis_point_count": len(points),
                })
                out.setdefault("cache", {}).update({"hit": False, "mode": "rtofs_scene_bridge_cache_only", "rtofs_json_bridge": True})
                return out

            # Bait bridge: convert the cached RTOFS points to a compact gridded
            # ocean bundle, then run the existing server-side bait/marching-square
            # solver.  This makes scene-frame return real bait.polygons instead
            # of just point rows when RTOFS scene-cache is empty.
            try:
                from server.gfs.derive.bait import derive_bait_payload
            except Exception as exc:
                return {
                    "ok": False,
                    "source": "ncep_nomads_rtofs_cached_surface_bait_bridge_import_failed",
                    "payload_state": "rtofs_bait_bridge_import_failed",
                    "status": "waiting_for_solver",
                    "error": str(exc),
                    "points": points,
                    "count": len(points),
                }

            grid = self._rtofs_points_to_bait_ocean_grid(points, b)
            if not grid.get("sst") or not grid.get("current_u") or not grid.get("current_v"):
                return None
            solved = derive_bait_payload({}, grid, {}, bbox=[b["west"], b["south"], b["east"], b["north"]])
            bait = dict(solved.get("bait") or {})
            polygons = list(bait.get("inner_polygons") or bait.get("polygons") or [])
            outer = list(bait.get("outer_polygons") or [])
            core = list(bait.get("core_polygons") or [])
            polygon_rows = polygons or outer or core
            bait.update({
                "source": "full_stack",
                "live_source": "ncep_nomads_rtofs_cached_surface_scene_bait_bridge",
                "provider_source": "ncep_nomads_rtofs_cached_surface",
                "status": "ready" if polygon_rows else "warming",
                "polygons": polygons,
                "outer_polygons": outer,
                "inner_polygons": polygons,
                "core_polygons": core,
            })
            bait.setdefault("meta", {}).update({
                "input_ocean": "warmed RTOFS cached SST/current JSON",
                "scene_frame_bridge": True,
                "rtofs_point_count": len(points),
                "rtofs_grid_shape": grid.get("grid_shape"),
                "contour_contract": "server_marching_square_polygons_from_warmed_rtofs_cache",
            })
            out = dict(solved)
            out.update({
                "ok": bool(polygon_rows),
                "source": "ncep_nomads_rtofs_cached_surface_scene_bait_bridge",
                "mode": "scene_frame_cache_empty_fell_through_to_rtofs_json_marching_squares",
                "schema": "rtofs_scene_bait_bridge_v1",
                "payload_state": "ready" if polygon_rows else "warming",
                "status": "ok" if polygon_rows else "warming",
                "bbox": b,
                "bbox_used": b,
                "visible_bbox": vis,
                "render_bbox": vis,
                "fetch_bbox": b,
                "bait": bait,
                "polygons": polygon_rows,
                "zones": polygon_rows,
                "polygon_count": len(polygon_rows),
                "count": len(polygon_rows),
                "points": points,
                "ocean_points": points,
                "oceanPoints": {"ok": True, "source": "ncep_nomads_rtofs_cached_surface_scene_bait_bridge", "points": points, "count": len(points)},
                "advanced_bait_rows": solved.get("advanced_bait_rows") or solved.get("bait_score") or [],
                "advancedBaitRows": solved.get("advanced_bait_rows") or solved.get("bait_score") or [],
                "bait_score": solved.get("bait_score") or [],
                "scene_frame_bridge": True,
                "bridge_contract": "scene_frame_bait_consumes_warmed_rtofs_json_and_runs_server_marching_squares",
                "grid": {"real_grid": True, "source": "rtofs_cached_json_gridded_for_bait", **{k: v for k, v in grid.items() if k in {"grid_shape", "lat_values", "lon_values"}}},
                "cache": (ocean or {}).get("cache") or {"hit": True, "mode": "rtofs_scene_bridge_cache_only"},
                "diagnostics": {"rtofs_bridge": True, "rtofs_point_count": len(points), "grid_shape": grid.get("grid_shape"), "polygon_count": len(polygon_rows)},
            })
            out.setdefault("cache", {}).update({"hit": False, "mode": "rtofs_scene_bridge_cache_only", "rtofs_json_bridge": True})
            return out
        except Exception as exc:
            return {"ok": False, "source": "ncep_nomads_rtofs_cached_surface_scene_bridge_exception", "payload_state": "rtofs_scene_bridge_exception", "status": "waiting_for_rtofs_cache", "error": str(exc), "points": [], "count": 0}

    def _rtofs_points_to_bait_ocean_grid(self, points: list[dict[str, Any]], bbox: dict[str, float]) -> dict[str, Any]:
        """Turn sampled RTOFS point rows into the grid expected by derive_bait_payload."""
        finite: list[dict[str, float]] = []
        west, south, east, north = float(bbox["west"]), float(bbox["south"]), float(bbox["east"]), float(bbox["north"])
        for p in points or []:
            try:
                lat = float(p.get("lat"))
                lon = self._lon_pm180(float(p.get("lon", p.get("lng"))))
                sst = float(p.get("sst_c", p.get("temp_c", p.get("water_temp_c"))))
                u = float(p.get("u_ms", p.get("u", p.get("current_u", 0.0))))
                v = float(p.get("v_ms", p.get("v", p.get("current_v", 0.0))))
            except Exception:
                continue
            if not (math.isfinite(lat) and math.isfinite(lon) and math.isfinite(sst) and math.isfinite(u) and math.isfinite(v)):
                continue
            lon_ok = (west <= lon <= east) if west <= east else (lon >= west or lon <= east)
            if south <= lat <= north and lon_ok:
                finite.append({"lat": lat, "lon": lon, "sst": sst, "u": u, "v": v})
        if not finite:
            return {"sst": [], "current_u": [], "current_v": [], "ocean_mask": [], "grid_shape": [0, 0]}
        # Quantize enough to recover the regular sampled RTOFS lattice while
        # tolerating small floating-point jitter from curvilinear coordinates.
        lat_values = sorted({round(p["lat"], 4) for p in finite})
        lon_values = sorted({round(p["lon"], 4) for p in finite})
        # Avoid pathological curvilinear uniqueness by falling back to a bounded
        # regular bin grid if too many unique values are present.
        if len(lat_values) * len(lon_values) > max(40000, len(finite) * 8):
            ny = max(12, min(120, int(math.sqrt(len(finite)))))
            nx = max(12, min(160, int(math.ceil(len(finite) / max(1, ny)))))
            lat_values = [round(south + (north - south) * i / max(1, ny - 1), 4) for i in range(ny)]
            lon_values = [round(west + (east - west) * j / max(1, nx - 1), 4) for j in range(nx)]
        ny, nx = len(lat_values), len(lon_values)
        lat_index = {v: i for i, v in enumerate(lat_values)}
        lon_index = {v: j for j, v in enumerate(lon_values)}
        sst = [[float("nan") for _ in range(nx)] for __ in range(ny)]
        ug = [[float("nan") for _ in range(nx)] for __ in range(ny)]
        vg = [[float("nan") for _ in range(nx)] for __ in range(ny)]
        mask = [[False for _ in range(nx)] for __ in range(ny)]
        for p in finite:
            la = round(p["lat"], 4)
            lo = round(p["lon"], 4)
            if la not in lat_index:
                la = min(lat_values, key=lambda x: abs(x - p["lat"]))
            if lo not in lon_index:
                lo = min(lon_values, key=lambda x: abs(x - p["lon"]))
            i, j = lat_index[la], lon_index[lo]
            sst[i][j] = p["sst"]
            ug[i][j] = p["u"]
            vg[i][j] = p["v"]
            mask[i][j] = True
        return {
            "sst": sst,
            "current_u": ug,
            "current_v": vg,
            "ocean_mask": mask,
            "lat_values": lat_values,
            "lon_values": lon_values,
            "grid_shape": [ny, nx],
            "source_meta": {"provider": "rtofs", "ocean_source": "ncep_nomads_rtofs_cached_surface", "real_subset": True, "has_sst": True, "has_current": True},
        }

    def scene_cache_fast_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, layers: list[str] | tuple[str, ...] | None = None, *, mode: str = "fast", scene_tier: str | None = None) -> dict[str, Any]:
        """Strict cache-only boot/read path.

        This must never call live providers, never schedule builds, and never run
        janitor work.  It exists so the browser can draw the last-good scene
        immediately while slower refresh workers update cache for later runs.
        """
        bbox_norm = self._normalize_bbox(bbox)
        visible_norm = self._normalize_bbox(visible_bbox or bbox_norm)
        wanted = [str(x).strip() for x in (layers or []) if str(x).strip()] or list(LIVE_SCENE_CACHE_DEFAULT_LAYERS)
        now = self._now_ms()
        out_layers: dict[str, Any] = {}
        meta_layers: dict[str, Any] = {}
        for raw in wanted:
            layer = str(raw).strip().lower()
            canonical = "boater" if layer in {"boats", "boater_awareness"} else ("inland-water" if layer in {"inland_water", "inland_waterways"} else ("shark-intel" if layer in {"shark_intel", "sharkintel", "shark"} else layer))
            cached = self._scene_cache_peek_layer(canonical, bbox_norm, visible_norm, max_age_sec=SCENE_CACHE_MAX_AGE_SECONDS, allow_first_paint=True)
            if cached is None:
                # Static shoreline layers are allowed to do an immediate local-only
                # build on fast/global boot. This does not hit NOAA/ArcGIS/live
                # providers; it reads local runtime tiles or the baked one-lake-
                # per-tile boot overview so the globe does not start blank.
                if canonical == "inland-water":
                    try:
                        cached = self.inland_water_tiles_payload(visible_norm, 96, visible_norm, source="auto", geometry="vector", lod="overview", scene_tier=(scene_tier or "global"))
                        cached.setdefault("cache", {}).update({"hit": False, "mode": "fast_static_local_boot_build", "fast": True, "refresh_scheduled": False})
                    except Exception:
                        cached = None
                elif canonical in {"inland_water_temp", "inland-temp", "inland_temp"}:
                    try:
                        cached = self.inland_water_temp_payload(visible_norm, visible_norm, scene_tier=(scene_tier or "global"))
                        cached.setdefault("cache", {}).update({"hit": False, "mode": "fast_static_temp_boot_build", "fast": True, "refresh_scheduled": False})
                    except Exception:
                        cached = None
                if cached is None:
                    cached = self._scene_cache_empty_layer(canonical, bbox_norm, "fast_cache_miss_no_live_fetch")
                    cached.setdefault("cache", {}).update({"hit": False, "mode": "fast_cache_miss_no_live_fetch", "fast": True, "refresh_scheduled": False})
            else:
                cached.setdefault("cache", {}).update({"fast": True, "refresh_scheduled": False})
            if canonical in {"boater", "bait"} and self._scene_cache_layer_is_placeholder(canonical, cached):
                try:
                    bridged = self._scene_cache_rtofs_bridge_layer(canonical, bbox_norm, visible_norm)
                    if isinstance(bridged, dict) and self._scene_cache_layer_has_renderable_content(canonical, bridged):
                        bridged.setdefault("cache", {}).update({"hit": False, "mode": "fast_rtofs_scene_bridge", "fast": True, "refresh_scheduled": False})
                        cached = bridged
                except Exception as exc:
                    cached.setdefault("diagnostics", {})["rtofs_scene_bridge_error"] = str(exc)
            if canonical in STATIC_SCENE_CACHE_LAYERS:
                cached.setdefault("cache", {})["ttl_policy"] = "static_no_2min_reload"
            out_layers[canonical] = cached
            meta_layers[canonical] = {
                "subscribed": True,
                "cache_hit": bool(cached.get("cache", {}).get("hit")),
                "cache_mode": cached.get("cache", {}).get("mode"),
                "age_sec": cached.get("cache", {}).get("age_sec"),
                "refresh_scheduled": False,
                "quality": cached.get("cache_quality") or {"quality_rank": self._scene_cache_quality_rank(canonical, bbox_norm, visible_norm)},
                "ttl_policy": cached.get("cache", {}).get("ttl_policy") or ("static_no_2min_reload" if canonical in STATIC_SCENE_CACHE_LAYERS else "live_background_refresh_when_stale"),
                "status": cached.get("status") or cached.get("payload_state") or "ok",
                "source": cached.get("source"),
            }
        return {
            "ok": True,
            "schema": "lftr_scene_cache_subscription_v1",
            "source": "shared_scene_cache_subscription_spine_fast_cache_only",
            "policy": "boot_reads_last_good_cache_only_live_downloads_progressively_update_next_run_cache",
            "refresh_interval_ms": SCENE_CACHE_REFRESH_INTERVAL_MS,
            "bbox": bbox_norm,
            "visible_bbox": visible_norm,
            "render_bbox": visible_norm,
            "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, role="scene-cache-fast-read"),
            "layers": out_layers,
            "cache": {
                "layers": meta_layers,
                "ts": now,
                "mode": mode,
                "read_only": True,
                "fast": True,
                "no_live_fetch": True,
                "no_build": True,
                "no_janitor": True,
                "ttl_policy": "2min_is_background_ttl_heartbeat_not_visible_cache_reload",
                "static_layers": sorted(STATIC_SCENE_CACHE_LAYERS),
                "first_paint_policy": "draw_last_good_cache_immediately_then_background_refresh_updates_changed_versions",
            },
            "ts": now,
        }

    def scene_cache_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, layers: list[str] | tuple[str, ...] | None = None, *, refresh: bool = True, mode: str = "read") -> dict[str, Any]:
        bbox_norm = self._normalize_bbox(bbox)
        explicit_visible_bbox = visible_bbox is not None
        visible_norm = self._normalize_bbox(visible_bbox or bbox_norm)
        wanted = [str(x).strip() for x in (layers or []) if str(x).strip()]
        if not wanted:
            wanted = list(BOOT_SCENE_CACHE_DEFAULT_LAYERS)
        mode = str(mode or "read").lower()
        read_only = mode in {"read", "first_paint", "fast", "cache"}
        janitor = self._split_scene_cache_janitor_locked(reason="scene_cache_payload")
        now = self._now_ms()
        out_layers: dict[str, Any] = {}
        meta_layers: dict[str, Any] = {}
        for raw in wanted:
            layer = str(raw).strip().lower()
            canonical = "boater" if layer in {"boats", "boater_awareness"} else ("inland-water" if layer in {"inland_water", "inland_waterways"} else ("shark-intel" if layer in {"shark_intel", "sharkintel", "shark"} else layer))
            cached = self._scene_cache_peek_layer(canonical, bbox_norm, visible_norm, max_age_sec=SCENE_CACHE_MAX_AGE_SECONDS, allow_first_paint=True)
            if cached is None:
                if canonical == "locations":
                    cached = self._scene_cache_build_layer(canonical, bbox_norm, visible_norm)
                    cached = self._scene_cache_write_layer(canonical, bbox_norm, cached, visible_norm, quality_rank=100)
                else:
                    cached = self._scene_cache_empty_layer(canonical, bbox_norm, "queued_background_warm")
            if canonical in {"boater", "bait"} and self._scene_cache_layer_is_placeholder(canonical, cached):
                try:
                    bridged = self._scene_cache_rtofs_bridge_layer(canonical, bbox_norm, visible_norm)
                    if isinstance(bridged, dict) and self._scene_cache_layer_has_renderable_content(canonical, bridged):
                        bridged.setdefault("cache", {}).update({"hit": False, "mode": "read_rtofs_scene_bridge", "refresh_scheduled": False})
                        cached = bridged
                except Exception as exc:
                    cached.setdefault("diagnostics", {})["rtofs_scene_bridge_error"] = str(exc)
            scheduled = False
            age = cached.get("cache", {}).get("age_sec") if isinstance(cached, dict) else None
            static_layer = canonical in STATIC_SCENE_CACHE_LAYERS
            # Static layers do not reload on the 2-minute TTL loop. They only warm
            # when missing/cold or when explicitly requested on boot/toggle. Live
            # companion sublayers, such as inland_water_temp, keep the TTL policy.
            empty_placeholder = self._scene_cache_layer_is_placeholder(canonical, cached)
            ocean_heavy = canonical in {"bait", "boater", "boats", "shark-intel", "ocean", "oceanpoints", "current", "currents"}
            try:
                scene_plan_for_refresh = self.build_scene_plan(bbox_norm, visible_norm, layer=f"scene-cache-payload-{canonical}")
                scene_tier_for_refresh = str(scene_plan_for_refresh.get("tier") or "global").lower()
            except Exception:
                scene_plan_for_refresh = {}
                scene_tier_for_refresh = "global"
            world_ocean_cache_only = False  # fixed-36 architecture allows controlled ocean tile warm at every LOD
            if (not read_only) and refresh and world_ocean_cache_only:
                scheduled = False
                cached.setdefault("cache", {}).update({
                    "refresh_scheduled": False,
                    "skipped_by_tier_policy": True,
                    "skipped_tier_policy": True,
                    "ttl_policy": "fixed_36_tiles_all_lods_ocean_refresh_allowed",
                    "requested_tiles_total": 0,
                    "scheduled_tiles": 0,
                    "tiles_scheduled": 0,
                    "remaining_tiles": 0,
                })
                if empty_placeholder:
                    cached.setdefault("cache", {})["empty_placeholder_refresh"] = False
            elif ocean_heavy and not explicit_visible_bbox and (not read_only) and refresh:
                # Critical: old 24x24 / scene-child callers often arrive here with
                # bbox only, so visible_bbox silently equals the child bbox.  Do not
                # let those implicit/legacy requests wake the fixed-36 ocean provider.
                # Ocean is refreshed only by an explicit camera visible_bbox refresh.
                scheduled = False
                cached.setdefault("cache", {}).update({
                    "refresh_scheduled": False,
                    "provider_fetch_allowed": False,
                    "skipped_implicit_ocean_refresh_no_visible_bbox": True,
                    "ttl_policy": "explicit_visible_bbox_required_for_ocean_provider",
                    "requested_tiles_total": 36,
                    "scheduled_tiles": 0,
                    "tiles_scheduled": 0,
                    "remaining_tiles": 36,
                })
            elif (not read_only) and refresh and (empty_placeholder or cached.get("payload_state") == "warming" or age is None or ((not static_layer) and float(age or 999999) > SCENE_CACHE_STALE_SECONDS)):
                scheduled = self._scene_cache_schedule_layer_refresh(canonical, bbox_norm, visible_norm, explicit_visible_bbox=explicit_visible_bbox)
                cached.setdefault("cache", {})["refresh_scheduled"] = scheduled
                if empty_placeholder:
                    cached.setdefault("cache", {})["empty_placeholder_refresh"] = scheduled
            if static_layer:
                cached.setdefault("cache", {})["ttl_policy"] = "static_no_2min_reload"
            out_layers[canonical] = cached
            meta_layers[canonical] = {
                "subscribed": True,
                "cache_hit": bool(cached.get("cache", {}).get("hit")),
                "cache_mode": cached.get("cache", {}).get("mode"),
                "age_sec": cached.get("cache", {}).get("age_sec"),
                "refresh_scheduled": bool(cached.get("cache", {}).get("refresh_scheduled", scheduled)),
                "quality": cached.get("cache_quality") or {"quality_rank": self._scene_cache_quality_rank(canonical, bbox_norm, visible_norm)},
                "ttl_policy": cached.get("cache", {}).get("ttl_policy") or ("static_no_2min_reload" if canonical in STATIC_SCENE_CACHE_LAYERS else "live_2min_refresh_when_stale"),
                "status": cached.get("status") or cached.get("payload_state") or "ok",
                "source": cached.get("source"),
            }
        return {
            "ok": True,
            "schema": "lftr_scene_cache_subscription_v1",
            "source": "shared_scene_cache_subscription_spine",
            "policy": "live_data_feeds_cache_cache_feeds_globe_pills_control_subscription_and_visibility",
            "refresh_interval_ms": SCENE_CACHE_REFRESH_INTERVAL_MS,
            "bbox": bbox_norm,
            "visible_bbox": visible_norm,
            "render_bbox": visible_norm,
            "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, role="scene-cache-read"),
            "layers": out_layers,
            "cache": {
                "layers": meta_layers,
                "ts": now,
                "janitor": janitor,
                "mode": mode,
                "read_only": read_only,
                "scheme": "one_main_scene_cache_call_resolves_quantized_layer_tiles",
                "ttl_policy": "2min_live_layers_only_static_layers_local_or_cache_until_missing",
                "static_layers": sorted(STATIC_SCENE_CACHE_LAYERS),
                "lod_policy": "two_level_global_local_weather_stable_ocean_inland_detail_only",
                "highest_quality_policy": "current_equal_or_better_replaces_lower_quality_never_downgrade_detail",
                "first_paint_policy": "pill_click_reads_latest_good_layer_cache_immediately_live_refresh_runs_background",
                "visible_priority_policy": "one_camera_aware_viewport_bbox_fixed_36_tiles_center_first",
            },
            "ts": now,
        }

    def scene_cache_refresh_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, layers: list[str] | tuple[str, ...] | None = None, reason: str = "browser_2min_subscription_refresh") -> dict[str, Any]:
        bbox_norm = self._normalize_bbox(bbox)
        explicit_visible_bbox = visible_bbox is not None
        visible_norm = self._normalize_bbox(visible_bbox or bbox_norm)
        wanted = [str(x).strip() for x in (layers or []) if str(x).strip()] or list(LIVE_SCENE_CACHE_DEFAULT_LAYERS)

        def _canon_refresh_layer(name: str) -> str:
            layer = str(name or "").strip().lower()
            return "boater" if layer in {"boats", "boater_awareness"} else ("inland-water" if layer in {"inland_water", "inland_waterways"} else ("shark-intel" if layer in {"shark_intel", "sharkintel", "shark"} else layer))

        canonical_wanted = [_canon_refresh_layer(x) for x in wanted]
        # Ocean bundle ownership: when boater is part of the same refresh request,
        # let boater/RTOFS fill the shared ocean points once.  Bait and shark-intel
        # should not each wake separate RTOFS paths in the same refresh tick; they
        # will consume the boater oceanAnalysisPoints bridge on the next cache read.
        ocean_dependents: set[str] = set()
        if "boater" in canonical_wanted:
            ocean_dependents = {x for x in canonical_wanted if x in {"bait", "shark-intel", "ocean", "oceanpoints", "current", "currents"}}
        jobs = {}
        reason_lc = str(reason or "").lower()
        movement = any(tok in reason_lc for tok in ("camera_move", "cache_pop", "viewport"))
        force_empty_repair = ("empty_placeholder_repair" in reason_lc) or ("force=1" in reason_lc) or ("force_refresh" in reason_lc)
        for layer in wanted:
            canonical = _canon_refresh_layer(layer)
            if canonical in ocean_dependents:
                jobs[canonical] = {
                    "scheduled": False,
                    "ttl_policy": "ocean_bundle_dependency",
                    "dependency": "boater",
                    "provider_fetch_allowed": False,
                    "note": "boater owns this refresh tick's RTOFS ocean bundle; dependent ocean layers read boater_oceanAnalysisPoints bridge instead of waking duplicate RTOFS",
                    "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, canonical, role="scene-cache-refresh-job"),
                }
                continue
            if canonical in STATIC_SCENE_CACHE_LAYERS:
                jobs[canonical] = {"scheduled": False, "ttl_policy": "static_no_2min_reload", "note": "static layer is served from existing cache/local data and is not refreshed by the live refresh loop"}
                continue

            scene_plan = self.build_scene_plan(bbox_norm, visible_norm, layer=f"scene-cache-refresh-{canonical}")
            scene_tier = str(scene_plan.get("tier") or "global").lower()
            if scene_tier == "world":
                scene_tier = "global"
            tile_budget = scene_plan.get("tile_budget") if isinstance(scene_plan.get("tile_budget"), dict) else {}
            ocean_heavy = canonical in {"bait", "boater", "boats", "shark-intel", "ocean", "oceanpoints", "current", "currents"}
            if ocean_heavy:
                try:
                    vw = abs(float(visible_norm.get("east")) - float(visible_norm.get("west")))
                    vh = abs(float(visible_norm.get("north")) - float(visible_norm.get("south")))
                except Exception:
                    vw = vh = 999.0
                oversized_implicit = (vw > 20.0 or vh > 15.0) and not explicit_visible_bbox
                if (not explicit_visible_bbox) or oversized_implicit:
                    jobs[canonical] = {
                        "scheduled": False,
                        "ttl_policy": "explicit_visible_bbox_required_for_ocean_provider",
                        "provider_fetch_allowed": False,
                        "skipped_implicit_ocean_refresh_no_visible_bbox": not explicit_visible_bbox,
                        "skipped_oversized_implicit_ocean_refresh": oversized_implicit,
                        "note": "legacy scene/24x24/global bbox request cannot wake ocean provider; use explicit visible_bbox once for the active camera viewport",
                        "scene_tier": scene_tier,
                        "tile_budget": tile_budget,
                        "requested_tiles_total": 36,
                        "scheduled_tiles": 0,
                        "tiles_scheduled": 0,
                        "skipped_tiles_budget": 36,
                        "remaining_tiles": 36,
                        "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, canonical, role="scene-cache-refresh-job"),
                    }
                    try:
                        log.info(
                            "scene-cache/ocean-refresh-skipped layer=%s policy=explicit_visible_bbox_required bbox=%s visible_bbox=%s requested_tiles_total=36 scheduled_tiles=0",
                            canonical, bbox_norm, visible_norm,
                        )
                    except Exception:
                        pass
                    continue
            if False and scene_tier in {"world", "global"} and ocean_heavy:
                jobs[canonical] = {
                    "scheduled": False,
                    "ttl_policy": "fixed_36_tiles_all_lods_ocean_refresh_allowed",
                    "fresh_enough": False,
                    "empty_placeholder": True,
                    "skipped_by_tier_policy": True,
                    "skipped_tier_policy": True,
                    "scene_tier": scene_tier,
                    "tile_budget": tile_budget,
                    "requested_tiles_total": 0,
                    "scheduled_tiles": 0,
                    "tiles_scheduled": 0,
                    "remaining_tiles": 0,
                    "note": "world tier keeps pill ON and cache-visible but does not force RTOFS/bait/boater live repair",
                    "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, canonical, role="scene-cache-refresh-job"),
                }
                continue


            # Ocean must be refreshed from one authoritative camera viewport only.
            # If the request bbox is a child/scene-tile bbox while visible_bbox is
            # larger/different, skip provider scheduling here.  This removes the
            # legacy 24x24/scene-tile ocean bridge while preserving one 36-tile
            # ocean provider batch for explicit viewport refreshes.
            if ocean_heavy:
                try:
                    bw = abs(float(bbox_norm.get("east")) - float(bbox_norm.get("west")))
                    bh = abs(float(bbox_norm.get("north")) - float(bbox_norm.get("south")))
                    vw = abs(float(visible_norm.get("east")) - float(visible_norm.get("west")))
                    vh = abs(float(visible_norm.get("north")) - float(visible_norm.get("south")))
                    bbox_sig = tuple(round(float(bbox_norm[k]), 3) for k in ("west", "south", "east", "north"))
                    vis_sig = tuple(round(float(visible_norm[k]), 3) for k in ("west", "south", "east", "north"))
                    child_of_visible = bbox_sig != vis_sig and bw <= max(0.01, vw * 0.55) and bh <= max(0.01, vh * 0.55)
                except Exception:
                    child_of_visible = False
                if child_of_visible:
                    jobs[canonical] = {
                        "scheduled": False,
                        "ttl_policy": "authoritative_viewport_ocean_only",
                        "provider_fetch_allowed": False,
                        "skipped_legacy_scene_tile_ocean_fanout": True,
                        "note": "legacy scene/24x24 child bbox is not allowed to wake ocean provider; use one visible_bbox 6x6/36 refresh",
                        "scene_tier": scene_tier,
                        "tile_budget": tile_budget,
                        "requested_tiles_total": 36,
                        "scheduled_tiles": 0,
                        "tiles_scheduled": 0,
                        "skipped_tiles_budget": 36,
                        "remaining_tiles": 36,
                        "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, canonical, role="scene-cache-refresh-job"),
                    }
                    continue

            cached = self._scene_cache_peek_layer(canonical, bbox_norm, visible_norm, max_age_sec=SCENE_CACHE_MAX_AGE_SECONDS, allow_first_paint=False)
            age = cached.get("cache", {}).get("age_sec") if isinstance(cached, dict) else None
            empty_placeholder = self._scene_cache_layer_is_placeholder(canonical, cached)
            should_refresh = empty_placeholder or (cached is None) or (age is None) or (float(age or 999999) > SCENE_CACHE_STALE_SECONDS)

            # Prevent camera motion / overlapping visible bboxes from scheduling
            # near-identical heavy providers every few seconds. This is especially
            # important for GFS/cfgrib cloud/rain/jetstream and RTOFS/CoastWatch bait/boater.
            qkey = self._scene_cache_layer_key(canonical, bbox_norm, visible_norm)
            global_marker_key = f"scene-cache-refresh-marker:{canonical}"
            local_marker_key = f"scene-cache-refresh-marker:{qkey}"
            # Empty placeholders are not good cache. They may bypass the global
            # cooldown once so a first real drawable warm is not blocked by an early
            # empty shell, but they still keep a short local cooldown to prevent
            # repeated RTOFS/CoastWatch/GFS stampedes while the provider is slow.
            if empty_placeholder or cached is None:
                global_recent = None
                local_gap = 0 if force_empty_repair else max(10, min(30, SCENE_CACHE_LAYER_REFRESH_MIN_GAP_SECONDS // 3))
            else:
                global_recent = self._split_cache_get(global_marker_key, max(1, SCENE_CACHE_LAYER_REFRESH_MIN_GAP_SECONDS))
                local_gap = max(45, SCENE_CACHE_LAYER_REFRESH_MIN_GAP_SECONDS * (2 if movement else 1))
            local_recent = None if force_empty_repair else self._split_cache_get(local_marker_key, max(1, local_gap))
            throttled = False if force_empty_repair else bool(global_recent or local_recent)
            scheduled = False
            if should_refresh and not throttled:
                try:
                    self._split_cache_set(global_marker_key, {"ts": self._now_ms(), "reason": reason, "layer": canonical})
                    self._split_cache_set(local_marker_key, {"ts": self._now_ms(), "reason": reason, "layer": canonical})
                except Exception:
                    pass
                scheduled = self._scene_cache_schedule_layer_refresh(canonical, bbox_norm, visible_norm, explicit_visible_bbox=explicit_visible_bbox)

            requested_tiles_total = 0
            scheduled_tiles = 0
            skipped_tiles_budget = 0
            try:
                if ocean_heavy and hasattr(self, "_split_ocean_provider_tiles"):
                    all_tiles = self._split_ocean_provider_tiles(visible_norm)
                    requested_tiles_total = len(all_tiles)
                    if hasattr(self, "_cap_ocean_provider_tiles"):
                        _selected, _diag = self._cap_ocean_provider_tiles(canonical, visible_norm, all_tiles, scene_plan)
                        scheduled_tiles = int(_diag.get("tiles_scheduled") or 0) if scheduled else 0
                        skipped_tiles_budget = int(_diag.get("skipped_tiles_budget") or max(0, requested_tiles_total - scheduled_tiles))
                    else:
                        cap = int(tile_budget.get("max_ocean_refresh_tiles") or 0)
                        scheduled_tiles = min(requested_tiles_total, cap) if scheduled else 0
                        skipped_tiles_budget = max(0, requested_tiles_total - scheduled_tiles)
                else:
                    requested_tiles_total = int(tile_budget.get("requested_tiles_total") or 0)
                    scheduled_tiles = int(tile_budget.get("max_weather_refresh_tiles") or 0) if scheduled else 0
                    skipped_tiles_budget = max(0, requested_tiles_total - scheduled_tiles)
            except Exception:
                requested_tiles_total = 0
                scheduled_tiles = 0
                skipped_tiles_budget = 0

            jobs[canonical] = {
                "scheduled": scheduled,
                "ttl_policy": "live_refresh_when_stale_with_layer_cooldown",
                "age_sec": age,
                "fresh_enough": not should_refresh,
                "empty_placeholder": bool(empty_placeholder),
                "priority": "visible_bbox_high_detail_first",
                "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, canonical, role="scene-cache-refresh-job"),
                "throttled": bool(should_refresh and throttled),
                "min_gap_seconds": (0 if (force_empty_repair and empty_placeholder) else (max(10, min(30, SCENE_CACHE_LAYER_REFRESH_MIN_GAP_SECONDS // 3)) if empty_placeholder else SCENE_CACHE_LAYER_REFRESH_MIN_GAP_SECONDS)),
                "force_empty_repair": bool(force_empty_repair and empty_placeholder),
                "movement_reason": movement,
                "scene_tier": scene_tier,
                "tile_budget": tile_budget,
                "requested_tiles_total": requested_tiles_total,
                "scheduled_tiles": scheduled_tiles,
                "tiles_scheduled": scheduled_tiles,
                "skipped_tiles_budget": skipped_tiles_budget,
                "skipped_by_tile_budget": skipped_tiles_budget > 0,
                "partial_refresh": skipped_tiles_budget > 0,
                "remaining_tiles": skipped_tiles_budget,
            }
        return {
            "ok": True,
            "schema": "lftr_scene_cache_refresh_v2_throttled",
            "reason": reason,
            "mode": "background",
            "refresh_interval_ms": SCENE_CACHE_REFRESH_INTERVAL_MS,
            "bbox": bbox_norm,
            "visible_bbox": visible_norm,
            "render_bbox": visible_norm,
            "bbox_contract": self._scene_cache_bbox_contract(bbox_norm, visible_norm, role="scene-cache-refresh"),
            "priority_policy": "one_camera_aware_viewport_fixed_36_tiles_all_providers_center_first",
            "jobs": jobs,
            "ts": self._now_ms(),
        }

    def scene_cache_janitor_payload(self, reason: str = "manual") -> dict[str, Any]:
        return self._split_scene_cache_janitor_locked(reason=reason)

    def _inland_scene_tier_for_bbox(self, bbox: dict[str, float] | None) -> str:
        # One authoritative two-tier LOD gate: global or local only.
        # Local starts at the same visible-bbox threshold used by viewport36.py
        # and the browser: width<=8°, height<=6°, area<=36 deg².
        try:
            from server.gfs.viewport36 import lod_for_bbox
            tier = str(lod_for_bbox(self._normalize_bbox(bbox)) or "global").lower()
            return "local" if tier == "local" else "global"
        except Exception:
            return "global"

    def _inland_detail_allowed_for_bbox(self, bbox: dict[str, float] | None) -> bool:
        return self._inland_scene_tier_for_bbox(bbox) == "local"

    def _inland_temp_cache_key(self, bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None, scene_tier: str | None) -> str:
        try:
            b = self._normalize_bbox(visible_bbox or bbox)
            tier = str(scene_tier or self._inland_scene_tier_for_bbox(b) or "global").lower()
            q = (round(float(b["west"]), 2), round(float(b["south"]), 2), round(float(b["east"]), 2), round(float(b["north"]), 2))
            return f"{tier}:{q}"
        except Exception:
            return f"global:{int(time.time() // 120)}"

    def inland_water_temp_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, max_points: int = 36, scene_tier: str | None = None) -> dict[str, Any]:
        # Separate NCSS temp companion sublayer. Geometry stays in /gfs/api/inland-water.
        # World zoom is overview-only: one largest closed lake temp per selected tile/viewport,
        # no bait seed rows. Local/lake/harbor viewports may include bait seeds for contour rendering.
        from server.gfs.inland_water import inland_water_payload, inland_bait_payload, sample_surface_temperature, _centroid, _temperature_point, _enrich_inland_feature
        b = self._normalize_bbox(visible_bbox or bbox)
        tier = str(scene_tier or self._inland_scene_tier_for_bbox(b)).lower()
        tier = normalize_lod_name(tier)
        detail_allowed = (tier == "local") and self._inland_detail_allowed_for_bbox(b)
        cache_key = self._inland_temp_cache_key(bbox, visible_bbox, tier)
        now_ms = self._now_ms()
        ttl_ms = 120000 if not detail_allowed else 45000
        try:
            cache = getattr(self, "_inland_temp_payload_cache", None)
            if not isinstance(cache, dict):
                cache = {}
                setattr(self, "_inland_temp_payload_cache", cache)
            hit = cache.get(cache_key)
            if isinstance(hit, dict) and now_ms - int(hit.get("_cache_ts", 0)) < ttl_ms:
                out = dict(hit.get("payload") or {})
                out.setdefault("cache", {}).update({"hit": True, "mode": "inland_temp_payload_ttl", "ttl_ms": ttl_ms, "key": cache_key})
                out["status"] = out.get("status") or "cached"
                return out
        except Exception:
            cache = None
        water = inland_water_payload(self.static_dir, b, source="auto", geometry="vector", lod=("auto" if detail_allowed else "overview"), scene_tier=tier)
        # Global temp companion is cache/read-only.  If geometry is not ready,
        # do not try to repair it by sampling GFS temps; return an empty cached
        # companion and let /gfs/api/inland-water/build-cache create geometry.
        if not detail_allowed and not ((water.get("polygons") or []) or (water.get("lines") or [])):
            return {
                "ok": True,
                "status": "geometry_cache_miss",
                "schema": "lftr_inland_water_temp_labels_v8_global_no_geometry_no_temp_decode",
                "source": "global_inland_temp_skipped_until_geometry_cache_ready",
                "bbox": b,
                "bbox_used": b,
                "scene_tier": tier,
                "overview_only": True,
                "inland_bait_render_allowed": False,
                "global_live_temp_decode_allowed": False,
                "temperature_points": [],
                "tempLabels": [],
                "bait": {"ok": True, "status": "zoom_gated", "source": "inland_bait_gated_global_overview", "targets": [], "bait_score": [], "temperature_points": []},
                "count": 0,
                "water_feature_count": 0,
                "cache": {"hit": False, "mode": "global_geometry_cache_miss_no_temp_decode", "ttl_ms": ttl_ms, "key": cache_key},
                "policy": "global overview never decodes lake temps when shoreline geometry is missing",
                "ts": now_ms,
            }
        features = list((water.get("polygons") or [])) + ([] if not detail_allowed else list(water.get("lines") or []))
        def _area(item: dict[str, Any]) -> float:
            try:
                val = float(item.get("area_km2") or item.get("area_sqkm") or item.get("lake_area_sqkm") or item.get("AREASQKM") or item.get("shape_area") or item.get("Shape_Area") or item.get("source_prominence_score") or 0.0)
                if val > 0:
                    return val
            except Exception:
                pass
            try:
                path = item.get("path") or []
                if not path:
                    return 0.0
                lats = [float(p.get("lat")) for p in path if isinstance(p, dict) and p.get("lat") is not None]
                lngs = [float(p.get("lng", p.get("lon"))) for p in path if isinstance(p, dict) and (p.get("lng") is not None or p.get("lon") is not None)]
                if not lats or not lngs:
                    return 0.0
                return max(0.0, (max(lngs)-min(lngs)) * (max(lats)-min(lats)) * 111.0 * 111.0)
            except Exception:
                return 0.0
        def _tile_key(item: dict[str, Any], idx: int) -> str:
            key = item.get("global_tile_key") or item.get("world_tile_key") or item.get("tile_key")
            if key:
                return str(key)
            tb = item.get("tile_bbox") or item.get("bbox") or item.get("lake_bounds")
            try:
                if isinstance(tb, dict):
                    return f'{float(tb["west"]):.4f},{float(tb["south"]):.4f},{float(tb["east"]):.4f},{float(tb["north"]):.4f}'
                if isinstance(tb, (list, tuple)) and len(tb) >= 4:
                    return f'{float(tb[0]):.4f},{float(tb[1]):.4f},{float(tb[2]):.4f},{float(tb[3]):.4f}'
            except Exception:
                pass
            c = _centroid(item.get("path") or [])
            try:
                if c:
                    lat, lon = float(c[0]), float(c[1])
                    return f'{math.floor(lon):+04d}:{math.floor(lat):+03d}'
            except Exception:
                pass
            return f'unknown:{idx}'
        if not detail_allowed:
            # Global boot: one temperature target for the largest accepted lake in
            # each selected tile.  This matches the shoreline geometry contract and
            # prevents a worldwide clutter bloom while still making lakes visible
            # immediately after earth-first paint.
            winners: dict[str, dict[str, Any]] = {}
            for idx, item in enumerate(features):
                key = _tile_key(item, idx)
                cur = winners.get(key)
                if cur is None or _area(item) > _area(cur):
                    tagged = dict(item)
                    tagged["global_largest_lake_per_tile"] = True
                    tagged["world_largest_lake_per_tile"] = True
                    tagged["global_tile_key"] = key
                    tagged["world_tile_key"] = key
                    tagged["global_tile_rank"] = 1
                    winners[key] = tagged
            cap = max(1, min(96, int(max_points or 36)))
            features = sorted(winners.values(), key=lambda x: str(x.get("global_tile_key") or ""))[:cap]
            max_points = min(cap, len(features) or 1)
        points = []
        checked = 0
        for item in features:
            c = _centroid(item.get("path") or [])
            if not c:
                continue
            lat, lon = float(c[0]), float(c[1])
            checked += 1
            if detail_allowed:
                temp = sample_surface_temperature(self, {"west": lon - 0.15, "south": lat - 0.15, "east": lon + 0.15, "north": lat + 0.15}, lat, lon, live=False, lake_path=item.get("path"))
                temp_f = temp.get("value_f")
                temp_source = temp.get("used") or temp.get("source")
                confidence = "medium"
            else:
                # Global tier must stay cache/read-only: do not decode GFS/NCSS
                # per lake at world scale.  Still emit an honest, low-confidence
                # overview label so global shoreline geometry has a visible temp
                # marker.  Local zoom replaces this with sampled lake_environment
                # values from the companion endpoint.
                temp = {
                    "temp_reason": "global_tier_live_temp_decode_disabled_estimated_overview_label",
                    "temp_role": "cached_or_estimated_overview_only",
                }
                temp_f = item.get("water_temp_f") or item.get("temp_f") or item.get("surface_temp_f")
                try:
                    temp_f = float(temp_f) if temp_f is not None else None
                except Exception:
                    temp_f = None
                if temp_f is None:
                    # Deterministic freshwater overview estimate by latitude/season.
                    # It prevents silent missing labels at earth/global zoom without
                    # claiming a live measurement or starting wide GFS decode.
                    try:
                        import datetime as _dt, math as _math
                        day = int(_dt.datetime.utcnow().timetuple().tm_yday)
                        seasonal = _math.sin(2.0 * _math.pi * (day - 172) / 365.25)
                        abs_lat = abs(float(lat))
                        base = 73.0 - max(0.0, abs_lat - 28.0) * 0.72
                        temp_f = max(34.0, min(88.0, base + seasonal * 12.0))
                        temp["estimated"] = True
                        temp["estimate_model"] = "lat_season_freshwater_global_overview_v1"
                    except Exception:
                        temp_f = None
                temp_source = item.get("temp_source") or ("cached_inland_feature_temp" if not temp.get("estimated") and temp_f is not None else "global_boot_estimated_lake_surface_temp")
                confidence = "low" if temp_f is not None else "unresolved"
            if temp_f is not None:
                env = _enrich_inland_feature(item, self, lat, lon, temp_f, temp_source, confidence, live=detail_allowed)
                pt = _temperature_point({**item, **env}, lat, lon, temp_f, temp_source, confidence, len(points))
                if isinstance(pt, dict):
                    lake_id = str(item.get("id") or item.get("permanent_identifier") or item.get("Permanent_Identifier") or item.get("global_tile_key") or item.get("world_tile_key") or item.get("tile_key") or item.get("name") or f"lake:{len(points)}")
                    pt["lake_id"] = lake_id
                    pt["stable_lake_id"] = lake_id
                    pt["geometry_hash"] = str(item.get("geometry_hash") or item.get("path_hash") or item.get("global_tile_key") or item.get("world_tile_key") or lake_id)
                    pt["geometry_status"] = "ready"
                    pt["temp_status"] = "ready"
                    pt["temp_var"] = temp.get("temp_var")
                    pt["temp_level"] = temp.get("temp_level")
                    pt["temp_role"] = temp.get("temp_role")
                    pt["temp_reason"] = temp.get("temp_reason")
                    pt["grid_cell_lat"] = temp.get("grid_cell_lat")
                    pt["grid_cell_lng"] = temp.get("grid_cell_lng")
                    pt["update_mode"] = "metadata_only_do_not_rebuild_perimeter"
                    pt["global_boot_estimated"] = temp_source == "global_boot_estimated_lake_surface_temp"
                    pt["global_largest_lake_per_tile"] = item.get("global_largest_lake_per_tile") or item.get("world_largest_lake_per_tile") or not detail_allowed
                    pt["world_largest_lake_per_tile"] = pt["global_largest_lake_per_tile"]
                    pt["global_tile_key"] = item.get("global_tile_key") or item.get("world_tile_key") or item.get("tile_key")
                    # Canonical inland temp contract. Keep old aliases for JS that
                    # has not migrated yet; new intel panes read source_/norm_/status_/display_*.
                    try:
                        apply_inland_temp_contract(pt)
                    except Exception:
                        pass
                points.append(pt)
            if len(points) >= max_points or checked >= max_points * (2 if detail_allowed else 1):
                break
        if detail_allowed:
            try:
                bait = inland_bait_payload(self.static_dir, self, b, live=False)
            except Exception as exc:
                bait = {"ok": False, "status": "error", "source": "inland_bait_companion_failed", "error": str(exc), "targets": [], "bait_score": [], "temperature_points": []}
        else:
            bait = {"ok": True, "status": "zoom_gated", "source": "inland_bait_gated_global_overview", "targets": [], "bait_score": [], "temperature_points": [], "policy": "inland bait contours render only at local lake/harbor zoom"}
        out = {
            "ok": True,
            "schema": "lftr_inland_water_temp_labels_v7_two_tier_global_cache_only_local_live",
            "source": "inland_temp_two_tier_global_cache_only_local_live",
            "bbox": b,
            "bbox_used": b,
            "scene_tier": tier,
            "overview_only": not detail_allowed,
            "inland_bait_render_allowed": detail_allowed,
            "global_live_temp_decode_allowed": bool(detail_allowed),
            "temperature_points": points,
            "tempLabels": points,
            "bait": bait,
            "inland_bait": bait,
            "bait_score": bait.get("bait_score") if isinstance(bait, dict) else [],
            "bait_targets": bait.get("targets") if isinstance(bait, dict) else [],
            "bait_score_count": int(bait.get("bait_score_count") or len(bait.get("bait_score") or [])) if isinstance(bait, dict) else 0,
            "count": len(points),
            "water_feature_count": len((water.get("polygons") or [])) + len((water.get("lines") or [])),
            "overview_policy": "global uses cached/no-live-decode largest lake per tile; local alone may run surface-TMP sampling and inland bait detail",
            "per_lake_temp_policy": "one authoritative canonical temp object per stable_lake_id; same cache key returns TTL payload and never rebuilds shoreline",
            "intel_contract": "source_raw_norm_derived_score_status_reason_display_v1",
            "one_largest_lake_per_tile": not detail_allowed,
            "contract": "lftr_inland_water_temp_v7_two_tier_global_cache_only_local_live",
            "cache": {"hit": False, "mode": "inland_temp_payload_build", "ttl_ms": ttl_ms, "key": cache_key},
            "ts": now_ms,
        }
        try:
            if isinstance(cache, dict):
                cache[cache_key] = {"_cache_ts": now_ms, "payload": out}
                # Keep the small request cache bounded.
                for k in list(cache.keys())[:-24]:
                    cache.pop(k, None)
        except Exception:
            pass
        return out


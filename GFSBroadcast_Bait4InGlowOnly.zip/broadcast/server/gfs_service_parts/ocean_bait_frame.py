from __future__ import annotations

import builtins
import os
import server.gfs_service as _svc
from server.gfs.viewport36 import VIEWPORT_TILE_COUNT, VIEWPORT_TILE_GRID, normalize_lod
from server.gfs.intel_contract import apply_ocean_contract, OCEAN_MISSION_LAYERS
builtins.ALLOW_SYNTHETIC_FALLBACK = False
ALLOW_SYNTHETIC_FALLBACK = False
globals().update({k: v for k, v in vars(_svc).items() if not k.startswith('__')})
ALLOW_SYNTHETIC_FALLBACK = False

# Compatibility guard: some older mixin shards reference this quality-policy
# flag, but the current service no longer exports it. Keep live payloads strict
# by default and prevent cache warmers for bait/boater from crashing before
# RTOFS SST/current data can reach the scene cache.
ALLOW_SYNTHETIC_FALLBACK = False


class OceanBaitFrameMixin:
    def _rtofs_cached_current_payload(self, bbox: dict[str, float] | None, lod: str = "auto", visible_bbox: dict[str, float] | None = None, *, role: str = "field") -> Dict[str, Any]:
        """Consume warmed RTOFS JSON without network/xarray work.

        The warmer owns NOAA download/local NetCDF parsing.  This helper shapes
        the JSON cache into the same buckets used by boats, boater analysis,
        advanced bait, shark HUD, and /field?field=current.
        """
        started = time.time()
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean-points")
        try:
            from server.gfs.rtofs_source import load_cached_rtofs_surface, spawn_rtofs_surface_warmer
            cached = load_cached_rtofs_surface(b)
            points = cached.get("points") or cached.get("current_points") or cached.get("ocean_points") or []
            if not points:
                warmer = spawn_rtofs_surface_warmer(b, max_points=int(os.getenv("GFS_RTOFS_WARM_MAX_POINTS", "3000") or "3000")) if os.getenv("GFS_RTOFS_AUTOSPAWN_WARMER", "true").strip().lower() in {"1", "true", "yes", "on"} else {"started": False, "reason": "autosspawn_disabled"}
                return {
                    "ok": False,
                    "source": "ncep_nomads_rtofs_cached_surface_missing",
                    "payload_state": "rtofs_cache_miss",
                    "status": "warming" if warmer.get("started") else "waiting_for_rtofs_cache",
                    "bbox": [b["west"], b["south"], b["east"], b["north"]],
                    "bbox_object": b,
                    "scene_plan": scene,
                    "points": [],
                    "current_points": [],
                    "ocean_points": [],
                    "count": 0,
                    "cache": cached.get("cache") or {"hit": False, "path": cached.get("cache_path")},
                    "warmer": warmer,
                    "diagnostics": {"consumer_role": role, "field_read_mode": "rtofs_cached_json_missing_no_remote_open", "next_step": "scripts/warm_rtofs_surface_cache.py --bbox=-125,32,-117,38"},
                    "latency_ms": int((time.time() - started) * 1000),
                    "ts": self._now_ms(),
                }
            boats, boat_meta = self._boats_from_ocean_points({"points": points, "current_points": points, "source": cached.get("source")}, limit=int(os.getenv("GFS_BOATER_MAX_BOATS", "12") or "12"))
            try:
                _direct_key, _lod_key, _scene = self._direct_ocean_points_cache_key_for_current_field(b, lod, visible_bbox)
            except Exception:
                _direct_key = None
            payload = {
                "ok": True,
                "source": "ncep_nomads_rtofs_cached_surface",
                "schema": "rtofs_cached_current_consumption_v1",
                "payload_state": "ready",
                "status": "ok",
                "bbox": [b["west"], b["south"], b["east"], b["north"]],
                "bbox_object": b,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "points": points,
                "current_points": points,
                "ocean_points": points,
                "ocean_analysis_points": points,
                "oceanPoints": {"ok": True, "source": "ncep_nomads_rtofs_cached_surface", "points": points, "count": len(points), "contract": "rtofs_cached_points_feed_boats_boater_advancedbait"},
                "oceanAnalysisPoints": {"ok": True, "source": "ncep_nomads_rtofs_cached_surface", "points": points, "count": len(points), "contract": "rtofs_cached_ocean_analysis_points_for_boats_advanced_bait"},
                "boats": boats,
                "boat_count": len(boats),
                "count": len(points),
                "grid": {"real_grid": True, "point_count": len(points), "source": "rtofs_cached_json"},
                "cache": cached.get("cache") or {"hit": True, "path": cached.get("cache_path")},
                "source_meta": cached.get("source_meta") or {},
                "direct_ocean_points_cache_key": _direct_key,
                "fallback_warm_used": True,
                "diagnostics": {"consumer_role": role, "field_read_mode": "rtofs_cached_json_consumption", "boat_meta": boat_meta, "cache_path": cached.get("cache_path")},
                "latency_ms": int((time.time() - started) * 1000),
                "ts": self._now_ms(),
            }
            try:
                if _direct_key:
                    self._split_cache_set(_direct_key, payload)
            except Exception as exc:
                payload.setdefault("diagnostics", {})["cache_promote_error"] = str(exc)
            return payload
        except Exception as exc:
            return {"ok": False, "source": "ncep_nomads_rtofs_cached_surface_exception", "payload_state": "rtofs_cache_exception", "status": "waiting_for_rtofs_cache", "error": str(exc), "points": [], "current_points": [], "ocean_points": [], "count": 0, "latency_ms": int((time.time() - started) * 1000), "ts": self._now_ms()}

    def _rtofs_live_bbox_policy(self, bbox: dict[str, float] | None, scene: dict[str, Any] | None = None, *, layer: str = "ocean") -> dict[str, Any]:
        """Decide whether a RTOFS NCSS live fetch is safe for one request.

        RTOFS is the provider, not a whole-world renderer.  Large visible bboxes
        should be satisfied by existing quantized scene-cache tiles or wait for
        smaller tiles, not by one giant blocking NCSS query.
        """
        b = self._normalize_bbox(bbox)
        width = abs(float(b.get("east", 0)) - float(b.get("west", 0)))
        height = abs(float(b.get("north", 0)) - float(b.get("south", 0)))
        area = width * height
        max_span = float(os.getenv("GFS_RTOFS_MAX_LIVE_SPAN_DEG", "1.0") or "1.0")
        max_area = float(os.getenv("GFS_RTOFS_MAX_LIVE_AREA_DEG2", "1.0") or "1.0")
        allowed = bool(width <= max_span and height <= max_span and area <= max_area)
        return {
            "allowed": allowed,
            "layer": layer,
            "bbox": b,
            "span_deg": round(max(width, height), 3),
            "area_deg2": round(area, 3),
            "max_span_deg": max_span,
            "max_area_deg2": max_area,
            "policy": "tile_cache_only_for_wide_views; provider_fetches_split_to_1deg_tiles; no_large_one_shot_rtofs_ncss",
        }

    def _rtofs_large_bbox_shell(self, bbox: dict[str, float] | None, scene: dict[str, Any] | None, *, layer: str, reason: str = "large_bbox_cache_only") -> dict[str, Any]:
        b = self._normalize_bbox(bbox)
        policy = self._rtofs_live_bbox_policy(b, scene, layer=layer)
        return {
            "ok": False,
            "source": f"rtofs_{layer}_cache_only_large_bbox",
            "payload_state": "cache_only_large_bbox",
            "reason": reason,
            "bbox": b,
            "bbox_object": b,
            "scene_plan": scene or {},
            "visible_bbox": (scene or {}).get("visible_bbox"),
            "fetch_bbox": (scene or {}).get("fetch_bbox"),
            "boats": [],
            "points": [],
            "ocean_points": [],
            "oceanPoints": [],
            "count": 0,
            "grid": {"real_grid": False, "reason": reason},
            "rtofs_live_policy": policy,
            "quality_policy": {"allow_synthetic_fallback": False, "allow_proxy_fallback": False},
            "ts": self._now_ms(),
        }



    def _rtofs_provider_ledger_status(self, raw: dict[str, Any] | None, *, stride: int) -> tuple[str, bool, int, dict[str, Any]]:
        """Summarize one RTOFS tile fetch for the provider ledger.

        A non-empty dict is not success. Success means the NCSS payload passed the
        ocean quality gate and is promotable into render/cache products. Empty
        HTTP 200 / zero-byte responses must be visible in /provider-ledger.
        """
        raw = raw if isinstance(raw, dict) else {}
        meta = raw.get("source_meta") if isinstance(raw.get("source_meta"), dict) else {}
        q = meta.get("quality_gate") if isinstance(meta.get("quality_gate"), dict) else {}
        live_ok = bool(meta.get("real_subset") or q.get("live_ncss_ok") or meta.get("live_ocean_truth_ok"))
        has_sst = bool(meta.get("has_sst") or q.get("has_rtofs_sst") or raw.get("sst"))
        has_current = bool(meta.get("has_current") or q.get("has_rtofs_current") or (raw.get("current_u") and raw.get("current_v")))
        diagnostics = meta.get("diagnostics") if isinstance(meta.get("diagnostics"), list) else []
        bytes_received = 0
        zero_byte_http_200 = False
        for d in diagnostics:
            if not isinstance(d, dict):
                continue
            try:
                bytes_received += int(d.get("bytes") or d.get("bytes_received") or 0)
            except Exception:
                pass
            if str(d.get("status") or "") in {"200", "ok"} or d.get("status") == 200:
                try:
                    if int(d.get("bytes") or d.get("bytes_received") or 0) <= 0:
                        zero_byte_http_200 = True
                except Exception:
                    pass
        if live_ok:
            status = "ok"
        elif zero_byte_http_200:
            status = "empty_http_200_size_0"
        elif diagnostics:
            status = "quality_gate_failed"
        else:
            status = "empty"
        detail = {
            "stride": stride,
            "grid_shape": meta.get("grid_shape") or [],
            "selected_attempt": meta.get("selected_attempt"),
            "selected_dataset": meta.get("selected_dataset"),
            "selected_vars": meta.get("selected_vars"),
            "has_sst": has_sst,
            "has_current": has_current,
            "blocking_reasons": meta.get("blocking_reasons") or q.get("blocking_reasons") or [],
            "opened_urls": meta.get("subset_urls") or len(meta.get("opened_urls") or []),
            "ncss_time": "present",
        }
        # When RTOFS is the active provider, keep old detail shape but expose the
        # actual provider family and selected dataset to the ledger.
        if isinstance(meta, dict) and meta.get("provider_ledger_family"):
            detail["provider_family"] = meta.get("provider_ledger_family")
            detail["ocean_source"] = meta.get("ocean_source")
            detail["rtofs_cycle"] = meta.get("rtofs_cycle")
            detail["lod_stride_policy"] = meta.get("lod_stride_policy")
        return status, bool(live_ok), int(bytes_received), detail

    def _ocean_provider_ledger_family(self, raw: dict[str, Any] | None) -> str:
        meta = (raw or {}).get("source_meta") if isinstance((raw or {}), dict) else {}
        if isinstance(meta, dict):
            fam = meta.get("provider_ledger_family")
            if fam:
                return str(fam)
            if str(meta.get("provider") or "").lower().startswith("rtofs") or str(meta.get("ocean_source") or "").startswith("rtofs"):
                return "rtofs_ocean_bundle"
        return "rtofs_ocean_bundle"

    def _ocean_provider_tile_deg(self) -> float:
        try:
            return max(0.1, min(float(os.getenv("GFS_OCEAN_PROVIDER_TILE_DEG", "1.0") or "1.0"), 1.0))
        except Exception:
            return 1.0

    def _split_ocean_provider_tiles(self, bbox: dict[str, float] | None, tile_deg: float | None = None) -> list[dict[str, float]]:
        """Split the shared viewport bbox into the fixed 6x6 / 36-tile provider grid.

        This is deliberately provider-agnostic.  RTOFS, GFS, CoastWatch and
        station/inland enrichments see the same tile ids/bboxes.  LOD changes
        density/stride inside each tile, never the number of tiles.
        """
        from server.gfs.tile_contract import split_viewport_tiles
        b = self._normalize_bbox(bbox)
        out: list[dict[str, float]] = []
        for t in split_viewport_tiles(b, grid=VIEWPORT_TILE_GRID):
            tile = dict(t.bbox)
            tile.update({"row": int(t.row), "col": int(t.col), "tile_id": t.tile_id, "grid": "6x6", "tile_count": VIEWPORT_TILE_COUNT})
            out.append(tile)
        return out

    def _is_wide_ocean_provider_bbox(self, bbox: dict[str, float] | None, tile_deg: float | None = None) -> bool:
        # Provider fetches are expected to operate on one of the 36 split tiles.
        # This helper is retained for legacy guards, but the scheduler now owns
        # splitting so a full viewport should not be passed to RTOFS directly.
        b = self._normalize_bbox(bbox)
        width = abs(float(b["east"]) - float(b["west"]))
        height = abs(float(b["north"]) - float(b["south"]))
        return bool(width > 0.0 and height > 0.0 and (width * height) > float(os.getenv("GFS_RTOFS_MAX_LIVE_AREA_DEG2", "1.0") or "1.0"))

    def _ocean_provider_tile_budget_for_scene(self, scene: dict[str, Any] | None, *, layer: str = "ocean") -> dict[str, Any]:
        tier = normalize_lod((scene or {}).get("tier") or (scene or {}).get("lod") or "global")
        # Fixed 6x6 provider architecture: one authoritative viewport ocean refresh
        # is allowed to schedule all 36 provider tiles concurrently.  OOM protection
        # belongs at the batch/in-flight dedupe layer, not by silently shrinking the
        # provider tile count.  This preserves the intended full viewport cache fill.
        default_cap = {"global": 36, "local": 36}.get(tier, 36)
        try:
            cap = int(os.getenv("GFS_OCEAN_PROVIDER_MAX_SCHEDULED_TILES", str(default_cap)) or str(default_cap))
        except Exception:
            cap = default_cap
        cap = max(0, min(cap, VIEWPORT_TILE_COUNT))
        return {
            "scene_tier": tier,
            "lod": tier,
            "layer": layer,
            "max_tiles": cap,
            "tile_rows": VIEWPORT_TILE_GRID,
            "tile_cols": VIEWPORT_TILE_GRID,
            "tile_count": VIEWPORT_TILE_COUNT,
            "env": "GFS_OCEAN_PROVIDER_MAX_SCHEDULED_TILES",
            "policy": "fixed_36_provider_tiles_per_authoritative_ocean_viewport_refresh_batch_deduped",
        }

    def _prioritize_ocean_provider_tiles(self, tiles: list[dict[str, float]], scene: dict[str, Any] | None = None) -> list[dict[str, float]]:
        """Sort provider tiles nearest the visible/camera center first."""
        if not tiles:
            return []
        visible = (scene or {}).get("visible_bbox") if isinstance((scene or {}).get("visible_bbox"), dict) else None
        if not visible:
            visible = (scene or {}).get("bbox") if isinstance((scene or {}).get("bbox"), dict) else None
        try:
            cx = (float((visible or {}).get("west")) + float((visible or {}).get("east"))) / 2.0
            cy = (float((visible or {}).get("south")) + float((visible or {}).get("north"))) / 2.0
        except Exception:
            return list(tiles)
        def score(t: dict[str, float]) -> tuple[float, float]:
            tx = (float(t.get("west", 0.0)) + float(t.get("east", 0.0))) / 2.0
            ty = (float(t.get("south", 0.0)) + float(t.get("north", 0.0))) / 2.0
            return ((tx - cx) * (tx - cx) + (ty - cy) * (ty - cy), abs(tx - cx) + abs(ty - cy))
        return sorted(list(tiles), key=score)

    def _cap_ocean_provider_tiles(self, layer: str, bbox: dict[str, float], tiles: list[dict[str, float]], scene: dict[str, Any] | None = None) -> tuple[list[dict[str, float]], dict[str, Any]]:
        budget = self._ocean_provider_tile_budget_for_scene(scene, layer=layer)
        requested = len(tiles or [])
        mask_diag: dict[str, Any] = {"enabled": False, "reason": "not_checked"}
        candidate_tiles = list(tiles or [])
        try:
            if os.getenv("GFS_RTOFS_SST_MASK_TILE_PLAN", "true").strip().lower() in {"1", "true", "yes", "on"}:
                from server.gfs.rtofs_source import load_cached_rtofs_ocean_mask
                from server.gfs.ocean_landmask import annotate_tiles_with_ocean_mask
                mask_payload = load_cached_rtofs_ocean_mask(bbox)
                if mask_payload.get("ok"):
                    min_fraction = float(os.getenv("GFS_RTOFS_SST_MASK_MIN_TILE_WATER_FRACTION", "0.0") or "0.0")
                    candidate_tiles, mask_diag = annotate_tiles_with_ocean_mask(candidate_tiles, mask_payload, min_water_fraction=min_fraction)
                else:
                    mask_diag = {
                        "enabled": False,
                        "reason": mask_payload.get("status") or mask_payload.get("reason") or "mask_cache_not_ready",
                        "cache_path": mask_payload.get("cache_path"),
                        "tiles_total": requested,
                        "tiles_requested_ocean": requested,
                        "tiles_skipped_land": 0,
                        "policy": "no_quality_reduction_without_mask",
                    }
        except Exception as exc:
            mask_diag = {"enabled": False, "reason": "mask_plan_error", "error": str(exc), "tiles_total": requested, "tiles_requested_ocean": requested, "tiles_skipped_land": 0}
            candidate_tiles = list(tiles or [])
        cap = max(0, int(budget.get("max_tiles") or 0))
        ordered = self._prioritize_ocean_provider_tiles(list(candidate_tiles or []), scene)
        selected = ordered[:cap]
        now = self._now_ms()
        diagnostics = {
            **budget,
            "requested_tiles_total": requested,
            "tiles_total": requested,
            "tiles_considered_after_sst_mask": len(candidate_tiles or []),
            "tiles_scheduled": len(selected),
            "scheduled_tiles": len(selected),
            "skipped_tiles_landmask": max(0, requested - len(candidate_tiles or [])) if mask_diag.get("enabled") else 0,
            "skipped_tiles_budget": max(0, len(candidate_tiles or []) - len(selected)),
            "skipped_by_tile_budget": len(candidate_tiles or []) > len(selected),
            "partial_refresh": requested > len(selected),
            "remaining_tiles": max(0, requested - len(selected)),
            "next_refresh_allowed_at": now + int(os.getenv("GFS_OCEAN_TILE_REFRESH_COOLDOWN_MS", "120000") or "120000"),
            "tile_deg": self._ocean_provider_tile_deg(),
            "ocean_mask_plan": mask_diag,
            "ocean_mask_source": mask_diag.get("mask_source") if mask_diag.get("enabled") else None,
            "tiles_requested_ocean": mask_diag.get("tiles_requested_ocean", len(candidate_tiles or [])),
            "tiles_skipped_land": mask_diag.get("tiles_skipped_land", 0),
            "provider_tiles_selected": selected,
        }
        return selected, diagnostics

    def _log_ocean_provider_tile_policy(self, layer: str, bbox: dict[str, float], tiles: list[dict[str, float]], scene: dict[str, Any] | None = None) -> dict[str, Any]:
        try:
            selected, diag = self._cap_ocean_provider_tiles(layer, bbox, tiles, scene)
            log.info(
                "ocean/provider-wide-request-skipped policy=tile_cache_only layer=%s visible_bbox=%s tile_deg=%.2f requested_tiles_total=%s tiles_total=%s",
                layer, bbox, self._ocean_provider_tile_deg(), diag.get("requested_tiles_total"), diag.get("tiles_total")
            )
            log.info(
                "ocean/tile-refresh requested_tiles_total=%s ocean_tiles=%s scheduled=%s scheduled_tiles=%s skipped_land=%s skipped_tiles_budget=%s partial_refresh=%s remaining_tiles=%s scene_tier=%s tile_deg=%.1f layer=%s mask=%s",
                diag.get("requested_tiles_total"), diag.get("tiles_requested_ocean"), diag.get("tiles_scheduled"), diag.get("scheduled_tiles"),
                diag.get("tiles_skipped_land"), diag.get("skipped_tiles_budget"), diag.get("partial_refresh"), diag.get("remaining_tiles"),
                diag.get("scene_tier"), self._ocean_provider_tile_deg(), layer, diag.get("ocean_mask_source") or (diag.get("ocean_mask_plan") or {}).get("reason")
            )
            diag["provider_tiles_preview"] = selected[: min(len(selected), 16)]
            return diag
        except Exception:
            return {"requested_tiles_total": len(tiles or []), "tiles_scheduled": 0, "scheduled_tiles": 0, "skipped_tiles_budget": len(tiles or [])}

    def _merge_ocean_tile_live_payloads(self, bbox: dict[str, float], scene: dict[str, Any], tile_payloads: list[dict[str, Any]], started: float) -> dict[str, Any]:
        good = [p for p in tile_payloads if isinstance(p, dict) and p.get("ok")]
        boats: list[dict[str, Any]] = []
        points: list[dict[str, Any]] = []
        current_points: list[dict[str, Any]] = []
        for payload in good:
            boats.extend(payload.get("boats") or [])
            points.extend(payload.get("points") or payload.get("ocean_points") or [])
            current_points.extend(payload.get("current_points") or payload.get("points") or [])
        max_boats = int(os.getenv("GFS_BOAT_COUNT_MAX", "10") or "10")
        out = {
            "ok": bool(points or current_points or boats),
            "source": "rtofs_espc_d_v02_ncss_tile_merged" if good else "rtofs_espc_d_v02_ncss_tile_empty",
            "mode": "tile_cache_only_merged_ocean_provider_payload",
            "engine": "provider-safe <=1deg RTOFS tile merge",
            "bbox": bbox,
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "boats": boats[:max_boats],
            "boat_count": min(len(boats), max_boats),
            "points": points,
            "ocean_points": points,
            "current_points": current_points or points,
            "current_zone_points_count": len(current_points or points),
            "swell_components": [],
            "grid": {"real_grid": bool(points or current_points), "tile_count": len(tile_payloads), "good_tile_count": len(good)},
            "source_meta": {"tile_cache_only": True, "provider_tile_deg": self._ocean_provider_tile_deg(), "tile_count": len(tile_payloads), "good_tile_count": len(good)},
            "cache": {"hit": False, "ttl_seconds": 180, "mode": "live_tile_merged", "tile_count": len(tile_payloads), "good_tile_count": len(good)},
            "quality_policy": self._live_payload_policy(),
            "fallback": {"used": False, "allowed": False},
            "payload_state": "live_tile_merged" if good else "provider_empty",
            "latency_ms": int((time.time() - started) * 1000),
            "ts": self._now_ms(),
        }
        if not out["ok"]:
            out.setdefault("cache", {}).update({"hit": False, "mode": "provider_empty_not_cached", "write_policy": "do_not_promote_empty_ocean_tile_merge"})
        return out

    def source_diagnostics_payload(self, bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        lat, lon = self._bbox_center(b)
        gfs_vars = [
            "u-component_of_wind_height_above_ground", "v-component_of_wind_height_above_ground",
            "Temperature_height_above_ground", "Relative_humidity_height_above_ground",
            "Precipitation_rate_surface", "Total_cloud_cover_entire_atmosphere",
            "Low_cloud_cover_low_cloud", "Medium_cloud_cover_middle_cloud", "High_cloud_cover_high_cloud",
            "Pressure_reduced_to_MSL_msl",
        ]
        from urllib.parse import urlencode
        gfs_query = urlencode({
            "north": round(b["north"], 4), "south": round(b["south"], 4),
            "west": round(b["west"], 4), "east": round(b["east"], 4),
            "time": "present", "accept": "netCDF4", "addLatLon": "true", "horizStride": 1,
        }) + "&" + "&".join(f"var={v}" for v in gfs_vars)
        gfs_ncss = f"https://thredds.ucar.edu/thredds/ncss/grid/grib/NCEP/GFS/Global_0p25deg/TwoD?{gfs_query}"
        rows = [
            self._source_row("weather", "GFS THREDDS NCSS", "weather/clouds/rain/wind", gfs_ncss, engine="netcdf4/h5netcdf target", ttl_seconds=0, status="target_next_live_first", details="Preferred fast path: one NetCDF4 subset shared by weather, clouds, and rain. Cloud/rain freshness is live-first: retained payloads are display-only while fresh GFS is requested.", variables=gfs_vars),
            self._source_row("weather_retained_display", "NOAA NOMADS GFS", "cloud/rain retained last-good display bridge", NOMADS_FILTER_BASE, engine="grib2+cfgrib current", ttl_seconds=0, status="current_live_first", details="Current working path. No 15-60 minute cloud source TTL: each active cloud request schedules a fresh GFS attempt; last-known-good is labeled retained_display only for instant pop-on/off."),
            self._source_row("ocean", "NOAA/NCEP RTOFS NRT", "depth-0 water_temp + salinity + U/V currents", "https://nomads.ncep.noaa.gov/pub/data/nccf/com/rtofs/prod", engine="h5netcdf/netCDF4 live", ttl_seconds=180, status="current_live_if_bbox_small", details="Primary live path uses NOAA/NCEP RTOFS NOMADS products through the RTOFS adapter. The adapter owns file discovery, variable aliases, land mask, depth slices, and surface current/SST contracts.", variables=["water_temp", "salinity", "water_u", "water_v"]),
            self._source_row("swells", "NOAA WaveWatch III", "3 swell components", "https://nomads.ncep.noaa.gov/cgi-bin/filter_wave.pl", engine="netcdf4/grib2 target", ttl_seconds=180, status="target_next", details="Use multi-swell height/period/direction where fields are available. In strict mode, unavailable WW3 data remains diagnostic only and must not be presented as live measured swell."),
            self._source_row("sst", "NOAA OISST / ERDDAP", "bait temperature band", "https://coastwatch.pfeg.noaa.gov/erddap/griddap/ncdcOisst21Agg_LonPM180.csv", engine="csv/netcdf target", ttl_seconds=300, status="target_next", details="Observed SST for bait species likelihood and water/land validity."),
            self._source_row("chlorophyll", "NOAA CoastWatch ERDDAP", "bait productivity", "https://coastwatch.pfeg.noaa.gov/erddap/griddap/erdMH1chlamday.csv", engine="csv/netcdf target", ttl_seconds=300, status="target_next", details="Chlorophyll/productivity multiplier for bait polygons."),
            self._source_row("markers", "local CSV", "fish locations/intelligence", str(self._fish_csv_path()), engine="csv", ttl_seconds=0, status="current", details="Fish marker locations and fishing history reports."),
        ]
        api_calls = [
            {"endpoint": "/gfs/api/weather", "function": "weather fields", "source_role": "weather", "target_ttl_seconds": WEATHER_REFRESH_TTL_SECONDS},
            {"endpoint": "/gfs/api/clouds", "function": "cloud/rain scene", "source_role": "weather", "target_ttl_seconds": 0, "policy": "live_first_retained_display_only", "dedupe_seconds": CLOUD_LIVE_DEDUPE_SECONDS},
            {"endpoint": "/gfs/api/ocean", "function": "currents/ocean solve", "source_role": "ocean", "target_ttl_seconds": 180},
            {"endpoint": "/gfs/api/boats", "function": "boating solve + 3 swells", "source_role": "ocean/swells", "target_ttl_seconds": 180},
            {"endpoint": "/gfs/api/bait-advanced", "function": "bait polygons/scores", "source_role": "sst/chl/ocean live grid; markers sample grid only", "target_ttl_seconds": 300},
            {"endpoint": "/gfs/api/scene-cache", "function": "fast composite assembler", "source_role": "cached split payloads", "target_ttl_seconds": 15},
        ]
        return {"ok": True, "bbox": b, "center": {"lat": round(lat, 4), "lon": round(lon, 4)}, "api_calls": api_calls, "sources": rows, "ts": self._now_ms()}

    def _ocean_stride_for_bbox(self, bbox: dict[str, float], target_cells: int | None = None) -> int:
        """Budget-derived RTOFS NCSS stride.

        The old fixed harbor/regional/world buckets made stride and LOD hard to
        reason about.  This keeps tiny harbor views native, then derives stride
        from a scene target-cell budget so provider fetch resolution is explicit.
        Final visual density is still controlled later by render budgets.
        """
        return self._estimate_provider_stride_for_bbox(bbox, target_cells or int(os.getenv("GFS_SCENE_PROVIDER_TARGET_CELLS", "14000") or "14000"))

    @staticmethod
    def _current_dir_deg(u_ms: float, v_ms: float) -> float | None:
        if not (math.isfinite(u_ms) and math.isfinite(v_ms)):
            return None
        if abs(u_ms) < 1e-9 and abs(v_ms) < 1e-9:
            return None
        return (math.degrees(math.atan2(u_ms, v_ms)) + 360.0) % 360.0

    @staticmethod
    def _safety_from_current(speed_kt: float, sst_c: float | None = None) -> dict[str, Any]:
        speed = max(0.0, float(speed_kt or 0.0))
        if speed >= 2.5:
            color, label, score = "red", "Strong current / rough drift caution", 0.82
        elif speed >= 1.5:
            color, label, score = "yellow", "Active current / plan drift", 0.62
        elif speed >= 0.75:
            color, label, score = "yellow", "Moderate current", 0.42
        else:
            color, label, score = "green", "Light current", 0.22
        if sst_c is not None and math.isfinite(float(sst_c)) and (sst_c < 8 or sst_c > 31):
            score = min(1.0, score + 0.08)
        return {"color": color, "label": label, "summary": label, "score": round(score, 3), "risk": round(score, 3)}

    @staticmethod
    def _json_float(value: Any, digits: int | None = None) -> float | None:
        try:
            f = float(value)
        except Exception:
            return None
        if not math.isfinite(f):
            return None
        return round(f, digits) if digits is not None else f

    @classmethod
    def _safety_from_wave_ft(cls, wave_ft: Any, fallback: dict[str, Any] | None = None) -> dict[str, Any]:
        ft = cls._json_float(wave_ft, 3)
        if ft is None:
            out = dict(fallback or {"color": "gray", "label": "Wave height unavailable", "score": 0.5, "risk": 0.5})
            out.setdefault("summary", out.get("label") or "Wave height unavailable")
            out["wave_height_ft"] = None
            out["wave_policy"] = "missing_wave_height_preserve_current_or_unknown"
            return out
        if ft <= 3.0:
            color, label, score = "green", "0-3 ft seas: favorable boating zone", 0.22
        elif ft <= 4.0:
            color, label, score = "yellow", "3-4 ft seas: caution boating zone", 0.55
        else:
            color, label, score = "red", "4+ ft seas: hazardous boating zone", 0.86
        return {"color": color, "label": label, "summary": label, "score": score, "risk": score, "wave_height_ft": ft, "wave_policy": "combined_seas_thresholds_green_le_3_yellow_le_4_red_gt_4"}

    def _proxy_swells_for_point(self, lat: float, lon: float, regional_boats: list[dict[str, Any]]) -> list[dict[str, Any]]:
        best = None
        best_d = 1e9
        for boat in regional_boats or []:
            try:
                d = (float(boat.get("lat")) - lat) ** 2 + (float(boat.get("lon")) - lon) ** 2
            except Exception:
                continue
            if d < best_d:
                best, best_d = boat, d
        if best:
            sw = best.get("swells") or best.get("swell_components") or []
            if sw:
                return sw[:3]
            waves = best.get("waves") or {}
            cand = []
            for k in ("primary", "secondary", "tertiary"):
                if isinstance(waves.get(k), dict):
                    cand.append(waves[k])
            if cand:
                return cand[:3]
        return []

    @staticmethod
    def _lon_pm180(value: float) -> float:
        lon = float(value)
        while lon > 180.0:
            lon -= 360.0
        while lon <= -180.0:
            lon += 360.0
        return lon

    @staticmethod
    def _grid_spacing(values: list[float], index: int, fallback: float) -> float:
        vals = [float(v) for v in values if isinstance(v, (int, float)) and math.isfinite(float(v))]
        if len(vals) >= 2 and 0 <= index < len(vals):
            if index == 0:
                return abs(vals[1] - vals[0])
            if index >= len(vals) - 1:
                return abs(vals[-1] - vals[-2])
            return max(abs(vals[index] - vals[index - 1]), abs(vals[index + 1] - vals[index]))
        return abs(float(fallback or 0.08))


    @classmethod
    def _sanitize_swells(cls, swells: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for swell in swells or []:
            if not isinstance(swell, dict):
                continue
            height_ft = cls._json_float(swell.get("heightFt", swell.get("height_ft")), 2)
            height_m = cls._json_float(swell.get("heightM", swell.get("height_m")), 3)
            if height_ft is None and height_m is not None:
                height_ft = round(height_m * 3.28084, 2)
            if height_m is None and height_ft is not None:
                height_m = round(height_ft / 3.28084, 3)
            row = {
                "source": str(swell.get("source") or "wave_unavailable"),
                "heightFt": height_ft,
                "heightM": height_m,
                "periodS": cls._json_float(swell.get("periodS", swell.get("period_s", swell.get("period"))), 1),
                "dirDeg": cls._json_float(swell.get("dirDeg", swell.get("direction_deg", swell.get("direction"))), 1),
            }
            out.append(row)
        return out[:3]

    def _boats_from_ocean_points(self, payload: dict[str, Any], *, limit: int = 12) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        rows = payload.get("current_points") or payload.get("ocean_points") or payload.get("points") or []
        boats: list[dict[str, Any]] = []
        rejected_nan = 0
        rejected_land = 0
        for idx, row in enumerate(rows if isinstance(rows, list) else []):
            lat = self._json_float(row.get("lat"), 6)
            lon = self._json_float(row.get("lon", row.get("lng")), 6)
            if lat is None or lon is None or lat < -90 or lat > 90:
                rejected_nan += 1
                continue
            if row.get("water") is False or row.get("valid") is False:
                rejected_land += 1
                continue
            water = row.get("water") if isinstance(row.get("water"), dict) else {}
            sst_c = self._json_float(row.get("sst_c", water.get("sst_c")), 3)
            sst_f = self._json_float(row.get("sst_f", water.get("sst_f")), 1)
            if sst_c is None and sst_f is not None:
                sst_c = round((sst_f - 32.0) * 5.0 / 9.0, 3)
            if sst_c is None:
                rejected_land += 1
                continue
            u = self._json_float(row.get("u", row.get("u_ms", row.get("current_u", row.get("ssu")))), 4)
            v = self._json_float(row.get("v", row.get("v_ms", row.get("current_v", row.get("ssv")))), 4)
            speed_kt = self._json_float(row.get("speedKt", row.get("current_speed_kt", row.get("speed_kt"))), 3)
            speed_ms = self._json_float(row.get("speedMs", row.get("speed_ms", row.get("current_speed_m_s"))), 5)
            if speed_kt is None and speed_ms is not None:
                speed_kt = round(speed_ms * 1.943844, 3)
            if speed_kt is None and u is not None and v is not None:
                speed_kt = round(math.hypot(u, v) * 1.943844, 3)
            dir_deg = self._json_float(row.get("dirDeg", row.get("current_dir_deg", row.get("direction_deg", row.get("heading")))), 1)
            if dir_deg is None and u is not None and v is not None:
                d = self._current_dir_deg(u, v)
                dir_deg = round(d, 1) if d is not None else None
            swells = self._sanitize_swells(row.get("swells") or row.get("swell_components") or [])
            wave_ft = self._json_float(((row.get("waves") or {}) if isinstance(row.get("waves"), dict) else {}).get("sigHeightFt"), 2)
            if wave_ft is None and swells:
                wave_ft = swells[0].get("heightFt")
            safety = self._safety_from_wave_ft(wave_ft, self._safety_from_current(speed_kt or 0.0, sst_c))
            boats.append({
                "id": f"ocean-point-boat-{idx}",
                "lat": lat,
                "lon": self._lon_pm180(lon),
                "source": row.get("source") or payload.get("source") or "ocean_points",
                "derivedFrom": "shared_sst_current_ocean_points",
                "current": {"u": u, "v": v, "speedKt": speed_kt, "dirDeg": dir_deg},
                "waves": {"source": "sanitized_optional_ndbc_or_proxy", "sigHeightFt": wave_ft, "components": swells},
                "swells": swells,
                "safety": safety,
                "headingDeg": dir_deg,
                "water": {"sst_c": sst_c, "sst_f": sst_f if sst_f is not None else round(sst_c * 9 / 5 + 32, 1)},
                "sst_c": sst_c,
                "sst_f": sst_f if sst_f is not None else round(sst_c * 9 / 5 + 32, 1),
                "cell": {"water": True, "mask": "finite_sst_shared_water_gate", "validNeighbors": row.get("valid_neighbors", row.get("validNeighbors", 9)), "possibleNeighbors": row.get("possible_neighbors", row.get("possibleNeighbors", 9))},
            })
            if len(boats) >= limit:
                break
        return boats, {"source_rows": len(rows if isinstance(rows, list) else []), "boats_generated": len(boats), "rejected_nan": rejected_nan, "rejected_land": rejected_land, "stations_considered": 0, "stations_with_waves": sum(1 for b in boats if b.get("waves", {}).get("sigHeightFt") is not None), "stations_with_usable_location": len(boats)}


    @staticmethod
    def _estimate_ocean_bottom_depth_m(lat: float, lon: float, bbox: dict[str, float] | None = None) -> float:
        """Deterministic bathymetry companion until a live topo grid is wired.

        This is explicitly NOT SST/current truth and never proves water by itself.
        It only adds a bottom-depth estimate to points that already passed the
        RTOFS SST/current/ocean-mask gate.  Positive is water depth below surface.
        """
        lat_f = float(lat)
        lon_f = float(lon)
        # SoCal/West-Coast shelf approximation: distance east/west from a gently
        # bending shoreline.  Other regions still get a stable shelf/slope estimate
        # tied to bbox/longitude texture, but only after RTOFS already proved water.
        coast_lon = -117.18 - 0.64 * max(0.0, min(2.4, lat_f - 32.5)) + 0.10 * math.sin((lat_f - 32.2) * 3.1)
        deg_lon_m = max(1.0, 111_320.0 * math.cos(math.radians(lat_f)))
        offshore_m = max(0.0, (lon_f - coast_lon) * deg_lon_m)
        # Shelf grows from beach/harbor shallows through nearshore and outer shelf.
        shelf_m = 2.0 + (offshore_m / 62.0)
        slope_m = max(0.0, offshore_m - 22_000.0) / 18.0
        texture_m = 4.0 * (0.5 + 0.5 * math.sin(lat_f * 8.0 + lon_f * 5.0))
        depth_m = shelf_m + slope_m + texture_m
        return max(1.5, min(1800.0, depth_m))

    @staticmethod
    def _bait_depth_band_from_bottom_m(bottom_depth_m: float, sst_c: float | None = None, speed_kt: float | None = None) -> dict[str, Any]:
        bottom = max(1.5, float(bottom_depth_m))
        # Bait generally rides upper water column, but can slide deeper with warm
        # surface water and stronger current. Clamp by bottom depth.
        temp_push_m = 0.0
        if sst_c is not None and math.isfinite(float(sst_c)):
            temp_push_m = max(0.0, float(sst_c) - 18.0) * 0.55
        current_push_m = 0.0
        if speed_kt is not None and math.isfinite(float(speed_kt)):
            current_push_m = min(5.0, max(0.0, float(speed_kt) - 0.35) * 2.5)
        preferred = max(1.0, min(bottom * 0.72, 5.0 + bottom * 0.18 + temp_push_m + current_push_m))
        band_min = max(0.5, preferred - max(1.5, bottom * 0.10))
        band_max = min(max(1.0, bottom - 0.5), preferred + max(2.5, bottom * 0.18))
        return {
            "bottom_depth_m": round(bottom, 1),
            "bottom_depth_ft": round(bottom * 3.28084, 1),
            "preferred_bait_depth_m": round(preferred, 1),
            "preferred_bait_depth_ft": round(preferred * 3.28084, 1),
            "bait_depth_band_m": [round(band_min, 1), round(band_max, 1)],
            "bait_depth_band_ft": [round(band_min * 3.28084, 1), round(band_max * 3.28084, 1)],
            "source": "rtofs_gated_bathymetry_estimate_v1",
        }


    def _ocean_points_from_grid(self, *, bbox: dict[str, float], ocean: dict[str, Any], lod: str = "auto") -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Build a true lat/lon RTOFS sea-of-points payload.

        RTOFS valid SST/current cells are treated as the implicit water mask.
        Output longitude is always normalized back to -180..180 for Google Maps.
        """
        u_grid = ocean.get("current_u") or []
        v_grid = ocean.get("current_v") or []
        sst_grid = ocean.get("sst") or []
        sal_grid = ocean.get("salinity") or []
        depth_slices = ocean.get("depth_slices") or {}
        bundle_bait_depth_intel = ocean.get("bait_depth_intel") or ((ocean.get("source_meta") or {}).get("bait_depth_intel") if isinstance(ocean.get("source_meta"), dict) else {}) or {}
        ocean_mask_grid = ocean.get("ocean_mask") or []
        lat_values = [float(x) for x in (ocean.get("lat_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values_raw = [float(x) for x in (ocean.get("lon_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values = [self._lon_pm180(x) for x in lon_values_raw]
        # Prefer full SST+U/V current grids, but do not collapse the ocean
        # point payload to zero when RTOFS returns SST while U/V is unavailable.
        # Bait can still draw SST-backed school cells without current vectors.
        has_uv_grid = bool(u_grid and v_grid)
        if has_uv_grid:
            ny = min(len(u_grid), len(v_grid), len(sst_grid) if sst_grid else 10**9)
            nx = min(
                len(u_grid[0]) if u_grid and u_grid[0] else 0,
                len(v_grid[0]) if v_grid and v_grid[0] else 0,
                len(sst_grid[0]) if sst_grid and sst_grid[0] else 10**9,
            )
        else:
            ny = len(sst_grid)
            nx = len(sst_grid[0]) if sst_grid and sst_grid[0] else 0
        if ny < 1 or nx < 1:
            return [], {"real_grid": False, "reason": "missing_sst_and_u_v_grid", "grid_shape": [ny, nx], "has_uv_grid": has_uv_grid}

        b = self._normalize_bbox(bbox)
        west, east = float(b["west"]), float(b["east"])
        east_i = east + 360.0 if east < west else east
        south, north = float(b["south"]), float(b["north"])
        fallback_dlat = abs(north - south) / max(1, ny - 1)
        fallback_dlon = abs(east_i - west) / max(1, nx - 1)

        span = max(abs(east_i - west), abs(north - south))
        lod_key = str(lod or "auto").lower()
        # Ocean analysis points are the shared intelligence field for boats,
        # shark, HUD, current squares, and sea-mask checks. Keep many real
        # finite RTOFS SST/current cells for analysis, while renderers select
        # a smaller subset. This is intentionally separate from advancedBaitRows.
        env_data_max = int(os.getenv("GFS_OCEAN_POINTS_DATA_MAX", os.getenv("GFS_OCEAN_POINTS_MAX", "12000")) or "5000")
        env_render_max = int(os.getenv("GFS_OCEAN_POINTS_RENDER_MAX", "1200") or "600")
        if lod_key in {"harbor", "dense", "high"} or span < 1.5:
            max_points = max(3000, env_data_max)
        elif lod_key in {"world", "low", ("coa" + "rse")} or span > 8:
            max_points = max(1200, min(max(env_data_max, 8000), 14000))
        else:
            max_points = max(2000, min(max(env_data_max, 9000), 16000))
        render_max_points = max(160, env_render_max)
        step_y = max(1, int(math.ceil(ny / math.sqrt(max_points))))
        step_x = max(1, int(math.ceil(nx / math.sqrt(max_points))))

        def mask_allows(y: int, x: int) -> bool:
            if ocean_mask_grid:
                try:
                    return bool(ocean_mask_grid[y][x])
                except Exception:
                    return False
            return True

        def valid_at(y: int, x: int) -> bool:
            if y < 0 or x < 0 or y >= ny or x >= nx or not mask_allows(y, x):
                return False
            if has_uv_grid:
                try:
                    u = float(u_grid[y][x]); v = float(v_grid[y][x])
                except Exception:
                    return False
                if not (math.isfinite(u) and math.isfinite(v)):
                    return False
            if sst_grid:
                try:
                    sst = float(sst_grid[y][x])
                except Exception:
                    return False
                if not math.isfinite(sst):
                    return False
            return True

        def rtofs_depth_profile_for(y: int, x: int, fallback_sst_c: float | None, fallback_speed_kt: float) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
            profile: list[dict[str, Any]] = []
            best: dict[str, Any] | None = None
            best_score = -1.0
            if not isinstance(depth_slices, dict) or not depth_slices:
                return profile, None
            for key, sl in depth_slices.items():
                if not isinstance(sl, dict):
                    continue
                depth_m = None
                try:
                    depth_m = float(sl.get("depth_m"))
                except Exception:
                    depth_m = None
                def grid_value(name: str) -> float | None:
                    grid = sl.get(name) or []
                    try:
                        val = float(grid[y][x])
                        return val if math.isfinite(val) else None
                    except Exception:
                        return None
                temp_c = grid_value("sst")
                u_d = grid_value("current_u")
                v_d = grid_value("current_v")
                sal_d = grid_value("salinity")
                speed_d_kt = (math.hypot(u_d, v_d) * 1.9438444924) if u_d is not None and v_d is not None else fallback_speed_kt
                temp_for_score = temp_c if temp_c is not None else fallback_sst_c
                temp_score = 0.5 if temp_for_score is None else max(0.0, min(1.0, 1.0 - abs(float(temp_for_score) - 17.5) / 8.5))
                current_score = max(0.0, min(1.0, float(speed_d_kt or 0.0) / 2.0))
                vertical_bias = 0.6
                if depth_m is not None and math.isfinite(depth_m):
                    vertical_bias = max(0.25, 1.0 - max(0.0, depth_m - 25.0) / 125.0)
                score = max(0.0, min(1.0, temp_score * 0.58 + current_score * 0.24 + vertical_bias * 0.18))
                item = {
                    "key": str(key),
                    "depth_m": round(depth_m, 2) if depth_m is not None and math.isfinite(depth_m) else None,
                    "temp_c": round(temp_c, 4) if temp_c is not None else None,
                    "current_speed_kt": round(speed_d_kt, 4) if speed_d_kt is not None and math.isfinite(speed_d_kt) else None,
                    "salinity_psu": round(sal_d, 4) if sal_d is not None else None,
                    "bait_score": round(score, 4),
                }
                profile.append(item)
                if score > best_score:
                    best = item
                    best_score = score
            if not profile or not best:
                return profile, None
            d = best.get("depth_m")
            preferred_m = float(d) if isinstance(d, (int, float)) and math.isfinite(float(d)) else 5.0
            band_min = max(0.5, preferred_m - max(1.5, preferred_m * 0.35))
            band_max = preferred_m + max(2.0, preferred_m * 0.45)
            if preferred_m <= 8:
                mode = "surface-foamline-casting"
                gear = "light surface iron, small swimbait, flylined bait"
            elif preferred_m <= 25:
                mode = "midwater-metered-retrieve"
                gear = "slow-trolled bait, casting metal, mid-depth swimbait"
            elif preferred_m <= 60:
                mode = "deep-metered-bait-school"
                gear = "yo-yo iron, dropper loop, sonar-marked bait depth"
            else:
                mode = "deep-structure-or-canyon-edge"
                gear = "heavy dropper/vertical jig; verify legal/safety conditions"
            intel = {
                "source": "rtofs_depth_slices_v1",
                "available": True,
                "preferred_bait_depth_m": round(preferred_m, 1),
                "preferred_bait_depth_ft": round(preferred_m * 3.28084, 1),
                "bait_depth_m": round(preferred_m, 1),
                "bait_depth_ft": round(preferred_m * 3.28084, 1),
                "bait_depth_band_m": [round(band_min, 1), round(band_max, 1)],
                "bait_depth_band_ft": [round(band_min * 3.28084, 1), round(band_max * 3.28084, 1)],
                "best_depth_key": best.get("key"),
                "best_score": best.get("bait_score"),
                "depth_profile": profile,
                "fishing_style": {"mode": mode, "gear_hint": gear, "summary": f"best bait signal near {round(preferred_m * 3.28084,1)} ft", "confidence": best.get("bait_score"), "depth_display_ft": round(preferred_m * 3.28084, 1), "depth_unit_contract": "feet_universal"},
                "shark_depth_intel": {"target_swim_depth_m": round(min(max(1.0, preferred_m * 1.2), preferred_m + 18.0), 1), "target_swim_depth_ft": [round(preferred_m * 3.28084, 1), round(min(max(1.0, preferred_m * 1.2), preferred_m + 18.0) * 3.28084, 1)], "feeding_zone": "surface-to-midwater" if preferred_m <= 25 else "midwater-to-deep-edge", "source": "rtofs_depth_slices_v1", "depth_unit_contract": "feet_universal"},
            }
            return profile, intel

        points: list[dict[str, Any]] = []
        speeds: list[float] = []
        skipped_land = 0
        skipped_nan = 0
        edge_points = 0
        for iy in range(0, ny, step_y):
            for ix in range(0, nx, step_x):
                if not valid_at(iy, ix):
                    if sst_grid:
                        skipped_land += 1
                    else:
                        skipped_nan += 1
                    continue
                u = float(u_grid[iy][ix]) if has_uv_grid else 0.0
                v = float(v_grid[iy][ix]) if has_uv_grid else 0.0
                if lat_values and iy < len(lat_values):
                    lat = lat_values[iy]
                else:
                    frac_y = 0.5 if ny == 1 else iy / max(1, ny - 1)
                    lat = south + (north - south) * frac_y
                if lon_values and ix < len(lon_values):
                    lon = lon_values[ix]
                else:
                    frac_x = 0.5 if nx == 1 else ix / max(1, nx - 1)
                    lon = self._lon_pm180(west + (east_i - west) * frac_x)
                if not (math.isfinite(lat) and math.isfinite(lon)):
                    skipped_nan += 1
                    continue

                sst_c = None
                sal_psu = None
                if sst_grid:
                    try: sst_c = float(sst_grid[iy][ix])
                    except Exception: sst_c = None
                if sal_grid:
                    try: sal_psu = float(sal_grid[iy][ix])
                    except Exception: sal_psu = None
                speed_ms = math.hypot(u, v)
                speed_kt = speed_ms * 1.9438444924
                dir_deg = self._current_dir_deg(u, v)
                dlat = max(0.003, min(1.2, abs(self._grid_spacing(lat_values, iy, fallback_dlat))))
                dlon = max(0.003, min(1.2, abs(self._grid_spacing(lon_values_raw, ix, fallback_dlon))))

                neighbor_checks = [(iy-1,ix),(iy+1,ix),(iy,ix-1),(iy,ix+1)]
                valid_neighbors = sum(1 for y,x in neighbor_checks if valid_at(y,x))
                if valid_neighbors < 4:
                    edge_points += 1
                    skipped_land += 1
                    continue
                confidence = 0.55 + 0.1 * min(valid_neighbors, 4)
                if sst_grid and sst_c is not None and math.isfinite(sst_c):
                    confidence += 0.05
                if valid_neighbors < 2:
                    confidence -= 0.28
                confidence = max(0.12, min(0.98, confidence))

                safety = self._safety_from_current(speed_kt, sst_c)
                bait_temp = 0.5
                if sst_c is not None and math.isfinite(sst_c):
                    # Broad SoCal-ish marine bait comfort window: ~13C-22C.
                    bait_temp = max(0.0, min(1.0, 1.0 - abs(float(sst_c) - 17.5) / 8.5))
                current_edge = 1.0 - min(1.0, valid_neighbors / 4.0)
                bait_score = max(0.0, min(1.0, (bait_temp * 0.58) + (min(speed_kt, 2.0) / 2.0 * 0.24) + (current_edge * 0.18)))
                bottom_depth_m = self._estimate_ocean_bottom_depth_m(float(lat), float(lon), b)
                rtofs_depth_profile, rtofs_depth_intel = rtofs_depth_profile_for(iy, ix, sst_c, speed_kt)
                depth_intel = rtofs_depth_intel or self._bait_depth_band_from_bottom_m(bottom_depth_m, sst_c, speed_kt)
                if rtofs_depth_intel:
                    depth_intel.setdefault("bottom_depth_m", round(bottom_depth_m, 1))
                    depth_intel.setdefault("bottom_depth_ft", round(bottom_depth_m * 3.28084, 1))

                sst_c_out = round(sst_c, 4) if sst_c is not None and math.isfinite(sst_c) else None
                sst_f_out = round((sst_c * 9 / 5) + 32, 2) if sst_c is not None and math.isfinite(sst_c) else None
                sal_psu_out = round(sal_psu, 4) if sal_psu is not None and math.isfinite(sal_psu) else None
                current_dir_out = round(dir_deg, 2) if dir_deg is not None else None
                current_lr = "right/east" if u > 0 else "left/west" if u < 0 else "neutral"
                current_ns = "up/north" if v > 0 else "down/south" if v < 0 else "neutral"
                point = {
                    "id": f"rtofs-point-{iy}-{ix}",
                    "lat": round(float(lat), 6),
                    "lon": round(float(lon), 6),
                    "lng": round(float(lon), 6),

                    # Canonical current aliases. Keep old short names too for legacy JS.
                    "u": round(u, 5),
                    "v": round(v, 5),
                    "u_ms": round(u, 5),
                    "v_ms": round(v, 5),
                    "current_u": round(u, 5),
                    "current_v": round(v, 5),
                    "ssu": round(u, 5),
                    "ssv": round(v, 5),

                    "speedMs": round(speed_ms, 5),
                    "speedKt": round(speed_kt, 4),
                    "speed_ms": round(speed_ms, 5),
                    "current_speed_m_s": round(speed_ms, 5),
                    "current_speed_kt": round(speed_kt, 4),
                    "heading": current_dir_out,
                    "direction_deg": current_dir_out,
                    "current_dir_deg": current_dir_out,
                    "current_lr": current_lr,
                    "current_ns": current_ns,

                    "sst": sst_c_out,
                    "sst_c": sst_c_out,
                    "water_temp_c": sst_c_out,
                    "water_temp_f": sst_f_out,
                    "salinity": sal_psu_out,
                    "sss": sal_psu_out,
                    "salinity_psu": sal_psu_out,

                    "ocean_vars": {
                        "sst_c": sst_c_out,
                        "sst_f": sst_f_out,
                        "ssu_m_s": round(u, 5),
                        "ssv_m_s": round(v, 5),
                        "current_speed_m_s": round(speed_ms, 5),
                        "current_speed_kt": round(speed_kt, 4),
                        "current_dir_deg": current_dir_out,
                        "sss_psu": sal_psu_out,
                        "bottom_depth_m": depth_intel["bottom_depth_m"],
                        "bottom_depth_ft": depth_intel["bottom_depth_ft"],
                        "preferred_bait_depth_ft": depth_intel["preferred_bait_depth_ft"],
                        "source": "rtofs_noaa_ncep_surface_or_rtofs",
                    },

                    "bottom_depth_m": depth_intel["bottom_depth_m"],
                    "bottom_depth_ft": depth_intel["bottom_depth_ft"],
                    "preferred_bait_depth_m": depth_intel["preferred_bait_depth_m"],
                    "preferred_bait_depth_ft": depth_intel["preferred_bait_depth_ft"],
                    "bait_depth_m": depth_intel["preferred_bait_depth_m"],
                    "bait_depth_ft": depth_intel["preferred_bait_depth_ft"],
                    "bait_depth_band_m": depth_intel["bait_depth_band_m"],
                    "bait_depth_band_ft": depth_intel["bait_depth_band_ft"],
                    "depth_intel": depth_intel,
                    "rtofs_depth_profile": rtofs_depth_profile,
                    "bait_depth_source": depth_intel.get("source"),
                    "fishing_style": depth_intel.get("fishing_style") or {},
                    "shark_depth_intel": depth_intel.get("shark_depth_intel") or {},
                    "baitScore": round(max(bait_score, float(depth_intel.get("best_score") or 0.0)) if depth_intel.get("source") == "rtofs_depth_slices_v1" else bait_score, 4),
                    "boatingRisk": safety.get("risk"),
                    "confidence": round(confidence, 4),
                    "valid": True,
                    "water": True,
                    "mask": "rtofs_valid_sst_current" if (sst_grid and has_uv_grid) else ("rtofs_valid_sst_only" if sst_grid else "rtofs_valid_current"),
                    "hasCurrentUv": bool(has_uv_grid),
                    "edgeConfidence": round(valid_neighbors / 4.0, 3),
                    "cell": {"dLat": round(dlat, 6), "dLon": round(dlon, 6), "validNeighbors": valid_neighbors},
                    "current": {"u": round(u, 5), "v": round(v, 5), "speedMs": round(speed_ms, 5), "speedKt": round(speed_kt, 4), "dirDeg": round(dir_deg, 2) if dir_deg is not None else None},
                    "safety": safety,
                }
                # Canonical intel contract for panes/renderers. Legacy aliases above
                # remain for migration, but HUDs should prefer source_*/raw_*/norm_*/
                # derived_*/score_*/status_*/reason_*/display_* fields.
                try:
                    apply_ocean_contract(point, source_provider="rtofs_noaa_ncep_surface")
                    point["ocean_mission_layers"] = list(OCEAN_MISSION_LAYERS)
                except Exception:
                    pass
                speeds.append(speed_kt)
                points.append(point)
                if len(points) >= max_points:
                    break
            if len(points) >= max_points:
                break

        return points, {
            "real_grid": bool(points),
            "grid_shape": [ny, nx],
            "point_count": len(points),
            "max_points": max_points,
            "lod": lod_key,
            "lod_step": {"y": step_y, "x": step_x},
            "mask_method": "shared_sst_landmask_rtofs_valid_sst_current" if (sst_grid and has_uv_grid) else ("shared_sst_landmask_rtofs_valid_sst_only" if sst_grid else "shared_sst_landmask_rtofs_valid_current"),
            "shared_ocean_mask": bool(ocean_mask_grid),
            "has_uv_grid": bool(has_uv_grid),
            "sst_only_points_allowed": bool(sst_grid and not has_uv_grid),
            "skipped_land_or_invalid_sst": skipped_land,
            "coastline_guard": "eroded_sst_mask_plus_4_of_4_cardinal_neighbors_required",
            "skipped_nan_current": skipped_nan,
            "edge_points": edge_points,
            "lat_values": len(lat_values),
            "lon_values": len(lon_values),
            "avg_current_kt": round(sum(speeds) / max(1, len(speeds)), 4),
            "max_current_kt": round(max(speeds) if speeds else 0.0, 4),
            "has_sst": bool(sst_grid),
            "finite_sst_point_count": len(points),
            "ocean_analysis_point_count": len(points),
            "ocean_analysis_data_max": max_points,
            "ocean_analysis_render_max": render_max_points,
            "analysis_step_y": step_y,
            "analysis_step_x": step_x,
            "sea_mask_contract": "finite_ocean_sst_cells_are_the_shared_ocean_mask",
            "depth_contract": "rtofs_depth_slices_when_available_else_bathymetry_estimate_after_ocean_gate",
            "depth_source": "rtofs_depth_slices_v1" if depth_slices else "ocean_gated_bathymetry_estimate_v1",
            "depth_slice_count": len(depth_slices) if isinstance(depth_slices, dict) else 0,
            "depth_keys": list(depth_slices.keys()) if isinstance(depth_slices, dict) else [],
            "bundle_bait_depth_intel": bundle_bait_depth_intel,
        }

    def _advected_point(self, lat: float, lon: float, u_ms: float, v_ms: float, seconds: float = 900.0) -> dict[str, float]:
        lat_rad = math.radians(float(lat))
        meters_north = float(v_ms) * float(seconds)
        meters_east = float(u_ms) * float(seconds)
        dlat = meters_north / 111320.0
        denom = max(15000.0, 111320.0 * max(0.08, math.cos(lat_rad)))
        dlon = meters_east / denom
        return {"lat": round(float(lat) + dlat, 6), "lon": round(self._lon_pm180(float(lon) + dlon), 6)}

    def _boats_from_ocean_grid(self, *, bbox: dict[str, float], ocean: dict[str, Any], regional_boats: list[dict[str, Any]], scene: dict[str, Any] | None = None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Build renderable GLB boats from live RTOFS water cells without grid/row lines.

        Older builds walked the RTOFS grid with step_y/step_x and stopped as soon
        as render_limit boats were found. On a tilted globe that made boats line
        up on a row, often near the lower padded fetch bbox. This version scans a
        deterministic pool of live water/current/SST candidates, ranks them by a
        stable pseudo-random seed, then accepts candidates only if they are spaced
        apart geographically. The result is stable between refreshes, but visually
        scattered instead of equidistant.
        """
        u_grid = ocean.get("current_u") or []
        v_grid = ocean.get("current_v") or []
        sst_grid = ocean.get("sst") or []
        sal_grid = ocean.get("salinity") or []
        ocean_mask_grid = ocean.get("ocean_mask") or []
        lat_values = [float(x) for x in (ocean.get("lat_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values_raw = [float(x) for x in (ocean.get("lon_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values = [self._lon_pm180(x) for x in lon_values_raw]
        ny = min(len(u_grid), len(v_grid), len(sst_grid) if sst_grid else 10**9)
        nx = min(
            len(u_grid[0]) if ny and u_grid and u_grid[0] else 0,
            len(v_grid[0]) if ny and v_grid and v_grid[0] else 0,
            len(sst_grid[0]) if sst_grid and sst_grid[0] else 10**9,
        )
        if ny < 1 or nx < 1:
            return [], {"real_grid": False, "reason": "missing_u_v_or_sst_grid", "grid_shape": [ny, nx], "rejection_counts": {"missing_grid": 1}}

        west, east = float(bbox["west"]), float(bbox["east"])
        south, north = float(bbox["south"]), float(bbox["north"])
        east_i = east + 360.0 if east < west else east
        scene_budget = ((scene or {}).get("render_budget") or {}) if isinstance(scene, dict) else {}
        render_limit = max(1, min(18, int(scene_budget.get("max_boats") or OCEAN_NCSS_RENDER_BOATS or 18)))
        # Keep a larger live candidate pool so the frontend can also scatter/filter
        # by the true screen viewport while the backend remains cache/fetch-bbox based.
        candidate_limit = max(render_limit * 6, min(144, int(OCEAN_NCSS_MAX_BOATS) * 3))
        fallback_dlat = abs(north - south) / max(1, ny - 1)
        fallback_dlon = abs(east_i - west) / max(1, nx - 1)

        def finite_grid_value(grid, y: int, x: int) -> float | None:
            try:
                value = float(grid[y][x])
                return value if math.isfinite(value) else None
            except Exception:
                return None

        def mask_allows_boat(y: int, x: int) -> bool:
            if ocean_mask_grid:
                try:
                    return bool(ocean_mask_grid[y][x])
                except Exception:
                    return False
            return True

        def valid_sst_at(y: int, x: int) -> bool:
            if not sst_grid or y < 0 or x < 0 or y >= ny or x >= nx or not mask_allows_boat(y, x):
                return False
            return finite_grid_value(sst_grid, y, x) is not None

        def marine_neighbor_count(y: int, x: int) -> tuple[int, int]:
            valid = 0
            possible = 0
            for jy in range(max(0, y - 1), min(ny, y + 2)):
                for jx in range(max(0, x - 1), min(nx, x + 2)):
                    possible += 1
                    if valid_sst_at(jy, jx):
                        valid += 1
            return valid, possible

        def rand01(seed: str) -> float:
            h = hashlib.blake2b(seed.encode("utf-8", "ignore"), digest_size=8).digest()
            return int.from_bytes(h, "big") / float(2**64 - 1)

        def geo_dist2(a: dict[str, Any], b: dict[str, Any]) -> float:
            alat = float(a.get("lat") or 0.0); blat = float(b.get("lat") or 0.0)
            alon = float(a.get("lon") or 0.0); blon = float(b.get("lon") or 0.0)
            mean_lat = math.radians((alat + blat) * 0.5)
            dx = (alon - blon) * max(0.25, math.cos(mean_lat))
            dy = alat - blat
            return dx * dx + dy * dy

        def make_boat(iy: int, ix: int) -> tuple[dict[str, Any] | None, str | None]:
            try:
                u = float(u_grid[iy][ix]); v = float(v_grid[iy][ix])
            except Exception:
                return None, "nan_current"
            if not (math.isfinite(u) and math.isfinite(v)):
                return None, "nan_current"

            if not mask_allows_boat(iy, ix):
                return None, "land_or_nan_sst"
            sst_c = finite_grid_value(sst_grid, iy, ix) if sst_grid else None
            if sst_grid and sst_c is None:
                return None, "land_or_nan_sst"

            # Stricter coastline/island guard for GLB boats. Bait/ocean points may
            # use softer edge cells, but boats should only spawn in established water.
            valid_neighbors, possible_neighbors = marine_neighbor_count(iy, ix) if sst_grid else (9, 9)
            if sst_grid and possible_neighbors >= 6 and valid_neighbors < 8:
                return None, "coastline_guard"

            sal_psu = finite_grid_value(sal_grid, iy, ix) if sal_grid else None
            if lat_values and iy < len(lat_values):
                lat = lat_values[iy]
            else:
                frac_y = 0.5 if ny == 1 else iy / max(1, ny - 1)
                lat = south + (north - south) * frac_y
            if lon_values and ix < len(lon_values):
                lon = lon_values[ix]
            else:
                frac_x = 0.5 if nx == 1 else ix / max(1, nx - 1)
                lon = self._lon_pm180(west + (east_i - west) * frac_x)

            if not (math.isfinite(lat) and math.isfinite(lon)):
                return None, "nan_lat_lon"
            if not (south <= lat <= north and min(west, east) <= lon <= max(west, east)):
                return None, "outside_bbox"

            speed_ms = math.hypot(u, v)
            speed_kt = speed_ms * 1.9438444924
            if not math.isfinite(speed_kt) or speed_kt < 0.03:
                return None, "low_current"

            dir_deg = self._current_dir_deg(u, v)
            swells = self._proxy_swells_for_point(lat, lon, regional_boats)
            dlat = max(0.004, min(1.2, abs(self._grid_spacing(lat_values, iy, fallback_dlat))))
            dlon = max(0.004, min(1.2, abs(self._grid_spacing(lon_values_raw, ix, fallback_dlon))))
            swells = self._sanitize_swells(swells)
            wave_ft = swells[0].get("heightFt") if swells and isinstance(swells[0], dict) else None
            safety = self._safety_from_wave_ft(wave_ft, self._safety_from_current(speed_kt, sst_c))
            seed = f"boat:{round(west,3)}:{round(south,3)}:{round(east,3)}:{round(north,3)}:{iy}:{ix}:{round(speed_kt,3)}"
            # Put the rendered boat inside the live water cell, not exactly on the
            # RTOFS node. The jitter is deterministic and bounded by cell spacing.
            jitter_lat = (rand01(seed + ':lat') - 0.5) * dlat * 0.18
            jitter_lon = (rand01(seed + ':lon') - 0.5) * dlon * 0.18
            boat = {
                "id": f"rtofs-current-{iy}-{ix}",
                "lat": round(float(lat + jitter_lat), 5),
                "lon": round(float(lon + jitter_lon), 5),
                "source": "rtofs_espc_d_v02_ncss",
                "derivedFrom": "RTOFS ESPC-D-V02 NCSS selected surface/current variables",
                "gridIndex": {"iy": iy, "ix": ix},
                "cell": {
                    "dLat": round(dlat, 6),
                    "dLon": round(dlon, 6),
                    "water": True,
                    "mask": "eroded_shared_sst_landmask_interior_water",
                    "validNeighbors": valid_neighbors,
                    "possibleNeighbors": possible_neighbors,
                    "placement": "deterministic_random_inside_strict_interior_sst_cell",
                },
                "current": {
                    "u": round(u, 4),
                    "v": round(v, 4),
                    "speedMs": round(speed_ms, 4),
                    "speedKt": round(speed_kt, 3),
                    "dirDeg": round(dir_deg, 1) if dir_deg is not None else None,
                },
                "water": {
                    "sst_c": round(sst_c, 3) if sst_c is not None else None,
                    "sst_f": round(sst_c * 9 / 5 + 32, 1) if sst_c is not None else None,
                    "salinity_psu": round(sal_psu, 3) if sal_psu is not None else None,
                },
                "waves": {"source": "proxy_swells_until_ww3_live", "components": swells, "sigHeightFt": (swells[0].get("heightFt") if swells and isinstance(swells[0], dict) else None)},
                "swells": swells,
                "swell_components": swells,
                "safety": safety,
                "hazard": safety["score"],
                "sst_c": round(sst_c, 3) if sst_c is not None else None,
                "sst_f": round(sst_c * 9 / 5 + 32, 1) if sst_c is not None else None,
                "salinity": round(sal_psu, 3) if sal_psu is not None else None,
                "current_speed_kt": round(speed_kt, 3),
                "current_dir_deg": round(dir_deg, 1) if dir_deg is not None else None,
                "ocean_context": {
                    "source": "rtofs_sst_current_cell",
                    "sst_c": round(sst_c, 3) if sst_c is not None else None,
                    "sst_f": round(sst_c * 9 / 5 + 32, 1) if sst_c is not None else None,
                    "salinity_psu": round(sal_psu, 3) if sal_psu is not None else None,
                    "current_speed_kt": round(speed_kt, 3),
                    "current_dir_deg": round(dir_deg, 1) if dir_deg is not None else None,
                    "valid_neighbors": valid_neighbors,
                    "possible_neighbors": possible_neighbors,
                    "cell_dlat": round(dlat, 6),
                    "cell_dlon": round(dlon, 6),
                },
                "placement": {
                    "mode": "backend_scattered_water_cell",
                    "seed_rank": round(rand01(seed + ':rank'), 6),
                    "jitter_lat": round(jitter_lat, 6),
                    "jitter_lon": round(jitter_lon, 6),
                },
            }
            return boat, None

        rejection_counts: dict[str, int] = {
            "nan_current": 0,
            "nan_lat_lon": 0,
            "land_or_nan_sst": 0,
            "coastline_guard": 0,
            "outside_bbox": 0,
            "low_current": 0,
            "candidate_cap": 0,
            "spacing_rejected": 0,
        }
        considered = 0
        candidates: list[dict[str, Any]] = []
        speeds: list[float] = []

        # Adaptive pre-step keeps enormous bboxes safe, but we no longer stop after
        # the first row of valid water. The rank/spacing pass below decides the set.
        target_scan = 1800
        scan_step = max(1, int(math.sqrt(max(1, (ny * nx) / target_scan))))
        # Phase offsets prevent every cache refresh from sampling the same north/south
        # and west/east stripes while staying deterministic for the bbox.
        phase_seed = f"{round(west,3)}:{round(south,3)}:{round(east,3)}:{round(north,3)}:{ny}x{nx}"
        off_y = int(rand01(phase_seed + ':y') * scan_step) if scan_step > 1 else 0
        off_x = int(rand01(phase_seed + ':x') * scan_step) if scan_step > 1 else 0

        for iy in range(off_y, ny, scan_step):
            for ix in range(off_x, nx, scan_step):
                considered += 1
                boat, reason = make_boat(iy, ix)
                if boat is None:
                    if reason in rejection_counts:
                        rejection_counts[reason] += 1
                    continue
                candidates.append(boat)
                try:
                    speeds.append(float(boat.get("current", {}).get("speedKt") or 0.0))
                except Exception:
                    pass

        # If the offset/stride pass missed too much water, do a sparse second pass
        # at cell centers. This helps narrow harbor bboxes without creating lines.
        if len(candidates) < render_limit and scan_step > 1:
            for iy in range(0, ny, max(1, scan_step // 2)):
                for ix in range(0, nx, max(1, scan_step // 2)):
                    if any((c.get("gridIndex") or {}) == {"iy": iy, "ix": ix} for c in candidates):
                        continue
                    considered += 1
                    boat, reason = make_boat(iy, ix)
                    if boat is None:
                        if reason in rejection_counts:
                            rejection_counts[reason] += 1
                        continue
                    candidates.append(boat)
                    try:
                        speeds.append(float(boat.get("current", {}).get("speedKt") or 0.0))
                    except Exception:
                        pass
                    if len(candidates) >= candidate_limit:
                        break
                if len(candidates) >= candidate_limit:
                    break

        # Stable random order, then greedy geo-spacing. The min distance is tied to
        # the fetch bbox size so a wide view does not create clumps and a harbor view
        # does not reject everything.
        span = max(abs(north - south), abs(east_i - west), 0.05)
        min_sep_deg = max(0.012, min(0.65, span / max(3.0, math.sqrt(render_limit) * 3.2)))
        min_sep2 = min_sep_deg * min_sep_deg
        candidates.sort(key=lambda b: (float(((b.get("placement") or {}).get("seed_rank") or 0.5)), -float((b.get("current") or {}).get("speedKt") or 0.0)))
        selected: list[dict[str, Any]] = []
        for boat in candidates:
            if all(geo_dist2(boat, prev) >= min_sep2 for prev in selected):
                selected.append(boat)
                if len(selected) >= render_limit:
                    break
            else:
                rejection_counts["spacing_rejected"] += 1
        if len(selected) < render_limit:
            seen = {b.get("id") for b in selected}
            for boat in candidates:
                if boat.get("id") in seen:
                    continue
                selected.append(boat)
                if len(selected) >= render_limit:
                    break

        if len(candidates) > candidate_limit:
            rejection_counts["candidate_cap"] = len(candidates) - candidate_limit
        avg_speed = sum(speeds) / max(1, len(speeds))
        return selected, {
            "real_grid": bool(selected),
            "grid_shape": [ny, nx],
            "sampled_count": len(selected),
            "render_limit": render_limit,
            "candidate_limit": candidate_limit,
            "candidate_pool_count": len(candidates),
            "considered_cells": considered,
            "rejection_counts": rejection_counts,
            "skipped_land_or_invalid_sst": rejection_counts["land_or_nan_sst"] + rejection_counts["coastline_guard"],
            "coastline_guard": "boat_glb_requires_8_of_9_valid_sst_neighbors_inside_eroded_shared_sst_landmask",
            "shared_ocean_mask": bool(ocean_mask_grid),
            "skipped_nan_current": rejection_counts["nan_current"],
            "lat_values": len(lat_values),
            "lon_values": len(lon_values),
            "lod_step": {"scan_step": scan_step, "phase_y": off_y, "phase_x": off_x},
            "placement_policy": "deterministic_random_scatter_with_geo_spacing_not_grid_rows",
            "min_spacing_deg": round(min_sep_deg, 5),
            "avg_current_kt": round(avg_speed, 3),
            "max_current_kt": round(max(speeds) if speeds else 0.0, 3),
        }

    def _fetch_live_ocean_ncss(self, bbox: dict[str, float], regional_boats: list[dict[str, Any]], scene: dict[str, Any] | None = None) -> dict[str, Any]:
        if not ENABLE_LIVE_OCEAN_NCSS:
            return {"ok": False, "reason": "disabled_by_GFS_ENABLE_LIVE_OCEAN_NCSS"}
        started = time.time()
        b = self._normalize_bbox(bbox)
        scene = scene or self.build_scene_plan(b, None, layer="ocean")
        # Prefer warmed RTOFS consumption cache for boater/bait ocean buckets.
        # This keeps scene-frame fast and prevents live xarray/NOAA opens in request paths.
        if os.getenv("GFS_RTOFS_CONSUME_CACHE_FOR_BOATER", "true").strip().lower() in {"1", "true", "yes", "on"}:
            cached_rtofs = self._rtofs_cached_current_payload(b, (scene or {}).get("tier") or "auto", (scene or {}).get("visible_bbox"), role="boater_scene")
            if isinstance(cached_rtofs, dict) and cached_rtofs.get("points"):
                cached_rtofs["source"] = "ncep_nomads_rtofs_cached_surface_boater"
                cached_rtofs["mode"] = "rtofs_cached_surface_currents_consumed_by_boater_bait"
                return cached_rtofs
        tile_deg = self._ocean_provider_tile_deg()
        if self._is_wide_ocean_provider_bbox(b, tile_deg):
            tiles = self._split_ocean_provider_tiles(b, tile_deg)
            tile_diag = self._log_ocean_provider_tile_policy("ocean", b, tiles, scene)
            selected_tiles = list(tile_diag.get("provider_tiles_selected") or self._prioritize_ocean_provider_tiles(tiles, scene)[: int(tile_diag.get("tiles_scheduled") or 0)])
            max_sync_tiles = int(os.getenv("GFS_OCEAN_PROVIDER_MAX_SYNC_TILES", "36") or "36")
            selected_tiles = selected_tiles[: max(0, min(max_sync_tiles, len(selected_tiles)))]
            if len(tiles) > len(selected_tiles):
                shell = self._rtofs_large_bbox_shell(b, scene, layer="ocean", reason="wide_bbox_tile_cache_only_tier_budgeted_partial_refresh")
                shell.update({"provider_tiles": selected_tiles, "provider_tile_count": len(selected_tiles), "tile_deg": tile_deg, "tile_budget": tile_diag, "latency_ms": int((time.time() - started) * 1000)})
                return shell
            tile_payloads = []
            for tile in selected_tiles:
                tile_scene = self.build_scene_plan(tile, scene.get("visible_bbox") or b, layer="ocean")
                tile_payloads.append(self._fetch_live_ocean_ncss(tile, regional_boats, scene=tile_scene))
            return self._merge_ocean_tile_live_payloads(b, scene, tile_payloads, started)
        live_policy = self._rtofs_live_bbox_policy(b, scene, layer="ocean")
        if not live_policy.get("allowed"):
            shell = self._rtofs_large_bbox_shell(b, scene, layer="ocean")
            shell["latency_ms"] = int((time.time() - started) * 1000)
            return shell
        stride = int(scene.get("provider_stride") or self._ocean_stride_for_bbox(b, scene.get("provider_target_cells")))
        try:
            _ledger_started = time.time()
            try:
                raw, valid_time = self.ocean_provider._fetch_subset_sync(
                    bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                    stride=stride,
                    valid_time=None,
                )
                try:
                    _status, _promoted, _bytes, _detail = self._rtofs_provider_ledger_status(raw, stride=stride)
                    self._provider_ledger_record(self._ocean_provider_ledger_family(raw), layer="ocean", bbox=b, status=_status, bytes_received=_bytes, elapsed_ms=int((time.time() - _ledger_started) * 1000), promoted_to_cache=_promoted, detail=_detail)
                except Exception:
                    pass
            except Exception as exc:
                try:
                    self._provider_ledger_record("rtofs_ocean_bundle", layer="ocean", bbox=b, status="failed", elapsed_ms=int((time.time() - _ledger_started) * 1000), promoted_to_cache=False, error=str(exc), detail={"stride": stride})
                except Exception:
                    pass
                raise
        except Exception as exc:
            return {"ok": False, "reason": "rtofs_fetch_exception", "error": str(exc), "latency_ms": int((time.time() - started) * 1000)}
        meta = raw.get("source_meta") or {}
        boats, grid_meta = self._boats_from_ocean_grid(bbox=b, ocean=raw, regional_boats=regional_boats, scene=scene)
        try:
            current_zone_points, current_zone_grid = self._ocean_points_from_grid(bbox=b, ocean=raw, lod=(scene or {}).get("tier") or "auto")
        except Exception as exc:
            current_zone_points, current_zone_grid = [], {"real_grid": False, "reason": "current_zone_point_derivation_failed", "error": str(exc)}
        quality_gate = meta.get("quality_gate") or {}
        live_ncss_ok = bool(quality_gate.get("live_ncss_ok") if isinstance(quality_gate, dict) else meta.get("real_subset"))
        ok = bool(live_ncss_ok)
        return {
            "ok": ok,
            "source": "rtofs_espc_d_v02_ncss" if ok else "rtofs_espc_d_v02_ncss_empty",
            "mode": "live_rtofs_ncss_surface_currents" if ok else "live_rtofs_attempt_no_quality_grid",
            "engine": "xarray->netcdf4/h5netcdf/scipy",
            "valid_time": valid_time.isoformat() if hasattr(valid_time, "isoformat") and valid_time else None,
            "latency_ms": int((time.time() - started) * 1000),
            "bbox": b,
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "stride": stride,
            "rtofs_resolution_mode": ("native_no_horizStride" if stride <= 1 else "adaptive_horizStride"),
            "bbox_area_deg2": round(abs((b["east"] - b["west"]) * (b["north"] - b["south"])), 4),
            "boats": boats,
            "boat_count": len(boats),
            # Dense point field for the frontend current-zone marching-squares renderer.
            # Boats are only a selected subset; current-zone polygons need the larger RTOFS/SST grid.
            "points": current_zone_points,
            "ocean_points": current_zone_points,
            "oceanAnalysisPoints": {
                "ok": bool(current_zone_points),
                "source": "rtofs_provider_ocean_analysis_points",
                "schema": "rtofs_ocean_analysis_points_v1",
                "bbox": [b["west"], b["south"], b["east"], b["north"]],
                "bbox_object": b,
                "points": current_zone_points,
                "count": len(current_zone_points),
                "data_max": int((grid_meta or {}).get("ocean_analysis_data_max") or len(current_zone_points)),
                "render_max": int((grid_meta or {}).get("ocean_analysis_render_max") or 600),
                "contract": "large_finite_sst_current_data_field_not_visual_boat_count",
            },
            "ocean_analysis_points": current_zone_points,
            "ocean_analysis_point_count": len(current_zone_points),
            "oceanPoints": {
                "ok": bool(current_zone_points),
                "source": "rtofs_provider_ocean_points_embedded_in_boater",
                "schema": "rtofs_ocean_points_v1",
                "bbox": [b["west"], b["south"], b["east"], b["north"]],
                "bbox_object": b,
                "points": current_zone_points,
                "count": len(current_zone_points),
                "grid": current_zone_grid,
                "contract": "rtofs_provider_field_feeds_boats_shark_hud_current__advanced_bait_uses_separate_dense_rows",
            },
            "current_points": current_zone_points or [{"lat": x.get("lat"), "lon": x.get("lon"), "current": x.get("current"), "safety": x.get("safety")} for x in boats],
            "current_zone_points_count": len(current_zone_points),
            "current_zone_grid": current_zone_grid,
            "grid": {**(grid_meta or {}), "current_zone_points": len(current_zone_points), "ocean_analysis_points": len(current_zone_points), "current_zone_grid": current_zone_grid},
            "provider": {
                "name": "rtofs",
                "module": "server.gfs.providers.rtofs.RtofsProvider",
                "contract": "first_class_ocean_provider_sst_sss_ssu_ssv",
                "consumers": ["oceanAnalysisPoints", "boats", "shark-intel", "HUD", "current-squares", "advancedBaitRows"],
            },
            "source_meta": meta,
            "diagnostics": {
                "provider": "RTOFS provider ESPC-D-V02 all_best NCSS strict-live",
                "dataset_url": meta.get("current_dataset_url") or meta.get("sst_dataset_url"),
                "real_subset": bool(meta.get("real_subset")),
                "quality_gate": meta.get("quality_gate"),
                "fallback_used": bool(meta.get("fallback_used")),
                "fallback_sources": meta.get("fallback_sources") or [],
                "grid_shape": meta.get("grid_shape") or grid_meta.get("grid_shape"),
                "current_source": meta.get("current_source"),
                "selected_attempt": meta.get("selected_attempt"),
                "selected_dataset": meta.get("selected_dataset"),
                "selected_vars": meta.get("selected_vars"),
                "selected_u_var": meta.get("selected_u_var"),
                "selected_v_var": meta.get("selected_v_var"),
                "attempt_order": meta.get("attempt_order"),
                "rtofs_slices": meta.get("rtofs_slices"),
                "rtofs_lon_diagnostics": meta.get("rtofs_lon_diagnostics"),
                "diagnostics": meta.get("diagnostics", [])[:4],
                "debug_previews": meta.get("debug_previews", [])[:2],
            },
            "cache": {"hit": False, "ttl_seconds": 180},
            "ts": self._now_ms(),
        }


    def _bbox_from_any(self, bbox_like: Any) -> dict[str, float] | None:
        """Normalize common bbox shapes without throwing."""
        try:
            if isinstance(bbox_like, dict):
                if all(k in bbox_like for k in ("west", "south", "east", "north")):
                    return self._normalize_bbox(bbox_like)
                if all(k in bbox_like for k in ("minLon", "minLat", "maxLon", "maxLat")):
                    return self._normalize_bbox({"west": bbox_like.get("minLon"), "south": bbox_like.get("minLat"), "east": bbox_like.get("maxLon"), "north": bbox_like.get("maxLat")})
            if isinstance(bbox_like, (list, tuple)) and len(bbox_like) >= 4:
                return self._normalize_bbox({"west": bbox_like[0], "south": bbox_like[1], "east": bbox_like[2], "north": bbox_like[3]})
        except Exception:
            return None
        return None

    def _bbox_overlaps(self, a: Any, b: Any) -> bool:
        """True when two normalized lon/lat bboxes overlap."""
        try:
            aa = self._bbox_from_any(a)
            bb = self._bbox_from_any(b)
            if not aa or not bb:
                return False
            return not (aa["east"] < bb["west"] or aa["west"] > bb["east"] or aa["north"] < bb["south"] or aa["south"] > bb["north"])
        except Exception:
            return False

    def _points_bbox(self, points: list[dict[str, Any]]) -> dict[str, float] | None:
        lats: list[float] = []
        lons: list[float] = []
        for row in points or []:
            if not isinstance(row, dict):
                continue
            lat = self._json_float(row.get("lat", row.get("latitude")), 6)
            lon = self._json_float(row.get("lon", row.get("lng", row.get("longitude"))), 6)
            if lat is None or lon is None:
                continue
            if -90.0 <= float(lat) <= 90.0:
                lats.append(float(lat)); lons.append(float(lon))
        if not lats or not lons:
            return None
        return {"west": min(lons), "south": min(lats), "east": max(lons), "north": max(lats)}

    def _boater_scene_payload_from_any(self, payload: dict[str, Any] | None) -> tuple[dict[str, Any] | None, str]:
        """Return the boater layer payload from either a layer payload or whole scene frame.

        Scene-frame callers sometimes hand us the boater layer itself, while
        other caches retain the compiled frame as {"layers": {"boater": ...}}.
        The current-field bridge must accept both shapes, otherwise a working
        scene-frame can still be invisible to /gfs/api/field?field=current.
        """
        if not isinstance(payload, dict):
            return None, "none"
        try:
            points, label = self._extract_boater_scene_ocean_points(payload)
            if points:
                return payload, label
        except Exception:
            pass
        layers = payload.get("layers")
        if isinstance(layers, dict):
            for key in ("boater", "boats", "boater_awareness"):
                candidate = layers.get(key)
                if isinstance(candidate, dict):
                    try:
                        points, label = self._extract_boater_scene_ocean_points(candidate)
                        if points:
                            return candidate, f"layers.{key}.{label}"
                    except Exception:
                        continue
        for key in ("boater", "boats", "boater_awareness"):
            candidate = payload.get(key)
            if isinstance(candidate, dict):
                try:
                    points, label = self._extract_boater_scene_ocean_points(candidate)
                    if points:
                        return candidate, f"{key}.{label}"
                except Exception:
                    continue
        return None, "none"

    def _cache_row_time_seconds(self, row: dict[str, Any] | None) -> float:
        """Accept both split-cache seconds and legacy/state-cache millisecond rows."""
        if not isinstance(row, dict):
            return 0.0
        raw = row.get("time")
        if raw is None:
            raw = row.get("ts") or row.get("created_at") or row.get("updated_at")
        try:
            val = float(raw or 0.0)
            # JavaScript/Python millisecond timestamps are ~1.7e12; seconds are ~1.7e9.
            if val > 10_000_000_000:
                val = val / 1000.0
            return val
        except Exception:
            return 0.0

    def remember_scene_frame_boater_ocean_points(self, frame_payload: dict[str, Any] | None, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> dict[str, Any]:
        """Expose a returned scene-frame boater layer to direct current/ocean-point reads.

        This is intentionally a no-provider side effect: if /scene-frame already
        has real boater oceanAnalysisPoints/oceanPoints, cache/promote exactly
        those points so /field?field=current cannot lag behind with a warming shell.
        """
        out = {"ok": False, "promoted": False, "points": 0, "reason": "no_scene_frame_boater_points"}
        if not isinstance(frame_payload, dict):
            return out
        try:
            self._last_scene_frame_payload = frame_payload
            self._last_scene_frame_payload_ts = time.time()
        except Exception:
            pass
        boater_payload, payload_path = self._boater_scene_payload_from_any(frame_payload)
        if not isinstance(boater_payload, dict):
            return out
        points, points_field = self._extract_boater_scene_ocean_points(boater_payload)
        if not points:
            return out
        b = self._normalize_bbox(bbox or boater_payload.get("bbox_object") or boater_payload.get("visible_bbox") or boater_payload.get("bbox") or frame_payload.get("visible_bbox") or frame_payload.get("bbox"))
        vis = self._normalize_bbox(visible_bbox or boater_payload.get("visible_bbox") or frame_payload.get("visible_bbox") or b)
        try:
            promoted = self._promote_boater_scene_ocean_points_to_direct_cache(boater_payload, b, vis)
        except Exception as exc:
            promoted = None
            out["promotion_error"] = str(exc)
        # Also pin the boater layer into the layer scene cache. This does not call
        # providers; it only exposes the proven scene-frame payload to bridge scans.
        scene_key = None
        try:
            scene_key = self._scene_cache_layer_key("boater", b, vis)
            cached_boater = dict(boater_payload)
            cached_boater.setdefault("cache", {}).update({
                "mode": "scene_frame_return_bridge_pin",
                "key": scene_key,
                "source_scene_frame": True,
                "payload_path": payload_path,
                "ts": self._now_ms(),
            })
            cached_boater.setdefault("visible_bbox", vis)
            cached_boater.setdefault("render_bbox", vis)
            cached_boater.setdefault("fetch_bbox", b)
            self._split_cache_set(scene_key, cached_boater)
            fp_key = self._scene_cache_first_paint_key("boater")
            fp = dict(cached_boater)
            fp.setdefault("cache", {}).update({"mode": "scene_frame_return_first_paint_pin", "key": fp_key, "source_scene_key": scene_key, "ts": self._now_ms()})
            self._split_cache_set(fp_key, fp)
        except Exception as exc:
            out["scene_pin_error"] = str(exc)
        return {
            "ok": True,
            "promoted": bool(promoted),
            "points": len(points),
            "points_field": points_field,
            "payload_path": payload_path,
            "scene_cache_key": scene_key,
            "source": "scene_frame_boater_ocean_points_return_bridge",
        }

    def _extract_boater_scene_ocean_points(self, payload: dict[str, Any] | None) -> tuple[list[dict[str, Any]], str]:
        """Prefer boater.oceanAnalysisPoints.points, then boater.oceanPoints.points."""
        if not isinstance(payload, dict):
            return [], "none"
        candidates: list[tuple[Any, str]] = []
        analysis = payload.get("oceanAnalysisPoints")
        ocean_points_obj = payload.get("oceanPoints")
        if isinstance(analysis, dict):
            candidates.append((analysis.get("points"), "boater.oceanAnalysisPoints.points"))
        if isinstance(ocean_points_obj, dict):
            candidates.append((ocean_points_obj.get("points"), "boater.oceanPoints.points"))
        candidates.extend([
            (payload.get("ocean_analysis_points"), "boater.ocean_analysis_points"),
            (payload.get("ocean_points"), "boater.ocean_points"),
            (payload.get("current_points"), "boater.current_points"),
            (payload.get("points"), "boater.points"),
        ])
        for raw, label in candidates:
            if not isinstance(raw, list) or not raw:
                continue
            out: list[dict[str, Any]] = []
            for row in raw:
                if not isinstance(row, dict):
                    continue
                lat = self._json_float(row.get("lat", row.get("latitude")), 6)
                lon = self._json_float(row.get("lon", row.get("lng", row.get("longitude"))), 6)
                if lat is None or lon is None or not (-90.0 <= float(lat) <= 90.0):
                    continue
                item = dict(row)
                item["lat"] = float(lat)
                item["lon"] = self._lon_pm180(float(lon))
                out.append(item)
            if out:
                return out, label
        return [], "none"

    def _direct_ocean_points_cache_key_for_current_field(self, bbox: dict[str, float], lod: str = "auto", visible_bbox: dict[str, float] | None = None) -> tuple[str, str, dict[str, Any]]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean-points")
        lod_key = str(lod or scene.get("tier") or "auto").lower()
        if lod_key == "auto":
            lod_key = str(scene.get("tier") or "global")
        return self._bbox_cache_key(f"ocean-points-{lod_key}", b), lod_key, scene

    def _find_boater_scene_cache_ocean_points(self, bbox: dict[str, float] | None, visible_bbox: dict[str, float] | None = None, *, max_age_seconds: int | None = None) -> dict[str, Any]:
        """Find the newest overlapping boater scene/cache payload with ocean points.

        The bridge deliberately searches every cache shape that can hold the
        successful boater scene-frame payload: split layer cache, first-paint
        cache, compiled frame cache, legacy state.scene_cache/state.tile_cache,
        and the most recently returned scene-frame payload. This prevents
        /gfs/api/field?field=current from reporting a cold RTOFS warmer when the
        boater path has already produced valid oceanAnalysisPoints.
        """
        requested = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or requested)
        max_age = int(max_age_seconds or os.getenv("GFS_CURRENT_FIELD_BOATER_BRIDGE_MAX_AGE_SECONDS", "86400") or "86400")
        now = time.time()
        candidates: list[dict[str, Any]] = []
        seen_payload_ids: set[int] = set()

        def consider(key: str, row: dict[str, Any] | None, payload: dict[str, Any] | None, *, exact: bool = False, cache_family: str = "split") -> None:
            if not isinstance(payload, dict):
                return
            pid = id(payload)
            # Same dict can be present as scene-cache and first-paint; score once.
            if pid in seen_payload_ids and not exact:
                return
            boater_payload, payload_path = self._boater_scene_payload_from_any(payload)
            if not isinstance(boater_payload, dict):
                return
            points, points_field = self._extract_boater_scene_ocean_points(boater_payload)
            if not points:
                return
            seen_payload_ids.add(pid)
            row_time = self._cache_row_time_seconds(row)
            age = max(0.0, now - row_time) if row_time else 0.0
            if max_age > 0 and row_time and age > max_age:
                return
            pb_candidates = [
                boater_payload.get("visible_bbox"), boater_payload.get("render_bbox"), boater_payload.get("bbox_object"),
                boater_payload.get("bbox"), boater_payload.get("bbox_used"), boater_payload.get("fetch_bbox"),
                payload.get("visible_bbox"), payload.get("render_bbox"), payload.get("bbox_object"),
                payload.get("bbox"), payload.get("bbox_used"), payload.get("fetch_bbox"), self._points_bbox(points),
            ]
            pb = next((x for x in pb_candidates if self._bbox_from_any(x)), None)
            if not any(self._bbox_overlaps(requested, x) for x in pb_candidates if x is not None):
                return
            candidates.append({
                "ok": True,
                "key": key,
                "payload": boater_payload,
                "payload_path": payload_path,
                "cache_family": cache_family,
                "points": points,
                "point_count": len(points),
                "points_field": points_field,
                "bbox": self._bbox_from_any(pb) or requested,
                "age_sec": round(age, 3),
                "score": (row_time or now) + (0.01 if exact else 0.0) + min(len(points), 5000) / 1_000_000.0,
            })

        exact_keys = []
        try:
            exact_keys.append(self._scene_cache_layer_key("boater", requested, visible))
        except Exception:
            pass
        try:
            exact_keys.append(self._scene_cache_first_paint_key("boater"))
        except Exception:
            pass

        cache = getattr(self, "_split_payload_cache", None)
        seen_keys: set[str] = set()
        if isinstance(cache, dict):
            for key in exact_keys:
                if not key or key in seen_keys:
                    continue
                seen_keys.add(key)
                row = cache.get(key)
                consider(key, row if isinstance(row, dict) else None, (row or {}).get("payload") if isinstance(row, dict) else None, exact=True, cache_family="split_exact")
            for key, row in list(cache.items()):
                skey = str(key)
                if skey in seen_keys:
                    continue
                payload = (row or {}).get("payload") if isinstance(row, dict) else None
                # Prefer scene/boater keys, but also inspect compiled frame rows that
                # carry layers.boater. This scan is cheap and avoids a false warming state.
                if not (
                    skey.startswith("scene_cache:boater")
                    or skey.startswith("scene_first_paint:boater")
                    or skey.startswith("scene:")
                    or "boater" in skey
                    or (isinstance(payload, dict) and isinstance(payload.get("layers"), dict) and isinstance(payload.get("layers", {}).get("boater"), dict))
                ):
                    continue
                consider(skey, row if isinstance(row, dict) else None, payload, cache_family="split_scan")

        state = getattr(self, "state", None)
        try:
            state_scene = getattr(state, "scene_cache", None)
            state_scene_ts = getattr(state, "scene_cache_ts", 0)
            consider("state.scene_cache", {"ts": state_scene_ts}, state_scene if isinstance(state_scene, dict) else None, cache_family="state_scene_cache")
        except Exception:
            pass
        try:
            tile_cache = getattr(state, "tile_cache", None)
            if isinstance(tile_cache, dict):
                for key, row in list(tile_cache.items()):
                    payload = (row or {}).get("payload") if isinstance(row, dict) else None
                    if isinstance(payload, dict):
                        consider(f"state.tile_cache:{key}", row, payload, cache_family="state_tile_cache")
        except Exception:
            pass
        try:
            last_frame = getattr(self, "_last_scene_frame_payload", None)
            last_frame_ts = getattr(self, "_last_scene_frame_payload_ts", 0.0)
            consider("last_scene_frame_payload", {"time": last_frame_ts}, last_frame if isinstance(last_frame, dict) else None, exact=True, cache_family="route_returned_scene_frame")
        except Exception:
            pass

        if not candidates:
            return {"ok": False, "reason": "no_overlapping_boater_scene_cache_ocean_points", "points": [], "searched_cache_families": ["split", "state.scene_cache", "state.tile_cache", "last_scene_frame_payload"]}
        candidates.sort(key=lambda item: float(item.get("score") or 0.0), reverse=True)
        return candidates[0]

    def _ocean_points_payload_from_boater_bridge(self, bridge: dict[str, Any], bbox: dict[str, float], lod: str = "auto", visible_bbox: dict[str, float] | None = None, *, source: str = "scene_cache_boater_ocean_points_bridge") -> dict[str, Any]:
        b = self._normalize_bbox(bbox)
        points = list((bridge or {}).get("points") or [])
        direct_key, lod_key, scene = self._direct_ocean_points_cache_key_for_current_field(b, lod, visible_bbox)
        boater_key = str((bridge or {}).get("key") or "")
        diag = {
            "bridge_from_boater_scene_cache": True,
            "bridged_point_count": len(points),
            "boater_scene_cache_key": boater_key,
            "direct_ocean_points_cache_key": direct_key,
            "fallback_warm_used": False,
            "boater_points_field": (bridge or {}).get("points_field"),
            "boater_scene_cache_age_sec": (bridge or {}).get("age_sec"),
        }
        return {
            "ok": bool(points),
            "source": source,
            "schema": "rtofs_ocean_points_v1",
            "bbox": [b["west"], b["south"], b["east"], b["north"]],
            "bbox_object": b,
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "lod": lod_key,
            "points": points,
            "current_points": points,
            "ocean_points": points,
            "count": len(points),
            "mask": {"method": "boater_scene_cache_bridge", "valid_count": len(points), "rejected_count": 0},
            "grid": {"real_grid": bool(points), "reason": "bridged_from_latest_overlapping_boater_scene_cache", "source_cache_key": boater_key},
            "diagnostics": diag,
            "bridge_from_boater_scene_cache": True,
            "bridged_point_count": len(points),
            "boater_scene_cache_key": boater_key,
            "direct_ocean_points_cache_key": direct_key,
            "fallback_warm_used": False,
            "cache": {"hit": True, "mode": "scene_cache_boater_bridge", "key": boater_key, "direct_ocean_points_cache_key": direct_key},
            "payload_state": "live_or_cached_boater_ocean_points_bridge",
            "ts": self._now_ms(),
        }

    def _promote_boater_scene_ocean_points_to_direct_cache(self, payload: dict[str, Any] | None, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> dict[str, Any] | None:
        """Dual-write boater ocean points into the direct ocean-points split cache."""
        if not isinstance(payload, dict):
            return None
        points, points_field = self._extract_boater_scene_ocean_points(payload)
        if not points:
            return None
        b = self._normalize_bbox(bbox or payload.get("bbox_object") or payload.get("visible_bbox") or payload.get("bbox"))
        direct_key, lod_key, scene = self._direct_ocean_points_cache_key_for_current_field(b, "auto", visible_bbox or payload.get("visible_bbox"))
        promoted = self._ocean_points_payload_from_boater_bridge(
            {"ok": True, "points": points, "points_field": points_field, "key": (payload.get("cache") or {}).get("key") or payload.get("boater_scene_cache_key") or "scene_cache:boater", "age_sec": 0},
            b,
            lod_key,
            visible_bbox or payload.get("visible_bbox"),
            source="scene_cache_boater_ocean_points_promoted",
        )
        promoted.setdefault("diagnostics", {}).update({"promoted_from_boater_scene_cache": True, "promotion_points_field": points_field})
        promoted.setdefault("cache", {}).update({"hit": False, "mode": "promoted_from_boater_scene_cache", "key": direct_key, "source_scene_cache_key": (payload.get("cache") or {}).get("key")})
        self._split_cache_set(direct_key, promoted)
        return promoted

    def _boater_bridge_bait_score_rows(self, points: list[dict[str, Any]], *, limit: int = 1200) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for p in points[: max(0, int(limit or 0))]:
            if not isinstance(p, dict):
                continue
            lat = self._json_float(p.get("lat"), 6)
            lon = self._json_float(p.get("lon", p.get("lng")), 6)
            if lat is None or lon is None:
                continue
            ov = p.get("ocean_vars") if isinstance(p.get("ocean_vars"), dict) else {}
            current = self._json_float(p.get("current_kt", p.get("speed_kt", p.get("current_speed_kt", ov.get("current_speed_kt")))), 4)
            sst_f = self._json_float(p.get("sst_f", p.get("water_temp_f", ov.get("sst_f"))), 3)
            sst_c = self._json_float(p.get("sst_c", p.get("sst", ov.get("sst_c"))), 3)
            if sst_f is None and sst_c is not None:
                sst_f = round(float(sst_c) * 9.0 / 5.0 + 32.0, 3)
            probability = 0.42
            if current is not None:
                probability += min(0.22, abs(float(current)) * 0.08)
            if sst_f is not None:
                probability += max(0.0, min(0.18, (float(sst_f) - 55.0) / 80.0))
            rows.append({
                "lat": float(lat),
                "lon": self._lon_pm180(float(lon)),
                "probability": round(max(0.05, min(0.88, probability)), 3),
                "driver": "boater_oceanAnalysisPoints_bridge",
                "source": "scene_cache_boater_ocean_points_bridge",
                "current_kt": current,
                "sst_f": sst_f,
                "bottom_depth_ft": p.get("bottom_depth_ft") or ((p.get("depth_intel") or {}).get("bottom_depth_ft") if isinstance(p.get("depth_intel"), dict) else None),
            })
        return rows

    def _attach_boater_bridge_to_ocean_consumer_payload(self, payload: dict[str, Any], bridge: dict[str, Any] | None, *, role: str) -> dict[str, Any]:
        """Let bait/shark consumers reuse successful boater oceanAnalysisPoints."""
        if not isinstance(payload, dict) or not isinstance(bridge, dict) or not bridge.get("ok"):
            return payload
        points = list(bridge.get("points") or [])
        if not points:
            return payload
        out = dict(payload)
        out["boater_ocean_analysis_points"] = points
        out["boater_ocean_analysis_point_count"] = len(points)
        out["ocean_points"] = out.get("ocean_points") or points
        out["current_points"] = out.get("current_points") or points
        out["oceanPoints"] = {"ok": True, "source": "scene_cache_boater_ocean_points_bridge", "points": points, "count": len(points), "contract": "boater_oceanAnalysisPoints_reused_by_%s" % role}
        if role == "bait" and not out.get("bait_score"):
            rows = self._boater_bridge_bait_score_rows(points)
            out["bait_score"] = rows
            out["advanced_bait_rows"] = out.get("advanced_bait_rows") or rows
            out["advancedBaitRows"] = out.get("advancedBaitRows") or rows
            bait = dict(out.get("bait") or {})
            bait.setdefault("status", "ocean_points_ready_no_polygons_yet")
            bait.setdefault("source", "full_stack")
            bait.setdefault("polygons", [])
            bait.setdefault("meta", {})
            bait["meta"].update({"boater_ocean_analysis_points_reused": len(points), "bridge_source": "scene_cache_boater_ocean_points_bridge"})
            out["bait"] = bait
        out.setdefault("diagnostics", {})
        if isinstance(out["diagnostics"], dict):
            out["diagnostics"].update({
                "boater_oceanAnalysisPoints_bridge_used": True,
                "boater_oceanAnalysisPoints_count": len(points),
                "boater_scene_cache_key": bridge.get("key"),
                "bridge_points_field": bridge.get("points_field"),
            })
        out["payload_state"] = out.get("payload_state") or "boater_ocean_points_ready"
        return out

    def _rtofs_current_field_fallback_payload(self, b: dict[str, float], lod: str = "auto", visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """RTOFS rescue path for /gfs/api/field?field=current.

        Consumption-safe contract: this reads warmed JSON only.  It does not
        download NOAA data and does not open NetCDF/xarray inside the HTTP path.
        """
        if os.getenv("GFS_FIELD_CURRENT_RTOFS_FALLBACK", "true").strip().lower() not in {"1", "true", "yes", "on"}:
            return {"ok": False, "source": "rtofs_field_fallback_disabled", "points": [], "count": 0}
        return self._rtofs_cached_current_payload(b, lod, visible_bbox, role="field_current")

    def current_field_payload(self, bbox: dict[str, float] | None = None, lod: str = "auto", visible_bbox: dict[str, float] | None = None, *, field_name: str = "current") -> Dict[str, Any]:
        """Compatibility payload for /gfs/api/field?field=current.

        First bridge from latest overlapping boater scene-cache ocean points.
        On a miss, read direct ocean-points cache only and report the exact miss;
        do not wake legacy RTOFS warmers from this compatibility endpoint.
        """
        b = self._normalize_bbox(bbox)
        bridge = self._find_boater_scene_cache_ocean_points(b, visible_bbox)
        # self.ocean_points_payload is intentionally not called in this compat route;
        # /gfs/api/cache/refresh owns provider warming and /field only reads cache.
        direct_key, _lod_key, _scene = self._direct_ocean_points_cache_key_for_current_field(b, lod, visible_bbox)
        if isinstance(bridge, dict) and bridge.get("ok") and bridge.get("points"):
            out = self._ocean_points_payload_from_boater_bridge(bridge, b, lod, visible_bbox, source="scene_cache_boater_ocean_points_bridge")
            out.update({
                "endpoint": "/gfs/api/field",
                "field": field_name,
                "compat_route": True,
                "source_endpoint": "/gfs/api/scene-frame layers.boater.oceanAnalysisPoints/oceanPoints",
                "route_class": "compat_provider_debug",
                "replacement": "/gfs/api/scene-frame?layers=boater,bait,shark-intel",
            })
            try:
                self._split_cache_set(direct_key, self._ocean_points_payload_from_boater_bridge(bridge, b, lod, visible_bbox, source="scene_cache_boater_ocean_points_promoted"))
            except Exception:
                pass
            return out
        # Strict prune pass: /field is a compatibility read endpoint only.  It
        # must not wake the old ocean-points warmer, because that duplicated
        # RTOFS work and hid the real miss reason behind endless "warming" shells.
        cached = self._split_cache_get(direct_key, int(os.getenv("GFS_OCEAN_POINTS_STALE_SECONDS", "1800") or "1800"))
        if isinstance(cached, dict):
            points = cached.get("points") or cached.get("current_points") or cached.get("ocean_points") or []
            out = dict(cached)
            out.update({
                "ok": bool(points),
                "endpoint": "/gfs/api/field",
                "field": field_name,
                "compat_route": True,
                "source_endpoint": "direct_ocean_points_cache_read_only",
                "points": points,
                "current_points": points,
                "ocean_points": points,
                "count": len(points),
                "route_class": "compat_cache_read_only",
                "replacement": "/gfs/api/scene-frame?layers=boater,bait,shark-intel",
                "bridge_from_boater_scene_cache": False,
                "bridged_point_count": 0,
                "direct_ocean_points_cache_key": direct_key,
                "fallback_warm_used": False,
            })
            out.setdefault("diagnostics", {})
            if isinstance(out["diagnostics"], dict):
                out["diagnostics"].update({"field_read_mode": "cache_only_no_provider_wake", "bridge_miss_reason": (bridge or {}).get("reason") if isinstance(bridge, dict) else "bridge_unavailable"})
            return out

        rtofs = self._rtofs_current_field_fallback_payload(b, lod, visible_bbox)
        if isinstance(rtofs, dict) and rtofs.get("points"):
            rtofs.setdefault("route_class", "compat_cache_miss_rtofs_direct_rescue")
            rtofs.setdefault("replacement", "/gfs/api/scene-frame?layers=boater,bait,shark-intel")
            rtofs["bridge_from_boater_scene_cache"] = False
            rtofs["bridged_point_count"] = 0
            rtofs["boater_scene_cache_key"] = None
            rtofs["direct_ocean_points_cache_key"] = direct_key
            return rtofs

        out = {
            "ok": True,
            "endpoint": "/gfs/api/field",
            "field": field_name,
            "compat_route": True,
            "schema": "rtofs_current_field_cache_read_only_v1",
            "source": rtofs.get("source") if isinstance(rtofs, dict) else "current_field_cache_miss_no_provider_wake",
            "payload_state": "cache_miss",
            "status": "waiting_for_ocean_bundle",
            "bbox": [b["west"], b["south"], b["east"], b["north"]],
            "bbox_object": b,
            "points": [],
            "current_points": [],
            "ocean_points": [],
            "count": 0,
            "route_class": "compat_cache_read_then_rtofs_rescue",
            "replacement": "/gfs/api/scene-frame?layers=boater,bait,shark-intel",
            "bridge_from_boater_scene_cache": False,
            "bridged_point_count": 0,
            "boater_scene_cache_key": None,
            "direct_ocean_points_cache_key": direct_key,
            "fallback_warm_used": True,
            "rtofs_fallback": rtofs if isinstance(rtofs, dict) else None,
            "diagnostics": {
                "bridge_from_boater_scene_cache": False,
                "bridged_point_count": 0,
                "boater_scene_cache_key": None,
                "direct_ocean_points_cache_key": direct_key,
                "fallback_warm_used": True,
                "field_read_mode": "cache_miss_then_rtofs_direct_rescue_empty",
                "bridge_miss_reason": (bridge or {}).get("reason") if isinstance(bridge, dict) else "bridge_unavailable",
                "next_step": "warm boater via /gfs/api/cache/refresh?layers=boater,bait, then read /field again",
            },
            "ts": self._now_ms(),
        }
        return out



    def ocean_points_payload(self, bbox: dict[str, float] | None = None, lod: str = "auto", visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean-points")
        lod_key = str(lod or scene.get("tier") or "auto").lower()
        if lod_key == "auto":
            lod_key = str(scene.get("tier") or "global")
        key = self._bbox_cache_key(f"ocean-points-{lod_key}", b)
        if os.getenv("GFS_RTOFS_CONSUME_CACHE_FOR_OCEAN_POINTS", "true").strip().lower() in {"1", "true", "yes", "on"}:
            cached_rtofs = self._rtofs_cached_current_payload(b, lod_key, visible_bbox, role="ocean_points")
            if isinstance(cached_rtofs, dict) and cached_rtofs.get("points"):
                cached_rtofs["endpoint"] = "/gfs/api/ocean-points"
                cached_rtofs["source"] = "ncep_nomads_rtofs_cached_surface_ocean_points"
                return cached_rtofs
        def _shell():
            return {
                "ok": True,
                "source": "rtofs_ocean_points_cache_warming",
                "schema": "rtofs_ocean_points_v1",
                "bbox": [b["west"], b["south"], b["east"], b["north"]],
                "bbox_object": b,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "render_budget": scene.get("render_budget"),
                "lod": lod_key,
                "points": [],
                "count": 0,
                "mask": {"method": "cache_first_hold", "valid_count": 0, "rejected_count": 0},
                "grid": {"grid_shape": [0, 0], "real_grid": False, "reason": "cache_warming_no_direct_provider_block"},
                "source_meta": {"cache_first": True, "note": "RTOFS provider request queued; use stale cache or wait for warm pull."},
            }
        return self._cache_first_split_payload(
            key=key,
            label="ocean-points",
            ttl_seconds=int(os.getenv("GFS_OCEAN_POINTS_CACHE_TTL_SECONDS", "600") or "300"),
            stale_seconds=int(os.getenv("GFS_OCEAN_POINTS_STALE_SECONDS", "1800") or "1800"),
            builder=lambda: self._ocean_points_payload_heavy(b, lod_key, scene.get("visible_bbox")),
            shell_factory=_shell,
        )

    def _ocean_points_payload_heavy(self, bbox: dict[str, float] | None = None, lod: str = "auto", visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """RTOFS sea-of-points foundation for ocean/bait/current LOD rendering."""
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean-points")
        lod_key = str(lod or scene.get("tier") or "auto").lower()
        if lod_key == "auto":
            lod_key = str(scene.get("tier") or "global")
        key = self._bbox_cache_key(f"ocean-points-{lod_key}", b)
        cached = self._split_cache_get(key, 180)
        if cached:
            out = dict(cached)
            out["cache"] = {"hit": True, "ttl_seconds": 180}
            return out
        started = time.time()
        live_policy = self._rtofs_live_bbox_policy(b, scene, layer="ocean-points")
        if not live_policy.get("allowed"):
            payload = self._rtofs_large_bbox_shell(b, scene, layer="ocean_points")
            payload.update({"schema": "rtofs_ocean_points_v1", "lod": lod_key, "cache": {"hit": False, "mode": "large_bbox_cache_only_no_live_ncss"}})
            return payload
        stride = int(scene.get("provider_stride") or self._ocean_stride_for_bbox(b, scene.get("provider_target_cells")))
        try:
            _ledger_started = time.time()
            try:
                raw, valid_time = self.ocean_provider._fetch_subset_sync(
                    bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                    stride=stride,
                    valid_time=None,
                )
                try:
                    _status, _promoted, _bytes, _detail = self._rtofs_provider_ledger_status(raw, stride=stride)
                    self._provider_ledger_record(self._ocean_provider_ledger_family(raw), layer="ocean-points", bbox=b, status=_status, bytes_received=_bytes, elapsed_ms=int((time.time() - _ledger_started) * 1000), promoted_to_cache=_promoted, detail=_detail)
                except Exception:
                    pass
            except Exception as exc:
                try:
                    self._provider_ledger_record("rtofs_ocean_bundle", layer="ocean-points", bbox=b, status="failed", elapsed_ms=int((time.time() - _ledger_started) * 1000), promoted_to_cache=False, error=str(exc), detail={"stride": stride})
                except Exception:
                    pass
                raise
        except Exception as exc:
            return {"ok": False, "source": "rtofs_ocean_points_error", "bbox": b, "error": str(exc), "points": [], "count": 0, "ts": self._now_ms()}
        points, grid_meta = self._ocean_points_from_grid(bbox=b, ocean=raw, lod=lod_key)
        for p in points:
            try:
                adv = self._advected_point(float(p["lat"]), float(p["lon"]), float(p.get("u") or 0.0), float(p.get("v") or 0.0), seconds=900.0)
                p["advected15m"] = adv
            except Exception:
                pass
        meta = raw.get("source_meta") or {}
        payload = {
            "ok": bool(points),
            "source": "rtofs_all_best_ocean_points" if points and bool((raw.get("source_meta") or {}).get("real_subset")) else "rtofs_ocean_points_empty_or_quality_gate_failed",
            "schema": "rtofs_ocean_points_v1",
            "bbox": [b["west"], b["south"], b["east"], b["north"]],
            "bbox_object": b,
            "lon_mode": "0_360_internal__minus180_180_output",
            "lod": lod_key,
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "stride": stride,
            "rtofs_resolution_mode": ("native_no_horizStride" if stride <= 1 else "adaptive_horizStride"),
            "bbox_area_deg2": round(abs((b["east"] - b["west"]) * (b["north"] - b["south"])), 4),
            "valid_time": valid_time.isoformat() if hasattr(valid_time, "isoformat") and valid_time else None,
            "points": points,
            "count": len(points),
            "ocean_var_contract": {
                "sst_c": "RTOFS sst sea surface temperature Celsius",
                "sst_f": "derived from sst_c",
                "ssu_m_s": "RTOFS ssu eastward surface current",
                "ssv_m_s": "RTOFS ssv northward surface current",
                "sss_psu": "RTOFS sss surface salinity",
                "current_speed_kt": "derived from ssu/ssv",
                "current_dir_deg": "derived from ssu/ssv",
                "bottom_depth_ft": "RTOFS-gated bathymetry companion estimate",
                "preferred_bait_depth_ft": "derived depth band for bait visuals/intel",
            },
            "mask": {
                "method": grid_meta.get("mask_method"),
                "valid_count": len(points),
                "rejected_count": int(grid_meta.get("skipped_land_or_invalid_sst") or 0) + int(grid_meta.get("skipped_nan_current") or 0),
                "shoreline_edge_points": grid_meta.get("edge_points"),
            },
            "grid": grid_meta,
            "source_meta": {
                "quality_gate": meta.get("quality_gate"),
                "fallback_used": bool(meta.get("fallback_used")),
                "fallback_sources": meta.get("fallback_sources") or [],
                "selected_attempt": meta.get("selected_attempt"),
                "selected_dataset": meta.get("selected_dataset"),
                "selected_vars": meta.get("selected_vars"),
                "selected_u_var": meta.get("selected_u_var"),
                "selected_v_var": meta.get("selected_v_var"),
                "rtofs_slices": meta.get("rtofs_slices"),
                "rtofs_lon_diagnostics": meta.get("rtofs_lon_diagnostics"),
                "real_subset": bool(meta.get("real_subset")),
                "grid_shape": meta.get("grid_shape"),
                "diagnostics": (meta.get("diagnostics") or [])[:3],
                "debug_previews": (meta.get("debug_previews") or [])[:2],
            },
            "cache": {"hit": False, "ttl_seconds": 180},
            "latency_ms": int((time.time() - started) * 1000),
            "ts": self._now_ms(),
        }
        payload = self._attach_truth_contract(self._attach_scene_plan(payload, scene), bbox=b, stride=stride, source_resolution_deg=0.25, derived_resolution_deg=0.03125, extra={"input_truth": "live_source_resolution_viewport_fetch"})
        if points:
            return self._split_cache_set(key, payload)
        payload.setdefault("cache", {}).update({"hit": False, "mode": "provider_empty_not_cached", "write_policy": "do_not_promote_empty_ocean_points"})
        return payload

    def ocean_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean")
        key = self._bbox_cache_key(f"ocean-live-{scene.get('tier')}", b)
        def _shell():
            return {
                "ok": True,
                "bbox": b,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "render_budget": scene.get("render_budget"),
                "source": "deferred_tile_cache",
                "mode": "cache_first_ocean_warming",
                "engine": "cache-first; RTOFS provider warm queued",
                "boats": [],
                "boat_count": 0,
                "swell_components": [],
                "grid": {"grid_shape": [0, 0], "real_grid": False, "reason": "cache_warming_no_direct_provider_block"},
                "fallback": {"used": False, "reason": "cache_warming"},
            }
        return self._cache_first_split_payload(
            key=key,
            label="ocean-live",
            ttl_seconds=int(os.getenv("GFS_OCEAN_CACHE_TTL_SECONDS", "600") or "300"),
            stale_seconds=int(os.getenv("GFS_OCEAN_STALE_SECONDS", "1800") or "1800"),
            builder=lambda: self._ocean_payload_heavy(b, scene.get("visible_bbox")),
            shell_factory=_shell,
        )

    def _live_payload_policy(self) -> dict[str, Any]:
        return {
            "strict_live_payloads": bool(GFS_STRICT_LIVE_PAYLOADS),
            "allow_proxy_fallback": False,
            "allow_synthetic_fallback": bool(ALLOW_SYNTHETIC_FALLBACK),
            "rule": "live_ncss_erddap_or_empty_no_mock_draw",
        }

    def _empty_live_required_payload(self, *, label: str, bbox: dict[str, float], reason: str, error: str | None = None, live_attempt: dict[str, Any] | None = None) -> Dict[str, Any]:
        now = self._now_ms()
        payload: Dict[str, Any] = {
            "ok": False,
            "bbox": bbox,
            "source": f"{label}_live_required_unavailable",
            "mode": "live_required_no_proxy_or_mock",
            "payload_state": "provider_failed" if error else "provider_empty",
            "status": "unavailable",
            "reason": reason,
            "error": error,
            "quality_policy": self._live_payload_policy(),
            "fallback": {"used": False, "allowed": False, "reason": "proxy_fallback_removed_by_quality_policy"},
            "live_attempt": live_attempt or {},
            "diagnostics": {
                "quality_gate": "failed_live_required",
                "label": label,
                "reason": reason,
                "error": error,
            },
            "cache": {"hit": False, "ttl_seconds": 45, "mode": "explicit_unavailable_not_fallback"},
            "ts": now,
        }
        if label in {"ocean", "boats"}:
            payload.update({
                "boats": [],
                "boat_count": 0,
                "current_points": [],
                "points": [],
                "grid": {"real_grid": False, "reason": reason, "quality_gate": "failed_live_required"},
                "swell_components": [],
            })
        if label == "bait":
            payload.update({
                "schema": "bait_live_required_unavailable_v1",
                "bait": {"status": "unavailable", "source": payload["source"], "polygons": [], "outer_polygons": [], "inner_polygons": [], "core_polygons": []},
                "bait_score": [],
                "oceanPoints": [],
                "ocean_points": [],
                "confidence": {"overall": 0.0, "reason": reason},
            })
        return payload

    def _ocean_payload_heavy(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean")
        key = self._bbox_cache_key(f"ocean-live-{scene.get('tier')}", b)
        cached = self._split_cache_get(key, 180)
        if cached:
            out = dict(cached)
            out["cache"] = {"hit": True, "ttl_seconds": 180}
            return out
        started = time.time()
        live = self._fetch_live_ocean_ncss(b, [], scene=scene)
        if live.get("ok"):
            live["swell_components"] = live.get("swell_components") or []
            live["fallback"] = {"used": False, "allowed": False}
            live["quality_policy"] = self._live_payload_policy()
            live["payload_state"] = "live"
            live["latency_ms"] = int((time.time() - started) * 1000)
            return self._split_cache_set(key, self._attach_scene_plan(live, scene))

        payload = self._empty_live_required_payload(
            label="ocean",
            bbox=b,
            reason=str(live.get("reason") or live.get("mode") or "rtofs_ncss_unavailable_or_empty"),
            error=live.get("error"),
            live_attempt=live,
        )
        payload["latency_ms"] = int((time.time() - started) * 1000)
        payload["diagnostics"].update({"source_diagnostics": self.source_diagnostics_payload(b)})
        payload = self._attach_scene_plan(payload, scene)
        payload.setdefault("cache", {}).update({"hit": False, "mode": "provider_empty_not_cached", "write_policy": "do_not_promote_empty_ocean_live"})
        return payload

    def boats_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        scene = self.build_scene_plan(bbox, visible_bbox, layer="boats")
        ocean = self.ocean_payload(bbox, visible_bbox=scene.get("visible_bbox"))
        boats = ocean.get("boats", []) or []
        derived_diag: dict[str, Any] = {}
        if not boats:
            boat_limit = max(1, min(18, int(((scene.get("render_budget") or {}).get("max_boats") or 12))))
            boats, derived_diag = self._boats_from_ocean_points(ocean, limit=boat_limit)
        boats = [b for b in boats if self._json_float(b.get("lat")) is not None and self._json_float(b.get("lon", b.get("lng"))) is not None]
        source = str(ocean.get("source") or "")
        mode = str(ocean.get("mode") or "")
        is_fallback = ("fallback" in source.lower()) or ("marker_ocean_solve" in source.lower()) or ("fallback" in mode.lower()) or ("proxy" in mode.lower())
        # Keep fallback/proxy boats visible in diagnostics, but separate them from
        # renderable GLB boats. The frontend only draws GLB boats from live
        # SST/current-backed water samples; this avoids saying “34 boats” when
        # all 34 were intentionally rejected as marker/proxy fallback.
        return {
            "ok": bool(boats or ocean.get("points") or ocean.get("current_points")),
            "incomplete": not bool(boats),
            "source": ocean.get("source"),
            "mode": ocean.get("mode"),
            "engine": ocean.get("engine"),
            "bbox": ocean.get("bbox"),
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "boats": boats,
            "points": ocean.get("points") or [],
            "ocean_points": ocean.get("ocean_points") or ocean.get("points") or [],
            "current_points": ocean.get("current_points") or ocean.get("points") or [],
            "current_zone_points_count": len(ocean.get("points") or ocean.get("current_points") or []),
            "count": len(boats),
            "renderable_count_hint": 0 if is_fallback else len(boats),
            "fallback_rejected_count_hint": len(boats) if is_fallback else 0,
            "render_contract": "glb_boats_require_live_sst_current_samples_and_eroded_shared_sst_landmask",
            "rejection_counts": ((ocean.get("grid") or {}).get("rejection_counts") or {}),
            "grid": ocean.get("grid"),
            "swell_components": ocean.get("swell_components", []),
            "source_meta": {**(ocean.get("source_meta") or {}), "noaa_landmask_cache": getattr(self, "noaa_landmask_cache", {})},
            "sst_landmask": ((ocean.get("source_meta") or {}).get("sst_landmask") or {}),
            "landmask_contract": ((ocean.get("source_meta") or {}).get("landmask_contract") or "finite_sst_is_shared_water_gate_for_boater_bait"),
            "diagnostics": {**(ocean.get("diagnostics") or {}), "boater": {**derived_diag, "boats_generated": len(boats), "cache_source": ((ocean.get("cache") or {}) if isinstance(ocean.get("cache"), dict) else {}).get("mode"), "live_source": ocean.get("source")}},
            "cache": (ocean.get("cache") if isinstance(ocean.get("cache"), dict) else {"hit": False, "ttl_seconds": 180, "mode": "boater_live_from_ocean_payload_no_cache_meta"}),
            "quality_policy": ocean.get("quality_policy") or self._live_payload_policy(),
            "payload_state": ocean.get("payload_state") or ("live" if not is_fallback and boats else "provider_empty"),
            "fallback": ocean.get("fallback") or {"used": bool(is_fallback)},
            "ts": self._now_ms(),
        }

    def _bait_tile_deg_for_bbox(self, bbox: dict[str, float]) -> float:
        b = self._normalize_bbox(bbox)
        span = max(abs(float(b["east"]) - float(b["west"])), abs(float(b["north"]) - float(b["south"])))
        if span <= 5.0:
            return BAIT_ADVANCED_TILE_DEG_LOCAL
        if span <= 14.0:
            return BAIT_ADVANCED_TILE_DEG_REGIONAL
        return BAIT_ADVANCED_TILE_DEG_WORLD

    def _quantize_bait_bbox(self, bbox: dict[str, float]) -> dict[str, float]:
        import math as _math
        b = self._normalize_bbox(bbox)
        step = self._bait_tile_deg_for_bbox(b)
        return {
            "west": max(-179.9, _math.floor(float(b["west"]) / step) * step),
            "south": max(-89.9, _math.floor(float(b["south"]) / step) * step),
            "east": min(179.9, _math.ceil(float(b["east"]) / step) * step),
            "north": min(89.9, _math.ceil(float(b["north"]) / step) * step),
        }

    def _bait_advanced_cache_key(self, scene: dict[str, Any], bbox: dict[str, float]) -> str:
        q = self._quantize_bait_bbox(bbox)
        tier = scene.get("tier") or "auto"
        return "bait-advanced:%s:%.2f,%.2f,%.2f,%.2f" % (tier, q["west"], q["south"], q["east"], q["north"])

    def _bait_advanced_refresh_allowed(self, key: str) -> bool:
        marker_key = f"bait-advanced-refresh-marker:{key}"
        if self._split_cache_get(marker_key, BAIT_ADVANCED_REFRESH_MIN_GAP_SECONDS):
            return False
        try:
            self._split_cache_set(marker_key, {"ts": self._now_ms(), "key": key})
        except Exception:
            pass
        return True

    def _cached_gfs_weather_fields_for_bait(self, bbox: dict[str, float]) -> dict[str, Any]:
        """Return cached GFS/weather fields for bait without waking GFS.

        Advanced bait needs wind/weather context, but it should not trigger a new
        cfgrib/GFS decode. This helper scans already-built split-cache payloads
        and reuses weather/cloud/frame fields if present.
        """
        if not BAIT_ADVANCED_USE_CACHED_GFS_WEATHER:
            return {}
        cache = getattr(self, "_split_payload_cache", None)
        if not isinstance(cache, dict):
            return {}
        now = time.time()
        b = self._normalize_bbox(bbox)

        def overlaps(pb: Any) -> bool:
            try:
                if isinstance(pb, (list, tuple)) and len(pb) >= 4:
                    west, south, east, north = map(float, pb[:4])
                    box = {"west": west, "south": south, "east": east, "north": north}
                elif isinstance(pb, dict):
                    box = self._normalize_bbox(pb)
                else:
                    return False
                return not (box["east"] < b["west"] or box["west"] > b["east"] or box["north"] < b["south"] or box["south"] > b["north"])
            except Exception:
                return False

        best: tuple[float, dict[str, Any], str] | None = None
        for key, row in list(cache.items()):
            if not isinstance(row, dict):
                continue
            age = now - float(row.get("time", 0) or 0)
            if age > SCENE_CACHE_STALE_SECONDS * 2:
                continue
            payload = row.get("payload")
            if not isinstance(payload, dict):
                continue
            candidates = []
            # Common frame/weather shapes.
            if isinstance(payload.get("weather"), dict):
                candidates.append((payload.get("weather"), "weather"))
            if isinstance(payload.get("frame"), dict) and isinstance(payload["frame"].get("weather"), dict):
                candidates.append((payload["frame"].get("weather"), "frame.weather"))
            # Scene-cache contract layer shapes.
            layers = payload.get("layers") if isinstance(payload.get("layers"), dict) else {}
            if isinstance(layers.get("weather"), dict):
                candidates.append((layers.get("weather"), "layers.weather"))
            if isinstance(layers.get("clouds"), dict):
                candidates.append((layers.get("clouds"), "layers.clouds"))
            for candidate, source in candidates:
                fields = candidate.get("fields") if isinstance(candidate, dict) else None
                if not isinstance(fields, dict) or not fields:
                    continue
                pb = candidate.get("bbox") or payload.get("bbox") or payload.get("bbox_used") or payload.get("visible_bbox")
                if pb is not None and not overlaps(pb):
                    continue
                score = -age
                # Prefer candidates with wind fields.
                if any(k in fields for k in ("wind_u", "u", "wind_v", "v")):
                    score += 1000.0
                if best is None or score > best[0]:
                    best = (score, dict(fields), f"{source}:{key}")
        if best:
            fields = best[1]
            fields["_bait_weather_source"] = f"cached_gfs_weather:{best[2]}"
            return fields
        return {}

    def bait_advanced_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        requested_b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(requested_b, visible_bbox, layer="bait")
        qb = self._quantize_bait_bbox(scene.get("fetch_bbox") or requested_b)
        key = self._bait_advanced_cache_key(scene, qb)
        def _shell():
            return {
                "ok": True,
                "bbox": qb,
                "requested_bbox": requested_b,
                "quantized_ocean_bbox": qb,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "render_budget": scene.get("render_budget"),
                "source": "deferred_tile_cache",
                "mode": "cache_first_bait_warming_quantized",
                "bait": {"status": "warming", "source": "cache_first", "polygons": []},
                "bait_score": [],
                "oceanPoints": [],
                "ocean_points": [],
                "confidence": {"overall": 0.0, "reason": "cache_warming"},
            }
        return self._cache_first_split_payload(
            key=key,
            label="bait",
            ttl_seconds=BAIT_ADVANCED_CACHE_TTL_SECONDS,
            stale_seconds=BAIT_ADVANCED_STALE_SECONDS,
            builder=lambda: self._bait_advanced_payload_heavy(qb, scene.get("visible_bbox")),
            shell_factory=_shell,
        )


    def _bait_advanced_payload_heavy(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """Live bait solve: RTOFS/RTOFS SST+current + CoastWatch chlorophyll + weather.

        This replaces the old marker-history proxy bait polygons. Fish CSV locations
        still exist as selectable nodes, but their glass-pane bait score should now
        be sampled from this live grid/bait_score contract instead of driving the
        polygon solve.
        """
        requested_b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(requested_b, visible_bbox, layer="bait")
        b = self._quantize_bait_bbox(scene.get("fetch_bbox") or requested_b)
        key = self._bait_advanced_cache_key(scene, b)
        if not self._bbox_has_probable_ocean_overlap(b):
            payload = self._empty_live_required_payload(label="bait", bbox=b, reason="no_ocean_overlap")
            payload.update({"requested_bbox": requested_b, "quantized_ocean_bbox": b, "payload_state": "skipped_no_ocean_overlap", "mode": "bait_advanced_skipped_inland_only"})
            return self._split_cache_set(key, self._attach_scene_plan(payload, scene))
        cached = self._split_cache_get(key, BAIT_ADVANCED_CACHE_TTL_SECONDS)
        if cached:
            cached_bait = cached.get("bait") if isinstance(cached.get("bait"), dict) else {}
            cached_has_content = bool((cached.get("bait_score") or cached.get("advanced_bait_rows") or cached_bait.get("polygons") or cached.get("polygons") or []))
            if cached_has_content:
                out = dict(cached)
                out.setdefault("cache", {})["hit"] = True
                out["cache"]["mode"] = "fresh_live_bait_grid_cache_quantized"
                return out

        if not self._bait_advanced_refresh_allowed(key):
            stale = self._split_cache_get(key, BAIT_ADVANCED_STALE_SECONDS)
            if isinstance(stale, dict):
                out = dict(stale)
                out.setdefault("cache", {})["hit"] = True
                out["cache"]["mode"] = "stale_bait_advanced_refresh_throttled"
                out["cache"]["refresh_throttled"] = True
                return out
            shell = self._empty_live_required_payload(label="bait", bbox=b, reason="bait_refresh_throttled")
            shell.update({"requested_bbox": requested_b, "quantized_ocean_bbox": b, "payload_state": "refresh_throttled", "mode": "bait_advanced_refresh_min_gap"})
            return self._attach_scene_plan(shell, scene)

        started = time.time()
        diagnostics: dict[str, Any] = {
            "solve": "live_grid_bait_probability",
            "states": [],
            "cache_warm_state": "builder_running",
        }

        def _bait_fail(reason: str, error: str | None = None) -> Dict[str, Any]:
            payload = self._empty_live_required_payload(label="bait", bbox=b, reason=reason, error=error)
            payload["latency_ms"] = int((time.time() - started) * 1000)
            payload.setdefault("diagnostics", {}).update(diagnostics)
            payload["payload_state"] = "provider_failed" if error else "provider_empty"
            payload["data_quality"] = {"live_ncss_erddap": False, "mock": False, "proxy": False, "fallback_used": False}
            payload = self._attach_scene_plan(payload, scene)
            payload.setdefault("cache", {}).update({"hit": False, "mode": "provider_empty_not_cached", "write_policy": "do_not_promote_empty_bait_grid"})
            return payload

        tile_deg = self._ocean_provider_tile_deg()
        if self._is_wide_ocean_provider_bbox(b, tile_deg):
            tiles = self._split_ocean_provider_tiles(b, tile_deg)
            tile_diag = self._log_ocean_provider_tile_policy("bait", b, tiles, scene)
            selected_tiles = list(tile_diag.get("provider_tiles_selected") or self._prioritize_ocean_provider_tiles(tiles, scene)[: int(tile_diag.get("tiles_scheduled") or 0)])
            shell = self._empty_live_required_payload(label="bait", bbox=b, reason="wide_bbox_tile_cache_only_no_rtofs_one_shot_tier_budgeted")
            shell.update({"requested_bbox": requested_b, "quantized_ocean_bbox": b, "payload_state": "cache_only_large_bbox", "mode": "bait_large_bbox_tile_cache_only", "provider_tile_count": len(selected_tiles), "tile_deg": tile_deg, "provider_tiles": selected_tiles[:int(os.getenv("GFS_OCEAN_PROVIDER_MAX_SYNC_TILES", "36") or "36")], "tile_budget": tile_diag})
            return self._attach_scene_plan(shell, scene)
        live_policy = self._rtofs_live_bbox_policy(b, scene, layer="bait")
        if not live_policy.get("allowed"):
            shell = self._empty_live_required_payload(label="bait", bbox=b, reason="large_bbox_cache_only_no_rtofs_one_shot")
            shell.update({"requested_bbox": requested_b, "quantized_ocean_bbox": b, "payload_state": "cache_only_large_bbox", "mode": "bait_large_bbox_tile_cache_only", "rtofs_live_policy": live_policy})
            return self._attach_scene_plan(shell, scene)
        stride = int(scene.get("provider_stride") or self._ocean_stride_for_bbox(b, scene.get("provider_target_cells")))
        try:
            _ledger_started = time.time()
            try:
                ocean_raw, ocean_time = self.ocean_provider._fetch_subset_sync(
                    bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                    stride=stride,
                    valid_time=None,
                )
                _meta = ocean_raw.get("source_meta") or {}
                diagnostics["states"].append({"provider": "ocean", "state": "ok", "stride": stride, "grid_shape": _meta.get("grid_shape")})
                try:
                    _status, _promoted, _bytes, _detail = self._rtofs_provider_ledger_status(ocean_raw, stride=stride)
                    self._provider_ledger_record(self._ocean_provider_ledger_family(ocean_raw), layer="bait", bbox=b, status=_status, bytes_received=_bytes, elapsed_ms=int((time.time() - _ledger_started) * 1000), promoted_to_cache=_promoted, detail=_detail)
                except Exception:
                    pass
            except Exception as exc:
                try:
                    self._provider_ledger_record("rtofs_ocean_bundle", layer="bait", bbox=b, status="failed", elapsed_ms=int((time.time() - _ledger_started) * 1000), promoted_to_cache=False, error=str(exc), detail={"stride": stride})
                except Exception:
                    pass
                raise
        except Exception as exc:
            return _bait_fail("ocean_provider_exception", str(exc))

        bio_raw: dict[str, Any] = {}
        if getattr(self, "bio_provider", None) is not None:
            try:
                _ledger_started = time.time()
                bio_raw, bio_time = self.bio_provider._fetch_subset_sync(
                    bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                    stride=max(1, min(stride, 2)),
                    valid_time=None,
                )
                _bio_shape = [len(bio_raw.get("chlorophyll") or []), len((bio_raw.get("chlorophyll") or [[]])[0] if bio_raw.get("chlorophyll") else [])]
                diagnostics["states"].append({"provider": "coastwatch_chlorophyll", "state": "ok" if bio_raw.get("chlorophyll") else "empty", "grid_shape": _bio_shape})
                try:
                    self._provider_ledger_record("coastwatch_chlorophyll_optional", layer="bait", bbox=b, status=("ok" if bio_raw.get("chlorophyll") else "empty"), elapsed_ms=int((time.time() - _ledger_started) * 1000), promoted_to_cache=False, detail={"stride": max(1, min(stride, 2)), "grid_shape": _bio_shape})
                except Exception:
                    pass
            except Exception as exc:
                diagnostics["states"].append({"provider": "coastwatch_chlorophyll", "state": "failed_optional", "error": str(exc)})
        else:
            diagnostics["states"].append({"provider": "coastwatch_chlorophyll", "state": "unavailable_optional"})

        weather_fields: dict[str, Any] = {}
        cached_weather_fields = self._cached_gfs_weather_fields_for_bait(b)
        if cached_weather_fields:
            weather_fields = cached_weather_fields
            diagnostics["states"].append({
                "provider": "gfs_weather_fields",
                "state": "cached",
                "field_keys": list(weather_fields.keys())[:12],
                "policy": "cached_scene_weather_only_no_gfs_wake",
                "source": weather_fields.get("_bait_weather_source"),
            })
        elif BAIT_ADVANCED_ALLOW_LIVE_GFS_WEATHER:
            try:
                weather_payload = self.generate_weather_payload(b)
                weather_fields = dict(weather_payload.get("fields") or {})
                diagnostics["states"].append({"provider": "gfs_weather_fields", "state": "live_explicit", "field_keys": list(weather_fields.keys())[:12], "policy": "GFS_BAIT_ADVANCED_ALLOW_LIVE_GFS_WEATHER=true"})
            except Exception as exc:
                diagnostics["states"].append({"provider": "gfs_weather_fields", "state": "failed_optional", "error": str(exc), "policy": "explicit_live_allowed"})
        else:
            diagnostics["states"].append({
                "provider": "gfs_weather_fields",
                "state": "cache_miss_skipped_live",
                "policy": "bait wants GFS wind/weather when already cached; live GFS decode disabled by default",
            })

        if derive_bait_payload is None:
            return _bait_fail("derive_bait_payload_import_missing")

        try:
            solved = derive_bait_payload(
                weather_fields,
                ocean_raw or {},
                bio_raw or {},
                bbox=[b["west"], b["south"], b["east"], b["north"]],
            )
        except Exception as exc:
            log.exception("live bait grid solve failed")
            return _bait_fail("derive_bait_payload_exception", str(exc))

        bait = dict(solved.get("bait") or {})
        score_rows = list(solved.get("bait_score") or solved.get("advanced_bait_rows") or solved.get("advancedBaitRows") or [])
        advanced_rows = list(solved.get("advanced_bait_rows") or solved.get("advancedBaitRows") or score_rows)
        if not score_rows:
            return _bait_fail("live_bait_grid_empty")

        def _valid_path(poly: dict[str, Any]) -> list[dict[str, float]]:
            coords = poly.get("path") or poly.get("coordinates") or []
            path: list[dict[str, float]] = []
            for pt in coords if isinstance(coords, list) else []:
                if isinstance(pt, dict):
                    lat = self._json_float(pt.get("lat", pt.get("latitude")), 6)
                    lon = self._json_float(pt.get("lng", pt.get("lon", pt.get("longitude")),), 6)
                    alt = self._json_float(pt.get("altitude"), 3)
                elif isinstance(pt, (list, tuple)) and len(pt) >= 2:
                    lon = self._json_float(pt[0], 6)
                    lat = self._json_float(pt[1], 6)
                    alt = self._json_float(pt[2], 3) if len(pt) >= 3 else None
                else:
                    continue
                if lat is None or lon is None or lat < -90 or lat > 90:
                    continue
                row = {"lat": lat, "lng": self._lon_pm180(lon)}
                if alt is not None:
                    row["altitude"] = alt
                path.append(row)
            if len(path) >= 2 and abs(path[0]["lat"] - path[-1]["lat"]) < 1e-7 and abs(path[0]["lng"] - path[-1]["lng"]) < 1e-7:
                path.pop()
            return path if len(path) >= 3 else []

        def _normalize_polys(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
            out: list[dict[str, Any]] = []
            for poly in rows or []:
                if not isinstance(poly, dict):
                    continue
                path = _valid_path(poly)
                if len(path) < 3:
                    continue
                p = dict(poly)
                p["path"] = path
                p["point_count"] = len(path)
                p.setdefault("type", p.get("band") or "bait_zone")
                p.setdefault("water_validated", True)
                out.append(p)
            return out

        bait["outer_polygons"] = _normalize_polys(list(bait.get("outer_polygons") or []))
        bait["inner_polygons"] = _normalize_polys(list(bait.get("inner_polygons") or bait.get("polygons") or []))
        bait["core_polygons"] = _normalize_polys(list(bait.get("core_polygons") or []))
        bait["polygons"] = bait["inner_polygons"]
        polygon_rows = bait["inner_polygons"] or bait["outer_polygons"] or bait["core_polygons"]
        if not polygon_rows:
            return _bait_fail("live_bait_polygons_empty_after_path_validation")

        # Keep bait.source as "full_stack" for the frontend renderer readiness contract.
        # Put the live provider name in live_source/provider_source instead of replacing it;
        # older JS checks bait.source === "full_stack" before trusting server polygons.
        bait["source"] = "full_stack"
        bait["live_source"] = "live_rtofs_coastwatch_weather_grid"
        bait["provider_source"] = "live_rtofs_coastwatch_weather_grid"
        bait["status"] = "ready"
        bait["bait_score"] = score_rows
        bait.setdefault("meta", {})
        bait["meta"].update({
            "solve_method": "server_live_marching_squares_grid",
            "input_ocean": "RTOFS/RTOFS SST/current grid",
            "input_bio": "CoastWatch chlorophyll when available",
            "input_weather": "cached GFS wind/cloud/precip when available; bait does not wake live GFS unless explicitly enabled",
            "marker_locations_drive_polygons": False,
            "location_intel_should_sample_grid": True,
            "advanced_bait_row_count": len(advanced_rows),
            "advanced_bait_rows_contract": "dense_rtofs_sst_current_probability_rows_not_boat_ocean_points",
            "contour_contract": "server_marching_square_polygons_with_depth_extrusion_metadata",
        })

        diagnostics.update({
            "valid_ocean_point_count": len(score_rows),
            "water_mask_count": ((bait.get("meta") or {}).get("valid_cells") or len(score_rows)),
            "bait_polygon_count": len(polygon_rows),
            "provider_counts": {"ocean_grid_rows": len((ocean_raw or {}).get("sst") or []), "advanced_bait_rows": len(advanced_rows), "polygons": len(polygon_rows)},
        })

        payload: Dict[str, Any] = {
            **solved,
            "ok": True,
            "bbox": b,
            "requested_bbox": requested_b,
            "quantized_ocean_bbox": b,
            "bbox_object": b,
            "source": "live_rtofs_coastwatch_bait_grid",
            "mode": "live_full_stack_marching_squares_bait_solve",
            "schema": "bait_live_marching_squares_v2",
            "engine": "RTOFS/RTOFS SST/current + CoastWatch chlorophyll + GFS weather -> bait_score grid -> marching-square contours",
            "source_meta": {**((ocean_raw or {}).get("source_meta") or {}), "noaa_landmask_cache": getattr(self, "noaa_landmask_cache", {})},
            "sst_landmask": (((ocean_raw or {}).get("source_meta") or {}).get("sst_landmask") or {}),
            "landmask_contract": (((ocean_raw or {}).get("source_meta") or {}).get("landmask_contract") or "finite_sst_is_shared_water_gate_for_bait"),
            "quality_policy": self._live_payload_policy(),
            "bait": bait,
            "polygons": polygon_rows,
            "zones": polygon_rows,
            "polygon_count": len(polygon_rows),
            "valid_ocean_point_count": len(score_rows),
            "water_mask_count": ((bait.get("meta") or {}).get("valid_cells") or len(score_rows)),
            "bait_score": score_rows,
            "advanced_bait_rows": advanced_rows,
            "advancedBaitRows": advanced_rows,
            "bait_rows": advanced_rows,
            "ocean_points": [],
            "oceanPoints": {"ok": False, "source": "not_boat_ocean_points_dense_bait_rows_are_advancedBaitRows", "points": [], "count": 0},
            "dense_bait_field": {
                "ok": True,
                "source": "advanced_rtofs_sst_current_bait_probability_field",
                "rows": advanced_rows,
                "count": len(advanced_rows),
                "contract": "dense_rows_for_bait_contours_not_boat_ocean_points",
            },
            "valid_time": ocean_time.isoformat() if hasattr(ocean_time, "isoformat") and ocean_time else None,
            "latency_ms": int((time.time() - started) * 1000),
            "diagnostics": diagnostics,
            "cache": {"hit": False, "ttl_seconds": BAIT_ADVANCED_CACHE_TTL_SECONDS, "mode": "live_grid_bait_solve_quantized"},
            "payload_state": "live",
            "data_quality": {"live_ncss_erddap": True, "mock": False, "proxy": False, "fallback_used": False},
            "ts": self._now_ms(),
        }
        payload["stride"] = stride
        payload["source_resolution_deg"] = 0.25
        payload["derived_resolution_deg"] = round(0.25 / max(1, int((bait.get("meta") or {}).get("detail_multiplier") or os.getenv("GFS_ADVANCED_BAIT_DETAIL_MULTIPLIER", "4") or "4")), 6)
        return self._split_cache_set(key, self._attach_truth_contract(self._attach_scene_plan(payload, scene), bbox=b, stride=stride, source_resolution_deg=0.25, derived_resolution_deg=payload["derived_resolution_deg"], extra={"input_truth": "live_source_resolution_viewport_fetch", "layer": "bait", "advanced_bait_rows": len(advanced_rows)}))

    def _split_cache_peek(self, key: str) -> Any:
        if not hasattr(self, "_split_payload_cache"):
            return None
        row = self._split_payload_cache.get(key)
        if not row:
            return None
        return row.get("payload")

    def _split_cache_row(self, key: str) -> dict[str, Any] | None:
        if not hasattr(self, "_split_payload_cache"):
            return None
        row = self._split_payload_cache.get(key)
        return row if isinstance(row, dict) else None

    def _split_cache_age_seconds(self, key: str) -> int | None:
        row = self._split_cache_row(key)
        if not row:
            return None
        try:
            return max(0, int(time.time() - float(row.get("time", 0))))
        except Exception:
            return None

    def _split_cache_inflight(self) -> set[str]:
        if not hasattr(self, "_split_warm_inflight"):
            self._split_warm_inflight = set()
        return self._split_warm_inflight

    def _schedule_split_warm(self, key: str, label: str, builder) -> bool:
        """Run a split payload builder in the background.

        This is the core cache-first rule for viewport changes: API callers get
        memory/stale/queued cache immediately while the slow provider work happens
        off the request path.  Errors stay visible in provider/payload debug and
        are not swallowed as fake data.
        """
        inflight = self._split_cache_inflight()
        if key in inflight:
            return False
        inflight.add(key)

        def _run() -> None:
            try:
                payload = builder()
                if isinstance(payload, dict):
                    cache_meta = payload.get("cache")
                    if not isinstance(cache_meta, dict):
                        cache_meta = {}
                        payload["cache"] = cache_meta
                    cache_meta["warmed_by"] = label
                    cache_meta["warmed_at"] = self._now_ms()
                    cache_meta["key"] = key
                    lower_label = str(label).lower()
                    is_ocean_backed = any(tok in lower_label for tok in ("ocean", "bait", "boater", "boat", "shark"))
                    point_count = len(payload.get("points") or payload.get("ocean_points") or payload.get("current_points") or [])
                    op = payload.get("oceanPoints")
                    if isinstance(op, dict):
                        point_count = max(point_count, len(op.get("points") or []), int(op.get("count") or 0))
                    bait = payload.get("bait") if isinstance(payload.get("bait"), dict) else {}
                    poly_count = len(bait.get("polygons") or []) + len(payload.get("polygons") or []) + len(payload.get("contours") or []) + len(payload.get("score_points") or [])
                    if is_ocean_backed and point_count <= 0 and poly_count <= 0:
                        payload["cache"].update({"write_policy": "warm_empty_ocean_payload_not_promoted", "empty_write_rejected": True})
                        return
                    self._split_cache_set(key, payload)
            except Exception as exc:
                level = log.info if isinstance(exc, FileNotFoundError) else log.warning
                level("[gfs/cache] split warm failed label=%s key=%s err=%s", label, key, exc)
            finally:
                try:
                    inflight.discard(key)
                except Exception:
                    pass

        threading.Thread(target=_run, name=f"gfs-{label}-warm", daemon=True).start()
        return True

    def _live_first_retained_split_payload(self, *, key: str, label: str, dedupe_seconds: int, retained_max_age_seconds: int, builder, shell_factory):
        """Return last-known-good display data while always trying to refresh live.

        Clouds/rain should not be considered fresh just because a split cache row
        exists.  The cache row is a retained display bridge: draw it instantly if
        available, but schedule a fresh provider attempt on each active request
        cycle unless an identical refresh is already in-flight or was started a
        few seconds ago.
        """
        row = self._split_cache_row(key)
        retained = row.get("payload") if isinstance(row, dict) else None
        age = self._split_cache_age_seconds(key) if isinstance(retained, dict) else None
        try:
            age_ok = age is not None and int(age) <= int(retained_max_age_seconds)
        except Exception:
            age_ok = False

        refresh_marker_key = f"live-refresh-marker:{key}"
        # Clouds/rain/lightning share the same expensive GFS/cfgrib source. In
        # practice the journal showed multiple bboxes waking full 721x1440
        # canonicalization within seconds. Gate both exact-key and global GFS live
        # refreshes so empty/warming placeholders cannot stampede NOMADS/cfgrib.
        is_gfs_live_label = any(tok in str(label).lower() for tok in ("cloud", "rain", "lightning", "jetstream", "gfs"))
        global_marker_key = "live-refresh-marker:gfs-global-provider"
        recent_marker = self._split_cache_get(refresh_marker_key, max(1, int(dedupe_seconds or 1)))
        global_recent = self._split_cache_get(global_marker_key, max(1, int(CLOUD_LIVE_DEDUPE_SECONDS))) if is_gfs_live_label else None
        scheduled = False
        if not recent_marker and not global_recent:
            self._split_cache_set(refresh_marker_key, {"ts": self._now_ms(), "label": label})
            if is_gfs_live_label:
                self._split_cache_set(global_marker_key, {"ts": self._now_ms(), "label": label, "key": key})
            scheduled = self._schedule_split_warm(key, f"{label}-live", builder)

        if isinstance(retained, dict) and age_ok:
            out = dict(retained)
            out.setdefault("cache", {})["hit"] = True
            out["cache"].update({
                "mode": "retained_last_good_display_while_fetching_fresh",
                "policy": "live_first_no_cloud_source_ttl",
                "age_sec": age,
                "key": key,
                "refresh_scheduled": scheduled,
                "dedupe_seconds": int(dedupe_seconds or 0),
                "retained_max_age_seconds": int(retained_max_age_seconds or 0),
            })
            out["display_state"] = "retained_last_good"
            out["request_state"] = "fresh_gfs_in_flight" if scheduled else "fresh_gfs_deduped_or_in_flight"
            out["payload_state"] = "retained_display_fetching_fresh"
            out.setdefault("debug", {})["cloud_cache_policy"] = "retained display; fresh GFS is globally throttled"
            return out

        shell = shell_factory() if callable(shell_factory) else {}
        if not isinstance(shell, dict):
            shell = {}
        shell.setdefault("ok", True)
        shell.setdefault("status", "fetching_fresh")
        shell.setdefault("source", "live_first_queued")
        shell.setdefault("cache", {})["hit"] = False
        shell["cache"].update({
            "mode": "no_retained_display_fetching_fresh",
            "policy": "live_first_no_cloud_source_ttl",
            "refresh_scheduled": scheduled,
            "key": key,
            "dedupe_seconds": int(dedupe_seconds or 0),
            "retained_max_age_seconds": int(retained_max_age_seconds or 0),
        })
        shell["display_state"] = "empty_until_first_live_payload"
        shell["request_state"] = "fresh_gfs_in_flight" if scheduled else "fresh_gfs_deduped_or_in_flight"
        shell["payload_state"] = "fetching_fresh"
        shell["ts"] = self._now_ms()
        return shell

    def _cache_first_split_payload(self, *, key: str, label: str, ttl_seconds: int, stale_seconds: int, builder, shell_factory):
        def _has_ocean_renderable(p: Any) -> bool:
            if not isinstance(p, dict):
                return False
            point_count = len(p.get("points") or p.get("ocean_points") or p.get("current_points") or [])
            op = p.get("oceanPoints")
            if isinstance(op, dict):
                point_count = max(point_count, len(op.get("points") or []), int(op.get("count") or 0))
            bait = p.get("bait") if isinstance(p.get("bait"), dict) else {}
            poly_count = len(bait.get("polygons") or []) + len(p.get("polygons") or []) + len(p.get("contours") or []) + len(p.get("score_points") or [])
            return point_count > 0 or poly_count > 0

        ocean_label = any(tok in str(label).lower() for tok in ("ocean", "bait", "boater", "boat", "shark"))
        cached = self._split_cache_get(key, ttl_seconds)
        if isinstance(cached, dict) and (not ocean_label or _has_ocean_renderable(cached)):
            out = dict(cached)
            out.setdefault("cache", {})["hit"] = True
            out["cache"]["mode"] = "fresh_memory_cache"
            out["cache"]["age_sec"] = self._split_cache_age_seconds(key)
            return out
        stale = self._split_cache_peek(key)
        scheduled = self._schedule_split_warm(key, label, builder)
        if isinstance(stale, dict) and (not ocean_label or _has_ocean_renderable(stale)):
            out = dict(stale)
            out.setdefault("cache", {})["hit"] = True
            out["cache"]["mode"] = "stale_while_revalidate"
            out["cache"]["age_sec"] = self._split_cache_age_seconds(key)
            out["cache"]["refresh_scheduled"] = scheduled
            out["payload_state"] = "stale_while_revalidate"
            return out
        shell = shell_factory() if callable(shell_factory) else {}
        if not isinstance(shell, dict):
            shell = {}
        shell.setdefault("ok", True)
        shell.setdefault("status", "warming")
        shell.setdefault("source", "cache_first_queued")
        shell.setdefault("cache", {})["hit"] = False
        shell["cache"].update({"mode": "queued_background_warm", "refresh_scheduled": scheduled, "key": key, "ttl_seconds": ttl_seconds, "stale_seconds": stale_seconds})
        shell["payload_state"] = "warming"
        shell["ts"] = self._now_ms()
        return shell

    def _cache_warm_status_payload(self) -> dict[str, Any]:
        state = getattr(self, "_globe_cache_warm_state", None)
        if not isinstance(state, dict):
            return {"running": False, "started": False, "message": "no warm has been scheduled", "ts": self._now_ms()}
        out = dict(state)
        out["ts"] = self._now_ms()
        return out

    def cache_warm_status_payload(self) -> dict[str, Any]:
        return {"ok": True, "schema": "lftr_globe_cache_warm_status_v1", "warm": self._cache_warm_status_payload()}

    def _schedule_priority_tile_warm(self, tiles: list[dict[str, Any]], scene: dict[str, Any], requested_layers: set[str], reason: str = "priority") -> dict[str, Any]:
        """Small foreground-adjacent warm for a new viewport while a large warm is still running."""
        if not tiles:
            return {"scheduled": False, "reason": "no_tiles"}
        ocean_layers = {"bait", "boater", "boats", "shark-intel", "ocean", "oceanpoints", "current", "currents"}
        original_requested_layers = {str(x).strip().lower() for x in (requested_layers or set()) if str(x).strip()}
        requested_layers = {x for x in original_requested_layers if x not in ocean_layers}
        if original_requested_layers and not requested_layers:
            return {
                "scheduled": False,
                "reason": "priority_ocean_layers_skipped_legacy_scene_tile_path",
                "policy": "rtofs_ocean_warmer_owns_ocean_not_scene_tile_priority_warmer",
                "blocked_layers": sorted(original_requested_layers & ocean_layers),
            }
        if not requested_layers:
            requested_layers = {"clouds", "rain"}
        if not hasattr(self, "_priority_tile_warm_lock"):
            self._priority_tile_warm_lock = threading.Lock()
            self._priority_tile_warm_keys = set()
        key = str((tiles[0] or {}).get("tile_id") or "") + ":" + ",".join(sorted(requested_layers))
        with self._priority_tile_warm_lock:
            if key in self._priority_tile_warm_keys:
                return {"scheduled": False, "reason": "priority_already_running", "key": key}
            self._priority_tile_warm_keys.add(key)
        limit = max(1, min(int(os.getenv("GFS_TILE_PRIORITY_WARM_LIMIT", "3") or "3"), len(tiles), 6))
        selected = [t for t in tiles[:limit] if t.get("tile_id")]
        def _run_priority() -> None:
            try:
                for item in selected:
                    try:
                        self.tile_intel_payload(str(item.get("tile_id")), ttl_seconds=0, visible_bbox=scene.get("visible_bbox"), allowed_layers=requested_layers)
                    except Exception as exc:
                        log.info("[gfs/cache] priority tile warm skipped tile=%s err=%s", item.get("tile_id"), exc)
            finally:
                try:
                    with self._priority_tile_warm_lock:
                        self._priority_tile_warm_keys.discard(key)
                except Exception:
                    pass
        threading.Thread(target=_run_priority, name="gfs-priority-tile-warm", daemon=True).start()
        return {"scheduled": True, "reason": reason, "key": key, "tiles": len(selected), "policy": "small_new_viewport_priority_warm_runs_alongside_long_warm"}

    def _scene_refresh_tile_budget_for_layers(self, scene: dict[str, Any], layers: set[str]) -> dict[str, Any]:
        tier = normalize_lod((scene or {}).get("tier") or "global")
        tile_budget = (scene or {}).get("tile_budget") if isinstance((scene or {}).get("tile_budget"), dict) else {}
        ocean_layers = {"bait", "boater", "boats", "shark-intel", "ocean", "oceanpoints", "current", "currents"}
        weather_layers = {"clouds", "rain", "lightning", "jetstream", "weather"}
        # No requested layer set means boot/default warm: weather only.
        # Ocean/RTOFS must be explicitly requested by a viewport-aware ocean warmer,
        # never by the legacy scene-tile warm path.
        wants_ocean = bool(layers & ocean_layers)
        wants_weather = bool(layers & weather_layers) or not layers
        # Scene cache warm budget is separate from provider-tile budget.  Weather
        # scene-tile warming may use generic scene tiles.  Ocean uses its own
        # provider-tile scheduler and should keep the 36-tile target.
        # Two-level LOD: ocean stays always eligible at 36 possible tiles,
        # weather/cloud/rain cache warming stays stable across zoom.
        ocean_default = {"global": 36, "local": 36}.get(tier, 36)
        weather_default = {"global": 8, "local": 8}.get(tier, 8)
        ocean_max = int(tile_budget.get("max_ocean_refresh_tiles") or os.getenv("GFS_CACHE_WARM_OCEAN_MAX_TILES", str(ocean_default)) or str(ocean_default))
        weather_max = int(tile_budget.get("max_weather_refresh_tiles") or os.getenv("GFS_CACHE_WARM_WEATHER_MAX_TILES", str(weather_default)) or str(weather_default))
        ocean_max = max(0, min(ocean_max, VIEWPORT_TILE_COUNT))
        weather_max = max(1, min(weather_max, VIEWPORT_TILE_COUNT))
        if wants_ocean:
            max_tiles = ocean_max
        elif wants_weather:
            max_tiles = weather_max
        else:
            max_tiles = weather_max
        return {
            "tier": tier,
            "wants_ocean": wants_ocean,
            "wants_weather": wants_weather,
            "max_ocean_refresh_tiles": ocean_max,
            "max_weather_refresh_tiles": weather_max,
            "max_tiles": max_tiles,
            "policy": "weather_scene_tiles_bounded_ocean_provider_tiles_fixed_36_batch_deduped",
        }

    def schedule_globe_cache_warm(self, bbox: dict[str, float] | None = None, max_tiles: int = 512, reason: str = "website_load", visible_bbox: dict[str, float] | None = None, layers: list[str] | None = None) -> dict[str, Any]:
        """Kick a center-first global cache warm without blocking the web request.

        The browser should load from whatever disk/memory cache exists immediately.
        This warmer then refreshes the selected center tile, visible tiles, and rings
        outward. It writes compact tile products to disk and releases memory per tile.
        This build is tuned for the LFTR e2 2-vCPU / 16GB RAM VM profile: bounded
        I/O parallelism, larger live build batches, and conservative CPU decode.
        """
        requested = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(requested, visible_bbox, layer="cache-refresh")
        requested_layers = {str(x).strip().lower() for x in (layers or []) if str(x).strip()}
        ocean_layers = {"bait", "boater", "boats", "shark-intel", "ocean", "oceanpoints", "current", "currents"}
        requested_ocean_layers = requested_layers & ocean_layers
        # The generic globe/scene-tile warmer is atmosphere-only.  It may warm
        # clouds/rain/lightning/jetstream scene products, but it must never feed
        # child bboxes into RTOFS/ocean/boater/bait.
        requested_layers = {x for x in requested_layers if x not in ocean_layers}
        if not requested_layers:
            requested_layers = {"clouds", "rain", "lightning"}
        budget = self._scene_refresh_tile_budget_for_layers(scene, requested_layers)
        try:
            requested_max_tiles = max(1, min(int(max_tiles or budget["max_tiles"] or 1), 512))
        except Exception:
            requested_max_tiles = int(budget["max_tiles"] or 1)
        max_tiles_i = max(1, min(requested_max_tiles, int(budget["max_tiles"] or 1)))
        plan = self.tile_plan_payload(requested, max_tiles=max_tiles_i)
        try:
            total_plan = self.tile_plan_payload(requested, max_tiles=576)
            tiles_total = int(total_plan.get("total_tiles") or len(total_plan.get("tiles") or []))
        except Exception:
            tiles_total = len(plan.get("tiles") or [])
        if not hasattr(self, "_globe_cache_warm_lock"):
            self._globe_cache_warm_lock = threading.Lock()
        with self._globe_cache_warm_lock:
            state = getattr(self, "_globe_cache_warm_state", {}) or {}
            if state.get("running"):
                priority = self._schedule_priority_tile_warm(list(plan.get("tiles") or []), scene, requested_layers, reason=reason)
                warm_status = self._cache_warm_status_payload()
                warm_status["priority"] = priority
                return {"ok": True, "schema": "lftr_globe_cache_warm_v1", "scheduled": bool(priority.get("scheduled")), "reason": "already_running_priority_tile_warm" if priority.get("scheduled") else "already_running", "plan": plan, "warm": warm_status, "priority": priority}
            run_id = f"warm-{self._now_ms()}"
            self._globe_cache_warm_state = {
                "running": True,
                "started": True,
                "run_id": run_id,
                "reason": reason,
                "requested_bbox": requested,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "center": plan.get("center"),
                "requested_tiles_total": tiles_total,
                "tiles_total": tiles_total,
                "tiles_scheduled": len(plan.get("tiles") or []),
                "skipped_tiles_budget": max(0, tiles_total - len(plan.get("tiles") or [])),
                "partial_refresh": tiles_total > len(plan.get("tiles") or []),
                "remaining_tiles": max(0, tiles_total - len(plan.get("tiles") or [])),
                "tile_budget": budget,
                "total_tiles_requested": len(plan.get("tiles") or []),
                "concurrency": int(os.getenv("GFS_TILE_WARM_WORKERS", "1") or "1"),
                "tile_count_policy": "tier_budgeted_center_first_refresh_tiles_never_hundreds_on_boot",
                "download_policy": "bounded_parallel_live_tile_refresh_cache_first_read_only_browser_tiles",
                "scene_tile_product": "gzip_json_large_diverse_payload_contracts",
                "completed_tiles": 0,
                "failed_tiles": 0,
                "last_tile_id": None,
                "started_at": self._now_ms(),
                "finished_at": None,
                "message": "warming bounded center-first gzip scene-tile point cache",
                "requested_layers": sorted(requested_layers) if requested_layers else ["all"],
                "blocked_ocean_layers": sorted(requested_ocean_layers),
                "route_policy": "generic_scene_tile_warmer_is_atmosphere_only_rtofs_ocean_has_separate_owner",
            }

        def _run() -> None:
            try:
                # Do not build the full frame inside the cache warmer.  The frame
                # endpoint is independently cache-first; doing a full frame plus 512
                # tile contract builds in one background run can starve /ws/gfs and
                # cause nginx 502s on small VMs.
                tiles = list(plan.get("tiles") or [])
                try:
                    live_build_limit = max(1, min(int(os.getenv("GFS_TILE_WARM_BUILD_LIMIT", str(max_tiles_i)) or str(max_tiles_i)), len(tiles), int(budget.get("max_tiles") or max_tiles_i), 64))
                except Exception:
                    live_build_limit = min(max_tiles_i, len(tiles), 64)
                tiles_to_build = tiles[:live_build_limit]
                with self._globe_cache_warm_lock:
                    st = self._globe_cache_warm_state
                    st["live_build_limit"] = live_build_limit
                    st["ocean_provider_target_tiles"] = int(os.getenv("GFS_OCEAN_PROVIDER_MAX_SCHEDULED_TILES", "36") or "36")
                    st["message"] = "warming weather-first scene cache; ocean uses one fixed-36 provider batch outside generic scene-tile warm"
                    st["phase"] = "weather_first"
                    st["warm_order"] = ["clouds", "rain", "oceanPoints", "boats", "baitAdvanced"]
                # Phase 1: weather first.  Clouds/rain are the visual first-paint
                # spine and should not sit behind RTOFS/RTOFS/CoastWatch ocean work.
                # Write weather-only scene-tile products for the first visible tiles;
                # phase 2 immediately overwrites with requested/full products.
                weather_first_layers = {"clouds", "rain"}
                try:
                    weather_first_limit = max(1, min(int(os.getenv("GFS_WEATHER_FIRST_WARM_LIMIT", "8") or "8"), len(tiles)))
                except Exception:
                    weather_first_limit = min(8, len(tiles))
                for item in tiles[:weather_first_limit]:
                    tid0 = str(item.get("tile_id") or "")
                    if not tid0:
                        continue
                    try:
                        self.tile_intel_payload(tid0, ttl_seconds=0, visible_bbox=scene.get("visible_bbox"), allowed_layers=weather_first_layers)
                        with self._globe_cache_warm_lock:
                            st = self._globe_cache_warm_state
                            st["weather_first_completed_tiles"] = int(st.get("weather_first_completed_tiles") or 0) + 1
                            st["last_tile_id"] = tid0
                    except Exception as exc:
                        log.info("[gfs/cache] weather-first warm skipped tile=%s err=%s", tid0, exc)
                        with self._globe_cache_warm_lock:
                            st = self._globe_cache_warm_state
                            st["weather_first_failed_tiles"] = int(st.get("weather_first_failed_tiles") or 0) + 1
                            st["last_weather_error"] = str(exc)
                with self._globe_cache_warm_lock:
                    st = self._globe_cache_warm_state
                    st["phase"] = "requested_layers"
                    st["message"] = "warming bounded live scene-tile point cache after weather-first pass"
                # Warm many small tiles in parallel. Each worker is synchronous for a
                # single tile, but the thread pool lets NCSS/cache exchanges overlap.
                # Existing disk cache is read first by tile_intel_payload(); ttl=0 then
                # refreshes the compact tile product while provider-level caches keep
                # network use bounded.
                workers = max(1, min(int(os.getenv("GFS_TILE_WARM_WORKERS", "1") or "1"), 4))

                # Do not feed ocean layers through generic scene-tile warm.  That
                # creates a nested fanout: 36 scene tiles * 36 ocean provider tiles.
                # Ocean/boater/bait are warmed by scene_cache_refresh_payload as one
                # authoritative fixed-36 provider batch for the viewport.
                ocean_layer_names = {"bait", "boater", "boats", "shark-intel", "ocean", "oceanpoints", "current", "currents"}
                tile_requested_layers = {x for x in requested_layers if x not in ocean_layer_names}
                if requested_layers and not tile_requested_layers:
                    tile_requested_layers = {"clouds", "rain"}

                def _warm_one(item: dict[str, Any]) -> dict[str, Any]:
                    tid = str(item.get("tile_id") or "")
                    if not tid:
                        return {"ok": False, "tile_id": None, "error": "missing_tile_id"}
                    payload = self.tile_intel_payload(tid, ttl_seconds=0, visible_bbox=scene.get("visible_bbox"), allowed_layers=tile_requested_layers)
                    return {"ok": True, "tile_id": tid, "latency_ms": payload.get("latency_ms"), "cache_hit": bool((payload.get("cache") or {}).get("hit")), "tile_layers": sorted(tile_requested_layers)}

                with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="gfs-tile-warm") as pool:
                    futures = [pool.submit(_warm_one, item) for item in tiles_to_build if item.get("tile_id")]
                    for fut in as_completed(futures):
                        try:
                            result = fut.result()
                            tid = str(result.get("tile_id") or "")
                            with self._globe_cache_warm_lock:
                                st = self._globe_cache_warm_state
                                if result.get("ok"):
                                    st["completed_tiles"] = int(st.get("completed_tiles") or 0) + 1
                                else:
                                    st["failed_tiles"] = int(st.get("failed_tiles") or 0) + 1
                                    st["last_error"] = str(result.get("error") or "tile warm failed")
                                st["last_tile_id"] = tid
                                st["message"] = "warming parallel small scene-tile point cache"
                        except Exception as exc:
                            log.warning("[gfs] tile warm failed err=%s", exc)
                            with self._globe_cache_warm_lock:
                                st = self._globe_cache_warm_state
                                st["failed_tiles"] = int(st.get("failed_tiles") or 0) + 1
                                st["last_error"] = str(exc)
                with self._globe_cache_warm_lock:
                    st = self._globe_cache_warm_state
                    st["running"] = False
                    st["finished_at"] = self._now_ms()
                    st["message"] = "scene-tile point cache warm complete"
            except Exception as exc:
                log.warning("[gfs] globe cache warm crashed err=%s", exc)
                try:
                    with self._globe_cache_warm_lock:
                        st = self._globe_cache_warm_state
                        st["running"] = False
                        st["finished_at"] = self._now_ms()
                        st["message"] = "cache warm failed"
                        st["last_error"] = str(exc)
                except Exception:
                    pass

        threading.Thread(target=_run, name="gfs-globe-cache-refresh", daemon=True).start()
        return {"ok": True, "schema": "lftr_globe_cache_warm_v1", "scheduled": True, "reason": reason, "requested_layers": sorted(requested_layers) if requested_layers else ["all"], "blocked_ocean_layers": sorted(requested_ocean_layers), "route_policy": "generic_scene_tile_warmer_is_atmosphere_only_rtofs_ocean_has_separate_owner", "scene_plan": scene, "tile_budget": budget, "requested_tiles_total": tiles_total, "tiles_total": tiles_total, "tiles_scheduled": len(plan.get("tiles") or []), "scheduled_tiles": len(plan.get("tiles") or []), "skipped_tiles_budget": max(0, tiles_total - len(plan.get("tiles") or [])), "partial_refresh": tiles_total > len(plan.get("tiles") or []), "remaining_tiles": max(0, tiles_total - len(plan.get("tiles") or [])), "next_refresh_allowed_at": self._now_ms() + int(os.getenv("GFS_SCENE_CACHE_REFRESH_INTERVAL_MS", "120000") or "120000"), "plan": plan, "warm": self._cache_warm_status_payload()}

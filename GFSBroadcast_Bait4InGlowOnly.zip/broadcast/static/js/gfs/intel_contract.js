export const OCEAN_MISSION_LAYERS = Object.freeze(['bait', 'boater', 'shark-intel']);
export const LOD_LEVELS = Object.freeze(['global', 'local']);

export function normalizeLodName(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (['local', 'regional', 'coastal', 'harbor', 'detail', 'full', 'lake'].includes(raw)) return 'local';
  return 'global';
}

function n(value, fallback = NaN) {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

export function displayTempF(value) {
  const temp = n(value, NaN);
  return Number.isFinite(temp) ? `${Math.round(temp)}°F` : null;
}

export function canonicalOceanIntelCell(point = {}) {
  const sstC = n(point.raw_sst_c ?? point.sst_c ?? point.sst ?? point.water_temp_c, NaN);
  const sstF = n(point.norm_sst_f ?? point.water_temp_f ?? (Number.isFinite(sstC) ? (sstC * 9 / 5 + 32) : NaN), NaN);
  const speedKt = n(point.norm_current_speed_kt ?? point.current_speed_kt ?? point.speedKt, NaN);
  const dirDeg = n(point.norm_current_dir_deg ?? point.current_dir_deg ?? point.direction_deg ?? point.heading, NaN);
  const water = point.derived_water_mask ?? point.water ?? point.valid ?? false;
  return {
    ...point,
    layer_family: point.layer_family || 'ocean_mission',
    norm_sst_f: Number.isFinite(sstF) ? Math.round(sstF * 10) / 10 : null,
    norm_current_speed_kt: Number.isFinite(speedKt) ? speedKt : null,
    norm_current_dir_deg: Number.isFinite(dirDeg) ? dirDeg : null,
    derived_water_mask: Boolean(water),
    derived_land_mask: !Boolean(water),
    status_ocean: point.status_ocean || (water ? 'ready' : 'unresolved'),
    display_temp: point.display_temp || displayTempF(sstF),
    display_current: point.display_current || (Number.isFinite(speedKt) ? `${speedKt.toFixed(1)} kt${Number.isFinite(dirDeg) ? ` @ ${Math.round(dirDeg)}°` : ''}` : null),
    score_bait: n(point.score_bait ?? point.baitScore ?? point.bait_score, 0),
  };
}

export function canonicalInlandTemp(point = {}) {
  const tempF = n(point.norm_temp_f ?? point.water_temp_f ?? point.temp_f ?? point.temperature_f, NaN);
  return {
    ...point,
    layer_family: point.layer_family || 'inland_water',
    norm_temp_f: Number.isFinite(tempF) ? Math.round(tempF * 10) / 10 : null,
    status_temp: point.status_temp || point.temp_status || (Number.isFinite(tempF) ? 'ready' : 'unresolved'),
    reason_temp: point.reason_temp || point.temp_reason || (Number.isFinite(tempF) ? 'temp_available' : 'temp_unresolved'),
    display_temp: point.display_temp || displayTempF(tempF),
    display_name: point.display_name || point.name || point.lake_name || null,
  };
}

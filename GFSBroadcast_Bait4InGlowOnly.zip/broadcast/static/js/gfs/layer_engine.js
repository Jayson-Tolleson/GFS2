export class LayerEngine {
  constructor(){
    this.layers = {}
    this.lastTs = performance.now()
    this.latestData = null
  }
  register(name, layer){
    this.layers[name] = { enabled:false, instance:layer }
    if (this.latestData && typeof layer.onData === 'function') {
      try { layer.onData(this.latestData) } catch (err) { console.error('[gfs layers] onData failed', name, err) }
    }
  }
  setData(payload){
    const started = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now()
    this.latestData = payload || null
    const results = {}
    const enabled = []
    Object.entries(this.layers).forEach(([name, layer]) => {
      if (layer.enabled) {
        enabled.push(name)
        try {
          results[name] = layer.instance.onData?.(this.latestData) || { layer:name, stage:'no_onData' }
        } catch (err) {
          console.error('[gfs layers] data sync failed', name, err)
          results[name] = { layer:name, stage:'engine_onData_failed', message:err?.message || String(err) }
        }
      }
    })
    const elapsed = Math.round(((typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now()) - started)
    const telemetry = window.__gfsRenderTelemetry?.estimate || {}
    const realization = Object.fromEntries(enabled.map((name) => {
      const m = telemetry[name] || {}
      return [name, {
        last_ms: Number(m.last_ms || 0),
        avg_ms: Number(m.avg_ms || 0),
        max_ms: Number(m.max_ms || 0),
        dom: Number(m.dom || 0),
        class: m.realization || 'pending',
      }]
    }))
    const summary = { stage:'engine_setData_done', enabled_layers:enabled, elapsed_ms:elapsed, layers:results, render_realization_estimate:realization }
    if (typeof window.__GFS_DEBUG_PANEL_EVENT === 'function') {
      try { window.__GFS_DEBUG_PANEL_EVENT('render/pipeline-summary', summary) } catch (_) {}
    } else {
      try { window.__gfsDebugEvent?.('render/pipeline-summary', summary) } catch (_) {}
    }
    try { if (window.__GFS_RENDER_STAGE_CONSOLE === true) console.info('[GFS RENDER SUMMARY]', summary) } catch (_) {}
    return summary
  }
  setEnabled(name, enabled){
    const layer = this.layers[name]
    if(!layer){ console.warn('[gfs layers] missing layer:', name); return false }
    if(layer.enabled === enabled) {
      if(enabled && this.latestData) {
        try { layer.instance.onData?.(this.latestData) } catch (err) { console.error('[gfs layers] onData failed', name, err) }
      }
      return true
    }
    layer.enabled = enabled
    try {
      if(enabled){
        layer.instance.show?.()
        if (this.latestData) layer.instance.onData?.(this.latestData)
      } else {
        layer.instance.hide?.()
      }
    } catch (err) {
      console.error('[gfs layers] toggle failed', name, err)
    }
    return true
  }
  toggle(name){
    const layer = this.layers[name]
    if(!layer){ console.warn('[gfs layers] missing layer:', name); return false }
    return this.setEnabled(name, !layer.enabled)
  }
  update(){
    const now = performance.now()
    const dt = Math.max(0, (now - this.lastTs) / 1000)
    this.lastTs = now
    Object.values(this.layers).forEach((layer) => {
      if(layer.enabled){
        try { layer.instance.update?.(dt) } catch (err) { console.error('[gfs layers] update failed', err) }
      }
    })
  }
}

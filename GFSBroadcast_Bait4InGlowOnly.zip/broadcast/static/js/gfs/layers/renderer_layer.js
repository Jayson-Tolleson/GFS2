const DRAWABLE_REASONS = new Set(['boot', 'steady', 'settled', 'refresh', 'manual', 'cache_update', 'tile_update', 'bait-deferred', 'clouds-deferred', 'boats-deferred', 'oceanPoints-deferred']);
const HOLD_REASONS = new Set(['camera_move', 'camera_moving', 'orbit', 'orbit_move', 'pan', 'tilt', 'range', 'heading']);

function nowMs() {
  return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
}
function normalizeReason(reason) { return String(reason || 'steady').toLowerCase(); }
function isDrawableReason(reason) {
  const r = normalizeReason(reason);
  return DRAWABLE_REASONS.has(r) || r.endsWith('_settled') || r.includes('settled') || r.includes('steady') || r.includes('update');
}
function isHoldReason(reason) {
  const r = normalizeReason(reason);
  return HOLD_REASONS.has(r) || r.includes('camera_move') || r.includes('moving');
}
function isPromiseLike(value) { return value && typeof value.then === 'function'; }
function countDebugArray(value) { return Array.isArray(value) ? value.length : 0; }

function summarizeDebugPayload(payload) {
  if (!payload || typeof payload !== 'object') return { type: typeof payload };
  const bait = payload.bait || {};
  const scene = payload.scene || {};
  const summary = {
    status: payload.status || payload.payload_state || payload.source_state || payload.mode || undefined,
    source: payload.source || payload.data_source || payload.provider || bait.source || undefined,
    version: payload.__gfsRenderVersion || payload.version || payload.cache?.version || payload.cache_quality?.version || payload.tile_version || undefined,
    cache_hit: payload.cache?.hit ?? payload.cache_hit ?? undefined,
    bbox: payload.bbox || payload.bbox_used || undefined,
    items: countDebugArray(payload.items || payload.features || payload.tiles),
    points: countDebugArray(payload.points || payload.samples || payload.ocean_points || payload.score_points),
    polygons: countDebugArray(payload.polygons || bait.polygons || payload.contours) + countDebugArray(bait.outer_polygons) + countDebugArray(bait.inner_polygons) + countDebugArray(bait.core_polygons),
    boats: countDebugArray(payload.boats),
    flashes: countDebugArray(payload.flashes || payload.regions),
    precip_columns: countDebugArray(payload.precip_columns || scene.precip),
    temp_points: countDebugArray(payload.temperature_points || payload.temp_points),
    lines: countDebugArray(payload.lines),
  };
  return Object.fromEntries(Object.entries(summary).filter(([, v]) => v !== undefined && v !== null && v !== '' && v !== 0));
}

function domCountForLayer(map, name) {
  try {
    if (!map || !name) return 0;
    const selectors = [
      `[data-gfs-layer="${name}"]`,
      name === 'clouds' ? '[data-cloud-shell],[data-cloud-particle]' : '',
      name === 'jetstream' ? '[data-jetstream-balloon],gmp-marker-3d[data-jetstream-balloon]' : '',
      name === 'boater' ? '[data-gfs-layer="current-zones"]' : '',
      name === 'bait' ? '[data-bait-renderer],[data-bait-particle-id]' : '',
    ].filter(Boolean).join(',');
    return map.querySelectorAll?.(selectors)?.length || 0;
  } catch (_) { return 0; }
}

function pushRenderTelemetry(detail) {
  try {
    const layer = detail?.layer || 'unknown';
    const elapsed = Number(detail?.elapsed_ms);
    const state = window.__gfsRenderTelemetry || { layers: {}, samples: [] };
    const prev = state.layers[layer] || { count: 0, avg_ms: 0, max_ms: 0, last_ms: 0, last_stage: '', last_reason: '' };
    if (Number.isFinite(elapsed) && elapsed >= 0) {
      const count = prev.count + 1;
      prev.avg_ms = Math.round(((prev.avg_ms * prev.count) + elapsed) / count);
      prev.count = count;
      prev.max_ms = Math.max(prev.max_ms || 0, Math.round(elapsed));
      prev.last_ms = Math.round(elapsed);
    }
    prev.last_stage = detail?.stage || prev.last_stage;
    prev.last_reason = detail?.reason || prev.last_reason;
    prev.dom = detail?.domAfter ?? detail?.domBefore ?? prev.dom;
    state.layers[layer] = prev;
    state.samples.push({ ts: Date.now(), layer, stage: detail?.stage, reason: detail?.reason, elapsed_ms: Number.isFinite(elapsed) ? Math.round(elapsed) : undefined, dom: prev.dom });
    if (state.samples.length > 120) state.samples.splice(0, state.samples.length - 120);
    state.estimate = Object.fromEntries(Object.entries(state.layers).map(([name, m]) => [name, {
      last_ms: m.last_ms || 0,
      avg_ms: m.avg_ms || 0,
      max_ms: m.max_ms || 0,
      dom: m.dom || 0,
      realization: (m.avg_ms || m.last_ms || 0) > 700 ? 'slow' : ((m.avg_ms || m.last_ms || 0) > 180 ? 'medium' : 'fast'),
    }]));
    window.__gfsRenderTelemetry = state;
  } catch (_) {}
}

function emitRenderStage(detail) {
  const clean = Object.fromEntries(Object.entries(detail || {}).filter(([, v]) => v !== undefined && v !== null && v !== ''));
  pushRenderTelemetry(clean);
  if (typeof window.__GFS_DEBUG_PANEL_EVENT === 'function') {
    try { window.__GFS_DEBUG_PANEL_EVENT('render/stage', clean); } catch (_) {}
  } else {
    try { window.__gfsDebugEvent?.('render/stage', clean); } catch (_) {}
  }
  try { if (window.__GFS_RENDER_STAGE_CONSOLE === true) console.info('[GFS RENDER]', clean); } catch (_) {}
  return clean;
}

function defaultSignature(frame, payload) {
  const explicitVersion = payload?.__gfsRenderVersion || payload?.version || payload?.cache?.version || payload?.cache_quality?.version || payload?.tile_version || payload?.cache?.key || payload?.__gfsCacheMeta?.version || payload?.__gfsCacheMeta?.cache_key || '';
  if (explicitVersion) return String(explicitVersion);
  const bbox = Array.isArray(payload?.bbox) ? payload.bbox.join(',') : (Array.isArray(frame?.bbox) ? frame.bbox.join(',') : '');
  const valid = payload?.valid_time || frame?.valid_time || '';
  const source = payload?.source_time || frame?.source_time || '';
  const resolved = payload?.resolved_time || frame?.resolved_time || '';
  const bait = payload?.bait || {};
  const hint = [
    Array.isArray(payload?.cloud_layers) ? payload.cloud_layers.length : 0,
    Array.isArray(payload?.items) ? payload.items.length : 0,
    Array.isArray(payload?.features) ? payload.features.length : 0,
    Array.isArray(payload?.polygon_field_v1?.features) ? payload.polygon_field_v1.features.length : 0,
    payload?.sea_feature_count || 0,
    payload?.sea_resolution?.subgrid_used || '',
    Array.isArray(payload?.precip_columns) ? payload.precip_columns.length : 0,
    Array.isArray(payload?.scene?.clouds) ? payload.scene.clouds.length : 0,
    Object.keys(payload?.fields || {}).join(','),
    Array.isArray(payload?.front_lines) ? payload.front_lines.length : 0,
    Array.isArray(bait?.polygons) ? bait.polygons.length : 0,
    Array.isArray(bait?.outer_polygons) ? bait.outer_polygons.length : 0,
    Array.isArray(bait?.inner_polygons) ? bait.inner_polygons.length : 0,
    Array.isArray(bait?.core_polygons) ? bait.core_polygons.length : 0,
    Array.isArray(payload?.bait_score) ? payload.bait_score.length : 0,
    Array.isArray(payload?.oceanPoints?.points) ? payload.oceanPoints.points.length : 0,
    payload?.oceanPoints?.source_time || payload?.oceanPoints?.valid_time || '',
    Array.isArray(payload?.boats) ? payload.boats.length : 0,
    Array.isArray(payload?.polygons?.boater) ? payload.polygons.boater.length : 0,
    Array.isArray(payload?.current_polygons) ? payload.current_polygons.length : 0,
  ].join(':');
  return `${bbox}|${valid}|${source}|${resolved}|${hint}`;
}

export class RendererLayer {
  constructor(map3DElement, { name, selector, renderer, signature, clearBeforeRender = true, preserveOnEmpty = false, minRenderIntervalMs = 0 }) {
    this.map = map3DElement;
    this.name = name;
    this.selector = selector;
    this.renderer = renderer;
    this.signature = signature || defaultSignature;
    this.visible = false;
    this.currentFrame = null;
    this.currentDisposer = null;
    this.lastSignature = '';
    this.clearBeforeRender = clearBeforeRender !== false;
    this.preserveOnEmpty = preserveOnEmpty === true;
    this.minRenderIntervalMs = Math.max(0, Number(minRenderIntervalMs || 0));
    this.lastRenderAt = 0;
    this.pendingRenderToken = null;
    this.stats = { draws: 0, skips: 0, preserves: 0, clears: 0 };
  }

  show() { this.visible = true; if (this.currentFrame) this.onData(this.currentFrame); }
  hide() { this.visible = false; this.clear(); }

  clear() {
    this.lastSignature = '';
    this.pendingRenderToken = null;
    this.stats.clears += 1;
    try { this.map?.querySelectorAll?.(`[data-gfs-layer="${this.name}"]`)?.forEach((el) => { try { el.remove(); } catch (_) {} }); } catch (_) {}
    if (typeof this.currentDisposer === 'function') {
      try { this.currentDisposer(); } catch (err) { console.warn('[gfs renderer layer] disposer failed', this.name, err); }
    }
    this.currentDisposer = null;
  }

  _commitRenderResult({ result, previousDisposer, nextSignature, shortSignature, base, payloadSummary, domBefore, started }) {
    if (result && result.__gfsKeepExisting === true) {
      this.currentDisposer = result;
      this.lastSignature = nextSignature;
      this.lastRenderAt = Date.now();
      this.stats.draws += 1;
      return emitRenderStage({ ...base, stage: 'draw_reconciled_keep_existing', signature: shortSignature, payload: payloadSummary, domBefore, domAfter: domCountForLayer(this.map, this.name), elapsed_ms: Math.round(nowMs() - started), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    if (result && result.__gfsDidRender === true) {
      if (typeof previousDisposer === 'function') {
        try { previousDisposer(); } catch (err) { console.warn('[gfs renderer layer] previous disposer failed', this.name, err); }
      }
      this.currentDisposer = result;
      this.lastSignature = nextSignature;
      this.lastRenderAt = Date.now();
      this.stats.draws += 1;
      return emitRenderStage({ ...base, stage: 'draw_replaced_previous', signature: shortSignature, payload: payloadSummary, domBefore, domAfter: domCountForLayer(this.map, this.name), elapsed_ms: Math.round(nowMs() - started), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    if (typeof result === 'function') {
      if (this.clearBeforeRender && typeof previousDisposer === 'function') {
        try { previousDisposer(); } catch (_) {}
      }
      this.currentDisposer = result;
      this.lastSignature = nextSignature;
      this.lastRenderAt = Date.now();
      this.stats.draws += 1;
      return emitRenderStage({ ...base, stage: this.clearBeforeRender ? 'draw_done' : 'draw_replaced_plain_disposer', signature: shortSignature, payload: payloadSummary, domBefore, domAfter: domCountForLayer(this.map, this.name), elapsed_ms: Math.round(nowMs() - started), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    this.stats.preserves += 1;
    return emitRenderStage({ ...base, stage: 'draw_returned_noop_preserve', signature: shortSignature, payload: payloadSummary, domBefore, domAfter: domCountForLayer(this.map, this.name), elapsed_ms: Math.round(nowMs() - started), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
  }

  onData(frame) {
    const started = nowMs();
    const base = { layer: this.name, reason: frame?.render_reason || frame?.meta?.render_reason || 'steady' };
    this.currentFrame = frame || null;
    if (!this.visible || !this.map || !frame) {
      return emitRenderStage({ ...base, stage: 'skip_not_visible_or_no_frame', visible: this.visible, hasMap: Boolean(this.map), hasFrame: Boolean(frame), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    const viewportReason = frame?.render_reason || frame?.meta?.render_reason || 'steady';
    const payload = this.selector?.(frame) || null;
    const domBefore = domCountForLayer(this.map, this.name);
    if (!payload) {
      if (this.preserveOnEmpty || isHoldReason(viewportReason)) {
        this.stats.preserves += 1;
        return emitRenderStage({ ...base, stage: this.currentDisposer ? 'preserve_empty_payload' : 'preserve_empty_payload_no_last_good', policy: 'preserve_last_good_clear_only_on_pill_off', domBefore, domAfter: domBefore, draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
      }
      this.clear();
      return emitRenderStage({ ...base, stage: 'clear_empty_payload', domBefore, domAfter: domCountForLayer(this.map, this.name), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    const payloadSummary = summarizeDebugPayload(payload);
    if (!isDrawableReason(viewportReason) && this.currentDisposer) {
      this.stats.preserves += 1;
      return emitRenderStage({ ...base, stage: 'hold_camera_moving', payload: payloadSummary, domBefore, domAfter: domBefore, draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    const nextSignature = String(this.signature(frame, payload));
    const shortSignature = nextSignature.length > 96 ? `${nextSignature.slice(0, 96)}…` : nextSignature;
    if (nextSignature && nextSignature === this.lastSignature) {
      this.stats.skips += 1;
      return emitRenderStage({ ...base, stage: 'skip_same_signature', signature: shortSignature, payload: payloadSummary, domBefore, domAfter: domBefore, draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    if (this.minRenderIntervalMs > 0 && this.currentDisposer && this.lastRenderAt > 0) {
      const elapsed = Date.now() - this.lastRenderAt;
      const reasonText = String(viewportReason || '').toLowerCase();
      const force = reasonText.includes('pill_') || reasonText.includes('manual') || reasonText.includes('boot');
      if (!force && elapsed < this.minRenderIntervalMs) {
        this.stats.skips += 1;
        return emitRenderStage({ ...base, stage: 'skip_min_interval', elapsed_ms: elapsed, min_ms: this.minRenderIntervalMs, signature: shortSignature, payload: payloadSummary, domBefore, domAfter: domBefore, draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
      }
    }
    emitRenderStage({ ...base, stage: 'draw_start', clearBeforeRender: this.clearBeforeRender, signature: shortSignature, payload: payloadSummary, domBefore, draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    const previousDisposer = this.currentDisposer;
    if (this.clearBeforeRender) this.clear();
    let result = null;
    try {
      result = this.renderer?.({ frame, payload, map3DElement: this.map, viewportReason: isDrawableReason(viewportReason) ? viewportReason : 'steady', layerName: this.name }) || null;
    } catch (err) {
      console.error('[gfs renderer layer] render failed', this.name, err);
      return emitRenderStage({ ...base, stage: 'draw_failed', message: err?.message || String(err), payload: payloadSummary, domBefore, domAfter: domCountForLayer(this.map, this.name), elapsed_ms: Math.round(nowMs() - started), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    if (isPromiseLike(result)) {
      const token = { layer: this.name, signature: nextSignature, started };
      this.pendingRenderToken = token;
      result.then((resolved) => {
        if (this.pendingRenderToken !== token || !this.visible) return;
        this._commitRenderResult({ result: resolved, previousDisposer, nextSignature, shortSignature, base, payloadSummary, domBefore, started });
      }).catch((err) => {
        if (this.pendingRenderToken !== token) return;
        console.error('[gfs renderer layer] async render failed', this.name, err);
        emitRenderStage({ ...base, stage: 'draw_async_failed', message: err?.message || String(err), payload: payloadSummary, domBefore, domAfter: domCountForLayer(this.map, this.name), elapsed_ms: Math.round(nowMs() - started), draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
      });
      return emitRenderStage({ ...base, stage: 'draw_async_pending', signature: shortSignature, payload: payloadSummary, domBefore, elapsed_ms: Math.round(nowMs() - started), policy: 'lazy_renderer_promise_tracked_for_realization_time', draws: this.stats.draws, skips: this.stats.skips, preserves: this.stats.preserves, clears: this.stats.clears });
    }
    return this._commitRenderResult({ result, previousDisposer, nextSignature, shortSignature, base, payloadSummary, domBefore, started });
  }

  update() {}
}

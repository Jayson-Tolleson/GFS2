import { attachPolygonHover } from './hover_tip.js';

// LFTR lightning visual layer.
//
// Data contract: this renderer accepts true GOES GLM L2 LCFA flash rows when the
// backend has them, but it does not fetch data and it never blocks first paint.
// It owns only drawing, fading, and scoped cleanup for lightning event particles.

const MAX_LIGHTENING_FLASHES = Number(window.GFS_LIGHTENING_MAX_FLASHES || window.GFS_LIGHTNING_MAX_FLASHES || 96);
const MAX_LIGHTENING_REGIONS = Number(window.GFS_LIGHTENING_MAX_REGIONS || window.GFS_LIGHTNING_MAX_REGIONS || 24);
const FLASH_TTL_SECONDS = Number(window.GFS_GLM_FLASH_TTL_SECONDS || 120);
const FADE_MS = Number(window.GFS_LIGHTENING_FADE_MS || window.GFS_LIGHTNING_FADE_OUT_MS || 1800);
const LAYER_SELECTOR = '[data-gfs-layer="lightning"],[data-gfs-layer="lightening"]';

function n(value, fallback = 0) {
  const out = Number(value);
  return Number.isFinite(out) ? out : fallback;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function firstArray(...values) {
  for (const value of values) {
    if (Array.isArray(value)) return value;
  }
  return [];
}

function asCenter(row) {
  return row?.center || row?.properties?.center || row?.geometry?.center || {};
}

function normalizeFlash(row) {
  if (!row || typeof row !== 'object') return null;
  const center = asCenter(row);
  const lat = n(row.lat ?? row.latitude ?? row.flash_lat ?? center.lat ?? center.latitude, NaN);
  const lon = n(row.lon ?? row.lng ?? row.longitude ?? row.flash_lon ?? center.lon ?? center.lng ?? center.longitude, NaN);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;

  const ttl = Math.max(8, n(row.event_ttl_seconds ?? row.particle_ttl_seconds, FLASH_TTL_SECONDS));
  const age = Math.max(0, n(row.age_seconds, 0));
  const expiresIn = Math.max(0, Math.min(ttl - age, n(row.expires_in_seconds, ttl - age)));
  if (expiresIn <= 0) return null;

  const energy = n(row.energy_j ?? row.energy ?? row.flash_energy ?? row.visual_priority ?? row.severity, 0);
  return {
    ...row,
    lat,
    lon,
    age_seconds: age,
    expires_in_seconds: expiresIn,
    event_ttl_seconds: ttl,
    energy_j: energy,
    source: row.source || row.properties?.source || 'goes_glm_l2_lcfa',
    product: row.product || 'GLM-L2-LCFA',
    satellite: row.satellite || row.platform || row.goes || 'GOES GLM',
    time: row.time || row.valid_time || row.event_time || row.generated_at || 'recent',
  };
}

function flashesFromPayload(payload) {
  return firstArray(payload?.flashes, payload?.items, payload?.events, payload?.features)
    .map(normalizeFlash)
    .filter(Boolean)
    .sort((a, b) => n(a.age_seconds, 0) - n(b.age_seconds, 0))
    .slice(0, MAX_LIGHTENING_FLASHES);
}

function regionsFromPayload(payload) {
  const ttl = Math.max(8, n(payload?.event_ttl_seconds ?? payload?.particle_ttl_seconds, FLASH_TTL_SECONDS));
  return firstArray(payload?.regions, payload?.clusters)
    .map((row) => {
      const center = asCenter(row);
      const lat = n(row?.lat ?? center.lat ?? center.latitude, NaN);
      const lon = n(row?.lon ?? row?.lng ?? center.lon ?? center.lng ?? center.longitude, NaN);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
      const age = Math.max(0, n(row.age_seconds, 0));
      const expiresIn = Math.max(0, ttl - age);
      if (expiresIn <= 0) return null;
      return { ...row, lat, lon, age_seconds: age, expires_in_seconds: expiresIn, event_ttl_seconds: ttl };
    })
    .filter(Boolean)
    .slice(0, MAX_LIGHTENING_REGIONS);
}

export function clearLighteningLayer(map3DElement) {
  try {
    map3DElement?.querySelectorAll?.(LAYER_SELECTOR)?.forEach((el) => el.remove());
  } catch (_) {}
}

function fadeRemove(el, durationMs = FADE_MS) {
  if (!el || el.__lftrLighteningRemoving) return;
  el.__lftrLighteningRemoving = true;
  try {
    el.style.transition = `opacity ${Math.max(100, durationMs)}ms ease-out, transform ${Math.max(100, durationMs)}ms ease-out`;
    el.style.opacity = '0';
    el.style.transform = 'scale(0.62)';
  } catch (_) {}
  window.setTimeout(() => { try { el.remove(); } catch (_) {} }, Math.max(120, durationMs));
}

function expireElement(el, item) {
  const expiresIn = Math.max(0, n(item?.expires_in_seconds, 0));
  const delayMs = Math.max(0, expiresIn * 1000 - FADE_MS);
  try { el.setAttribute('data-lightening-expires-in-seconds', expiresIn.toFixed(1)); } catch (_) {}
  window.setTimeout(() => fadeRemove(el), delayMs);
}

function boltTemplate(flash) {
  const uid = `lftr-lightening-${Math.random().toString(16).slice(2)}`;
  const energy = Math.max(0, n(flash.energy_j, 0));
  const age = Math.max(0, n(flash.age_seconds, 0));
  const fresh = clamp(1 - age / Math.max(20, n(flash.event_ttl_seconds, FLASH_TTL_SECONDS)), 0.25, 1);
  const scale = clamp(0.85 + Math.log10(energy + 10) * 0.10, 0.85, 1.45);
  const opacity = clamp(0.42 + fresh * 0.52, 0.36, 0.96);
  const tpl = document.createElement('template');
  tpl.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="72" height="72" viewBox="0 0 72 72" style="overflow:visible;pointer-events:none;transform:scale(${scale.toFixed(2)})">
    <defs>
      <filter id="${uid}-glow" x="-90%" y="-90%" width="280%" height="280%"><feGaussianBlur stdDeviation="3.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <radialGradient id="${uid}-halo" cx="50%" cy="50%" r="50%"><stop offset="0%" stop-color="#ffffff" stop-opacity="${opacity.toFixed(2)}"/><stop offset="45%" stop-color="#fde047" stop-opacity="${(opacity * 0.45).toFixed(2)}"/><stop offset="100%" stop-color="#60a5fa" stop-opacity="0"/></radialGradient>
    </defs>
    <circle cx="36" cy="36" r="27" fill="url(#${uid}-halo)"/>
    <path d="M38 3 L20 34 L34 34 L27 69 L53 29 L39 30 L48 3 Z" fill="#fff" stroke="#fde047" stroke-width="2.7" stroke-linejoin="round" filter="url(#${uid}-glow)" opacity="${opacity.toFixed(2)}"/>
  </svg>`;
  return tpl;
}

function makeFlashMarker(flash) {
  const altitude = clamp(7800 - n(flash.age_seconds, 0) * 18, 2200, 8200);
  const marker = document.createElement('gmp-marker-3d');
  marker.position = { lat: flash.lat, lng: flash.lon, altitude };
  marker.drawsWhenOccluded = true;
  marker.sizePreserved = true;
  marker.setAttribute('data-gfs-layer', 'lightening');
  marker.setAttribute('data-lightning-source', flash.source || 'goes_glm_l2_lcfa');
  marker.setAttribute('data-lightening-source', flash.source || 'goes_glm_l2_lcfa');
  marker.setAttribute('data-lightening-age-seconds', String(Math.round(n(flash.age_seconds, 0))));
  marker.append(boltTemplate(flash));
  attachPolygonHover(marker, {
    title: 'GOES GLM lightening',
    detail: `${flash.lat.toFixed(3)}, ${flash.lon.toFixed(3)}`,
    lines: [
      `age: ${Math.round(n(flash.age_seconds, 0))} s`,
      `energy: ${n(flash.energy_j, 0) ? n(flash.energy_j, 0).toExponential(2) : 'n/a'}`,
      `satellite: ${flash.satellite || 'GOES GLM'}`,
      `time: ${flash.time || 'recent'}`,
    ],
    metrics: { layer: 'lightening', source: flash.source, product: flash.product },
    payload: flash,
  });
  return marker;
}

function makeRegionMarker(region) {
  const count = Math.max(1, n(region.flash_count ?? region.count, 1));
  const radius = clamp(16 + Math.sqrt(count) * 7, 16, 72);
  const tpl = document.createElement('template');
  tpl.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="112" height="112" viewBox="0 0 112 112" style="overflow:visible;pointer-events:none">
    <circle cx="56" cy="56" r="${radius.toFixed(1)}" fill="#fef08a" fill-opacity="0.06" stroke="#facc15" stroke-opacity="0.34" stroke-width="2.5"/>
    <circle cx="56" cy="56" r="${Math.max(7, radius * 0.32).toFixed(1)}" fill="#60a5fa" fill-opacity="0.10"/>
  </svg>`;
  const marker = document.createElement('gmp-marker-3d');
  marker.position = { lat: region.lat, lng: region.lon, altitude: 5600 };
  marker.drawsWhenOccluded = true;
  marker.sizePreserved = true;
  marker.setAttribute('data-gfs-layer', 'lightening');
  marker.setAttribute('data-lightning-region', 'cluster');
  marker.setAttribute('data-lightening-region', 'cluster');
  marker.append(tpl);
  attachPolygonHover(marker, {
    title: 'Lightening cluster',
    detail: `${count} recent flashes`,
    lines: [`center: ${region.lat.toFixed(3)}, ${region.lon.toFixed(3)}`, `age: ${Math.round(n(region.age_seconds, 0))} s`],
    metrics: { layer: 'lightening', source: region.source || 'goes_glm_l2_lcfa' },
    payload: region,
  });
  return marker;
}

export function renderLighteningLayer({ payload, map3DElement }) {
  if (!map3DElement) return () => {};
  clearLighteningLayer(map3DElement);

  const flashes = flashesFromPayload(payload);
  const regions = regionsFromPayload(payload);
  const fragment = document.createDocumentFragment();
  let markerCount = 0;

  for (const region of regions) {
    const marker = makeRegionMarker(region);
    if (!marker) continue;
    expireElement(marker, region);
    fragment.append(marker);
    markerCount += 1;
  }

  for (const flash of flashes) {
    const marker = makeFlashMarker(flash);
    if (!marker) continue;
    expireElement(marker, flash);
    fragment.append(marker);
    markerCount += 1;
  }

  if (markerCount) map3DElement.append(fragment);
  console.info('[gfs lightening] rendered', {
    source: payload?.source,
    state: payload?.payload_state || payload?.status,
    flashes: flashes.length,
    regions: regions.length,
    markers: markerCount,
    glm: payload?.source === 'goes_glm_l2_lcfa' || payload?.quality?.live_goes_glm === true,
  });
  return () => clearLighteningLayer(map3DElement);
}

// Backward-compatible export for old imports while paths are being cleaned.
export const renderLightningLayer = renderLighteningLayer;
export const clearLightningLayer = clearLighteningLayer;

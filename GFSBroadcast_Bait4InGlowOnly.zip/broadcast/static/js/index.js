import { getSceneFrame, getJsonSafe } from './gfs/api.js';
import { ensureMaps3D, libs as loadMapsLibs } from './gfs/globe.js';
import { loadCsvLocations, renderCsvLocations } from './location-csv.js';
import { createIntelligencePane } from './intelligence-pane.js';
import { sceneFrameLayerSummary, oceanPointsFromPayload, baitRowsFromPayload, countPolygons } from './layers/scene-frame-utils.js';

const CAMERA_STEADY_DEBOUNCE_MS = Number(window.GFS_CAMERA_STEADY_DEBOUNCE_MS || 900);
const SCENE_REFRESH_MS = Number(window.GFS_SCENE_REFRESH_MS || 120000);
const MODULE_VERSION = '20260615-bait-4in-glow-only-v12';
const LAYER_ORDER = ['clouds', 'rain', 'ocean-glass', 'bait-3d', 'bait', 'boater', 'lightning', 'inland-water'];
const SCENE_LAYER_ALIASES = { 'ocean-glass': null, 'bait-3d': null, boater: 'boats', 'inland-water': 'inland-water' };

const statusEl = document.getElementById('status');
const debugEl = document.getElementById('debugPrompt');
const globeEl = document.getElementById('globe');
const fallbackEl = document.getElementById('globeFallback');
const pillsRoot = document.getElementById('layerPills');

const state = {
  maps3d: null,
  latestFrame: null,
  latestSceneSummary: null,
  latestLocations: [],
  locationDisposer: null,
  layerDisposers: new Map(),
  layerModules: new Map(),
  refreshSeq: 0,
  sceneTimer: null,
  cameraTimer: null,
  destroyed: false,
};

function setStatus(message) {
  if (statusEl) statusEl.textContent = message;
}

function debug(topic, detail = {}) {
  const line = `[${new Date().toLocaleTimeString('en-US', { hour12: false })}] ${topic} ${JSON.stringify(detail)}`;
  if (debugEl) {
    debugEl.value = `${debugEl.value ? `${debugEl.value}\n` : ''}${line}`.split('\n').slice(-250).join('\n');
    debugEl.scrollTop = debugEl.scrollHeight;
  }
  try { console.info(`[gfs clean] ${topic}`, detail); } catch (_) {}
  try { window.__gfsDebugEvent?.(topic, detail); } catch (_) {}
}

function layerEnabled(name) {
  // Ocean Cutout is now standard infrastructure, not an optional pill.
  // Bait-3D follows the Bait pill but uses its own volume endpoint/render pass.
  if (name === 'ocean-glass') return String(window.GFS_STANDARD_OCEAN_CUTOUT ?? '1') !== '0';
  if (name === 'bait-3d') return String(window.GFS_BAIT_3D_VOLUME ?? '1') !== '0' && layerEnabled('bait');
  const btn = pillsRoot?.querySelector(`[data-layer="${name}"]`);
  return btn ? btn.getAttribute('aria-pressed') !== 'false' : false;
}

function bait3dReplacesLegacySurfaceBait() {
  return String(window.GFS_BAIT_3D_REPLACES_SURFACE_BAIT ?? '1') !== '0';
}

function shouldSkipLegacyBaitRender(name) {
  return name === 'bait' && bait3dReplacesLegacySurfaceBait() && layerEnabled('bait-3d');
}

function enabledSceneLayers() {
  return LAYER_ORDER
    .filter(layerEnabled)
    .filter((name) => !shouldSkipLegacyBaitRender(name))
    .map((name) => (Object.prototype.hasOwnProperty.call(SCENE_LAYER_ALIASES, name) ? SCENE_LAYER_ALIASES[name] : name))
    .filter(Boolean);
}

function syncPill(btn, enabled) {
  btn.classList.toggle('active', enabled);
  btn.setAttribute('aria-pressed', enabled ? 'true' : 'false');
  btn.setAttribute('data-layer-enabled', enabled ? 'true' : 'false');
}

function installPills() {
  pillsRoot?.querySelectorAll('.overlay-pill[data-layer]').forEach((btn) => {
    syncPill(btn, btn.classList.contains('active') || btn.getAttribute('aria-pressed') === 'true');
    btn.addEventListener('click', () => {
      const layer = btn.getAttribute('data-layer');
      const next = btn.getAttribute('aria-pressed') === 'false';
      syncPill(btn, next);
      debug('pill/toggle', { layer, enabled: next });
      if (layer === 'locations') {
        renderLocationsSafe();
        return;
      }
      if (!next) clearLayer(layer);
      refreshScene(`pill_${layer}_${next ? 'on' : 'off'}`).catch((err) => debug('scene/refresh-failed', { message: err?.message || String(err) }));
    });
  });
}

function parseCenter() {
  const prop = globeEl?.center || globeEl?.camera?.center || null;
  const propLat = Number(prop?.lat);
  const propLon = Number(prop?.lng ?? prop?.lon);
  if (Number.isFinite(propLat) && Number.isFinite(propLon)) return { lat: propLat, lon: propLon };
  const raw = globeEl?.getAttribute?.('center') || '34.2,-120,120';
  const parts = raw.split(',').map((x) => Number(x.trim()));
  return { lat: Number.isFinite(parts[0]) ? parts[0] : 34.2, lon: Number.isFinite(parts[1]) ? parts[1] : -120 };
}

function parseRangeMeters() {
  const n = Number(globeEl?.range ?? globeEl?.camera?.range ?? globeEl?.getAttribute?.('range'));
  return Number.isFinite(n) && n > 0 ? n : 1800000;
}

function parseCameraNumber(name, fallback = 0) {
  const n = Number(globeEl?.[name] ?? globeEl?.camera?.[name] ?? globeEl?.getAttribute?.(name));
  return Number.isFinite(n) ? n : fallback;
}

function normalizeLongitude(lon) {
  const n = Number(lon);
  if (!Number.isFinite(n)) return 0;
  const wrapped = ((n + 180) % 360 + 360) % 360 - 180;
  return Object.is(wrapped, -180) ? 180 : wrapped;
}

function getViewport() {
  const c = parseCenter();
  const rangeKm = Math.max(5, Math.min(4200, parseRangeMeters() / 1000));
  const rect = globeEl?.getBoundingClientRect?.();
  const aspect = Math.max(0.75, Math.min(2.5, Number(rect?.width || 16) / Math.max(1, Number(rect?.height || 9))));
  const tilt = parseCameraNumber('tilt', 0);
  const viewportPad = Math.max(1.0, Number(window.GFS_SCENE_VIEWPORT_PAD || 1.12));
  const tiltPadGain = Math.max(0, Number(window.GFS_SCENE_VIEWPORT_TILT_PAD_GAIN || 0.16));
  const pad = viewportPad + Math.min(1, Math.max(0, tilt / 67)) * tiltPadGain;
  const latSpan = Math.max(1.2, Math.min(42, (rangeKm / 62) * pad));
  const lonSpan = Math.max(1.6, Math.min(64, ((latSpan * aspect) / Math.max(0.35, Math.cos((c.lat * Math.PI) / 180))) * pad));
  const south = Math.max(-89.9, c.lat - latSpan / 2);
  const north = Math.min(89.9, c.lat + latSpan / 2);
  let west = Math.max(-179.9, normalizeLongitude(c.lon - lonSpan / 2));
  let east = Math.min(179.9, normalizeLongitude(c.lon + lonSpan / 2));
  if (east <= west) { west = -179.9; east = 179.9; }
  return { west, south, east, north, camera: { center: c, range: parseRangeMeters(), heading: parseCameraNumber('heading', 0), tilt: parseCameraNumber('tilt', 0), roll: parseCameraNumber('roll', 0) } };
}

function bboxString(v) {
  return [v.west, v.south, v.east, v.north].map((n) => Number(n).toFixed(4)).join(',');
}

async function loadLayerModule(name) {
  if (!state.layerModules.has(name)) {
    const path = {
      clouds: './layers/clouds.js',
      rain: './layers/rain.js',
      lightning: './layers/lightning.js',
      'ocean-glass': './layers/ocean-glass.js',
      'bait-3d': './layers/bait-3d.js',
      bait: './layers/bait.js',
      boater: './layers/boats.js',
      'inland-water': './layers/inland-water.js',
    }[name];
    const versionedPath = `${path}?v=${encodeURIComponent(MODULE_VERSION)}`;
    state.layerModules.set(name, import(versionedPath));
  }
  return state.layerModules.get(name);
}

async function clearLayer(name) {
  if (name === 'bait') hardClearLegacyBaitDom('clear_bait_layer');
  const dispose = state.layerDisposers.get(name);
  state.layerDisposers.delete(name);
  if (typeof dispose === 'function') {
    try { dispose(); } catch (err) { debug('layer/dispose-failed', { name, message: err?.message || String(err) }); }
  }
  try {
    const mod = await loadLayerModule(name);
    const clearFn = {
      clouds: mod.clearCloudsLayer,
      rain: mod.clearRainLayer,
      lightning: mod.clearLightningLayer,
      'ocean-glass': mod.clearOceanGlassLayer,
      'bait-3d': mod.clearBait3dLayer,
      bait: mod.clearBaitLayer,
      boater: mod.clearBoatsSceneLayer,
      'inland-water': mod.clearInlandWaterSceneLayer,
    }[name];
    clearFn?.(globeEl);
  } catch (err) {
    debug('layer/clear-soft-failed', { name, message: err?.message || String(err) });
  }
}

function normalizeFrame(payload) {
  const layers = payload?.layers && typeof payload.layers === 'object' ? payload.layers : {};
  return {
    ...payload,
    clouds: layers.clouds || payload?.clouds || null,
    rain: layers.rain || payload?.rain || null,
    lightning: layers.lightning || layers.lightening || payload?.lightning || null,
    baitAdvanced: layers.bait || payload?.baitAdvanced || payload?.bait || null,
    boats: layers.boater || layers.boats || payload?.boats || null,
    inlandWater: layers['inland-water'] || layers.inland_water || layers.inland_waterways || payload?.inlandWater || null,
  };
}


function hasRenderableMarine(layerName, layerPayload) {
  if (!layerPayload || typeof layerPayload !== 'object') return false;
  if (layerName === 'bait') {
    return countPolygons(layerPayload) > 0 || baitRowsFromPayload(layerPayload).length > 0 || oceanPointsFromPayload(layerPayload).length > 0;
  }
  if (layerName === 'boater') {
    return (Array.isArray(layerPayload.boats) && layerPayload.boats.length > 0) || oceanPointsFromPayload(layerPayload).length > 0;
  }
  return false;
}

function marineSupplementNeeded(frame) {
  const layers = frame?.layers || {};
  return Boolean(
    (layerEnabled('bait') && !layerEnabled('bait-3d') && !hasRenderableMarine('bait', layers.bait))
    || (layerEnabled('boater') && !hasRenderableMarine('boater', layers.boater || layers.boats))
  );
}

function neededMarineSupplementLayers(frame) {
  const layers = frame?.layers || {};
  const needed = [];
  if (layerEnabled('bait') && !layerEnabled('bait-3d') && !hasRenderableMarine('bait', layers.bait)) needed.push('bait');
  if (layerEnabled('boater') && !hasRenderableMarine('boater', layers.boater || layers.boats)) needed.push('boats');
  return needed;
}

function mergeSupplementalFrame(baseFrame, supplementalFrame, sourceLabel = 'supplemental') {
  if (!supplementalFrame || typeof supplementalFrame !== 'object') return baseFrame;
  const baseLayers = baseFrame?.layers && typeof baseFrame.layers === 'object' ? baseFrame.layers : {};
  const supplementalLayers = supplementalFrame.layers && typeof supplementalFrame.layers === 'object' ? supplementalFrame.layers : {};
  const merged = normalizeFrame({
    ...(baseFrame || {}),
    layers: { ...baseLayers },
  });
  for (const [name, payload] of Object.entries(supplementalLayers)) {
    if (!payload || typeof payload !== 'object') continue;
    if (name === 'bait' && hasRenderableMarine('bait', payload)) merged.layers.bait = payload;
    else if ((name === 'boater' || name === 'boats') && hasRenderableMarine('boater', payload)) merged.layers.boater = payload;
    else if (name === 'shark-intel' && payload.ok !== false) merged.layers['shark-intel'] = payload;
  }
  merged.__supplementalMerge = {
    ...(merged.__supplementalMerge || {}),
    [sourceLabel]: {
      ts: Date.now(),
      layerKeys: Object.keys(supplementalLayers),
      baitRenderable: hasRenderableMarine('bait', merged.layers.bait),
      boaterRenderable: hasRenderableMarine('boater', merged.layers.boater),
    },
  };
  return normalizeFrame(merged);
}

function marineRowsSortedNearViewport(points = [], viewport = null, limit = 12) {
  const rows = (Array.isArray(points) ? points : []).filter((p) => p && typeof p === 'object');
  const center = viewport?.camera?.center || null;
  const clat = Number(center?.lat);
  const clon = Number(center?.lon ?? center?.lng);
  const hasCenter = Number.isFinite(clat) && Number.isFinite(clon);
  const dist2 = (p) => {
    if (!hasCenter) return 0;
    const lat = Number(p?.lat ?? p?.latitude);
    const lon = Number(p?.lon ?? p?.lng ?? p?.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return Infinity;
    const meanLat = ((lat + clat) * 0.5) * Math.PI / 180;
    const dx = (lon - clon) * Math.max(0.25, Math.cos(meanLat));
    const dy = lat - clat;
    return dx * dx + dy * dy;
  };
  return rows
    .map((row, index) => ({ row, index, distance: dist2(row) }))
    .sort((a, b) => a.distance - b.distance || a.index - b.index)
    .slice(0, limit)
    .map((x) => x.row);
}

function fieldCurrentToMarineFrame(fieldPayload, baseFrame = {}, viewport = null) {
  if (!fieldPayload || fieldPayload.ok === false) return null;
  const points = oceanPointsFromPayload(fieldPayload);
  if (!points.length) return null;
  const viewportBbox = baseFrame?.visible_bbox || baseFrame?.bbox || fieldPayload?.visible_bbox || fieldPayload?.bbox || null;
  const boatRows = marineRowsSortedNearViewport(points, viewport, 12);
  const boats = boatRows.map((p, index) => {
    const lat = Number(p?.lat ?? p?.latitude);
    const lon = Number(p?.lon ?? p?.lng ?? p?.longitude);
    const heading = Number(p?.direction_deg ?? p?.current_dir_deg ?? p?.dirDeg ?? p?.heading ?? 0);
    const speedKt = Number(p?.current_speed_kt ?? p?.speedKt ?? p?.speed_kt ?? 0);
    const tempF = Number(p?.water_temp_f ?? p?.sst_f ?? NaN);
    const tempC = Number(p?.water_temp_c ?? p?.sst_c ?? p?.sst ?? NaN);
    return {
      id: `field-current-boat-${index + 1}`,
      name: `Current Boat ${index + 1}`,
      lat,
      lon,
      heading,
      headingDeg: heading,
      current_speed_kt: Number.isFinite(speedKt) ? speedKt : 0,
      direction_deg: Number.isFinite(heading) ? heading : 0,
      current: {
        speedKt: Number.isFinite(speedKt) ? speedKt : 0,
        dirDeg: Number.isFinite(heading) ? heading : 0,
        u: p?.u ?? p?.current_u ?? p?.u_ms ?? null,
        v: p?.v ?? p?.current_v ?? p?.v_ms ?? null,
      },
      water: {
        tempF: Number.isFinite(tempF) ? tempF : null,
        sst_f: Number.isFinite(tempF) ? tempF : null,
        tempC: Number.isFinite(tempC) ? tempC : null,
        sst_c: Number.isFinite(tempC) ? tempC : null,
        salinity: p?.salinity ?? p?.sss ?? null,
      },
      source: 'frontend_field_current_boat_beacon',
      source_point: p,
    };
  }).filter((b) => Number.isFinite(b.lat) && Number.isFinite(b.lon));

  const oceanPoints = {
    points,
    count: points.length,
    source: fieldPayload.source || 'field_current_rtofs_ocean_points',
    bbox: fieldPayload.bbox || viewportBbox,
  };
  const shared = {
    ok: true,
    status: 'ok',
    payload_state: 'frontend_field_current_bridge',
    bbox: viewportBbox,
    visible_bbox: baseFrame?.visible_bbox || viewportBbox,
    source_endpoint: '/gfs/api/field?field=current',
    bridge_reason: 'scene_frame_marine_empty_field_current_fallback',
  };
  return normalizeFrame({
    ok: true,
    source: 'frontend_field_current_marine_bridge_debug_disabled_by_default',
    layers: {
      boater: {
        ...shared,
        source: 'field_current_rtofs_ocean_points_boater_debug_fallback',
        count: boats.length,
        boats,
        oceanPoints,
      },
    },
  });
}

async function fetchMarineFromCurrentField(baseFrame, reason, seq, viewport, bbox) {
  // Hard safety gate: do not fabricate viewport boats from /field?field=current.
  // The Boats pill must render only authoritative boater payloads or strict
  // RTOFS/OceanTruth SST+current samples.  This prevents random 12/18 viewport
  // boats with zero/default current when scene-cache is empty.
  const enabled = String(window.GFS_ENABLE_FRONTEND_BOAT_FIELD_FALLBACK || '0').toLowerCase();
  if (!['1', 'true', 'yes', 'on'].includes(enabled)) {
    debug('scene/marine-field-current-disabled', {
      reason,
      bbox,
      policy: 'frontend field/current boat fabrication disabled; wait for authoritative boater OceanTruth/RTOFS payload',
    });
    return null;
  }
  debug('scene/marine-field-current-request', { reason, bbox, why: 'explicit debug fallback enabled' });
  const field = await getJsonSafe(`/gfs/api/field?field=current&bbox=${encodeURIComponent(bbox)}`, { ok: false, points: [], error: 'field_current_unavailable' }, { timeoutMs: 22000, abortPrevious: false });
  if (seq !== state.refreshSeq || state.destroyed) return null;
  const synthetic = fieldCurrentToMarineFrame(field, baseFrame, viewport);
  if (!synthetic) {
    debug('scene/marine-field-current-empty', { ok: field?.ok, source: field?.source, count: field?.count, error: field?.error });
    return null;
  }
  return synthetic;
}

async function hydrateMarineLayersIfNeeded(baseFrame, reason, seq) {
  if (!marineSupplementNeeded(baseFrame)) return null;
  const viewport = getViewport();
  const bbox = bboxString(viewport);
  const neededLayers = neededMarineSupplementLayers(baseFrame);
  if (!neededLayers.length) return null;
  debug('scene/marine-supplement-request', { reason, bbox, layers: neededLayers, why: 'only hydrate the active marine pill that is missing' });
  try {
    const supplemental = await getSceneFrame({
      bbox,
      visibleBbox: bbox,
      layers: neededLayers,
      mode: 'fast',
      refresh: false,
      providerJobs: false,
      reason: `clean_spine_marine_supplement_${reason}`,
    }, { ok: false, layers: {}, error: 'marine_supplement_unavailable' }, { timeoutMs: 18000, abortPrevious: false });
    if (seq !== state.refreshSeq || state.destroyed) return null;
    let merged = mergeSupplementalFrame(state.latestFrame || baseFrame, supplemental, 'marine_scene_frame');
    debug('scene/marine-supplement-received', {
      ok: supplemental?.ok,
      layerKeys: Object.keys(supplemental?.layers || {}),
      baitRenderable: hasRenderableMarine('bait', merged?.layers?.bait),
      boaterRenderable: hasRenderableMarine('boater', merged?.layers?.boater),
    });

    if (layerEnabled('boater') && !hasRenderableMarine('boater', merged?.layers?.boater || merged?.layers?.boats)) {
      const fieldFrame = await fetchMarineFromCurrentField(merged, reason, seq, viewport, bbox);
      if (fieldFrame) {
        merged = mergeSupplementalFrame(merged, fieldFrame, 'field_current_boats_only');
        debug('scene/marine-field-current-merged', {
          summary: sceneFrameLayerSummary(merged),
          boaterRenderable: hasRenderableMarine('boater', merged?.layers?.boater),
          policy: 'field/current fallback only creates boats; bait remains owned by the Bait pill field renderer',
        });
      }
    }

    state.latestFrame = merged;
    state.latestSceneSummary = sceneFrameLayerSummary(merged);
    try { window.__gfsLatestSceneFrame = merged; window.__gfsLatestSceneSummary = state.latestSceneSummary; window.__gfsCleanSpineState = state; } catch (_) {}
    if (layerEnabled('ocean-glass')) {
      await renderLayer('ocean-glass', merged, `${reason}_marine_supplement`);
    }
    if (layerEnabled('bait-3d')) {
      await renderLayer('bait-3d', merged, `${reason}_marine_supplement`);
    }
    for (const name of ['bait', 'boater']) {
      if (seq !== state.refreshSeq || state.destroyed) return merged;
      if (name === 'bait' && shouldSkipLegacyBaitRender(name)) {
        debug('layer/skip-legacy-surface-bait', { reason: `${reason}_marine_supplement`, replacedBy: 'bait-3d' });
        continue;
      }
      if (name === 'bait' && !neededLayers.includes('bait')) continue;
      if (name === 'boater' && !layerEnabled('boater')) continue;
      await renderLayer(name, merged, `${reason}_marine_supplement`);
    }
    intelligencePane.refresh();
    setStatus(`Scene ready: ${Object.keys(merged.layers || {}).join(', ')} + marine supplement`);
    return merged;
  } catch (err) {
    debug('scene/marine-supplement-failed-soft', { reason, message: err?.message || String(err) });
    return null;
  }
}



function hardClearLegacyBaitDom(reason = 'legacy-bait-suppressed') {
  // The scalar-field bait cloud owns the Bait pill by default.  Legacy
  // surface bait zones/beacons were yellow square/polygon artifacts and can
  // persist across cached/hot reloads, so remove them whenever bait-3d runs.
  const selector = [
    '[data-gfs-layer="bait"]',
    '[data-bait-zone]',
    '[data-bait-beacon]',
    '[data-bait-cloud-particle]',
    '[data-bait-renderer]:not([data-gfs-layer="bait-3d"])',
  ].join(',');
  let removed = 0;
  try {
    globeEl?.querySelectorAll?.(selector)?.forEach((el) => {
      // Keep the new scalar cloud markers/shells, which always carry bait-3d.
      if (el?.getAttribute?.('data-gfs-layer') === 'bait-3d') return;
      el.remove();
      removed += 1;
    });
  } catch (_) {}
  if (removed) debug('bait/legacy-visuals-cleared', { reason, removed, owner: 'bait-3d-scalar-field-cloud' });
  try { window.__gfsLegacyBaitSuppressed = { reason, removed, ts: Date.now() }; } catch (_) {}
  return removed;
}

function layerDomSelector(name) {
  return {
    clouds: '[data-gfs-layer="clouds"],[data-cloud-particle],[data-cloud-shell]',
    rain: '[data-gfs-layer="rain"],[data-rain-drop],[data-rain-column]',
    lightning: '[data-gfs-layer="lightning"],[data-lightning-flash],[data-lightning-event]',
    'ocean-glass': '[data-gfs-layer="ocean-glass"]',
    'bait-3d': '[data-gfs-layer="bait-3d"],[data-bait-renderer="probability-volume-particle"]',
    bait: '[data-gfs-layer="bait"],[data-bait-zone],[data-bait-renderer]:not([data-gfs-layer="bait-3d"])',
    boater: '[data-gfs-layer="boater"],[data-gfs-layer="boats"],[data-boater-beacon]',
    'inland-water': '[data-gfs-layer="inland-water"],[data-inland-water]',
  }[name] || `[data-gfs-layer="${name}"]`;
}

function layerDomCount(name) {
  try { return globeEl?.querySelectorAll?.(layerDomSelector(name))?.length || 0; } catch (_) { return 0; }
}

function rememberDomStats(name, stats) {
  try {
    window.__gfsLayerDomStats = { ...(window.__gfsLayerDomStats || {}), [name]: stats };
  } catch (_) {}
}

async function renderLayer(name, frame, reason) {
  if (!layerEnabled(name)) return clearLayer(name);
  if (name === 'bait-3d' && bait3dReplacesLegacySurfaceBait()) {
    hardClearLegacyBaitDom(`${reason}_before_bait3d_render`);
  }
  if (shouldSkipLegacyBaitRender(name)) {
    hardClearLegacyBaitDom(`${reason}_skip_legacy_surface_bait`);
    rememberDomStats(name, { name, reason, skipped: true, replacedBy: 'bait-3d' });
    debug('layer/skip-legacy-surface-bait', { reason, replacedBy: 'bait-3d' });
    return null;
  }
  try {
    const mod = await loadLayerModule(name);
    const renderFn = {
      clouds: mod.renderCloudsLayer,
      rain: mod.renderRainLayer,
      lightning: mod.renderLightningLayer,
      'ocean-glass': mod.renderOceanGlassLayer,
      'bait-3d': mod.renderBait3dLayer,
      bait: mod.renderBaitLayer,
      boater: mod.renderBoatsSceneLayer,
      'inland-water': mod.renderInlandWaterSceneLayer,
    }[name];
    if (!renderFn) return;
    const beforeDom = layerDomCount(name);
    const disposer = await renderFn({ frame, payload: frame, map3DElement: globeEl, maps3d: state.maps3d, viewport: getViewport(), reason });
    if (typeof disposer === 'function') state.layerDisposers.set(name, disposer);
    await new Promise((resolve) => requestAnimationFrame(() => resolve()));
    const afterDom = layerDomCount(name);
    const didRender = Boolean(disposer?.__gfsDidRender ?? disposer ?? false) && afterDom > 0;
    const domStats = { name, reason, beforeDom, afterDom, didRender, disposerReturned: Boolean(disposer), keepExisting: Boolean(disposer?.__gfsKeepExisting) };
    rememberDomStats(name, domStats);
    debug('layer/rendered', domStats);
  } catch (err) {
    debug('layer/render-failed-keep-globe', { name, message: err?.message || String(err) });
  }
}


async function renderFrame(frame, reason) {
  const seq = state.refreshSeq;
  for (const name of LAYER_ORDER) {
    if (seq !== state.refreshSeq || state.destroyed) return;
    await renderLayer(name, frame, reason);
  }
}

async function refreshScene(reason = 'manual') {
  const seq = ++state.refreshSeq;
  const viewport = getViewport();
  const layers = enabledSceneLayers();
  const bbox = bboxString(viewport);
  setStatus(`Scene ${reason}: ${layers.join(', ') || 'no dynamic layers'}…`);
  debug('scene/request', { reason, bbox, layers });

  const payload = await getSceneFrame({
    bbox,
    visibleBbox: bbox,
    layers,
    mode: 'fast',
    refresh: false,
    providerJobs: false,
    reason: `clean_spine_${reason}`,
  }, { ok: false, layers: {}, error: 'scene_frame_unavailable' }, { timeoutMs: 14000, abortPrevious: false });

  if (seq !== state.refreshSeq || state.destroyed) return null;
  const frame = normalizeFrame(payload || {});
  state.latestFrame = frame;
  state.latestSceneSummary = sceneFrameLayerSummary(frame);
  try { window.__gfsLatestSceneFrame = frame; window.__gfsLatestSceneSummary = state.latestSceneSummary; window.__gfsCleanSpineState = state; } catch (_) {}
  debug('scene/received', {
    reason,
    ok: frame.ok,
    layerKeys: Object.keys(frame.layers || {}),
    source: frame.source || frame.error || 'unknown',
    summary: state.latestSceneSummary,
  });
  await renderFrame(frame, reason);
  // Do not let an all-layer cache-warm frame hide good marine data.
  // The backend already proves bait/boater hydrate cleanly when requested as the
  // marine bundle, so fetch that bundle as a non-blocking supplement only when
  // the combined frame came back empty for active marine pills.
  hydrateMarineLayersIfNeeded(frame, reason, seq).catch((err) => debug('scene/marine-supplement-unhandled', { message: err?.message || String(err) }));
  intelligencePane.refresh();
  setStatus(`Scene ready: ${Object.keys(frame.layers || {}).join(', ') || 'cache warming'}`);
  return frame;
}

async function renderLocationsSafe() {
  if (state.locationDisposer) {
    try { state.locationDisposer(); } catch (_) {}
    state.locationDisposer = null;
  }
  if (!layerEnabled('locations')) return;
  if (!state.latestLocations.length || !state.maps3d) return;
  try {
    state.locationDisposer = renderCsvLocations({
      locations: state.latestLocations,
      globeEl,
      maps3d: state.maps3d,
      onSelect: (loc) => intelligencePane.open(loc),
    });
    debug('locations/rendered', { count: state.latestLocations.length });
  } catch (err) {
    debug('locations/render-failed', { message: err?.message || String(err) });
  }
}

async function loadLocationsSafe() {
  try {
    state.latestLocations = await loadCsvLocations();
    await renderLocationsSafe();
  } catch (err) {
    debug('locations/load-failed', { message: err?.message || String(err) });
  }
}

function installCameraRefresh() {
  const schedule = (reason = 'camera') => {
    if (state.cameraTimer) clearTimeout(state.cameraTimer);
    state.cameraTimer = setTimeout(() => refreshScene(reason).catch((err) => debug('scene/camera-refresh-failed', { message: err?.message || String(err) })), CAMERA_STEADY_DEBOUNCE_MS);
  };
  ['gmp-centerchange', 'gmp-headingchange', 'gmp-rangechange', 'gmp-rollchange', 'gmp-tiltchange', 'gmp-camerapositionchange', 'centerchange', 'headingchange', 'rangechange', 'rollchange', 'tiltchange']
    .forEach((eventName) => globeEl?.addEventListener(eventName, () => schedule('camera_move')));
  globeEl?.addEventListener('gmp-steadystate', (ev) => {
    if (typeof ev?.isSteady === 'boolean' && !ev.isSteady) return;
    schedule('steady');
  });
}

function installSceneHeartbeat() {
  if (state.sceneTimer) clearInterval(state.sceneTimer);
  state.sceneTimer = setInterval(() => {
    refreshScene('heartbeat').catch((err) => debug('scene/heartbeat-failed', { message: err?.message || String(err) }));
  }, SCENE_REFRESH_MS);
}

const intelligencePane = createIntelligencePane({ getLatestFrame: () => state.latestFrame });

async function boot() {
  installPills();
  setStatus('Loading Google Photorealistic 3D Maps…');
  const mapsReady = await ensureMaps3D(globeEl, fallbackEl);
  if (!mapsReady?.ok) {
    setStatus(`Globe unavailable: ${mapsReady?.reason || 'maps3d failed'}`);
    debug('boot/maps-failed', mapsReady || {});
    return;
  }

  const mapsLibs = await loadMapsLibs();
  state.maps3d = mapsLibs.maps3d;
  setStatus('Globe ready. Loading CSV locations and scene-frame…');
  debug('boot/maps-ready', { maps3d: true });

  await loadLocationsSafe();
  await refreshScene('boot');
  installCameraRefresh();
  installSceneHeartbeat();
  setTimeout(() => refreshScene('initial_camera_sync').catch(() => {}), 900);
}

boot().catch((err) => {
  setStatus('Clean spine boot failed; see debug panel.');
  debug('boot/fatal', { message: err?.message || String(err), stack: err?.stack || '' });
});

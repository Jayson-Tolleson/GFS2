function text(value, fallback = '—') {
  const s = String(value ?? '').trim();
  return s || fallback;
}

function number(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function reportFields(location) {
  const rows = [];
  for (const [key, value] of Object.entries(location || {})) {
    if (/^report_?\d+$/i.test(key) && String(value || '').trim()) rows.push(String(value).trim());
  }
  if (!rows.length && location?.reports && Array.isArray(location.reports)) {
    return location.reports.map((r) => text(r?.text || r?.summary || r)).filter(Boolean);
  }
  return rows;
}

function scoreLocation(location, frameSummary) {
  const explicit = number(location?.probability ?? location?.score ?? location?.confidence);
  if (explicit !== null) return Math.max(1, Math.min(5, explicit > 1 ? explicit : 1 + explicit * 4));
  const reports = reportFields(location).length;
  const layerBoost = Math.min(1.2, Math.max(0, Number(frameSummary?.activeLayerCount || 0)) * 0.18);
  return Math.max(1, Math.min(5, 2.2 + Math.min(1.6, reports * 0.08) + layerBoost));
}

function summarizeFrame(frame) {
  const layers = frame?.layers && typeof frame.layers === 'object' ? frame.layers : {};
  const names = Object.keys(layers).filter((name) => layers[name]);
  const counts = names.map((name) => {
    const p = layers[name] || {};
    const firstArray = [p.items, p.features, p.polygons, p.boats, p.flashes, p.regions, p.precip_columns]
      .find((v) => Array.isArray(v));
    const count = firstArray ? firstArray.length : (Number(p.count || 0) || 0);
    return count ? `${name}: ${count}` : name;
  });
  return { activeLayerCount: names.length, text: counts.length ? counts.join(' • ') : 'No scene-frame layer payload yet.' };
}

export function createIntelligencePane({ root = document.getElementById('intelligencePane'), getLatestFrame = () => null } = {}) {
  const q = (name) => root?.querySelector(`[data-intel="${name}"]`);
  const closeBtn = root?.querySelector('[data-intel-action="close"]');
  let selected = null;

  function setOpen(open) {
    if (!root) return;
    root.classList.toggle('closed', !open);
    root.setAttribute('aria-hidden', open ? 'false' : 'true');
  }

  function paint(location) {
    if (!root || !location) return;
    selected = location;
    const frameSummary = summarizeFrame(getLatestFrame());
    const score = scoreLocation(location, frameSummary);
    const reports = reportFields(location).slice(0, 12);
    const lat = number(location.lat ?? location.latitude);
    const lon = number(location.lon ?? location.lng ?? location.longitude);

    q('title').textContent = text(location.name || location.title || location.location || location.id, 'Fishing location');
    q('coords').textContent = lat !== null && lon !== null ? `${lat.toFixed(4)}, ${lon.toFixed(4)}` : '';
    q('status').textContent = 'CSV row loaded. Live marine layer context is merged when scene-frame data arrives.';
    q('score').textContent = score.toFixed(1);
    q('score-fill').style.width = `${Math.round((score / 5) * 100)}%`;
    q('confidence').textContent = reports.length ? `${reports.length} CSV reports` : 'CSV location';
    q('trend').textContent = location.waterbody || location.habitat || location.location || 'local signal stack';
    q('summary').textContent = text(location.summary || location.description || reports[0], 'Use local bait, weather, rain, boat, and water context for this point.');
    q('live').textContent = frameSummary.text;

    const list = q('reports');
    list.innerHTML = '';
    (reports.length ? reports : ['No report fields found on this CSV row yet.']).forEach((line) => {
      const li = document.createElement('li');
      li.textContent = line;
      list.append(li);
    });
  }

  closeBtn?.addEventListener('click', () => setOpen(false));

  return {
    open(location) {
      paint(location);
      setOpen(true);
    },
    refresh() {
      if (selected) paint(selected);
    },
    close() { setOpen(false); },
  };
}

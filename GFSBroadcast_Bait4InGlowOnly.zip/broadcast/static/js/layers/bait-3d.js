import { bboxFromViewport } from './scene-frame-utils.js';

const BAIT3D_SELECTOR = '[data-gfs-layer="bait-3d"]';
const ENABLED = String(window.GFS_BAIT_3D_VOLUME ?? '1') !== '0';
const DEPTHS = String(window.GFS_BAIT_FIELD_DEPTHS || window.GFS_BAIT_3D_DEPTHS || '0,3.048,6.096,9.144,12.192,15.24,18.288,21.336,24.384,27.432,30.48,36.576,45.72,60.96,76.2,91.44,121.92,152.4,200');
const FETCH_GRID = Number(window.GFS_BAIT_FIELD_GRID || window.GFS_BAIT_3D_GRID || 20);
const CACHE_TTL_MS = Number(window.GFS_BAIT_FIELD_CACHE_TTL_MS || window.GFS_BAIT_3D_CACHE_TTL_MS || 120000);
const FIELD_THRESHOLD = Number(window.GFS_BAIT_FIELD_THRESHOLD || 0.80);
const FIELD_MAX_RENDERED = Number(window.GFS_BAIT_FIELD_MAX_RENDERED || 9000);
const FIELD_MAX_CELLS = Number(window.GFS_BAIT_FIELD_MAX_CELLS || 2400);
const FIELD_MAX_DOM_NODES = Number(window.GFS_BAIT_FIELD_MAX_DOM_NODES || 12000);
const FIELD_SURFACE_MIN_DEPTH_M = Number(window.GFS_BAIT_FIELD_SURFACE_MIN_DEPTH_M || 3.0);
const FIELD_CUBE_STEP_FT = Number(window.GFS_BAIT_FIELD_CUBE_STEP_FT || 10);
const FIELD_CUBE_STEP_M = Number(window.GFS_BAIT_FIELD_CUBE_STEP_M || (FIELD_CUBE_STEP_FT * 0.3048));
const FIELD_CUBE_FOOTPRINT_SHRINK = Number(window.GFS_BAIT_FIELD_CUBE_FOOTPRINT_SHRINK || 1.0);
const FIELD_NO_SURFACE_SHEETS = String(window.GFS_BAIT_FIELD_NO_SURFACE_SHEETS ?? '1') !== '0';
const FIELD_DRAW_TOP_FACE = String(window.GFS_BAIT_FIELD_DRAW_TOP_FACE ?? '0') === '1';
const FIELD_DRAW_BOTTOM_FACE = String(window.GFS_BAIT_FIELD_DRAW_BOTTOM_FACE ?? '0') === '1';
const FIELD_DRAW_ALL_SIDES = String(window.GFS_BAIT_FIELD_DRAW_ALL_SIDES ?? '1') !== '0';
const FIELD_CUBE_HORIZONTAL_FT = Number(window.GFS_BAIT_FIELD_CUBE_HORIZONTAL_FT || FIELD_CUBE_STEP_FT || 10);
const FIELD_CUBE_VISUAL_HORIZONTAL_SCALE = Number(window.GFS_BAIT_FIELD_CUBE_VISUAL_HORIZONTAL_SCALE || 72);
const FIELD_CUBE_MAX_VISUAL_HORIZONTAL_FT = Number(window.GFS_BAIT_FIELD_CUBE_MAX_VISUAL_HORIZONTAL_FT || 1800);
const FIELD_CUBE_MIN_VISUAL_HORIZONTAL_FT = Number(window.GFS_BAIT_FIELD_CUBE_MIN_VISUAL_HORIZONTAL_FT || 80);
const FIELD_HOT_SIDE_THRESHOLD = Number(window.GFS_BAIT_FIELD_HOT_SIDE_THRESHOLD || FIELD_THRESHOLD);
const FIELD_OUTLINE_THRESHOLD = Number(window.GFS_BAIT_FIELD_OUTLINE_THRESHOLD || FIELD_THRESHOLD);
const FIELD_GLOW_THRESHOLD = Number(window.GFS_BAIT_FIELD_GLOW_THRESHOLD || 0.58);
const FIELD_MAX_GLOW_PARTICLES = Number(window.GFS_BAIT_FIELD_MAX_GLOW_PARTICLES || 900);
const FIELD_MAX_OUTLINES = Number(window.GFS_BAIT_FIELD_MAX_OUTLINES || 3800);
const FIELD_MAX_HOT_SIDE_CUBES = Number(window.GFS_BAIT_FIELD_MAX_HOT_SIDE_CUBES || Math.min(FIELD_MAX_RENDERED, 1200));
const FIELD_PROGRESSIVE_CHUNK = Number(window.GFS_BAIT_FIELD_PROGRESSIVE_CHUNK || 420);
const VISUAL_DEPTH_SCALE = Number(window.GFS_BAIT_FIELD_VISUAL_DEPTH_SCALE || window.GFS_BAIT_3D_VISUAL_DEPTH_SCALE || 12);
const MIN_VISUAL_DEPTH_M = Number(window.GFS_BAIT_FIELD_MIN_VISUAL_DEPTH_M || window.GFS_BAIT_3D_MIN_VISUAL_DEPTH_M || 80);
const MAX_VISUAL_DEPTH_M = Number(window.GFS_BAIT_FIELD_MAX_VISUAL_DEPTH_M || window.GFS_BAIT_3D_MAX_VISUAL_DEPTH_M || 2200);
const MIN_VISUAL_CUBE_THICKNESS_M = Number(window.GFS_BAIT_FIELD_MIN_VISUAL_CUBE_THICKNESS_M || 28);
const MAX_VISUAL_CUBE_THICKNESS_M = Number(window.GFS_BAIT_FIELD_MAX_VISUAL_CUBE_THICKNESS_M || 120);
const FIELD_RENDER_MODE = String(window.GFS_BAIT_FIELD_RENDER_MODE || 'particle-cloud').toLowerCase();
const FIELD_PARTICLE_CLOUD_ENABLED = ['particle-cloud', 'particles', 'cloud'].includes(FIELD_RENDER_MODE) && String(window.GFS_BAIT_FIELD_PARTICLE_CLOUD ?? '1') !== '0';
const FIELD_LITE_ENABLED = !FIELD_PARTICLE_CLOUD_ENABLED && FIELD_RENDER_MODE !== 'full-cubes' && String(window.GFS_BAIT_FIELD_LITE ?? '1') !== '0';
const FIELD_LITE_MAX_ANCHORS = Number(window.GFS_BAIT_FIELD_LITE_MAX_ANCHORS || 950);
const FIELD_LITE_MIN_ANCHOR_SPACING_M = Number(window.GFS_BAIT_FIELD_LITE_MIN_ANCHOR_SPACING_M || 6500);
const FIELD_LITE_HOT_KEEP_RATIO = Number(window.GFS_BAIT_FIELD_LITE_HOT_KEEP_RATIO || 0.34);
const FIELD_LITE_SIDE_THRESHOLD = Number(window.GFS_BAIT_FIELD_LITE_SIDE_THRESHOLD || 0.66);
const FIELD_LITE_BOTTOM_LOOP_THRESHOLD = Number(window.GFS_BAIT_FIELD_LITE_BOTTOM_LOOP_THRESHOLD || 0.62);
const FIELD_LITE_VERTICAL_EDGE_THRESHOLD = Number(window.GFS_BAIT_FIELD_LITE_VERTICAL_EDGE_THRESHOLD || 0.58);
const FIELD_IMPLICIT_CLUSTER_ENABLED = String(window.GFS_BAIT_FIELD_IMPLICIT_CLUSTERS ?? '1') !== '0';
const FIELD_CLUSTER_MAX_ANCHORS = Number(window.GFS_BAIT_FIELD_CLUSTER_MAX_ANCHORS || 760);
const FIELD_CLUSTER_MIN_SPACING_M = Number(window.GFS_BAIT_FIELD_CLUSTER_MIN_SPACING_M || 8200);
const FIELD_CLUSTER_LENGTH_FT_MIN = Number(window.GFS_BAIT_FIELD_CLUSTER_LENGTH_FT_MIN || 120);
const FIELD_CLUSTER_LENGTH_FT_MAX = Number(window.GFS_BAIT_FIELD_CLUSTER_LENGTH_FT_MAX || 680);
const FIELD_CLUSTER_WIDTH_FT_MIN = Number(window.GFS_BAIT_FIELD_CLUSTER_WIDTH_FT_MIN || 40);
const FIELD_CLUSTER_WIDTH_FT_MAX = Number(window.GFS_BAIT_FIELD_CLUSTER_WIDTH_FT_MAX || 240);
const FIELD_CLUSTER_HEIGHT_FT_MIN = Number(window.GFS_BAIT_FIELD_CLUSTER_HEIGHT_FT_MIN || 12);
const FIELD_CLUSTER_HEIGHT_FT_MAX = Number(window.GFS_BAIT_FIELD_CLUSTER_HEIGHT_FT_MAX || 120);
const FIELD_CLUSTER_SEGMENT_LIMIT = Number(window.GFS_BAIT_FIELD_CLUSTER_SEGMENT_LIMIT || 5);
const FIELD_BBOX_PAD = Number(window.GFS_BAIT_FIELD_BBOX_PAD || 1.18);
const FIELD_BBOX_TILT_PAD_GAIN = Number(window.GFS_BAIT_FIELD_BBOX_TILT_PAD_GAIN || 0.16);
const FIELD_PARTICLE_MAX = Number(window.GFS_BAIT_FIELD_PARTICLE_MAX || 9000);
const FIELD_PARTICLE_MAX_PER_SAMPLE = Number(window.GFS_BAIT_FIELD_PARTICLE_MAX_PER_SAMPLE || 6);
const FIELD_PARTICLE_ALPHA_HIGH = Number(window.GFS_BAIT_FIELD_PARTICLE_ALPHA_HIGH || 0.96);
const FIELD_PARTICLE_ALPHA_FLOOR = Number(window.GFS_BAIT_FIELD_PARTICLE_ALPHA_FLOOR || 0.16);
const FIELD_PARTICLE_ALPHA_FULL_AT = Number(window.GFS_BAIT_FIELD_PARTICLE_ALPHA_FULL_AT || 0.96);
const FIELD_PARTICLE_MIN_SPACING_M = Number(window.GFS_BAIT_FIELD_PARTICLE_MIN_SPACING_M || 85);
const FIELD_PARTICLE_JITTER_MIN_M = Number(window.GFS_BAIT_FIELD_PARTICLE_JITTER_MIN_M || 45);
const FIELD_PARTICLE_JITTER_MAX_M = Number(window.GFS_BAIT_FIELD_PARTICLE_JITTER_MAX_M || 900);
const FIELD_PARTICLE_VERTICAL_JITTER_FT = Number(window.GFS_BAIT_FIELD_PARTICLE_VERTICAL_JITTER_FT || 22);
const FIELD_PARTICLE_BODY_LENGTH_IN = Number(window.GFS_BAIT_FIELD_PARTICLE_BODY_LENGTH_IN || 4);
const FIELD_PARTICLE_BODY_WIDTH_IN = Number(window.GFS_BAIT_FIELD_PARTICLE_BODY_WIDTH_IN || 1.35);
const FIELD_PARTICLE_BODY_WORLD_M = FIELD_PARTICLE_BODY_LENGTH_IN * 0.0254;
const FIELD_PARTICLE_BODY_SCALE_ENABLED = String(window.GFS_BAIT_FIELD_PARTICLE_BODY_SCALE || '0').toLowerCase();
const FIELD_PARTICLE_BODY_VISUAL_HEIGHT_PX = Number(window.GFS_BAIT_FIELD_PARTICLE_BODY_VISUAL_HEIGHT_PX || 2.0);
const FIELD_PARTICLE_BODY_VISUAL_MIN_PX = Number(window.GFS_BAIT_FIELD_PARTICLE_BODY_VISUAL_MIN_PX || 1.2);
const FIELD_PARTICLE_BODY_VISUAL_MAX_PX = Number(window.GFS_BAIT_FIELD_PARTICLE_BODY_VISUAL_MAX_PX || 3.4);
const FIELD_PARTICLE_GLOW_MIN_PX = Number(window.GFS_BAIT_FIELD_PARTICLE_GLOW_MIN_PX || 10);
const FIELD_PARTICLE_GLOW_MAX_PX = Number(window.GFS_BAIT_FIELD_PARTICLE_GLOW_MAX_PX || 46);
// Backwards-compatible names are now treated as debug-only body overrides.
// Default bait body is not probability-scaled; only the glow scales.
const FIELD_PARTICLE_SIZE_MIN = Number(window.GFS_BAIT_FIELD_PARTICLE_SIZE_MIN || FIELD_PARTICLE_BODY_VISUAL_MIN_PX);
const FIELD_PARTICLE_SIZE_MAX = Number(window.GFS_BAIT_FIELD_PARTICLE_SIZE_MAX || FIELD_PARTICLE_BODY_VISUAL_MAX_PX);
const FIELD_PARTICLE_CORE_SHELL = String(window.GFS_BAIT_FIELD_PARTICLE_CORE_SHELL ?? '0') !== '0';
const FIELD_PARTICLE_CORE_THRESHOLD = Number(window.GFS_BAIT_FIELD_PARTICLE_CORE_THRESHOLD || 0.90);
const FIELD_PARTICLE_SHELL_MAX = Number(window.GFS_BAIT_FIELD_PARTICLE_SHELL_MAX || 0);
const PAYLOAD_CACHE = new Map();

function clamp(value, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, n));
}

function clamp01(value) {
  return clamp(value, 0, 1);
}

function normalizeLon(lon) {
  const n = Number(lon);
  if (!Number.isFinite(n)) return 0;
  const wrapped = ((n + 180) % 360 + 360) % 360 - 180;
  return Object.is(wrapped, -180) ? 180 : wrapped;
}

function safeBbox(viewport = null, frame = null) {
  return bboxFromViewport(viewport, frame?.visible_bbox || frame?.bbox || frame?.bbox_object) || { west: -125, south: 32, east: -117, north: 38 };
}

function bboxQuery(bbox) {
  return [bbox.west, bbox.south, bbox.east, bbox.north].map((x) => Number(x).toFixed(5)).join(',');
}


function padBbox(bbox, factor = 1.0) {
  if (!bbox) return bbox;
  const west = normalizeLon(bbox.west);
  const east = normalizeLon(bbox.east);
  const south = Number(bbox.south);
  const north = Number(bbox.north);
  if (![west, east, south, north].every(Number.isFinite)) return bbox;
  let lonSpan = east - west;
  if (lonSpan <= 0) lonSpan += 360;
  if (lonSpan > 180) lonSpan = 360 - lonSpan;
  const latSpan = Math.max(0.0001, north - south);
  const pad = Math.max(1.0, Number(factor) || 1.0);
  const cLat = (south + north) / 2;
  const cLon = normalizeLon(west + lonSpan / 2);
  const halfLat = (latSpan * pad) / 2;
  const halfLon = (lonSpan * pad) / 2;
  return {
    west: normalizeLon(cLon - halfLon),
    south: clamp(cLat - halfLat, -89.9, 89.9),
    east: normalizeLon(cLon + halfLon),
    north: clamp(cLat + halfLat, -89.9, 89.9),
  };
}

function requestBboxForField(viewport = null, frame = null) {
  const base = safeBbox(viewport, frame);
  const tilt = Number(viewport?.camera?.tilt ?? frame?.camera?.tilt ?? 0) || 0;
  const pad = FIELD_BBOX_PAD + clamp01(tilt / 67) * FIELD_BBOX_TILT_PAD_GAIN;
  return padBbox(base, pad);
}

function setAttr(el, name, value) {
  if (value === undefined || value === null) return;
  try { el.setAttribute(name, String(value)); } catch (_) {}
}

function setBoolAttr(el, name, value = true) {
  try { if (value) el.setAttribute(name, ''); else el.removeAttribute(name); } catch (_) {}
}

function pathString(path = []) {
  return path.map((p) => `${Number(p.lat).toFixed(6)},${Number(p.lng ?? p.lon).toFixed(6)},${Number(p.altitude || 0).toFixed(2)}`).join(' ');
}

function visualDepthForDepth(depthM) {
  const trueDepth = Math.max(0.25, Math.abs(Number(depthM) || 0));
  const visualDepth = clamp(trueDepth * VISUAL_DEPTH_SCALE, MIN_VISUAL_DEPTH_M, MAX_VISUAL_DEPTH_M);
  return { trueDepth, visualDepth, altitude: -visualDepth };
}

function visualCubeThickness(sample = null) {
  const dz = Math.abs(Number(sample?.depth_step_m || sample?.cube_size_m || FIELD_CUBE_STEP_M)) || FIELD_CUBE_STEP_M;
  return clamp(dz * VISUAL_DEPTH_SCALE, MIN_VISUAL_CUBE_THICKNESS_M, MAX_VISUAL_CUBE_THICKNESS_M);
}

function applyAltitudeMode(el) {
  try { el.altitudeMode = window.google?.maps?.maps3d?.AltitudeMode?.ABSOLUTE || 'ABSOLUTE'; } catch (_) {}
  setAttr(el, 'altitude-mode', 'absolute');
}


function metersToLat(m) {
  return Number(m || 0) / 111320;
}

function metersToLon(m, lat) {
  return Number(m || 0) / Math.max(1e-6, 111320 * Math.cos((Number(lat || 0) * Math.PI) / 180));
}

function offsetLatLonMeters(lat, lon, eastM, northM) {
  return {
    lat: Number(lat) + metersToLat(northM),
    lng: normalizeLon(Number(lon) + metersToLon(eastM, lat)),
  };
}

function headingFromCurrent(sample = {}) {
  const explicit = Number(sample?.direction_deg ?? sample?.heading ?? sample?.drift_heading_deg);
  if (Number.isFinite(explicit)) return explicit;
  const u = Number(sample?.u_ms ?? sample?.u ?? sample?.current_u);
  const v = Number(sample?.v_ms ?? sample?.v ?? sample?.current_v);
  if (Number.isFinite(u) && Number.isFinite(v) && (Math.abs(u) > 1e-6 || Math.abs(v) > 1e-6)) {
    return (Math.atan2(u, v) * 180 / Math.PI + 360) % 360;
  }
  return 90;
}

function rotatedRectFootprint(centerLat, centerLon, lengthFt, widthFt, headingDeg) {
  const halfL = (Math.max(10, Number(lengthFt) || 0) * 0.3048) / 2;
  const halfW = (Math.max(10, Number(widthFt) || 0) * 0.3048) / 2;
  const theta = (Number(headingDeg || 0) * Math.PI) / 180;
  const cos = Math.cos(theta);
  const sin = Math.sin(theta);
  const rotate = (forwardM, rightM) => {
    const east = sin * forwardM + cos * rightM;
    const north = cos * forwardM - sin * rightM;
    return offsetLatLonMeters(centerLat, centerLon, east, north);
  };
  return {
    nw: rotate(halfL, -halfW),
    ne: rotate(halfL, halfW),
    se: rotate(-halfL, halfW),
    sw: rotate(-halfL, -halfW),
    center: { lat: Number(centerLat), lng: normalizeLon(centerLon) },
    trueLengthFt: Number(lengthFt),
    trueWidthFt: Number(widthFt),
    visualEdgeFt: Math.max(lengthFt, widthFt),
  };
}

function mix(a, b, t) {
  return Math.round(a + (b - a) * clamp01(t));
}

function rgba(rgb, alpha) {
  return `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${clamp(alpha, 0, 1).toFixed(3)})`;
}

function hexRgb(rgb) {
  const part = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return `#${part(rgb[0])}${part(rgb[1])}${part(rgb[2])}`;
}

function interpolateColor(stops, t) {
  const x = clamp01(t);
  for (let i = 0; i < stops.length - 1; i += 1) {
    const a = stops[i];
    const b = stops[i + 1];
    if (x >= a.at && x <= b.at) {
      const u = (x - a.at) / Math.max(0.0001, b.at - a.at);
      return [mix(a.rgb[0], b.rgb[0], u), mix(a.rgb[1], b.rgb[1], u), mix(a.rgb[2], b.rgb[2], u)];
    }
  }
  return stops[stops.length - 1].rgb;
}

function smoothstep(edge0, edge1, x) {
  const t = clamp01((x - edge0) / Math.max(0.0001, edge1 - edge0));
  return t * t * (3 - 2 * t);
}

function fieldStyle(probability) {
  const p = clamp01(probability);
  const t = clamp01((p - FIELD_THRESHOLD) / Math.max(0.001, 1 - FIELD_THRESHOLD));
  const rgb = interpolateColor([
    { at: 0.00, rgb: [255, 246, 186] }, // pastel yellow
    { at: 0.34, rgb: [255, 255, 0] },   // neon yellow
    { at: 0.67, rgb: [190, 255, 180] }, // pastel green
    { at: 1.00, rgb: [57, 255, 20] },   // neon green / very hot
  ], t);

  // Transparency is concentrated at the threshold edge.  Above threshold the
  // cubes become mostly solid/glowing so the high probability field reads as a
  // true contoured volume instead of a faint sheet.
  const edgeFade = smoothstep(0.0, 0.18, t);
  const core = smoothstep(0.18, 1.0, t);
  const fillAlpha = 0.08 + edgeFade * 0.34 + core * 0.36;
  const sideAlpha = 0.05 + edgeFade * 0.18 + core * 0.26;
  const strokeAlpha = 0.28 + edgeFade * 0.34 + core * 0.32;
  const glowAlpha = 0.16 + core * 0.76;
  return {
    rgb,
    hex: hexRgb(rgb),
    fill: rgba(rgb, fillAlpha),
    side: rgba(rgb, sideAlpha),
    stroke: rgba(rgb, strokeAlpha),
    glow: rgba(rgb, glowAlpha),
    width: 0.25 + t * 1.55,
    glowPx: 5 + t * 22,
    t,
  };
}

function bboxToFootprint(bbox, shrink = FIELD_CUBE_FOOTPRINT_SHRINK) {
  if (!Array.isArray(bbox) || bbox.length < 4) return null;
  let [west, south, east, north] = bbox.slice(0, 4).map(Number);
  if (![west, south, east, north].every(Number.isFinite)) return null;
  west = normalizeLon(west); east = normalizeLon(east);
  const cLat = (south + north) / 2;
  const cLon = normalizeLon((west + east) / 2);
  const s = clamp(shrink, 0.15, 1.0);
  const latHalf = Math.abs(north - south) * 0.5 * s;
  let lonSpan = Math.abs(east - west);
  if (lonSpan > 180) lonSpan = 360 - lonSpan;
  const lonHalf = Math.max(0.00002, lonSpan * 0.5 * s);
  return {
    nw: { lat: cLat + latHalf, lng: normalizeLon(cLon - lonHalf) },
    ne: { lat: cLat + latHalf, lng: normalizeLon(cLon + lonHalf) },
    se: { lat: cLat - latHalf, lng: normalizeLon(cLon + lonHalf) },
    sw: { lat: cLat - latHalf, lng: normalizeLon(cLon - lonHalf) },
    center: { lat: cLat, lng: cLon },
  };
}

function fallbackBboxForSample(sample, bbox = null) {
  const lat = Number(sample?.lat);
  const lon = normalizeLon(sample?.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  const source = bbox || {};
  const latSpan = Math.max(0.00002, Math.abs(Number(source.north || lat + 0.1) - Number(source.south || lat - 0.1)) / 58);
  const lonSpan = Math.max(0.00002, Math.abs(Number(source.east || lon + 0.1) - Number(source.west || lon - 0.1)) / 58);
  return [normalizeLon(lon - lonSpan / 2), lat - latSpan / 2, normalizeLon(lon + lonSpan / 2), lat + latSpan / 2];
}

function cubeFootprintForSample(sample, requestBbox = null) {
  // The previous field renderer used each sample's source bbox as the footprint,
  // which made wide translucent depth sheets at global/regional views.  Field
  // mode now renders true cube glyphs at the sample center.  The data cube edge
  // remains the requested ~10 ft, but a visual horizontal scale keeps the cube
  // readable on Google Photorealistic 3D.
  if (!FIELD_NO_SURFACE_SHEETS) {
    const bbox = Array.isArray(sample?.bbox) ? sample.bbox : fallbackBboxForSample(sample, requestBbox);
    return bboxToFootprint(bbox);
  }
  const lat = Number(sample?.lat);
  const lon = normalizeLon(sample?.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  const trueEdgeFt = Math.max(1, Math.abs(Number(sample?.cube_edge_ft || sample?.cube_size_ft || FIELD_CUBE_HORIZONTAL_FT)) || FIELD_CUBE_HORIZONTAL_FT);
  const visualEdgeFt = clamp(trueEdgeFt * Math.max(1, FIELD_CUBE_VISUAL_HORIZONTAL_SCALE), FIELD_CUBE_MIN_VISUAL_HORIZONTAL_FT, FIELD_CUBE_MAX_VISUAL_HORIZONTAL_FT);
  const visualEdgeM = visualEdgeFt * 0.3048;
  const latHalf = (visualEdgeM / 2) / 111320;
  const lonHalf = (visualEdgeM / 2) / Math.max(12, 111320 * Math.cos(lat * Math.PI / 180));
  const s = clamp(FIELD_CUBE_FOOTPRINT_SHRINK, 0.15, 1.0);
  return {
    nw: { lat: lat + latHalf * s, lng: normalizeLon(lon - lonHalf * s) },
    ne: { lat: lat + latHalf * s, lng: normalizeLon(lon + lonHalf * s) },
    se: { lat: lat - latHalf * s, lng: normalizeLon(lon + lonHalf * s) },
    sw: { lat: lat - latHalf * s, lng: normalizeLon(lon - lonHalf * s) },
    center: { lat, lng: lon },
    trueEdgeFt,
    visualEdgeFt,
  };
}

function topPath(foot, alt) {
  return [
    { ...foot.nw, altitude: alt },
    { ...foot.ne, altitude: alt },
    { ...foot.se, altitude: alt },
    { ...foot.sw, altitude: alt },
  ];
}

function bottomPath(foot, alt) {
  return [
    { ...foot.sw, altitude: alt },
    { ...foot.se, altitude: alt },
    { ...foot.ne, altitude: alt },
    { ...foot.nw, altitude: alt },
  ];
}

function cubeEdgePaths(foot, topAlt, bottomAlt) {
  const top = topPath(foot, topAlt);
  const bottom = bottomPath(foot, bottomAlt);
  return [
    [...top, top[0]],
    [...bottom, bottom[0]],
    [{ ...foot.nw, altitude: topAlt }, { ...foot.nw, altitude: bottomAlt }],
    [{ ...foot.ne, altitude: topAlt }, { ...foot.ne, altitude: bottomAlt }],
    [{ ...foot.se, altitude: topAlt }, { ...foot.se, altitude: bottomAlt }],
    [{ ...foot.sw, altitude: topAlt }, { ...foot.sw, altitude: bottomAlt }],
  ];
}

function facePath(a, b, altTop, altBottom) {
  return [
    { ...a, altitude: altTop },
    { ...b, altitude: altTop },
    { ...b, altitude: altBottom },
    { ...a, altitude: altBottom },
  ];
}

function makePolygon(path, style, sample, kind, fillColor = null) {
  if (!Array.isArray(path) || path.length < 3) return null;
  const el = document.createElement('gmp-polygon-3d');
  try { el.path = path; } catch (_) {}
  applyAltitudeMode(el);
  const fill = fillColor || style.fill;
  try { el.fillColor = fill; } catch (_) {}
  try { el.strokeColor = style.stroke; } catch (_) {}
  try { el.strokeWidth = kind === 'top' ? Math.max(0.1, style.width * 0.24) : 0.05; } catch (_) {}
  try { el.drawsOccludedSegments = true; } catch (_) {}
  setAttr(el, 'path', pathString(path));
  setAttr(el, 'fill-color', fill);
  setAttr(el, 'stroke-color', kind === 'top' ? style.stroke : rgba(style.rgb, 0.08));
  setAttr(el, 'stroke-width', kind === 'top' ? Math.max(0.1, style.width * 0.24).toFixed(2) : '0.05');
  setBoolAttr(el, 'draws-occluded-segments', true);
  setBoolAttr(el, 'draws-when-occluded', true);
  setAttr(el, 'data-gfs-layer', 'bait-3d');
  setAttr(el, 'data-bait-renderer', 'bait-probability-contoured-cubes');
  setAttr(el, 'data-bait-cube-face', kind);
  decorateCubeNode(el, sample, style);
  try { el.style.filter = `drop-shadow(0 0 ${Math.round(style.glowPx)}px ${style.glow})`; } catch (_) {}
  return el;
}

function makePolyline(path, style, sample, kind = 'outline') {
  if (!Array.isArray(path) || path.length < 2) return null;
  const el = document.createElement('gmp-polyline-3d');
  try { el.path = path; } catch (_) {}
  applyAltitudeMode(el);
  try { el.strokeColor = style.stroke; } catch (_) {}
  try { el.strokeWidth = style.width; } catch (_) {}
  try { el.drawsOccludedSegments = true; } catch (_) {}
  setAttr(el, 'path', pathString(path));
  setAttr(el, 'stroke-color', style.stroke);
  setAttr(el, 'stroke-width', style.width.toFixed(2));
  setBoolAttr(el, 'draws-occluded-segments', true);
  setBoolAttr(el, 'draws-when-occluded', true);
  setAttr(el, 'data-gfs-layer', 'bait-3d');
  setAttr(el, 'data-bait-renderer', 'bait-probability-contoured-cubes');
  setAttr(el, 'data-bait-cube-face', kind);
  decorateCubeNode(el, sample, style);
  try { el.style.filter = `drop-shadow(0 0 ${Math.round(style.glowPx * 0.65)}px ${style.glow})`; } catch (_) {}
  return el;
}

function decorateCubeNode(el, sample, style) {
  const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
  const depthM = Math.abs(Number(sample?.depth_m ?? sample?.bait_depth_m ?? 0));
  setAttr(el, 'data-bait-field-mode', 'thresholded-contoured-cube-field');
  setAttr(el, 'data-bait-probability', p.toFixed(4));
  setAttr(el, 'data-bait-probability-u8', Math.round(p * 255));
  setAttr(el, 'data-bait-depth-m', depthM.toFixed(2));
  setAttr(el, 'data-bait-true-depth-m', depthM.toFixed(2));
  setAttr(el, 'data-bait-cube-size-ft', FIELD_CUBE_STEP_FT.toFixed(1));
  setAttr(el, 'data-bait-temperature-c', sample?.temperature_c);
  setAttr(el, 'data-bait-chlorophyll-mg-m3', sample?.chlorophyll_mg_m3);
  setAttr(el, 'data-bait-sample-method', sample?.sample_method || 'bait_probability_scalar_field');
  setAttr(el, 'data-bait-palette', 'pastel-yellow_neon-yellow_pastel-green_neon-green');
  setAttr(el, 'data-bait-glow', style.glow);
  setAttr(el, 'data-bait-no-surface-sheets', FIELD_NO_SURFACE_SHEETS ? 'true' : 'false');
  setAttr(el, 'data-bait-cube-true-edge-ft', FIELD_CUBE_HORIZONTAL_FT.toFixed(1));
  setAttr(el, 'data-bait-cube-visual-horizontal-scale', FIELD_CUBE_VISUAL_HORIZONTAL_SCALE.toFixed(1));
  setAttr(el, 'data-bait-cube-visual-edge-ft', sample?.visual_edge_ft);
  el.title = `Bait probability cube ${Math.round(p * 100)}% • ${Math.round(depthM * 3.28084)} ft • true edge ${FIELD_CUBE_HORIZONTAL_FT.toFixed(0)} ft`;
}

function makeGlowTemplate({ style, probability, index }) {
  const p = clamp01(probability);
  const t = style.t;
  const size = Math.round(10 + t * 24);
  const coreOpacity = (0.32 + t * 0.52).toFixed(2);
  const haloOpacity = (0.20 + t * 0.42).toFixed(2);
  const uid = `lftr-bait-field-glow-${index}-${Math.random().toString(16).slice(2)}`;
  const tpl = document.createElement('template');
  tpl.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="overflow:visible;pointer-events:none;filter:drop-shadow(0 0 ${Math.round(8 + t * 18)}px ${style.hex}) drop-shadow(0 0 ${Math.round(4 + t * 10)}px ${style.hex});">
    <defs>
      <radialGradient id="${uid}" cx="50%" cy="50%" r="62%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="${coreOpacity}"/>
        <stop offset="35%" stop-color="${style.hex}" stop-opacity="${haloOpacity}"/>
        <stop offset="100%" stop-color="${style.hex}" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <circle cx="16" cy="16" r="15" fill="url(#${uid})"/>
    <circle cx="16" cy="16" r="${(2.2 + t * 2.7).toFixed(1)}" fill="#fff" fill-opacity="${Math.min(0.76, 0.28 + t * 0.55).toFixed(2)}"/>
  </svg>`;
  return tpl;
}

function makeGlowParticle(sample, foot, topAlt, bottomAlt, style, index) {
  const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
  if (p < FIELD_GLOW_THRESHOLD) return null;
  const el = document.createElement('gmp-marker-3d');
  const altitude = (topAlt + bottomAlt) / 2;
  try { el.position = { lat: foot.center.lat, lng: foot.center.lng, altitude }; } catch (_) {}
  applyAltitudeMode(el);
  try { el.drawsWhenOccluded = true; } catch (_) {}
  try { el.sizePreserved = true; } catch (_) {}
  setAttr(el, 'position', `${foot.center.lat},${foot.center.lng},${altitude.toFixed(2)}`);
  setBoolAttr(el, 'draws-when-occluded', true);
  setBoolAttr(el, 'draws-occluded-segments', true);
  setAttr(el, 'data-gfs-layer', 'bait-3d');
  setAttr(el, 'data-bait-renderer', 'bait-probability-glow-particle');
  setAttr(el, 'data-bait-particle-glow', 'true');
  decorateCubeNode(el, sample, style);
  el.append(makeGlowTemplate({ style, probability: p, index }));
  return el;
}

function hashString(str) {
  let h = 2166136261;
  const text = String(str || 'bait');
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function seededRandom(seed) {
  let x = Number(seed) >>> 0;
  return () => {
    x += 0x6D2B79F5;
    let t = x;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function probabilityAlpha(probability) {
  const p = clamp01(probability);
  if (p < FIELD_THRESHOLD) return 0;
  const t = smoothstep(FIELD_THRESHOLD, Math.max(FIELD_THRESHOLD + 0.01, FIELD_PARTICLE_ALPHA_FULL_AT), p);
  return clamp(FIELD_PARTICLE_ALPHA_FLOOR + t * (FIELD_PARTICLE_ALPHA_HIGH - FIELD_PARTICLE_ALPHA_FLOOR), 0, 1);
}

function sampleParticleRadiusM(sample, requestBbox = null) {
  const lat = Number(sample?.lat || 0);
  const bbox = Array.isArray(sample?.bbox) ? sample.bbox : fallbackBboxForSample(sample, requestBbox);
  if (Array.isArray(bbox) && bbox.length >= 4) {
    const west = normalizeLon(bbox[0]);
    const south = Number(bbox[1]);
    const east = normalizeLon(bbox[2]);
    const north = Number(bbox[3]);
    let lonSpan = Math.abs(east - west);
    if (lonSpan > 180) lonSpan = 360 - lonSpan;
    const widthM = lonSpan * 111320 * Math.max(0.18, Math.cos((lat * Math.PI) / 180));
    const heightM = Math.abs(north - south) * 111320;
    const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
    return clamp(Math.max(widthM, heightM) * (0.18 + 0.34 * p), FIELD_PARTICLE_JITTER_MIN_M, FIELD_PARTICLE_JITTER_MAX_M);
  }
  return clamp(FIELD_CUBE_HORIZONTAL_FT * 0.3048 * FIELD_CUBE_VISUAL_HORIZONTAL_SCALE * 0.42, FIELD_PARTICLE_JITTER_MIN_M, FIELD_PARTICLE_JITTER_MAX_M);
}

function particleCountForSample(sample) {
  const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
  const t = smoothstep(FIELD_THRESHOLD, 1.0, p);
  const stack = clamp(Math.sqrt(Math.max(1, Number(sample?.field_stack_count || 1))), 1, 3);
  return Math.max(1, Math.min(FIELD_PARTICLE_MAX_PER_SAMPLE, Math.round(1 + t * (FIELD_PARTICLE_MAX_PER_SAMPLE - 1) * stack * 0.72)));
}

function buildParticleCandidates(samples, requestBbox = null) {
  const candidates = [];
  for (const sample of samples) {
    const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
    if (p < FIELD_THRESHOLD) continue;
    const depthM = Math.abs(Number(sample?.depth_m ?? sample?.bait_depth_m ?? 0));
    if (!Number.isFinite(depthM) || depthM < FIELD_SURFACE_MIN_DEPTH_M) continue;
    const lat = Number(sample?.lat);
    const lon = normalizeLon(sample?.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
    const alpha = probabilityAlpha(p);
    if (alpha <= 0) continue;
    const radiusM = sampleParticleRadiusM(sample, requestBbox);
    const count = particleCountForSample(sample);
    const heading = headingFromCurrent(sample);
    const theta = (heading * Math.PI) / 180;
    const sin = Math.sin(theta);
    const cos = Math.cos(theta);
    const rand = seededRandom(hashString(`${sample?.id || sample?.cell_index || 's'}:${sample?.depth_index || sample?.depth_m || 0}:${lat.toFixed(5)}:${lon.toFixed(5)}`));
    for (let i = 0; i < count; i += 1) {
      const r = Math.sqrt(rand()) * radiusM;
      const a = rand() * Math.PI * 2;
      const along = Math.cos(a) * r * (1.20 + p * 0.80);
      const across = Math.sin(a) * r * (0.45 + p * 0.35);
      const eastM = sin * along + cos * across;
      const northM = cos * along - sin * across;
      const pos = offsetLatLonMeters(lat, lon, eastM, northM);
      const verticalJitterM = ((rand() - 0.5) * FIELD_PARTICLE_VERTICAL_JITTER_FT * 0.3048) * (0.45 + p);
      candidates.push({
        ...sample,
        id: `bait-particle:${sample?.id || sample?.cell_index || 'x'}:${i}`,
        lat: pos.lat,
        lon: pos.lng,
        depth_m: Math.max(FIELD_SURFACE_MIN_DEPTH_M, depthM + verticalJitterM),
        probability: p,
        probability_u8: Math.round(p * 255),
        particle_alpha: alpha,
        particle_radius_m: radiusM,
        particle_index: i,
        selection_weight: p + rand() * 0.045,
        sample_method: `${sample?.sample_method || 'bait_probability_scalar_field'}_particle_cloud_sample`,
      });
    }
  }
  return candidates;
}

function selectParticleCandidates(candidates) {
  if (candidates.length <= FIELD_PARTICLE_MAX) return candidates;
  const sorted = candidates.slice().sort((a, b) => Number(b.selection_weight || b.probability || 0) - Number(a.selection_weight || a.probability || 0));
  const hotKeep = Math.max(60, Math.floor(FIELD_PARTICLE_MAX * 0.30));
  const selected = sorted.slice(0, hotKeep);
  const remaining = sorted.slice(hotKeep);
  const lats = remaining.map((x) => Number(x.lat)).filter(Number.isFinite);
  const lons = remaining.map((x) => normalizeLon(x.lon)).filter(Number.isFinite);
  const depths = remaining.map((x) => Math.abs(Number(x.depth_m || 0))).filter(Number.isFinite);
  const south = lats.length ? Math.min(...lats) : 0;
  const north = lats.length ? Math.max(...lats) : 1;
  const west = lons.length ? Math.min(...lons) : 0;
  const east = lons.length ? Math.max(...lons) : 1;
  const maxDepth = depths.length ? Math.max(1, Math.max(...depths)) : 1;
  const side = Math.max(8, Math.min(36, Math.round(Math.sqrt(FIELD_PARTICLE_MAX) / 2)));
  const buckets = new Map();
  for (const item of remaining) {
    const lat = Number(item.lat);
    const lon = normalizeLon(item.lon);
    const dep = Math.abs(Number(item.depth_m || 0));
    const key = [
      Math.floor(clamp01((lat - south) / Math.max(0.0001, north - south)) * side),
      Math.floor(clamp01((lon - west) / Math.max(0.0001, east - west)) * side),
      Math.floor(clamp01(dep / maxDepth) * 10),
    ].join(':');
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(item);
  }
  for (const stack of buckets.values()) stack.sort((a, b) => Number(b.selection_weight || b.probability || 0) - Number(a.selection_weight || a.probability || 0));
  let keys = [...buckets.keys()].sort();
  while (keys.length && selected.length < FIELD_PARTICLE_MAX) {
    for (const key of [...keys]) {
      const stack = buckets.get(key) || [];
      if (stack.length) selected.push(stack.shift());
      if (!stack.length) {
        buckets.delete(key);
        keys = keys.filter((k) => k !== key);
      }
      if (selected.length >= FIELD_PARTICLE_MAX) break;
    }
  }
  return selected;
}

function makeParticleTemplate({ style, probability, alpha, index, heading = 0 }) {
  const p = clamp01(probability);
  const t = style.t;
  // The cedar-plug ellipse represents real 4 inch bait and is intentionally
  // not scaled up by probability or viewport.  The glow halo is the only
  // element that grows, so the mass reads as glow while the body stays tiny.
  const bodyHRaw = clamp(FIELD_PARTICLE_BODY_VISUAL_HEIGHT_PX, FIELD_PARTICLE_BODY_VISUAL_MIN_PX, FIELD_PARTICLE_BODY_VISUAL_MAX_PX);
  const bodyH = Number(bodyHRaw.toFixed(2));
  const bodyW = Number((bodyH * 2.35).toFixed(2));
  const a = clamp(alpha, 0, 1);
  const uid = `lftr-bait-cedar-${index}-${Math.random().toString(16).slice(2)}`;
  const glowPx = Math.round(FIELD_PARTICLE_GLOW_MIN_PX + t * (FIELD_PARTICLE_GLOW_MAX_PX - FIELD_PARTICLE_GLOW_MIN_PX));
  const rot = ((Number(heading) || 0) % 360).toFixed(1);
  const tpl = document.createElement('template');
  tpl.innerHTML = `<svg width="${bodyW}" height="${bodyH}" viewBox="0 0 64 28" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" data-bait-body-world-length-in="${FIELD_PARTICLE_BODY_LENGTH_IN.toFixed(2)}" data-bait-body-world-length-m="${FIELD_PARTICLE_BODY_WORLD_M.toFixed(4)}" style="overflow:visible;pointer-events:none;filter:drop-shadow(0 0 ${glowPx}px rgba(218,244,255,${(0.24 + 0.56 * t).toFixed(3)})) drop-shadow(0 0 ${Math.round(glowPx * 0.62)}px rgba(255,255,255,${(0.16 + 0.36 * t).toFixed(3)}));opacity:${a.toFixed(3)};">
    <defs>
      <clipPath id="${uid}-body"><ellipse cx="32" cy="14" rx="28" ry="9.5"/></clipPath>
      <linearGradient id="${uid}-silver" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#ffffff"/>
        <stop offset="38%" stop-color="#d8dde0"/>
        <stop offset="100%" stop-color="#9aa3a8"/>
      </linearGradient>
      <radialGradient id="${uid}-eye" cx="50%" cy="50%" r="62%">
        <stop offset="0%" stop-color="#111111"/>
        <stop offset="36%" stop-color="#111111"/>
        <stop offset="42%" stop-color="#fff4c6"/>
        <stop offset="72%" stop-color="#f5b23b"/>
        <stop offset="100%" stop-color="#151515"/>
      </radialGradient>
    </defs>
    <g transform="rotate(${rot} 32 14)">
      <ellipse cx="32" cy="14" rx="28" ry="9.5" fill="#ffffff" stroke="#050505" stroke-width="1.45"/>
      <g clip-path="url(#${uid}-body)">
        <rect x="3" y="3" width="58" height="11" fill="url(#${uid}-silver)"/>
        <rect x="3" y="14" width="58" height="11" fill="#ffffff"/>
        <path d="M5 13.8 C15 11.8 26 12.5 36 13.8 C46 15.2 55 14.8 60 13.8" fill="none" stroke="#5a646a" stroke-opacity="0.48" stroke-width="0.8"/>
        <path d="M8 10 C20 7.5 38 7.7 55 10.5" fill="none" stroke="#ffffff" stroke-opacity="0.62" stroke-width="1.1"/>
      </g>
      <path d="M6 14 L1.5 9.5 L2.8 14 L1.5 18.5 Z" fill="#f8fbff" stroke="#050505" stroke-width="1.0" stroke-linejoin="round"/>
      <circle cx="51.5" cy="11.2" r="4.15" fill="url(#${uid}-eye)" stroke="#050505" stroke-width="0.95"/>
      <circle cx="50.1" cy="9.8" r="0.95" fill="#ffffff" fill-opacity="0.9"/>
      <ellipse cx="32" cy="14" rx="28" ry="9.5" fill="none" stroke="#050505" stroke-width="1.1"/>
    </g>
  </svg>`;
  return tpl;
}

function makeScalarParticleNode(sample, index) {
  const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
  const alpha = probabilityAlpha(p);
  if (alpha <= 0) return null;
  const lat = Number(sample?.lat);
  const lon = normalizeLon(sample?.lon);
  const depthM = Math.abs(Number(sample?.depth_m || 0));
  if (![lat, lon, depthM].every(Number.isFinite)) return null;
  const style = fieldStyle(p);
  const vd = visualDepthForDepth(depthM);
  const el = document.createElement('gmp-marker-3d');
  try { el.position = { lat, lng: lon, altitude: vd.altitude }; } catch (_) {}
  applyAltitudeMode(el);
  try { el.drawsWhenOccluded = true; } catch (_) {}
  try { el.sizePreserved = false; } catch (_) {}
  try { el.style.pointerEvents = 'none'; } catch (_) {}
  setAttr(el, 'position', `${lat},${lon},${vd.altitude.toFixed(2)}`);
  setBoolAttr(el, 'draws-when-occluded', true);
  setBoolAttr(el, 'draws-occluded-segments', true);
  setBoolAttr(el, 'size-preserved', false);
  setAttr(el, 'data-gfs-layer', 'bait-3d');
  setAttr(el, 'data-bait-renderer', 'bait-scalar-field-cedar-plug-ellipse-point-cloud');
  setAttr(el, 'data-bait-field-mode', 'continuous-xyz-scalar-field-top20-cedar-plug-point-cloud');
  setAttr(el, 'data-bait-probability', p.toFixed(4));
  setAttr(el, 'data-bait-probability-u8', Math.round(p * 255));
  setAttr(el, 'data-bait-depth-m', depthM.toFixed(2));
  setAttr(el, 'data-bait-true-depth-m', depthM.toFixed(2));
  setAttr(el, 'data-bait-alpha-threshold', FIELD_THRESHOLD.toFixed(3));
  setAttr(el, 'data-bait-particle-alpha', alpha.toFixed(3));
  setAttr(el, 'data-bait-particle-radius-m', Number(sample?.particle_radius_m || 0).toFixed(1));
  setAttr(el, 'data-bait-temperature-c', sample?.temperature_c);
  setAttr(el, 'data-bait-chlorophyll-mg-m3', sample?.chlorophyll_mg_m3);
  setAttr(el, 'data-bait-sample-method', sample?.sample_method || 'bait_probability_scalar_field_particle_cloud');
  setAttr(el, 'data-bait-palette', 'silver_top_white_bottom_black_outline_cedar_plug_eye');
  setAttr(el, 'data-bait-body-length-in', FIELD_PARTICLE_BODY_LENGTH_IN.toFixed(2));
  setAttr(el, 'data-bait-body-width-in', FIELD_PARTICLE_BODY_WIDTH_IN.toFixed(2));
  setAttr(el, 'data-bait-body-world-length-m', FIELD_PARTICLE_BODY_WORLD_M.toFixed(4));
  setAttr(el, 'data-bait-body-scale-policy', 'no-body-scale_glow-only');
  setAttr(el, 'data-bait-glow-px', Math.round(FIELD_PARTICLE_GLOW_MIN_PX + style.t * (FIELD_PARTICLE_GLOW_MAX_PX - FIELD_PARTICLE_GLOW_MIN_PX)));
  setAttr(el, 'data-bait-sprite-style', sample?.sprite_style || 'cedar_plug_eye_silver_top_white_bottom_black_outline_glow_only');
  el.title = `Bait scalar-field top-20% sample ${Math.round(p * 100)}% • ${Math.round(depthM * 3.28084)} ft • ${FIELD_PARTICLE_BODY_LENGTH_IN.toFixed(0)}in cedar-plug ellipse; body not scaled, glow only`;
  el.append(makeParticleTemplate({ style, probability: p, alpha, index, heading: sample?.direction_deg ?? headingFromCurrent(sample) }));
  return el;
}

function coreShellFootprintForSample(sample, requestBbox = null) {
  const lat = Number(sample?.lat);
  const lon = normalizeLon(sample?.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
  const radiusM = sampleParticleRadiusM(sample, requestBbox) * (0.64 + p * 0.38);
  return rotatedRectFootprint(lat, lon, (radiusM * 2.6) / 0.3048, (radiusM * 1.08) / 0.3048, headingFromCurrent(sample));
}

function makeParticleCoreShell(sample, requestBbox, index) {
  const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
  if (!FIELD_PARTICLE_CORE_SHELL || p < FIELD_PARTICLE_CORE_THRESHOLD) return null;
  const foot = coreShellFootprintForSample(sample, requestBbox);
  if (!foot) return null;
  const depthM = Math.abs(Number(sample?.depth_m || 0));
  const vd = visualDepthForDepth(depthM);
  const style = fieldStyle(p);
  const path = topPath(foot, vd.altitude);
  const alpha = probabilityAlpha(p) * 0.14;
  const el = makePolygon(path, style, sample, 'particle-cloud-threshold-shell', rgba(style.rgb, alpha));
  if (!el) return null;
  setAttr(el, 'data-bait-renderer', 'bait-scalar-field-particle-cloud-shell');
  setAttr(el, 'data-bait-field-mode', 'continuous-xyz-particle-cloud-core-shell');
  setAttr(el, 'data-bait-alpha-threshold', FIELD_THRESHOLD.toFixed(3));
  setAttr(el, 'data-bait-shell-index', index);
  return el;
}

function flattenPayloadFieldSamples(payload) {
  const supplied = Array.isArray(payload?.field_samples) ? payload.field_samples : [];
  if (supplied.length) return supplied;
  const cells = Array.isArray(payload?.cells) ? payload.cells : [];
  const depths = Array.isArray(payload?.depths_m) ? payload.depths_m : [];
  const field = payload?.fields?.bait_probability_u8;
  if (!cells.length || !depths.length || !Array.isArray(field)) return [];
  const samples = [];
  depths.forEach((depth, zi) => {
    const row = Array.isArray(field[zi]) ? field[zi] : [];
    const nextDepth = Math.abs(Number(depths[zi + 1] ?? (Number(depth) + FIELD_CUBE_STEP_M)) || (Number(depth) + FIELD_CUBE_STEP_M));
    const dz = Math.max(0.5, Math.abs(nextDepth - Math.abs(Number(depth) || 0)) || FIELD_CUBE_STEP_M);
    cells.forEach((cell, ci) => {
      const u8 = Number(row[ci] || 0);
      const p = clamp01(u8 / 255);
      const d = Math.abs(Number(depth) || 0);
      if (p < FIELD_THRESHOLD || d < FIELD_SURFACE_MIN_DEPTH_M) return;
      const bottom = Number(cell?.bottom_depth_m || cell?.seafloor_depth_m || 0);
      if (bottom > 0 && d >= bottom - 1) return;
      samples.push({
        id: `bait-cube:${ci}:${zi}`,
        cell_index: ci,
        depth_index: zi,
        lat: cell?.lat,
        lon: cell?.lon,
        bbox: cell?.bbox,
        tile_id: cell?.tile_id,
        depth_m: d,
        depth_step_m: dz,
        cube_size_m: dz,
        cube_size_ft: dz * 3.280839895,
        altitude_m: -d,
        seafloor_depth_m: bottom || null,
        probability: p,
        probability_u8: u8,
        temperature_c: cell?.sst_c,
        salinity: cell?.salinity,
        current_speed_kt: cell?.current_speed_kt,
        direction_deg: cell?.direction_deg,
        u_ms: cell?.u_ms,
        v_ms: cell?.v_ms,
        chlorophyll_mg_m3: cell?.chlorophyll_mg_m3,
        sample_method: cell?.sample_method || 'frontend_bait_probability_contoured_cube_field_sample',
      });
    });
  });
  return samples;
}

async function fetchBaitField(bbox) {
  const key = `${bboxQuery(bbox)}:${DEPTHS}:${FETCH_GRID}:${FIELD_THRESHOLD}:${FIELD_MAX_CELLS}:${FIELD_MAX_RENDERED}:${FIELD_RENDER_MODE}:${FIELD_PARTICLE_MAX}:cedar-plug-cloud-v1`;
  const cached = PAYLOAD_CACHE.get(key);
  if (cached && (Date.now() - cached.ts) < CACHE_TTL_MS) return { ...cached.data, frontend_cache_hit: true };
  const url = FIELD_PARTICLE_CLOUD_ENABLED
    ? `/gfs/api/bait-field-cloud?bbox=${encodeURIComponent(bboxQuery(bbox))}&depths=${encodeURIComponent(DEPTHS)}&grid=${encodeURIComponent(FETCH_GRID)}&max_cells=${encodeURIComponent(FIELD_MAX_CELLS)}&threshold=${encodeURIComponent(FIELD_THRESHOLD)}&max_field_points=${encodeURIComponent(FIELD_MAX_RENDERED)}&max_particles=${encodeURIComponent(FIELD_PARTICLE_MAX)}&warm=1`
    : `/gfs/api/bait-3d-volume?bbox=${encodeURIComponent(bboxQuery(bbox))}&depths=${encodeURIComponent(DEPTHS)}&grid=${encodeURIComponent(FETCH_GRID)}&max_clouds=0&max_cells=${encodeURIComponent(FIELD_MAX_CELLS)}&threshold=${encodeURIComponent(FIELD_THRESHOLD)}&max_field_points=${encodeURIComponent(FIELD_MAX_RENDERED)}&chlorophyll=warm&truth=1&warm=1&mode=field&render=${encodeURIComponent(FIELD_PARTICLE_CLOUD_ENABLED ? 'particle_cloud' : 'cubes')}&cube_step_ft=${encodeURIComponent(FIELD_CUBE_STEP_FT)}`;
  try {
    const res = await fetch(url, { cache: 'default' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const payload = { ...data, url };
    PAYLOAD_CACHE.set(key, { ts: Date.now(), data: payload });
    if (PAYLOAD_CACHE.size > 10) PAYLOAD_CACHE.delete(PAYLOAD_CACHE.keys().next().value);
    return payload;
  } catch (error) {
    return { ok: false, url, error: String(error?.message || error), particles: [], field_samples: [], fields: { bait_probability_u8: [] } };
  }
}

function clearBait3d(map3DElement) {
  try { map3DElement?.querySelectorAll?.(BAIT3D_SELECTOR)?.forEach((el) => el.remove()); } catch (_) {}
}

function sampleDepthStep(sample, sortedDepths = []) {
  const direct = Number(sample?.depth_step_m || sample?.cube_size_m);
  if (Number.isFinite(direct) && direct > 0) return direct;
  const d = Math.abs(Number(sample?.depth_m || 0));
  const idx = sortedDepths.findIndex((x) => Math.abs(Number(x) - d) < 0.01);
  if (idx >= 0 && idx < sortedDepths.length - 1) return Math.max(0.5, Math.abs(Number(sortedDepths[idx + 1]) - d));
  return FIELD_CUBE_STEP_M;
}

function selectRenderableSamples(payload) {
  const samples = flattenPayloadFieldSamples(payload)
    .map((s) => ({ ...s, probability: clamp01(s?.probability ?? (Number(s?.probability_u8 || 0) / 255)) }))
    .filter((s) => s.probability >= FIELD_THRESHOLD)
    .filter((s) => Math.abs(Number(s?.depth_m || 0)) >= FIELD_SURFACE_MIN_DEPTH_M);
  if (samples.length <= FIELD_MAX_RENDERED) {
    return samples.sort((a, b) => Number(a.depth_m || 0) - Number(b.depth_m || 0) || Number(b.probability || 0) - Number(a.probability || 0));
  }
  // Preserve the field shape: keep the hottest cores, then stratify the rest by
  // x/y/z buckets.  This is safer than blindly trying to draw 20k+ DOM cubes on
  // every global refresh.
  const sorted = samples.slice().sort((a, b) => Number(b.probability || 0) - Number(a.probability || 0));
  const hotKeep = Math.floor(FIELD_MAX_RENDERED * 0.42);
  const selected = sorted.slice(0, hotKeep);
  const remaining = sorted.slice(hotKeep);
  const lats = remaining.map((x) => Number(x.lat)).filter(Number.isFinite);
  const lons = remaining.map((x) => normalizeLon(x.lon)).filter(Number.isFinite);
  const deps = remaining.map((x) => Number(x.depth_m)).filter(Number.isFinite);
  const south = lats.length ? Math.min(...lats) : 0;
  const north = lats.length ? Math.max(...lats) : 1;
  const west = lons.length ? Math.min(...lons) : 0;
  const east = lons.length ? Math.max(...lons) : 1;
  const depMax = deps.length ? Math.max(1, Math.max(...deps)) : 1;
  const bucketSide = Math.max(8, Math.min(36, Math.round(Math.sqrt(FIELD_MAX_RENDERED) / 2)));
  const buckets = new Map();
  for (const item of remaining) {
    const lat = Number(item.lat);
    const lon = normalizeLon(item.lon);
    const dep = Number(item.depth_m || 0);
    const key = [
      Math.floor(clamp01((lat - south) / Math.max(0.0001, north - south)) * bucketSide),
      Math.floor(clamp01((lon - west) / Math.max(0.0001, east - west)) * bucketSide),
      Math.floor(clamp01(dep / depMax) * 10),
    ].join(':');
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(item);
  }
  for (const stack of buckets.values()) stack.sort((a, b) => Number(b.probability || 0) - Number(a.probability || 0));
  let keys = [...buckets.keys()].sort();
  while (keys.length && selected.length < FIELD_MAX_RENDERED) {
    for (const key of [...keys]) {
      const stack = buckets.get(key) || [];
      if (stack.length) selected.push(stack.shift());
      if (!stack.length) {
        buckets.delete(key);
        keys = keys.filter((k) => k !== key);
      }
      if (selected.length >= FIELD_MAX_RENDERED) break;
    }
  }
  return selected.sort((a, b) => Number(a.depth_m || 0) - Number(b.depth_m || 0) || Number(b.probability || 0) - Number(a.probability || 0));
}

function appendNodesInChunks(map3DElement, nodes) {
  if (!nodes.length) return;
  if (!Number.isFinite(FIELD_PROGRESSIVE_CHUNK) || FIELD_PROGRESSIVE_CHUNK <= 0 || nodes.length <= FIELD_PROGRESSIVE_CHUNK) {
    const frag = document.createDocumentFragment();
    nodes.forEach((node) => frag.append(node));
    map3DElement.append(frag);
    return;
  }
  let index = 0;
  const pump = () => {
    const frag = document.createDocumentFragment();
    const end = Math.min(nodes.length, index + FIELD_PROGRESSIVE_CHUNK);
    for (; index < end; index += 1) frag.append(nodes[index]);
    map3DElement.append(frag);
    if (index < nodes.length) window.requestAnimationFrame?.(pump) || setTimeout(pump, 0);
  };
  pump();
}

function makeCubeNodes(sample, requestBbox, sortedDepths, counters) {
  const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
  if (p < FIELD_THRESHOLD) return [];
  const depthM = Math.abs(Number(sample?.depth_m ?? sample?.bait_depth_m ?? 0));
  if (!Number.isFinite(depthM) || depthM < FIELD_SURFACE_MIN_DEPTH_M) return [];
  const foot = cubeFootprintForSample(sample, requestBbox);
  if (!foot) return [];
  const style = fieldStyle(p);
  const vd = visualDepthForDepth(depthM);
  const dzTrue = sampleDepthStep(sample, sortedDepths);
  const dzVisual = visualCubeThickness({ ...sample, depth_step_m: dzTrue });
  const topAlt = vd.altitude;
  const bottomAlt = vd.altitude - dzVisual;
  const top = topPath(foot, topAlt);
  const bottom = bottomPath(foot, bottomAlt);
  const decoratedSample = { ...sample, depth_step_m: dzTrue, cube_edge_ft: FIELD_CUBE_HORIZONTAL_FT, visual_edge_ft: foot.visualEdgeFt };
  const nodes = [];

  // Draw sides for every thresholded cube by default.  This is the core fix:
  // the renderer no longer depends on wide top faces, so the field no longer
  // reads as surface/depth sheets.
  const sideAllowed = FIELD_DRAW_ALL_SIDES && p >= FIELD_HOT_SIDE_THRESHOLD && counters.hotSideCubes < FIELD_MAX_HOT_SIDE_CUBES;
  if (sideAllowed) {
    const sides = [
      facePath(foot.nw, foot.ne, topAlt, bottomAlt),
      facePath(foot.ne, foot.se, topAlt, bottomAlt),
      facePath(foot.se, foot.sw, topAlt, bottomAlt),
      facePath(foot.sw, foot.nw, topAlt, bottomAlt),
    ];
    for (let idx = 0; idx < sides.length; idx += 1) {
      if ((FIELD_MAX_DOM_NODES - counters.nodes - nodes.length) <= 0) break;
      const side = makePolygon(sides[idx], style, decoratedSample, `side-${idx + 1}`, style.side);
      if (side) nodes.push(side);
    }
    counters.hotSideCubes += 1;
    counters.faces += nodes.length;
  }

  if (FIELD_DRAW_TOP_FACE && (FIELD_MAX_DOM_NODES - counters.nodes - nodes.length) > 0) {
    const topFace = makePolygon(top, style, decoratedSample, 'top', style.fill);
    if (topFace) {
      setAttr(topFace, 'data-bait-top-face-optional', 'true');
      nodes.push(topFace);
      counters.faces += 1;
    }
  }

  if (FIELD_DRAW_BOTTOM_FACE && (FIELD_MAX_DOM_NODES - counters.nodes - nodes.length) > 0) {
    const bottomFace = makePolygon(bottom, style, decoratedSample, 'bottom', rgba(style.rgb, Math.max(0.04, style.t * 0.24)));
    if (bottomFace) {
      setAttr(bottomFace, 'data-bait-bottom-face-optional', 'true');
      nodes.push(bottomFace);
      counters.faces += 1;
    }
  }

  counters.cubes += 1;

  if (p >= FIELD_OUTLINE_THRESHOLD && counters.outlines < FIELD_MAX_OUTLINES && (FIELD_MAX_DOM_NODES - counters.nodes - nodes.length) > 0) {
    for (const [edgeIndex, edge] of cubeEdgePaths(foot, topAlt, bottomAlt).entries()) {
      if (counters.outlines >= FIELD_MAX_OUTLINES || (FIELD_MAX_DOM_NODES - counters.nodes - nodes.length) <= 0) break;
      const outline = makePolyline(edge, style, decoratedSample, edgeIndex < 2 ? 'cube-loop-outline' : 'cube-vertical-edge');
      if (outline) {
        nodes.push(outline);
        counters.outlines += 1;
      }
    }
  }

  if (p >= FIELD_GLOW_THRESHOLD && counters.glowParticles < FIELD_MAX_GLOW_PARTICLES && (FIELD_MAX_DOM_NODES - counters.nodes - nodes.length) > 0) {
    const particle = makeGlowParticle(decoratedSample, foot, topAlt, bottomAlt, style, counters.glowParticles);
    if (particle) {
      nodes.push(particle);
      counters.glowParticles += 1;
    }
  }

  return nodes;
}


function sampleGroupKey(sample) {
  const idx = sample?.cell_index;
  if (idx !== undefined && idx !== null) return `cell:${idx}`;
  const lat = Number(sample?.lat);
  const lon = normalizeLon(sample?.lon);
  if (Number.isFinite(lat) && Number.isFinite(lon)) return `xy:${lat.toFixed(3)}:${lon.toFixed(3)}`;
  return `sample:${sample?.id || Math.random()}`;
}

function aggregateFieldSamplesToAnchors(samples = []) {
  const groups = new Map();
  for (const sample of samples) {
    const p = clamp01(sample?.probability ?? (Number(sample?.probability_u8 || 0) / 255));
    if (p < FIELD_THRESHOLD) continue;
    const depthM = Math.abs(Number(sample?.depth_m || sample?.bait_depth_m || 0));
    if (!Number.isFinite(depthM) || depthM < FIELD_SURFACE_MIN_DEPTH_M) continue;
    const key = sampleGroupKey(sample);
    const cur = groups.get(key) || { samples: [], maxP: 0, weight: 0, weightedDepth: 0, topDepth: Infinity, bottomDepth: 0, best: sample };
    cur.samples.push(sample);
    const weight = Math.pow(Math.max(0.001, p), 2.2);
    cur.maxP = Math.max(cur.maxP, p);
    cur.weight += weight;
    cur.weightedDepth += depthM * weight;
    cur.topDepth = Math.min(cur.topDepth, depthM);
    cur.bottomDepth = Math.max(cur.bottomDepth, depthM + sampleDepthStep(sample));
    if (p >= clamp01(cur.best?.probability ?? (Number(cur.best?.probability_u8 || 0) / 255))) cur.best = sample;
    groups.set(key, cur);
  }
  const anchors = [];
  for (const group of groups.values()) {
    const best = group.best || group.samples[0];
    const depthM = group.weight > 0 ? group.weightedDepth / group.weight : Math.abs(Number(best?.depth_m || 0));
    const dz = Math.max(FIELD_CUBE_STEP_M, Math.min(80, Math.max(0, group.bottomDepth - group.topDepth)) || sampleDepthStep(best));
    anchors.push({
      ...best,
      id: `bait-lite:${best?.cell_index ?? best?.id ?? anchors.length}`,
      probability: group.maxP,
      probability_u8: Math.round(group.maxP * 255),
      depth_m: depthM,
      depth_step_m: dz,
      cube_size_m: dz,
      field_stack_count: group.samples.length,
      field_top_depth_m: Number.isFinite(group.topDepth) ? group.topDepth : depthM,
      field_bottom_depth_m: group.bottomDepth || (depthM + dz),
      sample_method: `${best?.sample_method || 'bait_probability_scalar_field'}_lite_aggregate`,
    });
  }
  return anchors;
}

function distanceMetersApprox(a, b) {
  const lat1 = Number(a?.lat), lon1 = normalizeLon(a?.lon);
  const lat2 = Number(b?.lat), lon2 = normalizeLon(b?.lon);
  if (![lat1, lon1, lat2, lon2].every(Number.isFinite)) return Infinity;
  const meanLat = ((lat1 + lat2) * 0.5) * Math.PI / 180;
  const dx = (lon2 - lon1) * Math.cos(meanLat) * 111320;
  const dy = (lat2 - lat1) * 111320;
  return Math.sqrt(dx * dx + dy * dy);
}

function selectLiteAnchors(samples = []) {
  const anchors = aggregateFieldSamplesToAnchors(samples)
    .sort((a, b) => Number(b.probability || 0) - Number(a.probability || 0));
  if (anchors.length <= FIELD_LITE_MAX_ANCHORS) return anchors;
  const hotKeep = Math.max(40, Math.floor(FIELD_LITE_MAX_ANCHORS * clamp(FIELD_LITE_HOT_KEEP_RATIO, 0.05, 0.8)));
  const selected = anchors.slice(0, hotKeep);
  const rest = anchors.slice(hotKeep);
  for (const anchor of rest) {
    if (selected.length >= FIELD_LITE_MAX_ANCHORS) break;
    let tooClose = false;
    for (let i = 0; i < selected.length; i += 1) {
      if (distanceMetersApprox(anchor, selected[i]) < FIELD_LITE_MIN_ANCHOR_SPACING_M) { tooClose = true; break; }
    }
    if (!tooClose) selected.push(anchor);
  }
  if (selected.length < FIELD_LITE_MAX_ANCHORS) {
    for (const anchor of rest) {
      if (selected.length >= FIELD_LITE_MAX_ANCHORS) break;
      if (!selected.includes(anchor)) selected.push(anchor);
    }
  }
  return selected.sort((a, b) => Number(a.depth_m || 0) - Number(b.depth_m || 0) || Number(b.probability || 0) - Number(a.probability || 0));
}


function clusterFootprintForAnchor(anchor, requestBbox = null) {
  const lat = Number(anchor?.lat);
  const lon = normalizeLon(anchor?.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return cubeFootprintForSample(anchor, requestBbox);
  const p = clamp01(anchor?.probability ?? (Number(anchor?.probability_u8 || 0) / 255));
  const stackCount = Math.max(1, Number(anchor?.field_stack_count || 1));
  const stackDepthM = Math.max(sampleDepthStep(anchor), Math.abs(Number(anchor?.field_bottom_depth_m || 0) - Number(anchor?.field_top_depth_m || 0)) || sampleDepthStep(anchor));
  const currentKt = Math.max(0, Number(anchor?.current_speed_kt ?? anchor?.bait_current_speed_kt ?? 0));
  const headingDeg = headingFromCurrent(anchor);
  const lengthFt = clamp(FIELD_CLUSTER_LENGTH_FT_MIN + p * 280 + currentKt * 140 + Math.sqrt(stackCount) * 18, FIELD_CLUSTER_LENGTH_FT_MIN, FIELD_CLUSTER_LENGTH_FT_MAX);
  const widthFt = clamp(FIELD_CLUSTER_WIDTH_FT_MIN + p * 80 + Math.sqrt(stackCount) * 10, FIELD_CLUSTER_WIDTH_FT_MIN, FIELD_CLUSTER_WIDTH_FT_MAX);
  const heightFt = clamp(FIELD_CLUSTER_HEIGHT_FT_MIN + stackDepthM * 3.28084 * 0.72, FIELD_CLUSTER_HEIGHT_FT_MIN, FIELD_CLUSTER_HEIGHT_FT_MAX);
  const foot = rotatedRectFootprint(lat, lon, lengthFt, widthFt, headingDeg);
  return { ...foot, headingDeg, lengthFt, widthFt, heightFt, stackDepthM };
}

function implicitClusterAnchorKey(sample) {
  const lat = Number(sample?.lat || 0);
  const lon = normalizeLon(sample?.lon);
  const dep = Math.abs(Number(sample?.depth_m || 0));
  return [Math.round(lat * 8), Math.round(lon * 8), Math.round(dep / 7)].join(':');
}

function buildImplicitClusterAnchors(sourceSamples) {
  const groups = new Map();
  for (const sample of sourceSamples) {
    const key = implicitClusterAnchorKey(sample);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(sample);
  }
  const anchors = [];
  for (const stack of groups.values()) {
    stack.sort((a, b) => Number(a.depth_m || 0) - Number(b.depth_m || 0));
    const hottest = stack.reduce((best, cur) => (Number(cur.probability || 0) > Number(best?.probability || -1) ? cur : best), stack[0]);
    if (!hottest) continue;
    const avg = (name, fallback = null) => {
      const vals = stack.map((s) => Number(s?.[name])).filter(Number.isFinite);
      return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : fallback;
    };
    anchors.push({
      ...hottest,
      probability: Math.max(...stack.map((s) => Number(s.probability || 0))),
      lat: avg('lat', hottest.lat),
      lon: avg('lon', hottest.lon),
      depth_m: avg('depth_m', hottest.depth_m),
      field_top_depth_m: Math.min(...stack.map((s) => Math.abs(Number(s.depth_m || 0))).filter(Number.isFinite)),
      field_bottom_depth_m: Math.max(...stack.map((s) => Math.abs(Number(s.depth_m || 0))).filter(Number.isFinite)),
      field_stack_count: stack.length,
      current_speed_kt: avg('current_speed_kt', hottest.current_speed_kt),
      direction_deg: avg('direction_deg', hottest.direction_deg),
      u_ms: avg('u_ms', hottest.u_ms),
      v_ms: avg('v_ms', hottest.v_ms),
      sample_method: 'implicit_voxel_cluster_formula_anchor',
    });
  }
  anchors.sort((a, b) => Number(b.probability || 0) - Number(a.probability || 0));
  const chosen = [];
  for (const anchor of anchors) {
    if (chosen.length >= FIELD_CLUSTER_MAX_ANCHORS) break;
    let tooClose = false;
    for (const other of chosen) {
      if (distanceMetersApprox(anchor, other) < FIELD_CLUSTER_MIN_SPACING_M) { tooClose = true; break; }
    }
    if (!tooClose) chosen.push(anchor);
  }
  if (chosen.length < Math.min(FIELD_CLUSTER_MAX_ANCHORS, anchors.length)) {
    for (const anchor of anchors) {
      if (chosen.length >= FIELD_CLUSTER_MAX_ANCHORS) break;
      if (!chosen.includes(anchor)) chosen.push(anchor);
    }
  }
  return chosen.sort((a, b) => Number(a.depth_m || 0) - Number(b.depth_m || 0) || Number(b.probability || 0) - Number(a.probability || 0));
}

function makeLiteColumnNodes(anchor, requestBbox, counters) {
  const p = clamp01(anchor?.probability ?? (Number(anchor?.probability_u8 || 0) / 255));
  const foot = FIELD_IMPLICIT_CLUSTER_ENABLED ? clusterFootprintForAnchor(anchor, requestBbox) : cubeFootprintForSample(anchor, requestBbox);
  if (!foot) return [];
  const style = fieldStyle(p);
  const depthM = Math.abs(Number(anchor?.depth_m || 0));
  const vd = visualDepthForDepth(depthM);
  const stackDepthM = Math.max(sampleDepthStep(anchor), Math.abs(Number(anchor?.field_bottom_depth_m || 0) - Number(anchor?.field_top_depth_m || 0)) || sampleDepthStep(anchor));
  const dzVisual = clamp(stackDepthM * VISUAL_DEPTH_SCALE, MIN_VISUAL_CUBE_THICKNESS_M, MAX_VISUAL_CUBE_THICKNESS_M * 1.65);
  const topAlt = vd.altitude + dzVisual * 0.42;
  const bottomAlt = vd.altitude - dzVisual * 0.58;
  const decoratedSample = { ...anchor, depth_step_m: stackDepthM, cube_edge_ft: FIELD_CUBE_HORIZONTAL_FT, visual_edge_ft: foot.visualEdgeFt, cluster_length_ft: foot.lengthFt, cluster_width_ft: foot.widthFt, cluster_height_ft: foot.heightFt, cluster_heading_deg: foot.headingDeg };
  const nodes = [];

  if (p >= FIELD_LITE_SIDE_THRESHOLD && counters.faces < FIELD_MAX_HOT_SIDE_CUBES) {
    const face = makePolygon(facePath(foot.ne, foot.se, topAlt, bottomAlt), style, decoratedSample, 'lite-side-glow-face', rgba(style.rgb, Math.max(0.08, style.t * 0.32)));
    if (face) { nodes.push(face); counters.faces += 1; }
  }

  if (p >= FIELD_OUTLINE_THRESHOLD && counters.outlines < FIELD_MAX_OUTLINES) {
    const tpath = topPath(foot, topAlt);
    const top = makePolyline([...tpath, tpath[0]], style, decoratedSample, 'lite-top-outline');
    if (top) { nodes.push(top); counters.outlines += 1; }
  }
  if (p >= FIELD_LITE_BOTTOM_LOOP_THRESHOLD && counters.outlines < FIELD_MAX_OUTLINES) {
    const bpath = bottomPath(foot, bottomAlt);
    const bottom = makePolyline([...bpath, bpath[0]], style, decoratedSample, 'lite-bottom-outline');
    if (bottom) { nodes.push(bottom); counters.outlines += 1; }
  }
  if (p >= FIELD_LITE_VERTICAL_EDGE_THRESHOLD && counters.outlines < FIELD_MAX_OUTLINES) {
    const edgeA = makePolyline([{ ...foot.nw, altitude: topAlt }, { ...foot.nw, altitude: bottomAlt }], style, decoratedSample, 'lite-vertical-edge');
    if (edgeA) { nodes.push(edgeA); counters.outlines += 1; }
    const edgeB = makePolyline([{ ...foot.se, altitude: topAlt }, { ...foot.se, altitude: bottomAlt }], style, decoratedSample, 'lite-vertical-edge');
    if (edgeB && counters.outlines < FIELD_MAX_OUTLINES) { nodes.push(edgeB); counters.outlines += 1; }
  }
  if (FIELD_IMPLICIT_CLUSTER_ENABLED) {
    const segments = Math.max(1, Math.min(FIELD_CLUSTER_SEGMENT_LIMIT, Math.round((Number(foot.lengthFt || 0) / Math.max(FIELD_CUBE_STEP_FT, 1)) / 8)));
    for (let i = 1; i <= segments && counters.outlines < FIELD_MAX_OUTLINES; i += 1) {
      const t = i / (segments + 1);
      const mixPoint = (a, b) => ({ lat: a.lat + (b.lat - a.lat) * t, lng: normalizeLon(a.lng + (b.lng - a.lng) * t) });
      const topA = mixPoint(foot.nw, foot.sw);
      const topB = mixPoint(foot.ne, foot.se);
      const line = makePolyline([{ ...topA, altitude: topAlt }, { ...topB, altitude: topAlt }], style, decoratedSample, 'lite-cluster-segment');
      if (line) { nodes.push(line); counters.outlines += 1; }
    }
  }
  if (p >= FIELD_GLOW_THRESHOLD && counters.glowParticles < FIELD_MAX_GLOW_PARTICLES) {
    const particle = makeGlowParticle(decoratedSample, foot, topAlt, bottomAlt, style, counters.glowParticles);
    if (particle) { nodes.push(particle); counters.glowParticles += 1; }
  }
  counters.cubes += Number(anchor?.field_stack_count || 1);
  counters.anchors += 1;
  return nodes;
}

function renderParticleCloud(map3DElement, payload, requestBbox) {
  clearBait3d(map3DElement);
  const backendParticles = Array.isArray(payload?.particles) ? payload.particles : [];
  const sourceSamples = backendParticles.length ? backendParticles : selectRenderableSamples(payload);
  const candidates = backendParticles.length
    ? selectParticleCandidates(backendParticles.map((s, i) => ({
        ...s,
        probability: clamp01(s?.probability ?? (Number(s?.probability_u8 || 0) / 255)),
        particle_alpha: Number(s?.particle_alpha ?? probabilityAlpha(clamp01(s?.probability ?? (Number(s?.probability_u8 || 0) / 255)))),
        selection_weight: Number(s?.selection_weight ?? s?.probability ?? 0) + (i % 13) * 0.00001,
      })))
    : selectParticleCandidates(buildParticleCandidates(sourceSamples, requestBbox));
  if (!candidates.length) return { rendered: 0, anchors: 0, candidate_count: sourceSamples.length, threshold: FIELD_THRESHOLD, dom_nodes: 0, glow_particles: 0, outlines: 0, cube_faces: 0, mode: 'particle-cloud' };
  const nodes = [];
  let shellCount = 0;
  for (let i = 0; i < candidates.length; i += 1) {
    const particle = makeScalarParticleNode(candidates[i], i);
    if (particle) nodes.push(particle);
    if (FIELD_PARTICLE_CORE_SHELL && shellCount < FIELD_PARTICLE_SHELL_MAX) {
      const shell = makeParticleCoreShell(candidates[i], requestBbox, shellCount);
      if (shell) {
        nodes.push(shell);
        shellCount += 1;
      }
    }
    if (nodes.length >= FIELD_MAX_DOM_NODES) break;
  }
  appendNodesInChunks(map3DElement, nodes);
  return {
    rendered: candidates.length,
    anchors: sourceSamples.length,
    candidate_count: sourceSamples.length,
    generated_particle_candidates: candidates.length,
    threshold: FIELD_THRESHOLD,
    dom_nodes: nodes.length,
    glow_particles: candidates.length,
    outlines: 0,
    cube_faces: shellCount,
    hot_side_cubes: 0,
    shell_faces: shellCount,
    mode: 'particle-cloud',
  };
}

function renderScalarFieldLite(map3DElement, payload, requestBbox) {
  clearBait3d(map3DElement);
  const sourceSamples = selectRenderableSamples(payload);
  const anchors = FIELD_IMPLICIT_CLUSTER_ENABLED ? buildImplicitClusterAnchors(sourceSamples) : selectLiteAnchors(sourceSamples);
  if (!anchors.length) return { rendered: 0, anchors: 0, candidate_count: sourceSamples.length, threshold: FIELD_THRESHOLD, dom_nodes: 0, glow_particles: 0, outlines: 0, cube_faces: 0, mode: 'adaptive-lite' };
  const nodes = [];
  const counters = { cubes: 0, anchors: 0, faces: 0, outlines: 0, glowParticles: 0, hotSideCubes: 0, nodes: 0 };
  for (const anchor of anchors) {
    if (nodes.length >= FIELD_MAX_DOM_NODES) break;
    counters.nodes = nodes.length;
    const made = makeLiteColumnNodes(anchor, requestBbox, counters);
    for (const node of made) {
      if (nodes.length >= FIELD_MAX_DOM_NODES) break;
      nodes.push(node);
    }
  }
  appendNodesInChunks(map3DElement, nodes);
  return {
    rendered: counters.cubes,
    anchors: counters.anchors,
    candidate_count: sourceSamples.length,
    threshold: FIELD_THRESHOLD,
    dom_nodes: nodes.length,
    glow_particles: counters.glowParticles,
    outlines: counters.outlines,
    cube_faces: counters.faces,
    hot_side_cubes: counters.hotSideCubes,
    mode: 'adaptive-lite',
  };
}

function renderScalarField(map3DElement, payload, requestBbox) {
  clearBait3d(map3DElement);
  const samples = selectRenderableSamples(payload);
  if (!samples.length) return { rendered: 0, candidate_count: 0, threshold: FIELD_THRESHOLD, dom_nodes: 0, glow_particles: 0, outlines: 0, cube_faces: 0 };
  const sortedDepths = Array.from(new Set(samples.map((s) => Math.abs(Number(s.depth_m || 0))).filter(Number.isFinite))).sort((a, b) => a - b);
  const nodes = [];
  const counters = { cubes: 0, faces: 0, outlines: 0, glowParticles: 0, hotSideCubes: 0, nodes: 0 };
  for (const sample of samples) {
    if (nodes.length >= FIELD_MAX_DOM_NODES) break;
    counters.nodes = nodes.length;
    const made = makeCubeNodes(sample, requestBbox, sortedDepths, counters);
    for (const node of made) {
      if (nodes.length >= FIELD_MAX_DOM_NODES) break;
      nodes.push(node);
    }
  }
  appendNodesInChunks(map3DElement, nodes);
  return {
    rendered: counters.cubes,
    candidate_count: samples.length,
    threshold: FIELD_THRESHOLD,
    dom_nodes: nodes.length,
    glow_particles: counters.glowParticles,
    outlines: counters.outlines,
    cube_faces: counters.faces,
    hot_side_cubes: counters.hotSideCubes,
  };
}

export async function renderBait3dLayer({ frame, map3DElement, viewport = null, reason = 'steady' } = {}) {
  if (!ENABLED || !map3DElement) return null;
  const requestBbox = requestBboxForField(viewport, frame || {});
  const payload = await fetchBaitField(requestBbox);
  const result = FIELD_PARTICLE_CLOUD_ENABLED
    ? renderParticleCloud(map3DElement, payload, requestBbox)
    : (FIELD_LITE_ENABLED ? renderScalarFieldLite(map3DElement, payload, requestBbox) : renderScalarField(map3DElement, payload, requestBbox));
  const stats = {
    reason,
    ok: Boolean(payload?.ok),
    source: payload?.source,
    url: payload?.url,
    renderer: FIELD_PARTICLE_CLOUD_ENABLED ? 'bait_probability_harbor_aware_scalar_field_cedar_plug_point_cloud_v1' : (FIELD_LITE_ENABLED ? (FIELD_IMPLICIT_CLUSTER_ENABLED ? 'bait_probability_implicit_voxel_cluster_field_v5' : 'bait_probability_scalar_field_adaptive_lite_glow_contours_v4') : 'bait_probability_scalar_field_true_cube_glyphs_v3_no_sheets'),
    render_mode: result.mode || (FIELD_PARTICLE_CLOUD_ENABLED ? 'particle-cloud' : (FIELD_LITE_ENABLED ? 'adaptive-lite' : 'full-cubes')),
    field_mode: true,
    cube_mode: !FIELD_PARTICLE_CLOUD_ENABLED,
    particle_cloud_mode: FIELD_PARTICLE_CLOUD_ENABLED,
    lite_mode: FIELD_LITE_ENABLED,
    threshold: FIELD_THRESHOLD,
    cube_step_ft: FIELD_CUBE_STEP_FT,
    cube_step_m: Number(FIELD_CUBE_STEP_M.toFixed(3)),
    no_surface_sheets: FIELD_NO_SURFACE_SHEETS,
    draw_top_face: FIELD_DRAW_TOP_FACE,
    draw_all_sides: FIELD_DRAW_ALL_SIDES,
    cube_horizontal_ft: FIELD_CUBE_HORIZONTAL_FT,
    cube_visual_horizontal_scale: FIELD_CUBE_VISUAL_HORIZONTAL_SCALE,
    rendered_particles: FIELD_PARTICLE_CLOUD_ENABLED ? result.rendered : 0,
    rendered_cubes: FIELD_PARTICLE_CLOUD_ENABLED ? 0 : result.rendered,
    rendered_anchors: result.anchors || result.rendered,
    rendered_field_patches: result.anchors || result.rendered,
    rendered_dom_nodes: result.dom_nodes,
    rendered_glow_particles: result.glow_particles,
    rendered_outlines: result.outlines,
    rendered_cube_faces: result.cube_faces,
    candidate_field_samples: result.candidate_count,
    max_rendered_cubes: FIELD_MAX_RENDERED,
    max_lite_anchors: FIELD_LITE_MAX_ANCHORS,
    max_dom_nodes: FIELD_MAX_DOM_NODES,
    max_particles: FIELD_PARTICLE_MAX,
    particle_alpha_threshold: FIELD_THRESHOLD,
    particle_alpha_full_at: FIELD_PARTICLE_ALPHA_FULL_AT,
    field_sample_count: payload?.field_sample_count ?? (Array.isArray(payload?.field_samples) ? payload.field_samples.length : null),
    field_render_policy: payload?.field_render_policy || null,
    bbox: requestBbox,
    bbox_padding: { base: FIELD_BBOX_PAD, tilt_gain: FIELD_BBOX_TILT_PAD_GAIN },
    depths_m: payload?.depths_m || [],
    shape: payload?.shape || [0, 0],
    rtofs_3d: payload?.rtofs_3d || null,
    rtofs_surface: payload?.rtofs_surface || null,
    ocean_truth: payload?.ocean_truth || null,
    chlorophyll: payload?.ocean_truth?.chlorophyll || null,
    palette: '4 inch ellipse bait sprite: silver top, white bottom, narrow black outline, cedar-plug painted eye; body unscaled, glow-only visibility',
    opacity_policy: FIELD_PARTICLE_CLOUD_ENABLED ? '80% bait probability is the alpha threshold; the 4 inch ellipse body is not scaled up; only the glow halo grows with probability' : 'transparent only near threshold; hot cells become mostly opaque/glowing',
    geometry_policy: FIELD_PARTICLE_CLOUD_ENABLED ? 'one harbor-aware continuous B(lat, lon, depth) scalar field rendered as a top-20% underwater cedar-plug ellipse point-cloud mass; 4 inch bait bodies remain unscaled and glow-only visibility carries the cloud' : (FIELD_LITE_ENABLED ? (FIELD_IMPLICIT_CLUSTER_ENABLED ? 'formula-driven implicit voxel clusters: thresholded scalar samples are aggregated into elongated sideways cluster prisms with cube-like contour segmentation and glow, so bait can read like 400ft-long schools without building every cube from the ground up' : 'adaptive-lite renderer aggregates hot depth cells into glowing contour anchors; preserves cube/outline style without drawing every 10 ft cube') : 'thresholded scalar samples render as true cube glyphs; no source-bbox surface sheets; all threshold cubes get side faces plus cube-edge outlines within DOM budget'),
    altitude_policy: FIELD_PARTICLE_CLOUD_ENABLED ? 'true depth is preserved on every particle; visual altitude = -clamp(depth*scale), so the cloud reads below the lifted ocean mask without becoming sheets' : 'true depth is preserved; visual altitude = -clamp(depth*scale); adaptive-lite anchors represent the local hot vertical bait stack',
    performance_policy: FIELD_PARTICLE_CLOUD_ENABLED ? 'default bait view renders one top-20% particle cloud from /gfs/api/bait-field-cloud; each ellipse body uses a fixed 4 inch semantic size with no probability body scale, and only the halo glow scales; full cube/cluster renderers stay available by setting GFS_BAIT_FIELD_RENDER_MODE to adaptive-lite or full-cubes' : (FIELD_LITE_ENABLED ? (FIELD_IMPLICIT_CLUSTER_ENABLED ? 'default global viewport budget stays light by rendering formula-driven cluster anchors instead of every 10ft voxel; about 760 clusters and about 6200 DOM nodes by default' : 'default global viewport budget stays light: about 950 anchors and about 6200 DOM nodes; full cubes opt-in with window.GFS_BAIT_FIELD_RENDER_MODE="full-cubes"') : 'budgeted DOM renderer; top faces disabled by default; raise max_rendered/max_dom_nodes toward 20000 cubes on powerful clients'),
    legacy_surface_bait: 'disabled by index.js when bait-3d is active',
    policy: FIELD_PARTICLE_CLOUD_ENABLED ? 'Bait pill renders one harbor-aware thresholded scalar-field point-cloud mass. 80% probability is the default alpha/visibility threshold; below-threshold field is hidden; boats stay on the Boats pill; cube/prism modes remain opt-in.' : 'Bait pill renders field mode only. Default lite mode uses formula-driven implicit voxel clusters with glow and cube-like contour lines; boats stay on the Boats pill; the bait request bbox is slightly padded for tilted/angled views.',
  };
  try {
    window.__gfsBait3dVolume = payload;
    window.__gfsBait3dStats = stats;
    window.__gfsBaitFieldStats = stats;
    window.__gfsDebugEvent?.(FIELD_PARTICLE_CLOUD_ENABLED ? 'bait-field/particle-cloud-rendered' : 'bait-field/contoured-cubes-rendered', stats);
  } catch (_) {}
  console.info('[gfs bait-field] scalar bait field rendered', stats);
  const disposer = () => clearBait3d(map3DElement);
  disposer.__gfsKeepExisting = true;
  disposer.__gfsDidRender = result.rendered > 0;
  return disposer;
}

export function clearBait3dLayer(map3DElement) {
  clearBait3d(map3DElement);
}

import { renderBaitZones } from '../gfs/bait-zones.js';
import { annotateOceanRenderPayload, baitRowsFromPayload, countPolygons, finiteNumber, oceanPointsFromPayload, pickLayer } from './scene-frame-utils.js';

const FALLBACK_MAX_BAIT_POINTS = Number(window.GFS_BAIT_POINT_FALLBACK_MAX || 260);
const FALLBACK_SELECTOR = '[data-gfs-layer="bait"][data-bait-renderer="scene-frame-point-cloud"],[data-gfs-layer="bait"][data-bait-renderer="scene-frame-visibility-beacon"]';
const BAIT_SUBSURFACE_MODE = String(window.GFS_BAIT_SUBSURFACE_MODE ?? '1') !== '0';


function viewportCenter(viewport = null) {
  const lat = finiteNumber(viewport?.camera?.center?.lat ?? viewport?.center?.lat, null);
  const lon = finiteNumber(viewport?.camera?.center?.lon ?? viewport?.camera?.center?.lng ?? viewport?.center?.lon ?? viewport?.center?.lng, null);
  if (Number.isFinite(lat) && Number.isFinite(lon)) return { lat, lon };
  const west = finiteNumber(viewport?.west, null);
  const east = finiteNumber(viewport?.east, null);
  const south = finiteNumber(viewport?.south, null);
  const north = finiteNumber(viewport?.north, null);
  if ([west, east, south, north].every(Number.isFinite)) return { lat: (south + north) / 2, lon: (west + east) / 2 };
  return null;
}

function geoDistance2(a, b) {
  if (!a || !b) return Infinity;
  const meanLat = ((Number(a.lat) + Number(b.lat)) * 0.5) * Math.PI / 180;
  const dx = (Number(a.lon) - Number(b.lon)) * Math.max(0.25, Math.cos(meanLat));
  const dy = Number(a.lat) - Number(b.lat);
  return dx * dx + dy * dy;
}

function pickPayload(frameOrPayload, viewport = null) {
  const bait = pickLayer(frameOrPayload, 'bait') || frameOrPayload?.baitAdvanced || frameOrPayload?.bait || frameOrPayload;
  if (!bait || typeof bait !== 'object') return null;
  return annotateOceanRenderPayload(bait, {
    viewport,
    fallbackBbox: frameOrPayload?.bbox || frameOrPayload?.visible_bbox || bait?.bbox || bait?.oceanPoints?.bbox,
  });
}

function drawableRows(payload = {}) {
  const rows = baitRowsFromPayload(payload);
  if (rows.length) return rows;
  return oceanPointsFromPayload(payload)
    .filter((p) => Number.isFinite(Number(p?.probability ?? p?.bait_probability ?? p?.score ?? p?.sst ?? p?.sst_c)))
    .map((p) => ({ ...p, probability: p.probability ?? p.bait_probability ?? p.score ?? 0.18, renderer: 'ocean_point_sst_bait_hint' }));
}

function rowLatLon(row) {
  const lat = finiteNumber(row?.lat ?? row?.latitude ?? row?.position?.lat, null);
  const lon = finiteNumber(row?.lon ?? row?.lng ?? row?.longitude ?? row?.position?.lng ?? row?.position?.lon, null);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  if (lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
  return { lat, lon };
}

function clamp01(v, fallback = 0) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.min(1, n > 1 ? n / 100 : n));
}

function baitColor(prob, index = 0) {
  const p = clamp01(prob, 0.2);
  const palette = ['#00f5ff', '#39ff14', '#fff200', '#ff7a00', '#ff2bd6'];
  return palette[Math.max(0, Math.min(palette.length - 1, Math.floor(p * palette.length + index * 0.17) % palette.length))];
}

function fallbackDepthMeters(row, probability = 0.2, index = 0) {
  const depthFt = finiteNumber(row?.bait_depth_ft ?? row?.preferred_bait_depth_ft ?? row?.preferred_depth_ft ?? row?.depth_ft, NaN);
  if (Number.isFinite(depthFt) && depthFt > 0) return Math.max(2.5, Math.min(140, depthFt * 0.3048));
  const depthM = 5 + clamp01(probability, 0.2) * 34 + (index % 11) * 1.6;
  return Math.max(4, Math.min(65, depthM));
}

function makeBaitTemplate({ probability, depthFt, index }) {
  const p = clamp01(probability, 0.2);
  const color = baitColor(p, index);
  const size = Math.round(14 + p * 20);
  const opacity = Math.max(0.24, Math.min(0.82, 0.22 + p * 0.64));
  const uid = `lftr-bait-fallback-${Math.random().toString(16).slice(2)}`;
  const tpl = document.createElement('template');
  tpl.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="overflow:visible;pointer-events:none;filter:drop-shadow(0 0 ${Math.round(4 + p * 7)}px ${color})">
    <defs><radialGradient id="${uid}" cx="45%" cy="35%" r="72%"><stop offset="0%" stop-color="#fff" stop-opacity="0.72"/><stop offset="52%" stop-color="${color}" stop-opacity="${opacity.toFixed(2)}"/><stop offset="100%" stop-color="${color}" stop-opacity="0"/></radialGradient></defs>
    <ellipse cx="12" cy="12" rx="10" ry="6" fill="url(#${uid})" transform="rotate(${Math.round((index * 47) % 180)} 12 12)"/>
    <circle cx="12" cy="12" r="2.4" fill="#fff" fill-opacity="${Math.min(0.58, opacity).toFixed(2)}"/>
  </svg>`;
  try { tpl.content?.firstElementChild?.setAttribute?.('data-bait-depth-ft', Number.isFinite(depthFt) ? String(Math.round(depthFt)) : ''); } catch (_) {}
  return tpl;
}

function clearFallbackBaitMarkers(map3DElement) {
  try { map3DElement?.querySelectorAll?.(FALLBACK_SELECTOR)?.forEach((el) => el.remove()); } catch (_) {}
}

function renderFallbackBaitPointCloud({ payload, map3DElement, viewport = null, maxPoints = FALLBACK_MAX_BAIT_POINTS, beaconMode = false }) {
  const rows = drawableRows(payload);
  if (!map3DElement || !rows.length) return null;
  clearFallbackBaitMarkers(map3DElement);
  const center = viewportCenter(viewport);
  const selected = rows
    .map((row, index) => ({ row, index, ll: rowLatLon(row), p: clamp01(row?.probability ?? row?.bait_probability ?? row?.score, 0.18) }))
    .filter((x) => x.ll)
    .sort((a, b) => {
      const da = center ? geoDistance2(a.ll, center) : 0;
      const db = center ? geoDistance2(b.ll, center) : 0;
      return da - db || b.p - a.p;
    })
    .slice(0, maxPoints);
  if (!selected.length) return null;
  const frag = document.createDocumentFragment();
  selected.forEach(({ row, index, ll, p }) => {
    const depthFt = finiteNumber(row?.bait_depth_ft ?? row?.preferred_bait_depth_ft ?? row?.preferred_depth_ft ?? row?.depth_ft, NaN);
    const marker = document.createElement('gmp-marker-3d');
    const depthM = fallbackDepthMeters(row, p, index);
    const altitude = BAIT_SUBSURFACE_MODE ? -depthM : (beaconMode ? Math.max(90, Math.min(220, 120 + p * 90)) : Math.max(4, Math.min(95, 8 + p * 52)));
    marker.position = { lat: ll.lat, lng: ll.lon, altitude };
    marker.drawsWhenOccluded = true;
    try { marker.altitudeMode = window.google?.maps?.maps3d?.AltitudeMode?.ABSOLUTE || 'ABSOLUTE'; } catch (_) {}
    marker.sizePreserved = true;
    marker.setAttribute('position', `${ll.lat},${ll.lon},${altitude.toFixed(2)}`);
    marker.setAttribute('altitude-mode', 'absolute');
    marker.setAttribute('draws-when-occluded', 'true');
    marker.setAttribute('draws-occluded-segments', 'true');
    marker.setAttribute('data-gfs-layer', 'bait');
    marker.setAttribute('data-bait-renderer', beaconMode ? 'scene-frame-visibility-beacon' : 'scene-frame-point-cloud');
    marker.setAttribute('data-bait-altitude-m', altitude.toFixed(1));
    marker.setAttribute('data-bait-depth-m', depthM.toFixed(1));
    marker.setAttribute('data-bait-probability', String(Math.round(p * 100)));
    if (Number.isFinite(depthFt)) marker.setAttribute('data-bait-depth-ft', String(Math.round(depthFt)));
    marker.title = `Bait probability ${Math.round(p * 100)}%${Number.isFinite(depthFt) ? ` • ${Math.round(depthFt)} ft` : ''}`;
    marker.append(makeBaitTemplate({ probability: p, depthFt, index }));
    frag.append(marker);
  });
  map3DElement.append(frag);
  try { window.__gfsBaitBeaconStats = { rows: rows.length, rendered: selected.length, source: payload?.source, center, beaconMode }; window.__gfsDebugEvent?.('bait/point-cloud-fallback', window.__gfsBaitBeaconStats); } catch (_) {}
  const disposer = () => clearFallbackBaitMarkers(map3DElement);
  disposer.__gfsKeepExisting = true;
  disposer.__gfsDidRender = true;
  return disposer;
}

export function hasBaitContent(frameOrPayload) {
  const payload = pickPayload(frameOrPayload);
  return Boolean(payload && (countPolygons(payload) > 0 || drawableRows(payload).length > 0));
}

export async function renderBaitLayer({ payload, frame, map3DElement, viewport = null, reason = 'steady' } = {}) {
  const baitPayload = pickPayload(payload || frame, viewport);
  if (!baitPayload) return null;
  if (countPolygons(baitPayload) > 0) {
    const disposers = [];
    try {
      const zoneDispose = renderBaitZones({ payload: baitPayload, map3DElement, viewportReason: reason === 'boot' ? 'steady' : reason });
      if (typeof zoneDispose === 'function') disposers.push(zoneDispose);
    } catch (err) {
      console.warn('[gfs clean bait] polygon renderer failed; point beacons continue', err);
    }
    try {
      const beaconDispose = renderFallbackBaitPointCloud({ payload: baitPayload, map3DElement, viewport, maxPoints: Math.min(96, FALLBACK_MAX_BAIT_POINTS), beaconMode: true });
      if (typeof beaconDispose === 'function') disposers.push(beaconDispose);
    } catch (err) {
      console.warn('[gfs clean bait] point beacon renderer failed; globe continues', err);
    }
    const disposer = () => disposers.reverse().forEach((dispose) => { try { dispose(); } catch (_) {} });
    disposer.__gfsKeepExisting = true;
    disposer.__gfsDidRender = disposers.some((dispose) => dispose?.__gfsDidRender !== false);
    return disposer;
  }
  return renderFallbackBaitPointCloud({ payload: baitPayload, map3DElement, viewport });
}

export function clearBaitLayer(map3DElement) {
  try { window.clearGfsBaitLayer?.(); } catch (_) {}
  clearFallbackBaitMarkers(map3DElement);
  try { map3DElement?.querySelectorAll?.('[data-gfs-layer="bait"],[data-bait-zone]')?.forEach((el) => el.remove()); } catch (_) {}
}

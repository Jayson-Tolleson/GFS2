import { renderCurrentZonesLayer } from '../gfs/current-zones.js';
import { renderBoatsLayer, clearBoatRenderState } from '../gfs/boats.js';
import { annotateOceanRenderPayload, oceanPointsFromPayload, pickLayer, finiteNumber, bboxFromViewport } from './scene-frame-utils.js';

const BOAT_BEACON_SELECTOR = '[data-gfs-sub-layer="boater-visibility-beacon"]';
const BOAT_BEACON_ENABLED = window.GFS_BOAT_VISIBILITY_BEACON_ENABLED === true || String(window.GFS_BOAT_VISIBILITY_BEACON_ENABLED || '').toLowerCase() === 'true' || String(window.GFS_BOAT_VISIBILITY_BEACON_ENABLED || '') === '1';
const BOAT_BEACON_MAX = BOAT_BEACON_ENABLED ? Number(window.GFS_BOAT_VISIBILITY_BEACON_MAX || 12) : 0;
const BOAT_CURRENT_ZONES_ENABLED = window.GFS_BOAT_CURRENT_ZONES_ENABLED === true || String(window.GFS_BOAT_CURRENT_ZONES_ENABLED || '').toLowerCase() === 'true' || String(window.GFS_BOAT_CURRENT_ZONES_ENABLED || '') === '1';

function normalizeLon(lon) {
  const n = Number(lon);
  if (!Number.isFinite(n)) return 0;
  return ((n + 180) % 360 + 360) % 360 - 180;
}

function bboxQuery(bbox) {
  return [bbox.west, bbox.south, bbox.east, bbox.north].map((x) => Number(x).toFixed(5)).join(',');
}

function marineViewportBbox(viewport = null, frameOrPayload = null) {
  const b = bboxFromViewport(viewport, frameOrPayload?.visible_bbox || frameOrPayload?.bbox || frameOrPayload?.bbox_object);
  if (b) return { west: normalizeLon(b.west), south: Number(b.south), east: normalizeLon(b.east), north: Number(b.north) };
  return null;
}

async function fetchOceanTruthBoatPayload(viewport = null, frameOrPayload = null) {
  const bbox = marineViewportBbox(viewport, frameOrPayload);
  if (!bbox) return null;
  const url = `/gfs/api/ocean-truth?bbox=${encodeURIComponent(bboxQuery(bbox))}&products=boats,ocean&max_samples=${encodeURIComponent(Number(window.GFS_OCEAN_TRUTH_BOAT_SAMPLES || 1400))}&grid=${encodeURIComponent(Number(window.GFS_OCEAN_TRUTH_GRID || 16))}&chlorophyll=off`;
  try {
    const res = await fetch(url, { cache: 'default' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const truth = await res.json();
    const boatProduct = truth?.products?.boats || {};
    const payload = annotateOceanRenderPayload({
      ...boatProduct,
      ok: boatProduct?.ok ?? truth?.ok,
      source: boatProduct?.source || truth?.source || 'lftr_ocean_truth_boat_payload',
      bbox: truth?.bbox || bbox,
      bbox_object: truth?.bbox || bbox,
      oceanTruth: truth,
      oceanPoints: boatProduct?.oceanPoints || truth?.oceanPoints || { points: truth?.samples || [], count: truth?.sample_count || 0, source: truth?.source, bbox: truth?.bbox || bbox },
      points: boatProduct?.points || truth?.samples || [],
      landmask_contract: boatProduct?.landmask_contract || 'ocean_truth_ocean_connected_bathymetry_plus_rtofs_sst_mask',
      source_meta: boatProduct?.source_meta || { sst_landmask: { method: 'ocean_truth_ocean_connected_bathymetry_plus_rtofs_sst_mask', water_cells: truth?.sample_count || 0 } },
      sst_landmask: boatProduct?.sst_landmask || { method: 'ocean_truth_ocean_connected_bathymetry_plus_rtofs_sst_mask', water_cells: truth?.sample_count || 0 },
    }, { viewport, fallbackBbox: truth?.bbox || bbox });
    payload.__oceanTruthFetched = { url, sample_count: truth?.sample_count || 0, rtofs_surface: truth?.rtofs_surface || null, query_contract: truth?.query_contract || null };
    return payload;
  } catch (err) {
    console.warn('[gfs clean boats] ocean-truth boat fetch failed', err);
    return null;
  }
}

function needsOceanTruthBoatPayload(payload) {
  if (!payload) return true;
  const n = oceanPointsFromPayload(payload).length;
  const min = Number(window.GFS_BOAT_MIN_OCEAN_POINTS || 48);
  return n < min || String(payload?.source || '').includes('scene_cache_empty') || String(payload?.status || '').toLowerCase().includes('warming');
}

function clearBoatVisibilityBeacons(map3DElement) {
  try { map3DElement?.querySelectorAll?.(BOAT_BEACON_SELECTOR)?.forEach((el) => el.remove()); } catch (_) {}
}

function viewportCenter(viewport = null) {
  const lat = finiteNumber(viewport?.camera?.center?.lat ?? viewport?.center?.lat, null);
  const lon = finiteNumber(viewport?.camera?.center?.lon ?? viewport?.camera?.center?.lng ?? viewport?.center?.lon ?? viewport?.center?.lng, null);
  if (Number.isFinite(lat) && Number.isFinite(lon)) return { lat, lon };
  const west = finiteNumber(viewport?.west, null);
  const east = finiteNumber(viewport?.east, null);
  const south = finiteNumber(viewport?.south, null);
  const north = finiteNumber(viewport?.north, null);
  if ([west, east, south, north].every(Number.isFinite)) return { lat: (south + north) / 2, lon: (west + east) / 2 };
  return null;
}

function rowLatLon(row) {
  const lat = finiteNumber(row?.lat ?? row?.position?.lat, null);
  const lon = finiteNumber(row?.lon ?? row?.lng ?? row?.longitude ?? row?.position?.lng ?? row?.position?.lon, null);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
  return { lat, lon };
}

function rowCurrentKt(row) {
  return finiteNumber(row?.current?.speedKt ?? row?.current_speed_kt ?? row?.speedKt ?? row?.speed_kt, 0) || 0;
}

function rowHeading(row) {
  const n = finiteNumber(row?.current?.dirDeg ?? row?.current_dir_deg ?? row?.direction_deg ?? row?.headingDeg ?? row?.heading, 0) || 0;
  return ((n % 360) + 360) % 360;
}

function rowWaterTempF(row) {
  return finiteNumber(row?.water?.sst_f ?? row?.water?.tempF ?? row?.water_temp_f ?? row?.sst_f, null);
}

function geoDistance2(a, b) {
  if (!a || !b) return Infinity;
  const meanLat = ((Number(a.lat) + Number(b.lat)) * 0.5) * Math.PI / 180;
  const dx = (Number(a.lon) - Number(b.lon)) * Math.max(0.25, Math.cos(meanLat));
  const dy = Number(a.lat) - Number(b.lat);
  return dx * dx + dy * dy;
}

function makeBoatBeaconTemplate(row, index) {
  const speed = rowCurrentKt(row);
  const tempF = rowWaterTempF(row);
  const hue = speed >= 1.1 ? '#ff5f57' : (speed >= 0.45 ? '#ffd866' : '#57d46f');
  const heading = rowHeading(row);
  const label = Number.isFinite(tempF) ? `${Math.round(tempF)}°F` : `${speed.toFixed(1)}kt`;
  const uid = `boat-beacon-${Date.now().toString(36)}-${index}`;
  const tpl = document.createElement('template');
  tpl.innerHTML = `<svg width="132" height="132" viewBox="0 0 132 132" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="overflow:visible;pointer-events:none;filter:drop-shadow(0 0 12px ${hue})">
    <defs><radialGradient id="${uid}" cx="50%" cy="50%" r="62%"><stop offset="0%" stop-color="#ffffff" stop-opacity="0.92"/><stop offset="38%" stop-color="${hue}" stop-opacity="0.74"/><stop offset="100%" stop-color="${hue}" stop-opacity="0"/></radialGradient></defs>
    <circle cx="66" cy="66" r="44" fill="url(#${uid})" opacity="0.82"/>
    <g transform="rotate(${heading} 66 66)">
      <path d="M66 18 C82 43 92 72 82 101 C75 112 57 112 50 101 C40 72 50 43 66 18 Z" fill="#faffff" stroke="${hue}" stroke-width="7"/>
      <path d="M66 29 L77 91 L66 103 L55 91 Z" fill="${hue}" fill-opacity="0.44"/>
      <circle cx="66" cy="58" r="8" fill="#062033" fill-opacity="0.82"/>
    </g>
    <rect x="34" y="104" width="64" height="18" rx="9" fill="#071827" fill-opacity="0.78" stroke="${hue}" stroke-opacity="0.8"/>
    <text x="66" y="118" fill="#ffffff" font-size="12" font-family="Arial, sans-serif" font-weight="700" text-anchor="middle">${label}</text>
  </svg>`;
  return tpl;
}

function candidateRows(payload) {
  const boats = Array.isArray(payload?.boats) ? payload.boats : [];
  if (boats.length) return boats;
  return oceanPointsFromPayload(payload);
}

function renderBoatVisibilityBeacons({ payload, map3DElement, viewport = null }) {
  if (!map3DElement || !payload) return null;
  clearBoatVisibilityBeacons(map3DElement);
  if (!BOAT_BEACON_ENABLED || BOAT_BEACON_MAX <= 0) {
    const stats = { enabled: false, rendered: 0, mode: 'disabled_single_projection_boats' };
    try { window.__gfsBoaterBeaconStats = stats; } catch (_) {}
    return null;
  }
  const center = viewportCenter(viewport);
  const rows = candidateRows(payload)
    .map((row, index) => ({ row, index, ll: rowLatLon(row) }))
    .filter((x) => x.ll)
    .sort((a, b) => {
      const da = center ? geoDistance2(a.ll, center) : a.index;
      const db = center ? geoDistance2(b.ll, center) : b.index;
      return da - db || rowCurrentKt(b.row) - rowCurrentKt(a.row);
    })
    .slice(0, BOAT_BEACON_MAX);
  if (!rows.length) return null;
  const frag = document.createDocumentFragment();
  rows.forEach(({ row, index, ll }) => {
    const marker = document.createElement('gmp-marker-3d');
    marker.position = { lat: ll.lat, lng: ll.lon, altitude: 185 };
    marker.drawsWhenOccluded = true;
    marker.sizePreserved = true;
    try { marker.altitudeMode = window.google?.maps?.maps3d?.AltitudeMode?.RELATIVE_TO_GROUND || 'RELATIVE_TO_GROUND'; } catch (_) {}
    marker.setAttribute('position', `${ll.lat},${ll.lon},185`);
    marker.setAttribute('data-gfs-layer', 'boater');
    marker.setAttribute('data-gfs-sub-layer', 'boater-visibility-beacon');
    marker.setAttribute('data-boater-beacon', 'true');
    marker.title = `Boat/current beacon • ${rowCurrentKt(row).toFixed(2)} kt${Number.isFinite(rowWaterTempF(row)) ? ` • ${Math.round(rowWaterTempF(row))}°F` : ''}`;
    marker.append(makeBoatBeaconTemplate(row, index));
    frag.append(marker);
  });
  map3DElement.append(frag);
  const stats = { requested: candidateRows(payload).length, rendered: rows.length, center, source: payload?.source || payload?.oceanPoints?.source || 'scene_frame_boater', mode: 'visible_marker_beacons' };
  try { window.__gfsBoaterBeaconStats = stats; window.__gfsDebugEvent?.('boats/visibility-beacons', stats); } catch (_) {}
  console.info('[gfs clean boats] visibility beacons rendered', stats);
  const disposer = () => clearBoatVisibilityBeacons(map3DElement);
  disposer.__gfsKeepExisting = true;
  disposer.__gfsDidRender = rows.length > 0;
  return disposer;
}

function pickPayload(frameOrPayload, viewport = null) {
  const layers = frameOrPayload?.layers || {};
  const boatsPayload = pickLayer(frameOrPayload, 'boater', 'boats') || null;
  const ocean = layers.ocean || frameOrPayload?.ocean || null;
  const oceanPointsLayer = layers.oceanPoints || frameOrPayload?.oceanPoints || null;
  if (!boatsPayload && !ocean && !oceanPointsLayer) return null;

  const merged = {
    ...(ocean || {}),
    ...(boatsPayload || {}),
  };

  const points = oceanPointsFromPayload(boatsPayload || {}).length
    ? oceanPointsFromPayload(boatsPayload)
    : (oceanPointsFromPayload(ocean || {}).length ? oceanPointsFromPayload(ocean) : oceanPointsFromPayload(oceanPointsLayer || {}));

  if (points.length && !merged.oceanPoints?.points) {
    merged.oceanPoints = { ...(merged.oceanPoints || {}), points, count: points.length, source: merged.source || 'scene_frame_ocean_points' };
  }

  const boats = Array.isArray(boatsPayload?.boats) ? boatsPayload.boats : (Array.isArray(ocean?.boats) ? ocean.boats : []);
  const annotated = annotateOceanRenderPayload({ ...merged, boats, ocean, oceanPoints: merged.oceanPoints || oceanPointsLayer, boatsPayload }, {
    viewport,
    fallbackBbox: frameOrPayload?.bbox || frameOrPayload?.visible_bbox || boatsPayload?.bbox || ocean?.bbox,
  });
  return annotated;
}

export async function renderBoatsSceneLayer({ payload, frame, map3DElement, viewport = null, reason = 'steady' } = {}) {
  let boatPayload = pickPayload(payload || frame, viewport);
  if (needsOceanTruthBoatPayload(boatPayload)) {
    const truthPayload = await fetchOceanTruthBoatPayload(viewport, payload || frame);
    if (truthPayload && oceanPointsFromPayload(truthPayload).length >= oceanPointsFromPayload(boatPayload || {}).length) {
      boatPayload = truthPayload;
    }
  }
  if (!boatPayload) return null;
  const disposers = [];
  if (BOAT_CURRENT_ZONES_ENABLED) {
    try {
      const disposeCurrent = renderCurrentZonesLayer({ payload: boatPayload, map3DElement, viewportReason: reason === 'boot' ? 'steady' : reason });
      if (typeof disposeCurrent === 'function') disposers.push(disposeCurrent);
    } catch (err) {
      console.warn('[gfs clean boats] current contour renderer failed; boat models continue', err);
    }
  } else {
    try { window.clearGfsCurrentLayer?.(); } catch (_) {}
  }
  try {
    const disposeBoats = renderBoatsLayer({ payload: boatPayload, map3DElement });
    if (typeof disposeBoats === 'function') disposers.push(disposeBoats);
  } catch (err) {
    console.warn('[gfs clean boats] boat renderer failed; globe continues', err);
  }
  try {
    const disposeBeacons = renderBoatVisibilityBeacons({ payload: boatPayload, map3DElement, viewport });
    if (typeof disposeBeacons === 'function') disposers.push(disposeBeacons);
  } catch (err) {
    console.warn('[gfs clean boats] visibility beacon renderer failed; globe continues', err);
  }
  const disposer = () => disposers.reverse().forEach((dispose) => { try { dispose(); } catch (_) {} });
  disposer.__gfsKeepExisting = true;
  disposer.__gfsDidRender = disposers.some((dispose) => dispose?.__gfsDidRender !== false);
  return disposer;
}

export function clearBoatsSceneLayer(map3DElement) {
  try { clearBoatRenderState?.(); } catch (_) {}
  try { window.clearGfsBoatsLayer?.(); } catch (_) {}
  try { window.clearGfsCurrentLayer?.(); } catch (_) {}
  clearBoatVisibilityBeacons(map3DElement);
  try { map3DElement?.querySelectorAll?.('[data-gfs-layer="boater"],[data-gfs-layer="boats"],[data-gfs-layer="current"],[data-gfs-layer="current-zones"]')?.forEach((el) => el.remove()); } catch (_) {}
}

import { renderCloudZones, cloudPayloadHasDrawableContent } from '../gfs/cloud-zones.js';
import { pickLayer } from './scene-frame-utils.js';

function pickPayload(frameOrPayload) {
  const clouds = pickLayer(frameOrPayload, 'clouds') || frameOrPayload?.clouds || frameOrPayload;
  if (!clouds || typeof clouds !== 'object') return null;
  return {
    ...clouds,
    fields: clouds.fields || frameOrPayload?.weather?.fields || frameOrPayload?.fields || {},
    bbox: clouds.bbox || clouds.bbox_used || frameOrPayload?.bbox || frameOrPayload?.visible_bbox,
    bbox_used: clouds.bbox_used || clouds.bbox || frameOrPayload?.bbox || frameOrPayload?.visible_bbox,
  };
}

export function hasCloudContent(frameOrPayload) {
  const payload = pickPayload(frameOrPayload);
  return Boolean(payload && cloudPayloadHasDrawableContent(payload));
}

export async function renderCloudsLayer({ payload, frame, map3DElement } = {}) {
  const cloudPayload = pickPayload(payload || frame);
  if (!cloudPayload || !cloudPayloadHasDrawableContent(cloudPayload)) return null;
  return renderCloudZones({ payload: cloudPayload, map3DElement });
}

export function clearCloudsLayer(map3DElement) {
  try { window.clearGfsCloudLayer?.(); } catch (_) {}
  try { map3DElement?.querySelectorAll?.('[data-gfs-layer="clouds"],[data-cloud-shell],[data-cloud-particle]')?.forEach((el) => el.remove()); } catch (_) {}
}

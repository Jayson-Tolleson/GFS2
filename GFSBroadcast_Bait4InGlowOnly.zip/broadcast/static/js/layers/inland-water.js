import { renderInlandWaterLayer } from '../gfs/inland-water.js';
import { pickLayer } from './scene-frame-utils.js';

function pickPayload(frameOrPayload) {
  const layers = frameOrPayload?.layers || {};
  const water = pickLayer(frameOrPayload, 'inland-water', 'inland_water', 'inland_waterways') || frameOrPayload?.inlandWater || frameOrPayload;
  if (!water || typeof water !== 'object') return null;
  return {
    ...water,
    conditions: water.conditions || layers.inland_conditions || frameOrPayload?.inlandConditions || null,
    bait: water.bait || layers.inland_bait || frameOrPayload?.inlandBait || null,
    temp: water.temp || layers.inland_water_temp || layers.inlandTemp || frameOrPayload?.inlandWaterTemp || null,
  };
}

function drawableCount(payload) {
  return [payload?.polygons, payload?.lines, payload?.features, payload?.temperature_points, payload?.temp_points]
    .reduce((sum, value) => sum + (Array.isArray(value) ? value.length : 0), 0);
}

export async function renderInlandWaterSceneLayer({ payload, frame, map3DElement } = {}) {
  const inlandPayload = pickPayload(payload || frame);
  if (!inlandPayload || drawableCount(inlandPayload) <= 0) return null;
  return renderInlandWaterLayer({ payload: inlandPayload, map3DElement });
}

export function clearInlandWaterSceneLayer(map3DElement) {
  try { window.clearGfsInlandWaterLayer?.(); } catch (_) {}
  try { map3DElement?.querySelectorAll?.('[data-gfs-layer="inland-water"],[data-inland-water]')?.forEach((el) => el.remove()); } catch (_) {}
}

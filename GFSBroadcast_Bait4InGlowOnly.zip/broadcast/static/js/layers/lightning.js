import { renderLighteningLayer, clearLighteningLayer } from '../gfs/lightening.js';
import { firstArray, pickLayer } from './scene-frame-utils.js';

function pickPayload(frameOrPayload) {
  const layers = frameOrPayload?.layers || {};
  const direct = pickLayer(frameOrPayload, 'lightning', 'lightening') || frameOrPayload?.lightning || frameOrPayload?.lightening || null;
  const clouds = layers.clouds || frameOrPayload?.clouds || null;
  const cloudEvents = firstArray(clouds?.lightning_events, clouds?.lightning?.events, clouds?.lightning?.flashes, clouds?.lightning, clouds?.hail?.lightning_events);
  if (direct && typeof direct === 'object') {
    const directRows = firstArray(direct.flashes, direct.items, direct.events, direct.features, direct.regions, direct.clusters);
    if (directRows.length) return direct;
  }
  if (cloudEvents.length) {
    return {
      ok: true,
      status: 'ok',
      source: clouds?.source ? `${clouds.source}_lightning_events` : 'scene_frame_cloud_lightning_events',
      items: cloudEvents,
      event_ttl_seconds: 120,
      scene_frame_bridge: 'cloud_payload_lightning_events',
    };
  }
  return direct || null;
}

function isRealEnough(payload) {
  if (!payload || typeof payload !== 'object') return false;
  if (payload.heuristic === true || payload.mock === true || payload.proxy === true || payload.fallback_used === true) return false;
  return firstArray(payload.flashes, payload.regions, payload.items, payload.events, payload.features, payload.clusters).length > 0;
}

export async function renderLightningLayer({ payload, frame, map3DElement } = {}) {
  const lightningPayload = pickPayload(payload || frame);
  if (!isRealEnough(lightningPayload)) return null;
  return renderLighteningLayer({ payload: lightningPayload, map3DElement });
}

export function clearLightningLayer(map3DElement) {
  try { clearLighteningLayer(map3DElement); } catch (_) {}
  try { map3DElement?.querySelectorAll?.('[data-gfs-layer="lightning"],[data-gfs-layer="lightening"]')?.forEach((el) => el.remove()); } catch (_) {}
}

import { bboxFromViewport, baitRowsFromPayload, finiteNumber, oceanPointsFromPayload, pickLayer } from './scene-frame-utils.js';

const OCEAN_GLASS_SELECTOR = '[data-gfs-layer="ocean-glass"]';
const DEFAULT_VOLUME_DEPTH_M = Number(window.GFS_OCEAN_GLASS_DEPTH_M || 90);
const MAX_VOLUME_DEPTH_M = Number(window.GFS_OCEAN_GLASS_MAX_DEPTH_M || 9000);
const MIN_VOLUME_DEPTH_M = Number(window.GFS_OCEAN_GLASS_MIN_DEPTH_M || 18);
const DRAW_FLOOR = String(window.GFS_OCEAN_GLASS_FLOOR ?? '1') !== '0';
// Default OFF for the no-glass cutout pass: keep the bathymetry cavity,
// rim lines, floor cells, and vertical edges, but do not place a glass
// surface polygon at altitude 0. Set window.GFS_OCEAN_CUTOUT_DRAW_SURFACE='1'
// before this module loads to temporarily restore the old glass skin.
const DRAW_SURFACE = String(window.GFS_OCEAN_CUTOUT_DRAW_SURFACE ?? window.GFS_OCEAN_GLASS_DRAW_SURFACE ?? '0') !== '0';
// Cutout construction walls/frames are debug-only now.  The standard view should read as seabed, not window panes.
const DRAW_WALLS = String(window.GFS_OCEAN_GLASS_WALLS ?? window.GFS_OCEAN_CUTOUT_WALLS ?? '0') !== '0';
const FRONT_WALL_OPEN = String(window.GFS_OCEAN_GLASS_FRONT_OPEN ?? '1') !== '0';
// Visual cutout policy: the browser should not tile bathymetry by default.
// Bathymetry/ETOPO still exists server-side for landmask, water fraction,
// ocean truth, bait scoring, and depth metadata.  The Google view only needs a
// stable mathematical under-sea floor so users can zoom through the cutout.
// Re-enable old tiled visual bathymetry only as a debug override.
const USE_BATHYMETRY_TILES = String(
  window.GFS_OCEAN_CUTOUT_RENDER_BATHYMETRY_TILES
  ?? window.GFS_OCEAN_GLASS_BATHYMETRY
  ?? '0'
) !== '0';
const LANDMASK_BATHYMETRY_MATH_RETAINED = true;
const BATHYMETRY_TILE_DEG = Number(window.GFS_BATHYMETRY_TILE_DEG || 4);
const BATHYMETRY_GRID = Number(window.GFS_BATHYMETRY_RENDER_GRID || 16);
const MAX_BATHYMETRY_TILES = Number(window.GFS_OCEAN_GLASS_MAX_TILES || 72);
const WATER_MASK_CUTAWAY = String(window.GFS_OCEAN_GLASS_WATER_MASK ?? '1') !== '0';
const FULL_WATER_TILE_FRACTION = Number(window.GFS_OCEAN_GLASS_FULL_TILE_FRACTION || 0.985);
const MIN_WATER_CELL_DEPTH_M = Number(window.GFS_OCEAN_GLASS_MIN_WATER_CELL_DEPTH_M || 1);
const MAX_WATER_CELLS_PER_TILE = Number(window.GFS_OCEAN_GLASS_MAX_WATER_CELLS_PER_TILE || 256);
const DIORAMA_CELL_FLOOR = String(window.GFS_OCEAN_DIORAMA_CELL_FLOOR ?? '1') !== '0';
const DIORAMA_FULL_OCEAN_CELLS = String(window.GFS_OCEAN_DIORAMA_FULL_OCEAN_CELLS ?? '1') !== '0';
const DIORAMA_DEPTH_EXAGGERATION = Number(window.GFS_OCEAN_DIORAMA_DEPTH_EXAGGERATION || 1);
const MAX_DIORAMA_TOTAL_CELLS = Number(window.GFS_OCEAN_DIORAMA_MAX_TOTAL_CELLS || 4096);
const DIORAMA_CELL_WALLS = String(window.GFS_OCEAN_DIORAMA_CELL_WALLS ?? '0') !== '0';
const REQUIRE_BATHYMETRY_MASK = String(window.GFS_OCEAN_GLASS_REQUIRE_BATHYMETRY_MASK ?? '1') !== '0';
const VIEWPORT_TILE_PAD = String(window.GFS_OCEAN_GLASS_PAD_VIEWPORT ?? '1') !== '0';
const VIEWPORT_PAD_FACTOR = Number(window.GFS_OCEAN_GLASS_VIEWPORT_PAD_FACTOR || 0.38);
const VIEWPORT_TILT_PAD_FACTOR = Number(window.GFS_OCEAN_GLASS_TILT_PAD_FACTOR || 0.42);
const VIEWPORT_HEADING_LOOKAHEAD = Number(window.GFS_OCEAN_GLASS_HEADING_LOOKAHEAD || 0.34);
const MAX_PADDED_LAT_SPAN = Number(window.GFS_OCEAN_GLASS_MAX_PADDED_LAT_SPAN || 28.0);
const MAX_PADDED_LON_SPAN = Number(window.GFS_OCEAN_GLASS_MAX_PADDED_LON_SPAN || 36.0);
const MIN_CELL_WATER_FRACTION = Number(window.GFS_OCEAN_GLASS_MIN_CELL_WATER_FRACTION || 0.35);
// One visible floor by default.  The older occlusion-skirt floor is useful for
// debugging Google occlusion, but it reads as a second seabed in normal use.
const SINGLE_FLOOR_MODE = String(window.GFS_OCEAN_CUTOUT_SINGLE_FLOOR ?? '1') !== '0';
const DRAW_OCCLUSION_SKIRT = !SINGLE_FLOOR_MODE && String(window.GFS_OCEAN_CUTOUT_DRAW_SKIRT ?? '0') !== '0';
const SKIRT_EXTRA_DEPTH_M = Number(window.GFS_OCEAN_CUTOUT_SKIRT_EXTRA_M || 30.48);
const DRAW_SHORELINE_RIM = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_DRAW_SHORELINE ?? '0') !== '0';
const MAX_SHORELINE_EDGES_PER_TILE = Number(window.GFS_OCEAN_CUTOUT_MAX_SHORELINE_EDGES_PER_TILE || 900);
// Ocean Cutout is now standard infrastructure, not a user-facing pill.
// Keep construction/debug helpers hidden by default so the seabed reads as a
// continuous sand-toned cutout instead of marching-square windows or tile boxes.
// Debug grid/window helpers can be re-enabled from the browser before load.
const CLEAN_SEABED_MODE = String(window.GFS_OCEAN_CUTOUT_CLEAN_SEABED ?? '1') !== '0';
const FRAMELESS_CUTOUT_MODE = String(window.GFS_OCEAN_CUTOUT_FRAMELESS ?? '1') !== '0';
const DRAW_CELL_GRID_LINES = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_CELL_GRID_LINES ?? (CLEAN_SEABED_MODE ? '0' : '1')) !== '0';
const DRAW_CELL_VERTICAL_EDGES = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_CELL_VERTICAL_EDGES ?? (CLEAN_SEABED_MODE ? '0' : '1')) !== '0';
const DRAW_CELL_FLOOR_RIMS = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_CELL_FLOOR_RIMS ?? (CLEAN_SEABED_MODE ? '0' : '1')) !== '0';
const DRAW_CELL_SKIRT_WALLS = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_CELL_SKIRT_WALLS ?? (CLEAN_SEABED_MODE ? '0' : '1')) !== '0';
const DRAW_TILE_BOUNDARY_RIMS = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_TILE_BOUNDARY_RIMS ?? '0') !== '0';
const DRAW_TILE_FLOOR_RIMS = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_TILE_FLOOR_RIMS ?? '0') !== '0';
const DRAW_TILE_VERTICAL_EDGES = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_TILE_VERTICAL_EDGES ?? '0') !== '0';
const DRAW_TILE_WALLS = USE_BATHYMETRY_TILES && String(window.GFS_OCEAN_CUTOUT_TILE_WALLS ?? '0') !== '0';
const FLOOR_ALPHA_CELL = Number(window.GFS_OCEAN_CUTOUT_FLOOR_ALPHA_CELL || (CLEAN_SEABED_MODE ? 0.97 : 0.34));
const FLOOR_ALPHA_TILE = Number(window.GFS_OCEAN_CUTOUT_FLOOR_ALPHA_TILE || (CLEAN_SEABED_MODE ? 0.94 : 0.22));
const SKIRT_ALPHA_CELL = Number(window.GFS_OCEAN_CUTOUT_SKIRT_ALPHA_CELL || (CLEAN_SEABED_MODE ? 0.88 : 0.50));
const SKIRT_ALPHA_TILE = Number(window.GFS_OCEAN_CUTOUT_SKIRT_ALPHA_TILE || (CLEAN_SEABED_MODE ? 0.74 : 0.42));
// Render the LFTR bathymetry floor shallower than the true ETOPO/RTOFS
// seafloor so it can act as a visible Google-altitude mask.
// The source depth remains real; only the rendered altitude is lifted.
const FLOOR_LIFT_FT = Number(window.GFS_OCEAN_CUTOUT_FLOOR_LIFT_FT || 65);
const FLOOR_LIFT_M = Math.max(0, Number(window.GFS_OCEAN_CUTOUT_FLOOR_LIFT_M || (FLOOR_LIFT_FT * 0.3048)) || 0);
// Google Photorealistic 3D can occlude deep negative-altitude custom polygons.
// Keep real bathymetry in metadata/color, but draw the mask floor in a shallow
// under-sea band so it reliably sits above Google's underwater terrain.
const FLOOR_MASK_MODE = String(window.GFS_OCEAN_CUTOUT_FLOOR_MASK_MODE ?? '1') !== '0';
const FLOOR_MASK_BASE_DEPTH_M = Number(window.GFS_OCEAN_CUTOUT_MASK_BASE_DEPTH_M || 7.5);
const FLOOR_MASK_RELIEF_M = Number(window.GFS_OCEAN_CUTOUT_MASK_RELIEF_M || 22.5);
const FLOOR_MASK_MIN_DEPTH_M = Number(window.GFS_OCEAN_CUTOUT_MASK_MIN_DEPTH_M || 2.0);
const FLOOR_CELL_SELECTION = String(window.GFS_OCEAN_CUTOUT_CELL_SELECTION || 'coverage').toLowerCase();
const FLOOR_DRAWS_WHEN_OCCLUDED = String(window.GFS_OCEAN_CUTOUT_FLOOR_OCCLUDED ?? '1') !== '0';
const BATHYMETRY_CACHE_TTL_MS = Number(window.GFS_OCEAN_GLASS_CACHE_TTL_MS || 180000);
const BATHYMETRY_PAYLOAD_CACHE = new Map();

function clamp(value, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, n));
}

function normalizeLon(lon) {
  const n = Number(lon);
  if (!Number.isFinite(n)) return null;
  const wrapped = ((n + 180) % 360 + 360) % 360 - 180;
  return wrapped;
}


function normalizeLonEdge(lon, edge = 'center') {
  const n = Number(lon);
  if (!Number.isFinite(n)) return null;
  if (edge === 'west' && n <= -180) return -180;
  if (edge === 'east' && n >= 180) return 180;
  return normalizeLon(n);
}

function safeBbox(viewport = null, frame = null) {
  const fromViewport = bboxFromViewport(viewport, null);
  if (fromViewport) return fromViewport;
  const candidates = [frame?.visible_bbox, frame?.render_bbox, frame?.bbox, frame?.bbox_object];
  for (const candidate of candidates) {
    const b = bboxFromViewport(null, candidate);
    if (b) return b;
  }
  return { west: -125, south: 32, east: -117, north: 38 };
}

function shrinkBbox(bbox) {
  const west = normalizeLon(bbox?.west);
  const east = normalizeLon(bbox?.east);
  const south = finiteNumber(bbox?.south, null);
  const north = finiteNumber(bbox?.north, null);
  if (![west, east, south, north].every(Number.isFinite)) return null;
  const latSpan = Math.max(0.025, Math.abs(north - south));
  const lonSpan = Math.max(0.025, Math.abs(east - west));
  const maxLatSpan = Number(window.GFS_OCEAN_GLASS_MAX_LAT_SPAN || 18.0);
  const maxLonSpan = Number(window.GFS_OCEAN_GLASS_MAX_LON_SPAN || 24.0);
  const cLat = (north + south) / 2;
  const cLon = normalizeLon((west + east) / 2);
  const useLat = Math.min(latSpan, maxLatSpan);
  const useLon = Math.min(lonSpan, maxLonSpan);
  return {
    west: normalizeLon(cLon - useLon / 2),
    east: normalizeLon(cLon + useLon / 2),
    south: clamp(cLat - useLat / 2, -89.85, 89.85),
    north: clamp(cLat + useLat / 2, -89.85, 89.85),
    source_bbox: bbox,
    clipped: latSpan > useLat || lonSpan > useLon,
  };
}


function cameraNumber(viewport, name, fallback = 0) {
  const n = Number(viewport?.camera?.[name] ?? viewport?.[name]);
  return Number.isFinite(n) ? n : fallback;
}

function centerOfBbox(bbox) {
  return {
    lat: (Number(bbox.south) + Number(bbox.north)) / 2,
    lon: normalizeLon((Number(bbox.west) + Number(bbox.east)) / 2),
  };
}

function paddedCameraBbox(bbox, viewport = null) {
  if (!VIEWPORT_TILE_PAD || !bbox) return bbox;
  const west = normalizeLon(bbox.west);
  const east = normalizeLon(bbox.east);
  const south = finiteNumber(bbox.south, null);
  const north = finiteNumber(bbox.north, null);
  if (![west, east, south, north].every(Number.isFinite)) return bbox;

  const c = centerOfBbox({ west, south, east, north });
  const latSpan = Math.max(0.025, Math.abs(north - south));
  const lonSpan = Math.max(0.025, Math.abs(east - west));
  const tilt = clamp(cameraNumber(viewport, 'tilt', 0), 0, 85);
  const heading = ((cameraNumber(viewport, 'heading', 0) % 360) + 360) % 360;
  const tilt01 = tilt / 85;
  const pad = clamp(VIEWPORT_PAD_FACTOR + tilt01 * VIEWPORT_TILT_PAD_FACTOR, 0, 1.25);

  const useLatSpan = Math.min(MAX_PADDED_LAT_SPAN, latSpan * (1 + pad));
  const useLonSpan = Math.min(MAX_PADDED_LON_SPAN, lonSpan * (1 + pad));

  // When the camera is tilted, the visible horizon is biased toward the heading.
  // Fetch a little farther in front of the camera so bathymetry does not pop on tilt/turn.
  const rad = heading * Math.PI / 180;
  const look = clamp(VIEWPORT_HEADING_LOOKAHEAD * tilt01, 0, 0.65);
  const forwardLat = Math.cos(rad) * useLatSpan * look * 0.5;
  const forwardLon = Math.sin(rad) * useLonSpan * look * 0.5;
  const shiftedLat = clamp(c.lat + forwardLat, -89.85, 89.85);
  const shiftedLon = normalizeLon(c.lon + forwardLon);

  return {
    west: normalizeLon(shiftedLon - useLonSpan / 2),
    east: normalizeLon(shiftedLon + useLonSpan / 2),
    south: clamp(shiftedLat - useLatSpan / 2, -89.85, 89.85),
    north: clamp(shiftedLat + useLatSpan / 2, -89.85, 89.85),
    source_bbox: bbox,
    padded: true,
    pad_factor: Number(pad.toFixed(3)),
    camera: { heading: Number(heading.toFixed(1)), tilt: Number(tilt.toFixed(1)) },
  };
}

function tileAlignedBbox(bbox) {
  if (!bbox) return bbox;
  const west = normalizeLon(bbox.west);
  const east = normalizeLon(bbox.east);
  const south = finiteNumber(bbox.south, null);
  const north = finiteNumber(bbox.north, null);
  if (![west, east, south, north].every(Number.isFinite)) return bbox;
  const d = Math.max(1, Number(BATHYMETRY_TILE_DEG) || 4);
  const w = Math.floor((west + 180) / d) * d - 180;
  const e = Math.ceil((east + 180) / d) * d - 180;
  const s = Math.floor((south + 90) / d) * d - 90;
  const n = Math.ceil((north + 90) / d) * d - 90;
  return {
    west: normalizeLonEdge(clamp(w, -180, 180), 'west'),
    east: normalizeLonEdge(clamp(e, -180, 180), 'east'),
    south: clamp(s, -89.85, 89.85),
    north: clamp(n, -89.85, 89.85),
    source_bbox: bbox,
    tile_aligned: true,
  };
}

function bboxQuery(bbox) {
  return [bbox.west, bbox.south, bbox.east, bbox.north].map((x) => Number(x).toFixed(6)).join(',');
}

function pathString(path) {
  return (Array.isArray(path) ? path : [])
    .map((p) => `${Number(p.lat).toFixed(7)},${Number(p.lng).toFixed(7)},${Number(p.altitude || 0).toFixed(2)}`)
    .join(' ');
}

function setAttr(el, name, value) {
  try { el?.setAttribute?.(name, String(value)); } catch (_) {}
}

function setBoolAttr(el, name, value = true) {
  try { if (value) el?.setAttribute?.(name, ''); else el?.removeAttribute?.(name); } catch (_) {}
}

function setColorStyle(el, { fillColor, strokeColor, strokeWidth = 1, strokeOpacity = null } = {}) {
  try { if (fillColor) el.fillColor = fillColor; } catch (_) {}
  try { if (strokeColor) el.strokeColor = strokeColor; } catch (_) {}
  try { el.strokeWidth = strokeWidth; } catch (_) {}
  setAttr(el, 'fill-color', fillColor);
  setAttr(el, 'stroke-color', strokeColor);
  setAttr(el, 'stroke-width', strokeWidth);
  if (strokeOpacity != null) setAttr(el, 'stroke-opacity', strokeOpacity);
}

function makePolygon({ path, kind, fillColor, strokeColor, strokeWidth = 1, occluded = false, tileId = null }) {
  if (!Array.isArray(path) || path.length < 3) return null;
  const el = document.createElement('gmp-polygon-3d');
  setAttr(el, 'path', pathString(path));
  try { el.path = path; } catch (_) {}
  setAttr(el, 'altitude-mode', 'absolute');
  try { el.altitudeMode = window.google?.maps?.maps3d?.AltitudeMode?.ABSOLUTE || 'ABSOLUTE'; } catch (_) {}
  setColorStyle(el, { fillColor, strokeColor, strokeWidth });
  setBoolAttr(el, 'draws-occluded-segments', occluded);
  setBoolAttr(el, 'draws-when-occluded', occluded);
  try { el.drawsOccludedSegments = Boolean(occluded); } catch (_) {}
  setAttr(el, 'data-gfs-layer', 'ocean-glass');
  setAttr(el, 'data-ocean-glass-kind', kind);
  if (tileId) setAttr(el, 'data-bathymetry-tile-id', tileId);
  return el;
}

function makePolyline({ path, kind, strokeColor = 'rgba(120,245,255,0.55)', strokeWidth = 2, occluded = true, tileId = null }) {
  if (!Array.isArray(path) || path.length < 2) return null;
  const el = document.createElement('gmp-polyline-3d');
  setAttr(el, 'path', pathString(path));
  try { el.path = path; } catch (_) {}
  setAttr(el, 'altitude-mode', 'absolute');
  try { el.altitudeMode = window.google?.maps?.maps3d?.AltitudeMode?.ABSOLUTE || 'ABSOLUTE'; } catch (_) {}
  try { el.strokeColor = strokeColor; } catch (_) {}
  try { el.strokeWidth = strokeWidth; } catch (_) {}
  setAttr(el, 'stroke-color', strokeColor);
  setAttr(el, 'stroke-width', strokeWidth);
  setBoolAttr(el, 'draws-occluded-segments', occluded);
  setBoolAttr(el, 'draws-when-occluded', occluded);
  try { el.drawsOccludedSegments = Boolean(occluded); } catch (_) {}
  setAttr(el, 'data-gfs-layer', 'ocean-glass');
  setAttr(el, 'data-ocean-glass-kind', kind);
  if (tileId) setAttr(el, 'data-bathymetry-tile-id', tileId);
  return el;
}

function bboxCorners(bbox, altitude = 0) {
  return [
    { lat: bbox.north, lng: bbox.west, altitude },
    { lat: bbox.north, lng: bbox.east, altitude },
    { lat: bbox.south, lng: bbox.east, altitude },
    { lat: bbox.south, lng: bbox.west, altitude },
  ];
}

function bboxFromArray(arr) {
  if (!Array.isArray(arr) || arr.length < 4) return null;
  return { west: Number(arr[0]), south: Number(arr[1]), east: Number(arr[2]), north: Number(arr[3]) };
}

function depthFtToM(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n * 0.3048 : null;
}

function depthFromFrame(frameOrPayload = {}) {
  const layers = frameOrPayload?.layers || {};
  const bait = pickLayer(frameOrPayload, 'bait') || layers.bait || frameOrPayload?.bait || null;
  const boater = pickLayer(frameOrPayload, 'boater', 'boats') || layers.boater || layers.boats || null;
  const rows = baitRowsFromPayload(bait || {});
  const points = [
    ...oceanPointsFromPayload(bait || {}),
    ...oceanPointsFromPayload(boater || {}),
    ...oceanPointsFromPayload(frameOrPayload || {}),
  ];
  const depths = [];
  for (const row of rows.slice(0, 1200)) {
    const m = finiteNumber(row?.bait_depth_m ?? row?.preferred_bait_depth_m ?? row?.depth_m, null)
      ?? depthFtToM(row?.bait_depth_ft ?? row?.preferred_bait_depth_ft ?? row?.preferred_depth_ft ?? row?.depth_ft);
    if (Number.isFinite(m) && m > 0) depths.push(m);
  }
  for (const point of points.slice(0, 1200)) {
    const m = finiteNumber(point?.depth_m ?? point?.bathymetry_m ?? point?.water_depth_m, null)
      ?? depthFtToM(point?.depth_ft ?? point?.water_depth_ft ?? point?.bathymetry_ft);
    if (Number.isFinite(m) && m > 0) depths.push(m);
  }
  if (!depths.length) return clamp(DEFAULT_VOLUME_DEPTH_M, MIN_VOLUME_DEPTH_M, MAX_VOLUME_DEPTH_M);
  depths.sort((a, b) => a - b);
  const p80 = depths[Math.max(0, Math.min(depths.length - 1, Math.floor(depths.length * 0.8)))];
  return clamp(p80 + 22, MIN_VOLUME_DEPTH_M, MAX_VOLUME_DEPTH_M);
}

function clearOceanGlass(map3DElement) {
  try { map3DElement?.querySelectorAll?.(OCEAN_GLASS_SELECTOR)?.forEach((el) => el.remove()); } catch (_) {}
}

async function fetchBathymetryTiles(bbox) {
  if (!USE_BATHYMETRY_TILES || !bbox) return null;
  const requestBbox = tileAlignedBbox(bbox);
  const key = `${BATHYMETRY_TILE_DEG}:${BATHYMETRY_GRID}:${MAX_BATHYMETRY_TILES}:${bboxQuery(requestBbox)}`;
  const cached = BATHYMETRY_PAYLOAD_CACHE.get(key);
  if (cached && (Date.now() - cached.ts) < BATHYMETRY_CACHE_TTL_MS) {
    return { ...cached.data, cache_hit_frontend: true, request_bbox: requestBbox };
  }
  const url = `/gfs/api/bathymetry-tiles?bbox=${encodeURIComponent(bboxQuery(requestBbox))}&tile_deg=${encodeURIComponent(BATHYMETRY_TILE_DEG)}&grid=${encodeURIComponent(BATHYMETRY_GRID)}&limit=${encodeURIComponent(MAX_BATHYMETRY_TILES)}`;
  try {
    const res = await fetch(url, { cache: 'default' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (!data || data.ok === false) return { ok: false, url, error: data?.error || 'not_ok', tiles: [], request_bbox: requestBbox };
    const payload = { ...data, url, request_bbox: requestBbox };
    BATHYMETRY_PAYLOAD_CACHE.set(key, { ts: Date.now(), data: payload });
    if (BATHYMETRY_PAYLOAD_CACHE.size > 18) {
      const oldest = BATHYMETRY_PAYLOAD_CACHE.keys().next().value;
      BATHYMETRY_PAYLOAD_CACHE.delete(oldest);
    }
    return payload;
  } catch (error) {
    return { ok: false, url, error: String(error?.message || error), tiles: [], request_bbox: requestBbox };
  }
}

function visualDepthFromTile(tile, fallbackDepthM) {
  const raw = Number(tile?.floor_depth_m ?? tile?.depth_mean_m ?? tile?.depth_max_m ?? fallbackDepthM);
  const sourceDepthM = Number.isFinite(raw) && raw > 0 ? raw : fallbackDepthM;
  const visualDepthM = clamp(sourceDepthM * DIORAMA_DEPTH_EXAGGERATION, MIN_VOLUME_DEPTH_M, MAX_VOLUME_DEPTH_M);
  return { sourceDepthM, visualDepthM };
}

function visualDepthFromSource(sourceDepthM, fallbackDepthM) {
  const src = Number.isFinite(Number(sourceDepthM)) && Number(sourceDepthM) > 0 ? Number(sourceDepthM) : fallbackDepthM;
  return {
    sourceDepthM: src,
    visualDepthM: clamp(src * DIORAMA_DEPTH_EXAGGERATION, MIN_VOLUME_DEPTH_M, MAX_VOLUME_DEPTH_M),
  };
}

function renderFloorAltitudeForDepth(depthM) {
  const safeDepthM = Math.max(0.1, Number(depthM) || 0.1);
  if (!FLOOR_MASK_MODE) return -Math.max(0.1, safeDepthM - FLOOR_LIFT_M);
  const maxDepth = Math.max(100, MAX_VOLUME_DEPTH_M);
  const relief01 = clamp(Math.log1p(safeDepthM) / Math.log1p(maxDepth), 0, 1);
  const maskDepth = clamp(FLOOR_MASK_BASE_DEPTH_M + relief01 * FLOOR_MASK_RELIEF_M, FLOOR_MASK_MIN_DEPTH_M, FLOOR_MASK_BASE_DEPTH_M + FLOOR_MASK_RELIEF_M);
  // Never push a cell above sea level.  The minimum depth keeps the mask away
  // from the Google water/terrain z-fighting band, while deep cells are clamped
  // into a visible shallow relief band instead of disappearing below Google.
  const liftedTrueDepth = Math.max(FLOOR_MASK_MIN_DEPTH_M, safeDepthM - FLOOR_LIFT_M);
  return -Math.max(FLOOR_MASK_MIN_DEPTH_M, Math.min(maskDepth, liftedTrueDepth));
}

function selectWaterCellsForCutout(waterCells, cap) {
  const sorted = (Array.isArray(waterCells) ? waterCells : [])
    .slice()
    .sort((a, b) => (Number(a.gy || 0) - Number(b.gy || 0)) || (Number(a.gx || 0) - Number(b.gx || 0)));
  const limit = Math.max(1, Math.floor(Number(cap) || sorted.length));
  if (sorted.length <= limit) return sorted;
  if (FLOOR_CELL_SELECTION === 'deepest') {
    return sorted
      .slice()
      .sort((a, b) => Number(b.depth_m || 0) - Number(a.depth_m || 0))
      .slice(0, limit)
      .sort((a, b) => (Number(a.gy || 0) - Number(b.gy || 0)) || (Number(a.gx || 0) - Number(b.gx || 0)));
  }
  const selected = [];
  const used = new Set();
  const stride = sorted.length / limit;
  for (let i = 0; i < limit; i += 1) {
    const idx = Math.min(sorted.length - 1, Math.floor(i * stride));
    if (!used.has(idx)) {
      used.add(idx);
      selected.push(sorted[idx]);
    }
  }
  // Fill any roundoff holes with remaining grid-order cells so the DOM budget is
  // used for broad coverage, not only deep-water pockets.
  for (let i = 0; selected.length < limit && i < sorted.length; i += 1) {
    if (!used.has(i)) {
      used.add(i);
      selected.push(sorted[i]);
    }
  }
  return selected.sort((a, b) => (Number(a.gy || 0) - Number(b.gy || 0)) || (Number(a.gx || 0) - Number(b.gx || 0)));
}

function sandToneForDepth(depthM, alpha = null) {
  const d = clamp(Number(depthM) || 0, 0, MAX_VOLUME_DEPTH_M);
  if (d < 20) return `rgba(232,213,160,${alpha ?? 0.82})`;
  if (d < 100) return `rgba(204,190,138,${alpha ?? 0.80})`;
  if (d < 500) return `rgba(112,157,145,${alpha ?? 0.74})`;
  if (d < 1500) return `rgba(75,112,126,${alpha ?? 0.72})`;
  return `rgba(36,64,86,${alpha ?? 0.72})`;
}

function skirtToneForDepth(depthM, alpha = 0.54) {
  const d = clamp(Number(depthM) || 0, 0, MAX_VOLUME_DEPTH_M);
  if (d < 100) return `rgba(96,79,50,${alpha})`;
  if (d < 500) return `rgba(52,80,78,${alpha})`;
  if (d < 1500) return `rgba(31,55,70,${alpha})`;
  return `rgba(14,29,44,${alpha})`;
}

// Legacy name retained for old callers, now sand/depth shaded.
function depthTint(depthM, alpha = 0.74) {
  return sandToneForDepth(depthM, alpha);
}

function surfaceTint(depthM, waterFraction = 1) {
  const d = clamp(Number(depthM) || 0, 0, MAX_VOLUME_DEPTH_M);
  const t = MAX_VOLUME_DEPTH_M > 0 ? d / MAX_VOLUME_DEPTH_M : 0;
  const a = clamp(0.05 + 0.065 * waterFraction + 0.025 * (1 - t), 0.045, 0.16);
  return `rgba(0,185,230,${a.toFixed(3)})`;
}


function renderGridFromTile(tile) {
  const grid = tile?.render_grid?.depth_m;
  if (!Array.isArray(grid) || !grid.length) return null;
  const rows = grid.length;
  const cols = Math.max(...grid.map((row) => Array.isArray(row) ? row.length : 0));
  if (!rows || !cols) return null;
  const waterFractionGrid = Array.isArray(tile?.render_grid?.water_fraction) ? tile.render_grid.water_fraction : null;
  return { grid, waterFractionGrid, rows, cols };
}

function tileWaterCells(tile) {
  const fromBackend = Array.isArray(tile?.water_cells) ? tile.water_cells : [];
  if (fromBackend.length) {
    return fromBackend
      .map((cell) => {
        const bbox = bboxFromArray(cell?.bbox);
        const depth = Number(cell?.depth_m);
        const wf = Number(cell?.water_fraction ?? 1);
        if (!bbox || !Number.isFinite(depth) || depth < MIN_WATER_CELL_DEPTH_M) return null;
        if (Number.isFinite(wf) && wf < MIN_CELL_WATER_FRACTION) return null;
        return {
          bbox,
          depth_m: depth,
          water_fraction: Number.isFinite(wf) ? wf : 1,
          gy: Number(cell?.r ?? cell?.gy ?? 0),
          gx: Number(cell?.c ?? cell?.gx ?? 0),
          shade: cell?.shade || null,
          fill_rgba: typeof cell?.fill_rgba === 'string' ? cell.fill_rgba : null,
          backend_cell: true,
        };
      })
      .filter(Boolean);
  }

  const tb = bboxFromArray(tile?.bbox);
  const rg = renderGridFromTile(tile);
  if (!tb || !rg) return [];
  const cells = [];
  const lonSpan = tb.east - tb.west;
  const latSpan = tb.north - tb.south;
  for (let gy = 0; gy < rg.rows; gy += 1) {
    const row = Array.isArray(rg.grid[gy]) ? rg.grid[gy] : [];
    for (let gx = 0; gx < rg.cols; gx += 1) {
      const depth = Number(row[gx]);
      const wfRow = Array.isArray(rg.waterFractionGrid?.[gy]) ? rg.waterFractionGrid[gy] : null;
      const cellWaterFraction = Number(wfRow?.[gx] ?? (Number.isFinite(depth) && depth >= MIN_WATER_CELL_DEPTH_M ? 1 : 0));
      if (!Number.isFinite(depth) || depth < MIN_WATER_CELL_DEPTH_M) continue;
      if (Number.isFinite(cellWaterFraction) && cellWaterFraction < MIN_CELL_WATER_FRACTION) continue;
      const west = tb.west + (gx / rg.cols) * lonSpan;
      const east = tb.west + ((gx + 1) / rg.cols) * lonSpan;
      const south = tb.south + (gy / rg.rows) * latSpan;
      const north = tb.south + ((gy + 1) / rg.rows) * latSpan;
      cells.push({
        bbox: { west, south, east, north },
        depth_m: depth,
        water_fraction: Number.isFinite(cellWaterFraction) ? cellWaterFraction : 1,
        gy,
        gx,
        backend_cell: false,
      });
    }
  }
  return cells;
}

function appendShorelineEdges(frag, tile) {
  if (!DRAW_SHORELINE_RIM || !Array.isArray(tile?.shoreline_edges)) return 0;
  let count = 0;
  for (const edge of tile.shoreline_edges.slice(0, MAX_SHORELINE_EDGES_PER_TILE)) {
    if (!Array.isArray(edge) || edge.length < 2) continue;
    const path = edge.slice(0, 2).map((p) => ({
      lat: Number(p.lat),
      lng: Number(p.lng),
      altitude: Number(p.altitude ?? 0),
    })).filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lng));
    if (path.length < 2) continue;
    const line = makePolyline({
      path,
      kind: 'zero-meter-shoreline-rim',
      strokeColor: 'rgba(244,218,158,0.78)',
      strokeWidth: 1.35,
      occluded: false,
      tileId: tile?.tile_id,
    });
    if (line) {
      frag.append(line);
      count += 1;
    }
  }
  return count;
}


function appendWaterMaskedTileVolume(frag, tile, fallbackDepthM, budget = null) {
  const waterFraction = Number(tile?.water_fraction ?? 0);
  const tb = bboxFromArray(tile?.bbox);
  if (!tb) return { mode: 'skipped_no_bbox', rendered: 0, waterCells: 0, cellMode: false };

  const waterCells = tileWaterCells(tile);
  const shorelineEdgeCount = appendShorelineEdges(frag, tile);
  const tileSkirtExtraM = Number(tile?.cutaway?.skirt_extra_depth_m ?? SKIRT_EXTRA_DEPTH_M);
  const shouldUseCells = DIORAMA_CELL_FLOOR && waterCells.length && (
    DIORAMA_FULL_OCEAN_CELLS || WATER_MASK_CUTAWAY || waterFraction < FULL_WATER_TILE_FRACTION
  );

  if (shouldUseCells) {
    const remaining = budget ? Math.max(0, budget.max - budget.used) : MAX_WATER_CELLS_PER_TILE;
    if (remaining <= 0) {
      return { mode: 'skipped_cell_budget_exhausted', rendered: 0, waterCells: waterCells.length, cellMode: true };
    }
    const perTileCap = Math.max(1, Math.min(4096, Number(MAX_WATER_CELLS_PER_TILE) || 256));
    const cap = Math.max(1, Math.min(perTileCap, remaining));
    // Coverage-first selection keeps the seabed as a continuous mask. The old
    // deepest-first cap made only some of the floor show up in coastal views.
    const selected = selectWaterCellsForCutout(waterCells, cap);

    let selectedDepthSum = 0;
    let selectedDepthCount = 0;
    for (const cell of selected) {
      const { sourceDepthM, visualDepthM } = visualDepthFromSource(cell.depth_m, fallbackDepthM);
      if (Number.isFinite(sourceDepthM)) {
        selectedDepthSum += sourceDepthM;
        selectedDepthCount += 1;
      }
      appendVolumeForBbox(frag, cell.bbox, visualDepthM, {
        tileId: `${tile.tile_id}:cell:${cell.gy}:${cell.gx}`,
        sourceDepthM,
        tileMode: true,
        cellMode: true,
        waterFraction: Number.isFinite(cell.water_fraction) ? cell.water_fraction : waterFraction,
        fillColor: cell.fill_rgba || null,
        skirtExtraDepthM: tileSkirtExtraM,
      });
    }
    if (budget) budget.used += selected.length;
    const selectedMeanDepthM = selectedDepthCount ? selectedDepthSum / selectedDepthCount : Number(tile?.depth_mean_m ?? fallbackDepthM);
    const fullTile = waterFraction >= FULL_WATER_TILE_FRACTION;
    return {
      mode: selected.length < waterCells.length
        ? (fullTile ? 'full_ocean_bathymetry_cells_capped' : 'bathymetry_water_cells_capped')
        : (fullTile ? 'full_ocean_bathymetry_cells' : 'bathymetry_water_cells'),
      rendered: selected.length,
      waterCells: waterCells.length,
      cappedTo: selected.length,
      selectionPolicy: FLOOR_CELL_SELECTION,
      sourceDepthM: selectedMeanDepthM,
      visualDepthM: selectedMeanDepthM,
      cellMode: true,
      renderGrid: tile?.render_grid ? { rows: tile.render_grid.rows, cols: tile.render_grid.cols } : null,
      shorelineEdges: shorelineEdgeCount,
      skirtExtraDepthM: tileSkirtExtraM,
    };
  }

  if (!WATER_MASK_CUTAWAY || waterFraction >= FULL_WATER_TILE_FRACTION) {
    const { sourceDepthM, visualDepthM } = visualDepthFromTile(tile, fallbackDepthM);
    appendVolumeForBbox(frag, tb, visualDepthM, {
      tileId: tile.tile_id,
      sourceDepthM,
      tileMode: true,
      cellMode: false,
      waterFraction,
      skirtExtraDepthM: tileSkirtExtraM,
    });
    return {
      mode: WATER_MASK_CUTAWAY ? 'full_ocean_tile_single_volume' : 'square_tile_water_mask_disabled',
      rendered: 1,
      waterCells: waterCells.length || null,
      cellMode: false,
      sourceDepthM,
      visualDepthM,
      shorelineEdges: shorelineEdgeCount,
      skirtExtraDepthM: tileSkirtExtraM,
    };
  }

  return { mode: 'skipped_mixed_tile_no_water_cells', rendered: 0, waterCells: waterCells.length, cellMode: false, shorelineEdges: shorelineEdgeCount, skirtExtraDepthM: tileSkirtExtraM };
}

function appendVolumeForBbox(frag, bbox, depthM, { tileId = null, sourceDepthM = null, tileMode = false, cellMode = false, waterFraction = 1, fillColor = null, skirtExtraDepthM = SKIRT_EXTRA_DEPTH_M } = {}) {
  const safeDepthM = Math.max(0.1, Number(depthM) || 0);
  const floorAlt = renderFloorAltitudeForDepth(safeDepthM);
  const skirtExtra = DRAW_OCCLUSION_SKIRT ? clamp(Number(skirtExtraDepthM), 0, 300) : 0;
  const skirtAlt = floorAlt - skirtExtra;
  const top = bboxCorners(bbox, 0);
  const floor = bboxCorners(bbox, floorAlt);
  const skirt = bboxCorners(bbox, skirtAlt);
  if (DRAW_SURFACE) {
    const topPoly = makePolygon({
      path: top,
      kind: tileMode ? 'surface-glass-tile' : 'surface-glass',
      fillColor: tileMode ? surfaceTint(depthM, waterFraction) : 'rgba(0,165,230,0.105)',
      strokeColor: cellMode ? 'rgba(120,255,255,0.18)' : (tileMode ? 'rgba(120,255,255,0.36)' : 'rgba(120,255,255,0.62)'),
      strokeWidth: cellMode ? 0.45 : (tileMode ? 1 : 2),
      occluded: false,
      tileId,
    });
    if (topPoly) frag.append(topPoly);
  }

  if (DRAW_FLOOR) {
    const floorAlpha = cellMode ? FLOOR_ALPHA_CELL : (tileMode ? FLOOR_ALPHA_TILE : 0.70);
    const showCellFloorStroke = cellMode && DRAW_CELL_GRID_LINES;
    const showTileFloorStroke = tileMode && DRAW_TILE_FLOOR_RIMS;
    const showLooseFloorStroke = !cellMode && !tileMode && !FRAMELESS_CUTOUT_MODE;
    const showFloorStroke = showCellFloorStroke || showTileFloorStroke || showLooseFloorStroke;
    const floorPoly = makePolygon({
      path: floor,
      kind: cellMode ? 'etopo2022-depth-cell-floor-debug' : (tileMode ? 'etopo2022-4deg-floor-debug' : 'google-floor-math-cutout'),
      fillColor: fillColor || (cellMode ? depthTint(depthM, floorAlpha) : sandToneForDepth(depthM, floorAlpha)),
      strokeColor: showFloorStroke ? 'rgba(232,213,160,0.18)' : 'rgba(232,213,160,0.00)',
      strokeWidth: showFloorStroke ? (cellMode ? 0.25 : 0.45) : 0,
      occluded: FLOOR_DRAWS_WHEN_OCCLUDED,
      tileId,
    });
    if (floorPoly) {
      setAttr(floorPoly, 'data-ocean-floor-lift-ft', FLOOR_LIFT_FT.toFixed(2));
      setAttr(floorPoly, 'data-ocean-floor-lift-m', FLOOR_LIFT_M.toFixed(3));
      setAttr(floorPoly, 'data-ocean-cutout-single-floor', SINGLE_FLOOR_MODE ? 'true' : 'false');
      setAttr(floorPoly, 'data-ocean-floor-mask-mode', FLOOR_MASK_MODE ? 'true' : 'false');
      setAttr(floorPoly, 'data-ocean-floor-source-depth-m', Number(sourceDepthM ?? depthM).toFixed(2));
      setAttr(floorPoly, 'data-ocean-floor-render-altitude-m', floorAlt.toFixed(3));
      setAttr(floorPoly, 'data-ocean-cutout-visual-policy', USE_BATHYMETRY_TILES ? 'debug_tiled_bathymetry' : 'single_google_floor_math');
      setAttr(floorPoly, 'data-ocean-landmask-math-retained', LANDMASK_BATHYMETRY_MATH_RETAINED ? 'true' : 'false');
      frag.append(floorPoly);
    }
  }

  if (DRAW_OCCLUSION_SKIRT && skirtExtra > 0) {
    const showCellSkirtStroke = cellMode && DRAW_CELL_GRID_LINES;
    const showTileSkirtStroke = tileMode && DRAW_TILE_FLOOR_RIMS;
    const showLooseSkirtStroke = !cellMode && !tileMode && !FRAMELESS_CUTOUT_MODE;
    const showSkirtStroke = showCellSkirtStroke || showTileSkirtStroke || showLooseSkirtStroke;
    const skirtPoly = makePolygon({
      path: skirt,
      kind: cellMode ? 'occlusion-skirt-cell-floor' : 'occlusion-skirt-floor',
      fillColor: skirtToneForDepth(depthM, cellMode ? SKIRT_ALPHA_CELL : SKIRT_ALPHA_TILE),
      strokeColor: showSkirtStroke ? 'rgba(71,52,31,0.18)' : 'rgba(71,52,31,0.00)',
      strokeWidth: showSkirtStroke ? (cellMode ? 0.1 : 0.25) : 0,
      occluded: FLOOR_DRAWS_WHEN_OCCLUDED,
      tileId,
    });
    if (skirtPoly) {
      setAttr(skirtPoly, 'data-ocean-floor-lift-ft', FLOOR_LIFT_FT.toFixed(2));
      setAttr(skirtPoly, 'data-ocean-floor-render-altitude-m', skirtAlt.toFixed(3));
      frag.append(skirtPoly);
    }

    if (DRAW_WALLS && cellMode && DRAW_CELL_SKIRT_WALLS) {
      const skirtWalls = [
        ['skirt-north-wall', [floor[0], floor[1], skirt[1], skirt[0]]],
        ['skirt-east-wall', [floor[1], floor[2], skirt[2], skirt[1]]],
        ['skirt-south-wall', [floor[2], floor[3], skirt[3], skirt[2]]],
        ['skirt-west-wall', [floor[3], floor[0], skirt[0], skirt[3]]],
      ];
      skirtWalls.forEach(([kind, path]) => {
        const wall = makePolygon({
          path,
          kind,
          fillColor: skirtToneForDepth(depthM, 0.22),
          strokeColor: 'rgba(71,52,31,0.12)',
          strokeWidth: 0.2,
          occluded: true,
          tileId,
        });
        if (wall) frag.append(wall);
      });
    }
  }

  const corners = ['NW', 'NE', 'SE', 'SW'];
  if ((!cellMode && (!tileMode || DRAW_TILE_VERTICAL_EDGES)) || (cellMode && DRAW_CELL_VERTICAL_EDGES)) {
    top.forEach((p, i) => {
      const edge = makePolyline({
        path: [p, { ...p, altitude: floorAlt }],
        kind: `vertical-edge-${corners[i]}`,
        strokeColor: cellMode ? 'rgba(150,255,255,0.10)' : (tileMode ? 'rgba(150,255,255,0.22)' : 'rgba(150,255,255,0.46)'),
        strokeWidth: cellMode ? 0.45 : (tileMode ? 0.85 : 2),
        occluded: true,
        tileId,
      });
      if (edge) frag.append(edge);
    });
  }

  const rimAlphaBoost = DRAW_SURFACE ? 1 : 0.72;
  const edges = [
    ['north-cutout-rim', [top[0], top[1]], `rgba(160,255,255,${(0.70 * rimAlphaBoost).toFixed(3)})`, tileMode ? 1.2 : 2.4],
    ['east-cutout-rim', [top[1], top[2]], `rgba(160,255,255,${(0.52 * rimAlphaBoost).toFixed(3)})`, tileMode ? 1.0 : 1.8],
    ['south-cutout-rim-open', [top[2], top[3]], `rgba(160,255,255,${(0.28 * rimAlphaBoost).toFixed(3)})`, 1.0],
    ['west-cutout-rim', [top[3], top[0]], `rgba(160,255,255,${(0.52 * rimAlphaBoost).toFixed(3)})`, tileMode ? 1.0 : 1.8],
    ['north-floor', [floor[0], floor[1]], 'rgba(75,220,255,0.38)', 1.0],
    ['east-floor', [floor[1], floor[2]], 'rgba(75,220,255,0.26)', 1.0],
    ['south-floor-open', [floor[2], floor[3]], 'rgba(75,220,255,0.18)', 1.0],
    ['west-floor', [floor[3], floor[0]], 'rgba(75,220,255,0.26)', 1.0],
  ];
  edges.forEach(([kind, path, color, width]) => {
    const isFloorLine = kind.includes('floor');
    const isRimLine = kind.includes('rim');
    // Standard LFTR cutout is frameless.  These cutout/floor/rim lines are
    // construction/debug guides only; keep them hidden unless a specific debug
    // flag asks for them.
    if (FRAMELESS_CUTOUT_MODE && !cellMode && !tileMode) return;
    if (cellMode && ((isFloorLine && !DRAW_CELL_FLOOR_RIMS) || (isRimLine && !DRAW_CELL_GRID_LINES))) return;
    if (tileMode && ((isFloorLine && !DRAW_TILE_FLOOR_RIMS) || (isRimLine && !DRAW_TILE_BOUNDARY_RIMS))) return;
    const line = makePolyline({ path, kind, strokeColor: color, strokeWidth: cellMode ? Math.max(0.45, width * 0.55) : width, occluded: isFloorLine, tileId });
    if (line) frag.append(line);
  });

  if (DRAW_WALLS && (!tileMode || DRAW_TILE_WALLS || DIORAMA_CELL_WALLS || String(window.GFS_OCEAN_GLASS_TILE_WALLS ?? '0') === '1')) {
    const wallPaths = [
      ['north-wall', [top[0], top[1], floor[1], floor[0]]],
      ['east-wall', [top[1], top[2], floor[2], floor[1]]],
      ['west-wall', [top[3], top[0], floor[0], floor[3]]],
    ];
    if (!FRONT_WALL_OPEN) wallPaths.push(['south-wall', [top[2], top[3], floor[3], floor[2]]]);
    wallPaths.forEach(([kind, path]) => {
      const wall = makePolygon({
        path,
        kind,
        fillColor: cellMode ? 'rgba(0,95,180,0.018)' : 'rgba(0,95,180,0.035)',
        strokeColor: 'rgba(100,230,255,0.16)',
        strokeWidth: 1,
        occluded: true,
        tileId,
      });
      if (wall) frag.append(wall);
    });
  }
  return { depthM, floorAlt, skirtAlt, skirtExtraDepthM: skirtExtra, sourceDepthM: sourceDepthM ?? depthM };
}

export async function renderOceanGlassLayer({ frame, payload, map3DElement, viewport = null, reason = 'steady' } = {}) {
  if (!map3DElement) return null;
  clearOceanGlass(map3DElement);
  const rawBbox = safeBbox(viewport, frame || payload || {});
  const paddedBbox = paddedCameraBbox(rawBbox, viewport);
  const bbox = shrinkBbox(paddedBbox);
  if (!bbox) return null;
  const fallbackDepthM = depthFromFrame(frame || payload || {});
  const bathy = await fetchBathymetryTiles(bbox);
  const tiles = Array.isArray(bathy?.tiles) ? bathy.tiles.filter((t) => Number(t?.water_fraction ?? 1) > 0.02) : [];

  const frag = document.createDocumentFragment();
  const renderedTiles = [];
  const dioramaBudget = { used: 0, max: Math.max(1, Number(MAX_DIORAMA_TOTAL_CELLS) || 384) };
  if (tiles.length) {
    for (const tile of tiles.slice(0, MAX_BATHYMETRY_TILES)) {
      const detail = appendWaterMaskedTileVolume(frag, tile, fallbackDepthM, dioramaBudget);
      if (!detail.rendered) continue;
      renderedTiles.push({
        tile_id: tile.tile_id,
        bbox: tile.bbox,
        water_fraction: tile.water_fraction,
        cutaway_mode: detail.mode,
        rendered_volume_count: detail.rendered,
        water_cell_count: detail.waterCells,
        cell_mode: Boolean(detail.cellMode),
        capped_to: detail.cappedTo ?? null,
        render_grid: detail.renderGrid ?? (tile?.render_grid ? { rows: tile.render_grid.rows, cols: tile.render_grid.cols } : null),
        shoreline_edges_rendered: detail.shorelineEdges ?? 0,
        skirt_extra_depth_m: Number(Number(detail.skirtExtraDepthM ?? SKIRT_EXTRA_DEPTH_M).toFixed(2)),
        selection_policy: detail.selectionPolicy ?? FLOOR_CELL_SELECTION,
        source_depth_m: Number(Number(detail.sourceDepthM ?? tile.depth_mean_m ?? 0).toFixed(1)),
        visual_depth_m: Number(Number(detail.visualDepthM ?? tile.floor_depth_m ?? fallbackDepthM).toFixed(1)),
        depth_min_m: tile.depth_min_m,
        depth_mean_m: tile.depth_mean_m,
        depth_max_m: tile.depth_max_m,
      });
    }
  }

  const allowFallbackVolume = !REQUIRE_BATHYMETRY_MASK || !USE_BATHYMETRY_TILES || bathy?.ok === false;
  if (!renderedTiles.length && allowFallbackVolume) {
    appendVolumeForBbox(frag, bbox, fallbackDepthM, { tileMode: false });
  }

  map3DElement.append(frag);
  const rendered = map3DElement.querySelectorAll?.(OCEAN_GLASS_SELECTOR)?.length || 0;
  const stats = {
    rendered,
    reason,
    draw_surface: DRAW_SURFACE,
    floor_lift_ft: Number(FLOOR_LIFT_FT.toFixed(2)),
    floor_lift_m: Number(FLOOR_LIFT_M.toFixed(3)),
    floor_mask_mode: FLOOR_MASK_MODE,
    floor_mask_base_depth_m: Number(FLOOR_MASK_BASE_DEPTH_M.toFixed(2)),
    floor_mask_relief_m: Number(FLOOR_MASK_RELIEF_M.toFixed(2)),
    floor_cell_selection: FLOOR_CELL_SELECTION,
    single_floor_mode: SINGLE_FLOOR_MODE,
    floor_draws_when_occluded: FLOOR_DRAWS_WHEN_OCCLUDED,
    cutout_mode: DRAW_SURFACE ? 'glass_surface_enabled_optional' : (USE_BATHYMETRY_TILES ? (SINGLE_FLOOR_MODE ? 'debug_single_lifted_bathymetry_tile_mask_floor_no_skirt' : 'debug_lifted_bathymetry_tile_floor_with_optional_skirt') : 'single_google_floor_math_cutout_no_bathymetry_tiles'),
    visual_bathymetry_tiles_enabled: USE_BATHYMETRY_TILES,
    landmask_bathymetry_math_retained: LANDMASK_BATHYMETRY_MATH_RETAINED,
    bbox,
    raw_bbox: rawBbox,
    padded_bbox: paddedBbox,
    request_bbox: bathy?.request_bbox || null,
    fallback_depth_m: Number(fallbackDepthM.toFixed(1)),
    floor_altitude_m: renderedTiles.length ? null : (allowFallbackVolume ? Number(renderFloorAltitudeForDepth(fallbackDepthM).toFixed(1)) : null),
    bathymetry: {
      enabled: USE_BATHYMETRY_TILES,
      visual_fetch_policy: USE_BATHYMETRY_TILES ? 'debug_enabled_by_window_override' : 'disabled_by_default_google_floor_math_only',
      landmask_math_policy: 'retained_server_side_for_ocean_truth_bait_water_fraction_not_rendered_as_tiles',
      source: bathy?.source || 'NOAA_ETOPO_2022_60s_cache_first',
      url: bathy?.url || null,
      ok: Boolean(bathy?.ok && renderedTiles.length),
      tile_deg: bathy?.tile_deg || BATHYMETRY_TILE_DEG,
      requested_tile_count: bathy?.requested_tile_count ?? null,
      tile_count: bathy?.tile_count ?? 0,
      missing_tile_count: bathy?.missing_tile_count ?? null,
      cache: bathy?.cache || null,
      errors: bathy?.errors || (bathy?.error ? [{ error: bathy.error }] : []),
      rendered_tiles: renderedTiles,
      water_mask: {
        enabled: WATER_MASK_CUTAWAY,
        full_tile_fraction: FULL_WATER_TILE_FRACTION,
        min_water_cell_depth_m: MIN_WATER_CELL_DEPTH_M,
        max_water_cells_per_tile: MAX_WATER_CELLS_PER_TILE,
        max_diorama_total_cells: MAX_DIORAMA_TOTAL_CELLS,
        rendered_diorama_cells: dioramaBudget.used,
        floor_cell_selection: FLOOR_CELL_SELECTION,
        single_floor_mode: SINGLE_FLOOR_MODE,
        floor_mask_mode: FLOOR_MASK_MODE,
        min_cell_water_fraction: MIN_CELL_WATER_FRACTION,
        diorama_cell_floor: DIORAMA_CELL_FLOOR,
        diorama_full_ocean_cells: DIORAMA_FULL_OCEAN_CELLS,
        depth_exaggeration: DIORAMA_DEPTH_EXAGGERATION,
        draw_surface: DRAW_SURFACE,
        draw_occlusion_skirt: DRAW_OCCLUSION_SKIRT,
        skirt_extra_depth_m: SKIRT_EXTRA_DEPTH_M,
        draw_shoreline_rim: DRAW_SHORELINE_RIM,
        frameless_cutout_mode: FRAMELESS_CUTOUT_MODE,
        max_shoreline_edges_per_tile: MAX_SHORELINE_EDGES_PER_TILE,
        palette: 'sand_depth_v2_frameless_no_grid',
        clean_seabed_mode: CLEAN_SEABED_MODE,
        draw_cell_grid_lines: DRAW_CELL_GRID_LINES,
        draw_cell_vertical_edges: DRAW_CELL_VERTICAL_EDGES,
        draw_cell_floor_rims: DRAW_CELL_FLOOR_RIMS,
        draw_cell_skirt_walls: DRAW_CELL_SKIRT_WALLS,
        draw_tile_boundary_rims: DRAW_TILE_BOUNDARY_RIMS,
        draw_tile_floor_rims: DRAW_TILE_FLOOR_RIMS,
        draw_tile_vertical_edges: DRAW_TILE_VERTICAL_EDGES,
        draw_tile_walls: DRAW_TILE_WALLS,
        floor_alpha_cell: FLOOR_ALPHA_CELL,
        skirt_alpha_cell: SKIRT_ALPHA_CELL,
        top_surface_policy: DRAW_SURFACE ? 'optional_glass_surface_enabled' : 'removed_by_default_keep_cutout_floor_only',
        mode: USE_BATHYMETRY_TILES ? (FRAMELESS_CUTOUT_MODE ? 'debug_bathymetry_tile_floor_frameless_clean_seabed' : 'debug_bathymetry_grid_water_cells') : 'single_viewport_google_floor_math_no_bathymetry_tiles',
      },
    },
    source: renderedTiles.length ? 'debug_cached_noaa_etopo2022_4deg_visual_tiles' : (allowFallbackVolume ? 'viewport_google_floor_math_cutout_no_bathymetry_tiles' : 'bathymetry_mask_required_no_cached_water_cells_drawn'),
    policy: 'boot clouds/rain, then draw one mathematical Google-floor cutout over the viewport; do not render bathymetry tiles by default; server bathymetry remains for landmask/ocean truth/bait math',
  };
  try { window.__gfsOceanGlassStats = stats; window.__gfsOceanCutoutStats = stats; window.__gfsDebugEvent?.('ocean-cutout/rendered', stats); window.__gfsDebugEvent?.('ocean-glass/rendered', stats); } catch (_) {}
  console.info('[gfs google-floor-math-cutout/no-bathymetry-tiles] rendered', stats);
  const disposer = () => clearOceanGlass(map3DElement);
  disposer.__gfsKeepExisting = true;
  disposer.__gfsDidRender = rendered > 0;
  return disposer;
}

export function clearOceanGlassLayer(map3DElement) {
  clearOceanGlass(map3DElement);
}

import { renderRainZones } from '../gfs/rain-zones.js';
import { pickLayer } from './scene-frame-utils.js';

function pickPayload(frameOrPayload) {
  const layers = frameOrPayload?.layers || {};
  const rain = pickLayer(frameOrPayload, 'rain') || frameOrPayload?.rain || null;
  const clouds = pickLayer(frameOrPayload, 'clouds') || frameOrPayload?.clouds || null;
  const weather = frameOrPayload?.weather || null;
  const base = rain || weather || clouds;
  if (!base || typeof base !== 'object') return null;
  return {
    ...base,
    bbox: base.bbox || base.bbox_used || clouds?.bbox || frameOrPayload?.bbox || frameOrPayload?.visible_bbox,
    bbox_used: base.bbox_used || base.bbox || clouds?.bbox_used || frameOrPayload?.bbox || frameOrPayload?.visible_bbox,
    fields: base.fields || weather?.fields || clouds?.fields || {},
    cloud_layers: base.cloud_layers || clouds?.cloud_layers || [],
    items: base.items || clouds?.items || clouds?.tiles || [],
    precip_columns: base.precip_columns || base.features || clouds?.precip_columns || clouds?.scene?.precip || [],
  };
}

export async function renderRainLayer({ payload, frame, map3DElement, reason = 'steady' } = {}) {
  const rainPayload = pickPayload(payload || frame);
  if (!rainPayload) return null;
  return renderRainZones({ payload: rainPayload, map3DElement, viewportReason: reason === 'boot' ? 'steady' : reason });
}

export function clearRainLayer(map3DElement) {
  try { window.clearGfsRainLayer?.(); } catch (_) {}
  try { map3DElement?.querySelectorAll?.('[data-gfs-layer="rain"],[data-rain-column],[data-rain-particle]')?.forEach((el) => el.remove()); } catch (_) {}
}

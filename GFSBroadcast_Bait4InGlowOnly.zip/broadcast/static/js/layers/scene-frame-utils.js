// Shared scene-frame adapter helpers for the clean /GFS frontend spine.
// These functions intentionally do not fetch data. They normalize the one
// frontend contract we want renderers to consume: /gfs/api/scene-frame.

export function asArray(value) {
  return Array.isArray(value) ? value : [];
}

export function firstArray(...values) {
  for (const value of values) {
    if (Array.isArray(value) && value.length) return value;
  }
  return [];
}

export function finiteNumber(value, fallback = null) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function pickLayer(frameOrPayload, ...names) {
  const layers = frameOrPayload?.layers || {};
  for (const name of names) {
    if (layers?.[name] && typeof layers[name] === 'object') return layers[name];
  }
  for (const name of names) {
    if (frameOrPayload?.[name] && typeof frameOrPayload[name] === 'object') return frameOrPayload[name];
  }
  return null;
}

export function bboxFromViewport(viewport = null, fallback = null) {
  const v = viewport || {};
  const west = finiteNumber(v.west ?? v[0], null);
  const south = finiteNumber(v.south ?? v[1], null);
  const east = finiteNumber(v.east ?? v[2], null);
  const north = finiteNumber(v.north ?? v[3], null);
  if ([west, south, east, north].every(Number.isFinite)) return { west, south, east, north };
  if (Array.isArray(fallback) && fallback.length >= 4) {
    const out = { west: finiteNumber(fallback[0]), south: finiteNumber(fallback[1]), east: finiteNumber(fallback[2]), north: finiteNumber(fallback[3]) };
    if ([out.west, out.south, out.east, out.north].every(Number.isFinite)) return out;
  }
  if (fallback && typeof fallback === 'object') {
    const out = { west: finiteNumber(fallback.west), south: finiteNumber(fallback.south), east: finiteNumber(fallback.east), north: finiteNumber(fallback.north) };
    if ([out.west, out.south, out.east, out.north].every(Number.isFinite)) return out;
  }
  return null;
}

export function oceanPointsFromPayload(payload = {}) {
  return firstArray(
    payload?.oceanPoints?.points,
    payload?.oceanAnalysisPoints?.points,
    payload?.ocean?.oceanPoints?.points,
    payload?.ocean?.points,
    payload?.points,
    payload?.ocean_points,
    payload?.oceanAnalysisPoints,
    payload?.oceanPoints,
    payload?.current_points,
    payload?.currentPoints,
  ).filter((p) => p && typeof p === 'object');
}

export function baitRowsFromPayload(payload = {}) {
  return firstArray(
    payload?.advancedBaitRows,
    payload?.advanced_bait_rows,
    payload?.bait_score,
    payload?.bait?.advancedBaitRows,
    payload?.bait?.advanced_bait_rows,
    payload?.bait?.bait_score,
  ).filter((p) => p && typeof p === 'object');
}

export function countPolygons(payload = {}) {
  const bait = payload?.bait || {};
  return [
    payload?.polygons,
    payload?.outer_polygons,
    payload?.inner_polygons,
    payload?.core_polygons,
    bait?.polygons,
    bait?.outer_polygons,
    bait?.inner_polygons,
    bait?.core_polygons,
  ].reduce((sum, value) => sum + (Array.isArray(value) ? value.length : 0), 0);
}

export function sceneFrameLayerSummary(frame = {}) {
  const layers = frame?.layers || {};
  const out = {};
  for (const [key, value] of Object.entries(layers)) {
    const points = oceanPointsFromPayload(value).length;
    out[key] = {
      ok: value?.ok,
      status: value?.status,
      source: value?.source,
      count: value?.count,
      points,
      polygons: countPolygons(value),
      baitRows: baitRowsFromPayload(value).length,
      boats: Array.isArray(value?.boats) ? value.boats.length : 0,
    };
  }
  return out;
}

export function annotateOceanRenderPayload(payload = {}, { viewport = null, fallbackBbox = null } = {}) {
  const points = oceanPointsFromPayload(payload);
  const bbox = bboxFromViewport(viewport, fallbackBbox || payload?.bbox_object || payload?.bbox || payload?.visible_bbox || payload?.oceanPoints?.bbox);
  const source = String(payload?.source || payload?.oceanPoints?.source || payload?.ocean?.source || '').trim();
  const out = {
    ...payload,
    source: source || (points.length ? 'rtofs_scene_frame_ocean_points' : payload?.source),
    bbox_object: payload?.bbox_object || bbox || null,
    bbox: payload?.bbox || bbox || payload?.oceanPoints?.bbox || null,
    __requestedViewport: bbox || payload?.__requestedViewport || null,
    landmask_contract: payload?.landmask_contract || 'rtofs_sst_ocean_mask',
    source_meta: {
      ...(payload?.source_meta || {}),
      sst_landmask: payload?.source_meta?.sst_landmask || payload?.sst_landmask || { method: 'rtofs_sst_ocean_mask', water_cells: points.length },
    },
    sst_landmask: payload?.sst_landmask || { method: 'rtofs_sst_ocean_mask', water_cells: points.length },
  };
  if (points.length && !out.oceanPoints?.points) {
    out.oceanPoints = { ...(out.oceanPoints || {}), points, count: points.length, source: out.oceanPoints?.source || out.source };
  }
  return out;
}

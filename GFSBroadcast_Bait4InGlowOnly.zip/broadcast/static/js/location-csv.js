import { getJsonSafe } from './gfs/api.js';
import { renderMarkers } from './gfs/markers.js';

function parseCsvLine(line) {
  const cells = [];
  let cur = '';
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (ch === '"') {
      if (quoted && line[i + 1] === '"') { cur += '"'; i += 1; }
      else quoted = !quoted;
    } else if (ch === ',' && !quoted) {
      cells.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  cells.push(cur);
  return cells;
}

function parseCsv(text) {
  const lines = String(text || '').split(/\r?\n/).filter((line) => line.trim());
  if (!lines.length) return [];
  const headers = parseCsvLine(lines.shift()).map((h) => h.trim());
  return lines.map((line, idx) => {
    const values = parseCsvLine(line);
    const row = { id: `csv-${idx + 1}` };
    headers.forEach((h, i) => { row[h || `col_${i}`] = values[i] ?? ''; });
    row.lat = Number(row.lat ?? row.latitude);
    row.lon = Number(row.lon ?? row.lng ?? row.longitude);
    row.name = String(row.name || row.location || `Location ${idx + 1}`).trim();
    return row;
  }).filter((row) => Number.isFinite(row.lat) && Number.isFinite(row.lon));
}

function normalizeLocations(payload) {
  const rows = Array.isArray(payload) ? payload : (payload?.locations || payload?.items || []);
  return rows.map((loc, idx) => ({
    ...loc,
    id: loc.id || loc.location_id || loc.location_key || `loc-${idx + 1}`,
    lat: Number(loc.lat ?? loc.latitude),
    lon: Number(loc.lon ?? loc.lng ?? loc.longitude),
    name: String(loc.name || loc.title || loc.location || `Location ${idx + 1}`).trim(),
  })).filter((loc) => Number.isFinite(loc.lat) && Number.isFinite(loc.lon));
}

export async function loadCsvLocations() {
  const apiPayload = await getJsonSafe('/gfs/api/locations', null, { timeoutMs: 10000, abortPrevious: false });
  const apiRows = normalizeLocations(apiPayload);
  if (apiRows.length) return apiRows;

  const res = await fetch('/static/data/fishloclist.csv', { cache: 'no-store' });
  if (!res.ok) throw new Error(`fishloclist.csv HTTP ${res.status}`);
  return parseCsv(await res.text());
}

export function renderCsvLocations({ locations, globeEl, maps3d, onSelect }) {
  return renderMarkers({ locations, globeEl, maps3d, onSelect });
}

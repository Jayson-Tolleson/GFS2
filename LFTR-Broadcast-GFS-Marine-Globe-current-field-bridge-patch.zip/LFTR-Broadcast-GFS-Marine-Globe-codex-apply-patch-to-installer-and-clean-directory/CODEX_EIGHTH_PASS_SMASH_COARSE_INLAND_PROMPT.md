# Codex Eighth Pass — Smash Inland Coarse/Placeholder Geometry

Goal: Inland-water must be real-vector-only. World/global overview may still show one representative lake per tile and temp labels, but the shoreline must come from real runtime NHD/ArcGIS vector tiles with raw vertices preserved. No static rounded/ellipse placeholder fallback. No simplified build output. No old simplified/cache artifacts promoted.

Required behavior:

- `/gfs/api/inland-water` always normalizes geometry to `vector`.
- World tier uses `lod=overview` and quantity-filters to one largest real vector lake per 1° tile.
- If real NHD runtime tiles/index are missing, return warming/no-data with diagnostics; do not draw placeholder/rounded lakes.
- Reject old cached artifacts when metadata indicates bootstrap/seed/demo/approx/static placeholder/simplified/low-detail/old coarse geometry, `render_simplified=true`, `raw_vertices_preserved=false`, or static overview fallback metadata.
- `scripts/build_nhdplus_hr_tiles.py` must ignore any legacy non-vector `NHDPLUS_GEOMETRY_MODE` request and always preserve raw source vertices.
- Zoomed-in regional/coastal/local/harbor tiers may render all accepted lakes and inland bait/thermal overlays.
- Frontend still prunes overview/detail DOM so world overview and detail do not stack.
- Keep the ocean-points NoneType fix and lightning deferred-warm guard from pass seven.

Validation:

```bash
python3 -m py_compile $(find server -name '*.py' -print)
python3 -m py_compile scripts/build_nhdplus_hr_tiles.py
bash -n scripts/*.sh deploy/*.sh deploy/lib/*.sh broadcast.sh install.sh
bash scripts/check_inland_real_vector_only_contract.sh
bash scripts/check_inland_no_coarse_geometry_contract.sh
bash scripts/check_inland_overview_replace_contract.sh
bash scripts/check_inland_bait_zoom_contract.sh
bash scripts/check_ocean_points_none_cache_contract.sh
bash scripts/check_lightning_deferred_warm_guard.sh
bash scripts/check_ocean_tile_scheduler_cap_contract.sh
```

Acceptance logs/payloads:

- Good world payload: `geometry_mode:"vector"`, `real_vector_required:true`, `static_placeholder_fallback_disabled:true`, `overview_only:true`, `inland_bait_render_allowed:false`.
- Good detail payload: `geometry_mode:"vector"`, `overview_only:false`, `inland_bait_render_allowed:true`.
- Bad: active inland-water URL or payload requests `geometry=coarse` or serves static/rounded placeholder lake outlines.

# Codex fifth-pass: remove inland-water coarse geometry path

Goal: keep the good global inland-water behavior, but remove the separate `coarse` geometry mode from active inland-water app paths.

Desired behavior:

- Global/world inland-water still appears quickly.
- World/global shows one representative lake per tile with the working temp label.
- The shoreline source should be vector/clear-shore, not a separate coarse geometry mode.
- Zoomed-in tiers replace the overview with detailed lake geometry and additional lakes.
- The overview/detail replacement contract remains: never stack old overview geometry and later detail geometry on the map.
- Inland bait remains gated until zoomed in.
- World tier still does not auto-build heavy NHD tiles from browser boot.

Implementation notes:

- Frontend `inlandWaterGeometryForTier()` must always return `vector`.
- `/gfs/api/inland-water` must not force `geometry="coarse"` for world/regional tiers. It should force `geometry="vector"` and use `lod=overview` for overview quantity behavior.
- `/gfs/api/inland-water/build-cache` must not report or request `geometry="coarse"` for skipped world-tier jobs.
- `_launch_inland_view_build()` must set `NHDPLUS_GEOMETRY_MODE=vector` for active app-launched builds.
- `inland_water_payload()` should normalize legacy `geometry=coarse`, `geometry=overview`, or `geometry=world_coarse` requests to vector.
- The one-lake-per-tile overview is a quantity/filter policy, not a separate coarse/simplified geometry path.
- Existing temp label logic stays intact.
- Existing global major-lake fallback stays intact for missing NHD index, but it is labeled as a lightweight overview fallback, not a coarse geometry mode.

Validation:

```bash
python3 -m py_compile $(find server -name '*.py' -print)
node --check static/js/gfs/*.js
bash -n scripts/*.sh deploy/*.sh deploy/lib/*.sh broadcast.sh install.sh
bash scripts/check_inland_no_coarse_geometry_contract.sh
bash scripts/check_inland_overview_replace_contract.sh
bash scripts/check_inland_temp_label_contract.sh
bash scripts/check_ocean_tile_scheduler_cap_contract.sh
bash scripts/check_no_wide_gfs_calls.sh
```

Acceptance:

- Browser debug for inland-water requests shows `geometry=vector` at world tier.
- Payload has `geometry_mode:"vector"` and `overview_only:true` for world/global.
- No active route forces `geometry="coarse"`.
- No active app-launched build sets `NHDPLUS_GEOMETRY_MODE=coarse`.
- World/global still draws one lake per tile with temp labels.
- Zoomed-in views replace overview with details instead of stacking.

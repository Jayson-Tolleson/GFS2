# Codex prompt — Inland-water overview/detail replacement pass

You are working on the LFTR Broadcast / GFS Marine Globe Quart app.

## Goal
Keep the new global inland-water overview behavior, but prevent the coarse/global overview and later high-detail inland-water payload from both remaining on the map at the same time.

The desired behavior is:

1. At world/global zoom:
   - render a lightweight inland-water overview quickly;
   - keep lake outlines clean and readable;
   - show about one representative closed lake per 1-degree tile;
   - keep the cool temperature labels from the coarse/world pass;
   - do not draw inland bait contours;
   - do not add every high-detail lake if a later NHD/runtime response arrives for the same world view.

2. At zoomed-in tiers:
   - replace the world overview with the detailed lake scene;
   - then render additional/detail lakes normally;
   - do not leave old overview shorelines or labels behind.

3. A newer inland-water draw must replace/prune stale inland-water DOM nodes. There should be only one active inland-water scene for the layer, not coarse plus high-detail leftovers.

## Implemented contract

- `static/js/gfs/inland-water.js`
  - Adds `selectInlandOverviewPolygons(...)`.
  - Adds a client-side one-lake-per-tile guard for world/overview payloads, even if the server returns extra high-detail polygons.
  - Adds render modes:
    - `overview_one_lake_per_tile`
    - `detail_all_accepted_lakes`
  - Adds per-render token tags:
    - `data-inland-render-mode`
    - `data-inland-render-token`
  - Adds `pruneExistingInlandRender(...)` so a new drawable inland-water payload removes stale DOM nodes from older coarse/detail passes.
  - Emits `inland-water/prune-stale-render` and `inland-water/client-overview-filter` diagnostics.

- `server/gfs/inland/payloads.py`
  - Runtime world-tier inland-water payloads now explicitly set:
    - `overview_only: true`
    - `inland_bait_render_allowed: false`
  - Non-world payloads can still return detail lakes.

## Acceptance

At global/world zoom:

- first pass should show coarse lake outlines and temp labels quickly;
- if a second high-detail inland-water payload arrives, it should not add all high-detail lakes on top of the overview;
- debug should show either `inland-water/client-overview-filter` or payload-level quantity filtering;
- debug may show `inland-water/prune-stale-render` when replacing an older inland-water render;
- there should not be two visible shoreline sets for the same lake/tile.

At closer zoom:

- the detailed lake payload should replace the world overview;
- more lakes can appear;
- temp labels remain guarded and should not crash.

## Validation

Run:

```bash
node --check static/js/gfs/*.js
python3 -m py_compile $(find server -name '*.py' -print)
bash -n scripts/*.sh deploy/*.sh deploy/lib/*.sh broadcast.sh install.sh
bash scripts/check_inland_temp_label_contract.sh
bash scripts/check_ocean_tile_scheduler_cap_contract.sh
bash scripts/check_inland_overview_replace_contract.sh
```

After restart, watch:

```bash
journalctl -u broadcast -n 200 --no-pager | grep -E "inland-water|global_lake_overview|ocean/tile-refresh"
```

Good signs:

- `inland-water/client-overview-filter`
- `inland-water/prune-stale-render`
- `overview_one_lake_per_tile`
- no `ReferenceError: tempLabelFontSize`
- no `ocean/tile-refresh scheduled=966` or `scheduled=1056`

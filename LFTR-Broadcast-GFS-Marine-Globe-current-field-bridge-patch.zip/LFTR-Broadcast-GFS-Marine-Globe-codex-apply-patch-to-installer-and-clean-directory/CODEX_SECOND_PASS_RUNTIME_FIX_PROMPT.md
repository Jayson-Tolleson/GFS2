# Codex second-pass prompt — LFTR GFS runtime orchestration

You are working on the LFTR Broadcast / GFS Marine Globe Quart app. This prompt is based on the post-deploy `journalctl` and browser debug results after the first big cache/TempLabel patch.

## Keep

- Keep all default pills ON: locations, clouds, rain, lightning, jetstream, bait, shark-intel, inland-water, boater.
- Do not solve runtime load by turning pills off.
- TempLabel `ReferenceError: tempLabelFontSize is not defined` is already fixed. Do not regress it.
- Wide HYCOM one-shot provider calls are already blocked. Preserve that.

## Observed after deploy

1. Ocean tile scheduling still reported hundreds of tiles:

   ```text
   ocean/provider-wide-request-skipped policy=tile_cache_only layer=bait ... tiles=1056
   ocean/tile-refresh scheduled=1056 tile_deg=1.0 layer=bait
   ocean/provider-wide-request-skipped policy=tile_cache_only layer=ocean ... tiles=966
   ocean/tile-refresh scheduled=966 tile_deg=1.0 layer=ocean
   ```

   The wide HYCOM request was skipped, but the scheduler still treated all split tiles as scheduled. This must become a real tier cap.

2. World-tier inland-water build still fired:

   ```text
   [inland-water/build] started ... bbox=-127.0000,33.5000,-103.0000,50.0000 tier=world
   ```

   World-tier browser boot/steady must read durable cache only. Build-cache should require explicit/admin intent.

3. Cloud/rain feature derivation still failed:

   ```text
   cloud_feature_derivation_failed
   invalid literal for int() with base 10: 'gfs-20-06:494712:frontal_shield'
   ```

   Do not call `int()` on string cloud feature ids/classes. Use stable string ids or hash-based numeric seeds.

4. Empty bait/boater repair still started/throttled at world tier:

   ```text
   scene_cache_empty_bait
   scene_cache_empty_boater
   scene-cache/empty-repair-throttled layers=["bait","boater"]
   ```

   At world tier, empty bait/boater/shark/ocean placeholders mean warming/cache-empty only. Do not start live repair.

5. Weather/jetstream bbox diagnostics still looked like fetch bboxes.

   Large cache-only boxes should be reported as `weather_cache_read_bbox` / `jetstream_cache_read_bbox`, while provider fetch bboxes are `null` when no provider fetch is allowed.

6. Inland temperature labels no longer crash but are not yet joining.

   Logs show `tempLabelsAttempted=0`, `tempLabelsRendered=0`, `tempLabelsErrors=0`. That is now a data join/enrichment issue, not a JS crash. Keep geometry persistent and add diagnostics like `tempJoinMiss` when companion temperature points cannot be matched to lake geometry.

## Acceptance

- No `ReferenceError: tempLabelFontSize`.
- No `cloud_global_full_bounds` in normal boot/steady scene paths.
- No `ocean/tile-refresh scheduled=966`, `scheduled=1056`, or other hundreds-of-tiles boot logs.
- World boot logs should look like `requested_tiles_total=966 scheduled=8 skipped_tiles_budget=958 partial_refresh=true` or skip ocean repair entirely.
- World tier does not live-repair bait/boater/shark/ocean placeholders.
- World tier `/gfs/api/inland-water` read path and browser boot do not auto-launch build-cache.
- `/gfs/api/inland-water/build-cache` at world tier returns `status=skipped` unless `explicit=1`, `admin=1`, or `force=1` is supplied.
- Cloud feature derivation does not fail on ids like `gfs-20-06:494712:frontal_shield`.
- Rain remains renderable even if cloud feature classes are partial.
- Empty payloads do not clear old visuals.

## Validation

```bash
python3 -m py_compile $(find server -name '*.py' -print)
node --check static/js/gfs/*.js static/js/gfs/layers/*.js
bash -n scripts/*.sh deploy/*.sh deploy/lib/*.sh broadcast.sh install.sh
bash scripts/check_no_wide_gfs_calls.sh
bash scripts/check_inland_temp_label_contract.sh
bash scripts/diag_viewport_tile_cache_render_contract.sh http://127.0.0.1:8000 '-126,28,-114,40'
bash scripts/diag_bait_boater_end_to_end.sh http://127.0.0.1:8000 '-126,28,-114,40'
```

If the server is not running, live diagnostics should fail clearly, but static checks must pass.

# Codex seventh pass: ocean points NoneType + lightning stability

Fix the issues found by the ocean-points diagnostic after the inland-water zoom work.

Observed diagnostic:

- Coastal scene frame for `bbox=-119,32.8,-117,34.4` schedules correctly:
  `requested_tiles_total=4 scheduled=4 scene_tier=coastal`.
- HYCOM tile fetches succeed for all 4 one-degree tiles and return `sst`, `sss`, `ssu`, `ssv` arrays.
- After successful tile fetches, boater warm fails:
  `[gfs/cache] split warm failed label=scene-cache-boater ... err='NoneType' object does not support item assignment`.
- `/gfs/api/field?field=current` still returns `current_points: []`, `ocean_points: []`, `points: []` because the boater/ocean warm is not promoted.

Required fixes:

1. In `server/gfs_service_parts/ocean_bait_frame.py`, `_schedule_split_warm()` must never do `payload.setdefault("cache", {})[...]` blindly. If `payload.cache` exists but is `None`, normalize it to `{}` first.
2. Tile-merged live HYCOM payloads must include a non-null `cache` dict even when `ok:true`.
3. `boats_payload()` must output a dict cache object even if the underlying ocean payload had `cache:null`.
4. Do not promote empty ocean-backed payloads. If no points, no boats, and no polygons, keep previous visuals and mark warm rejected.
5. Keep coastal tile scheduler behavior: 4 tiles requested, 4 scheduled is correct for the tested bbox.
6. Remove remaining server-side inland-water `geometry=("vector" if detail_allowed else "coarse")`; temp companion must always use `geometry="vector"`.
7. Lightning: keep pill ON and cached flashes renderable, but do not run in-process GOES/GLM NetCDF deferred warm by default. Gate it behind `GFS_ENABLE_GLM_DEFERRED_WARM=1` because NetCDF/HDF errors can crash Hypercorn below Python exception handling.

Acceptance:

- No `NoneType object does not support item assignment` from `scene-cache-boater`.
- Coastal `/gfs/api/scene-frame?...layers=bait,boater,shark-intel...` returns/promotes boater/ocean current points once HYCOM tiles succeed.
- `/gfs/api/field?field=current` shows nonzero `points`/`current_points` after warm succeeds, or clear diagnostics explaining why all cells were rejected.
- No active runtime path requests `geometry=coarse` for inland water.
- Lightning cache shell says GLM deferred warm is disabled unless `GFS_ENABLE_GLM_DEFERRED_WARM=1`.

# Codex sixth pass — inland bait only on zoomed detail

Goal: keep the improved inland-water global overview, but make the bait policy explicit and enforceable.

Required behavior:

- Keep all pills ON.
- Remove/avoid coarse inland-water geometry. Use vector shoreline everywhere.
- At world/global tier, render only the clean inland-water overview: one representative lake per tile, clear vector outline, and surface-temperature labels.
- At world/global tier, never render inland bait/thermal contours, bait targets, or bait score polygons.
- At regional/coastal/local/harbor detail tier, allow detailed inland-water geometry and inland bait/thermal contours.
- When transitioning between overview and detail, prune stale inland-water render nodes so overview and detail do not stack.
- Backend payloads must set `overview_only` and `inland_bait_render_allowed` consistently by scene tier.
- Frontend renderer must obey those fields and also fall back to camera range/tier when metadata is missing.

Acceptance:

- World debug shows `overview_only:true`, `inland_bait_render_allowed:false`, one-lake-per-tile outline/temp labels.
- Detail debug shows `overview_only:false`, `inland_bait_render_allowed:true`, and inland bait overlays can draw.
- No `geometry=coarse` inland-water requests.
- No overview/detail stacking.

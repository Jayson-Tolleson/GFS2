# Codex third-pass prompt — hard scheduler cap + global lake overview

You are working on the LFTR Broadcast / GFS Marine Globe Quart app.

Goal: fix the remaining backend scheduler/daemon path that can still emit `ocean/tile-refresh scheduled=966/1056`, and bring back lightweight global lakes at world zoom without reintroducing heavy NHD/ArcGIS boot builds.

Do not turn off pills. Keep default pills ON.

## 1. Main bug: uncapped backend ocean tile scheduling

Observed bad journal lines:

```text
ocean/provider-wide-request-skipped policy=tile_cache_only layer=bait ... tiles=1056
ocean/tile-refresh scheduled=1056 tile_deg=1.0 layer=bait
ocean/provider-wide-request-skipped policy=tile_cache_only layer=ocean ... tiles=966
ocean/tile-refresh scheduled=966 tile_deg=1.0 layer=ocean
```

The first line is good: a wide HYCOM provider call is blocked. The second line is the bug: splitting a world bbox into 966/1056 provider tiles and scheduling all of them still overloads boot/daemon refresh.

Acceptance:

```text
ocean/tile-refresh requested_tiles_total=966 scheduled=8 skipped_tiles_budget=958 partial_refresh=true ... layer=ocean
ocean/tile-refresh requested_tiles_total=1056 scheduled=8 skipped_tiles_budget=1048 partial_refresh=true ... layer=bait
```

Never emit the old uncapped log string:

```text
ocean/tile-refresh scheduled=966
ocean/tile-refresh scheduled=1056
ocean/tile-refresh scheduled=<hundreds>
```

World tier may schedule 0-8 ocean/bait/boater/shark tiles max. Regional max 24. Coastal/local/harbor max 64. Prioritize tiles nearest camera/visible-bbox center. Preserve old visuals on cache miss/failure.

## 2. Global lakes at world zoom

Bring back global lake outlines, but keep them cheap.

Rules:

- Real NHD/ArcGIS runtime tiles always win.
- If the NHD runtime tile index is missing, world tier may render a lightweight static major-lake overview fallback.
- Fallback should be outline-only, overview-only, approximate, and clearly tagged as fallback.
- Keep at most one representative lake per 1-degree world tile.
- Do not launch `/gfs/api/inland-water/build-cache` at world boot.
- Use the existing `inland_water_temp` companion to sample GFS/NCSS surface temperature at lake centroids and attach temp labels.
- Regional/local detail still depends on real NHD runtime tiles.

Expected debug after patch:

```text
source=static_global_lake_overview_fallback_when_runtime_nhd_index_missing
count>0
global_lake_overview.one_lake_per_tile=true
tempLabelsAttempted>0 once inland_water_temp companion has points
```

## 3. Validation commands

Run:

```bash
python3 -m py_compile $(find server -name '*.py' -print)
node --check static/js/gfs/*.js
bash -n scripts/*.sh deploy/*.sh deploy/lib/*.sh broadcast.sh install.sh
bash scripts/check_no_wide_gfs_calls.sh
bash scripts/check_inland_temp_label_contract.sh
bash scripts/check_ocean_tile_scheduler_cap_contract.sh
```

On the server after restart:

```bash
journalctl -u broadcast -n 200 --no-pager | grep -E "ocean/provider-wide|ocean/tile-refresh|global_lake_overview|inland-water/build"
```

Good:

```text
ocean/tile-refresh requested_tiles_total=966 scheduled=8 skipped_tiles_budget=958 partial_refresh=true
```

Bad:

```text
ocean/tile-refresh scheduled=966
[inland-water/build] started ... tier=world
```

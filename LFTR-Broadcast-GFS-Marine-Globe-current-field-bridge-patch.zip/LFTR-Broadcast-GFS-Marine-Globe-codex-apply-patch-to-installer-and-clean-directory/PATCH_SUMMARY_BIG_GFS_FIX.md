# Big GFS runtime orchestration fix summary

Applied to this package:

- Kept default pills ON; changed semantics toward cache-visible and tier-budgeted refresh.
- Removed normal frontend scene bbox use of `cloud_global_full_bounds`.
- Added cache-only world weather bbox source in frontend diagnostics.
- Added scene tier tile budget metadata for world/regional/coastal/harbor.
- Capped cache warm scheduling through scene refresh tile budgets and surfaced diagnostics:
  - `requested_tiles_total`
  - `tiles_scheduled` / `scheduled_tiles`
  - `skipped_tiles_budget`
  - `partial_refresh`
  - `remaining_tiles`
  - `next_refresh_allowed_at`
- Added world-tier live ocean repair guard for bait/boater/shark/ocean layers in scene cache refresh.
- Fixed inland TempLabel crash by replacing undeclared `tempLabelFontSize`/`tempLabelAltitude` calls with `getInlandTempLabelStyle(ctx)`.
- Added robust inland temp parsing and Celsius conversion.
- Added invalid lat/lng/altitude rejection before creating `gmp-marker-3d` TempLabels.
- Added lake-enrichment TempLabel diagnostics counters.
- Consolidated root `README.md` as authoritative docs and moved old root markdown note files to `docs/archive/`.
- Replaced `docs/HYCOM_PROVIDER.md` with a pointer to root `README.md`.
- Added `scripts/check_inland_temp_label_contract.sh`.
- Updated `scripts/check_no_wide_gfs_calls.sh` to fail on `cloud_global_full_bounds` in active scene/cache code.
- Added environment knobs to `.env.example`.

Validation run in this sandbox:

```bash
python3 -m py_compile $(find server -name '*.py' -print)
node --check static/js/gfs/*.js
bash -n scripts/*.sh deploy/*.sh deploy/lib/*.sh broadcast.sh install.sh
bash scripts/check_no_wide_gfs_calls.sh
bash scripts/check_inland_temp_label_contract.sh
```

Result: static validation passed. `check_no_wide_gfs_calls.sh` passed with warnings for existing comments/review-only clear functions; no active fail patterns found.

Live diagnostics were attempted but failed because no local server was running on `127.0.0.1:8000` in this sandbox. Run these on the server after install/restart:

```bash
bash scripts/diag_viewport_tile_cache_render_contract.sh http://127.0.0.1:8000 '-126,28,-114,40'
bash scripts/diag_bait_boater_end_to_end.sh http://127.0.0.1:8000 '-126,28,-114,40'
```

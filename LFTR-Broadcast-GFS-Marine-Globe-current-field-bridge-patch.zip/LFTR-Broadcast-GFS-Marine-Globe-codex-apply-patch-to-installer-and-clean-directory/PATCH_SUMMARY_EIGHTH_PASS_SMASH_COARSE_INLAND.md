# Patch Summary — Eighth Pass: Smash Inland Coarse/Placeholder Geometry

This pass makes Inland Waters real-vector-only.

Changed:

- `server/gfs/inland/payloads.py`
  - Disables the embedded static major-lake/ellipse fallback by default.
  - Adds `static_placeholder_fallback_disabled` and `real_vector_required` diagnostics.
  - Rejects old low-detail/simplified/static placeholder runtime cache artifacts before render/promotion.
  - Keeps world overview as quantity filtering only: one real vector NHD lake per 1° tile.

- `scripts/build_nhdplus_hr_tiles.py`
  - Ignores legacy non-vector geometry mode requests.
  - Always writes vector/raw-vertex-preserved tile products.
  - Removes source-path thinning from generated tiles.

- `.env.example` and `README.md`
  - Set `LFTR_GLOBAL_LAKE_OVERVIEW_ENABLED=0` by default.
  - Documents that missing real NHD tiles should return warming/no-data instead of rounded placeholders.

- `scripts/check_inland_real_vector_only_contract.sh`
  - New contract check for real-vector-only Inland Waters.
  - Works even if Node is not installed; JS syntax check is optional.

Expected behavior:

- Global/world: real vector NHD lake outlines only, one lake per tile, temp labels when companion data exists, no inland bait.
- Zoomed in: detailed real vector lakes and inland bait/thermal overlays.
- If the NHD index/tiles are missing: no rounded placeholder lakes are rendered.

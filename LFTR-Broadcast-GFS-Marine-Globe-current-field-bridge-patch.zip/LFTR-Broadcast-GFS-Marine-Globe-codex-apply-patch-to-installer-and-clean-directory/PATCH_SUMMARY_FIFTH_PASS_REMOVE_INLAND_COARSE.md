# Fifth-pass patch summary — remove inland-water coarse geometry mode

This patch removes the active inland-water `coarse` geometry branch while preserving the improved global lake overview.

## Files changed

- `static/js/gfs/main.js`
  - `inlandWaterGeometryForTier()` now always returns `vector`.
  - World/global overview is treated as quantity gating, not geometry simplification.

- `server/gfs/routes.py`
  - `/gfs/api/inland-water` no longer forces `geometry="coarse"` for world/regional overview.
  - `/gfs/api/inland-water/build-cache` skip responses now report `geometry:"vector"`.
  - Active build launcher forces `NHDPLUS_GEOMETRY_MODE=vector`.

- `server/gfs/inland/payloads.py`
  - Legacy geometry aliases are normalized to vector.
  - Payloads expose `geometry_mode:"vector"` with `overview_only:true` at world/global.
  - The one-lake-per-tile behavior remains a filter policy.

- `static/js/gfs/inland-water.js`
  - The stale render prune diagnostic now refers to overview/detail replacement rather than coarse/detail overlap.

- `scripts/check_inland_no_coarse_geometry_contract.sh`
  - New static contract check verifying active inland-water app paths no longer force coarse geometry.

- `README.md`
  - Updated inland-water policy to describe vector overview + detail replacement.

## Expected behavior

World/global:

- Fast lake overview.
- One representative vector lake outline per tile.
- Working surface-temp labels.
- No inland bait.
- No detail/overview stacking.

Zoomed in:

- Overview is replaced by detailed lake geometry.
- Additional lakes can render.
- Inland bait/detail behavior remains gated by tier.

## Validation status

Static checks passed in the package sandbox.

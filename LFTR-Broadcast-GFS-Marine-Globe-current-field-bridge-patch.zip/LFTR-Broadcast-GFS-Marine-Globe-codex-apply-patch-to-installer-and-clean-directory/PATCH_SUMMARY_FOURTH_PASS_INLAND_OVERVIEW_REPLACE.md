# Fourth-pass patch summary — inland-water overview/detail replacement

This pass keeps the successful global inland-water overview and temp labels, but prevents the later high-detail inland-water response from staying on the globe at the same time as the coarse overview.

## What changed

### Frontend

`static/js/gfs/inland-water.js`

- Added a world/overview display mode: `overview_one_lake_per_tile`.
- Added a zoomed detail display mode: `detail_all_accepted_lakes`.
- Added client-side one-lake-per-tile filtering for world/overview payloads, even if a later runtime/NHD payload contains extra polygons.
- Added render-token tagging for inland-water DOM nodes.
- Added stale render pruning so a new inland-water draw removes older coarse/detail leftovers.
- Added debug diagnostics:
  - `inland-water/client-overview-filter`
  - `inland-water/prune-stale-render`

### Backend

`server/gfs/inland/payloads.py`

- Runtime world-tier inland-water payloads now explicitly mark `overview_only=true`.
- Runtime world-tier inland-water payloads explicitly set `inland_bait_render_allowed=false`.
- Detail tiers still return detail lakes.

### Diagnostics

Added:

- `scripts/check_inland_overview_replace_contract.sh`

## Intended behavior

World/global zoom:

- fast coarse/overview lake outlines;
- about one representative lake per tile;
- clean temp labels;
- no duplicate high-detail shoreline overlay;
- no inland bait contours.

Zoomed-in tiers:

- detailed lakes replace the overview scene;
- additional lakes can render normally;
- old overview nodes are pruned.

# Second-pass LFTR GFS runtime fix summary

This package revises the previous big cache/TempLabel patch using the next journal/debug findings.

## Files changed

- `server/gfs_service_parts/ocean_bait_frame.py`
- `server/gfs_service_parts/lightning_cache_media.py`
- `server/gfs_service_parts/atmosphere.py`
- `server/gfs/routes.py`
- `static/js/gfs/main.js`
- `scripts/diag_viewport_tile_cache_render_contract.sh`
- `.env.example`
- `README.md`
- `CODEX_SECOND_PASS_RUNTIME_FIX_PROMPT.md`

## What changed

- Added hard tier-based HYCOM/ocean provider tile caps.
  - World default: max 8 ocean/bait/boater/shark provider tiles.
  - Regional default: 24.
  - Coastal/local/harbor default: 64.
- Added center-first provider tile prioritization.
- Changed ocean tile logs from misleading `scheduled=<all tiles>` to explicit diagnostics:
  - `requested_tiles_total`
  - `scheduled_tiles` / `tiles_scheduled`
  - `skipped_tiles_budget`
  - `partial_refresh`
  - `remaining_tiles`
  - `next_refresh_allowed_at`
- Added backend guard so world-tier scene-cache refresh cannot schedule ocean-heavy live repair for bait/boater/shark/ocean placeholders.
- Added frontend guard so world-tier empty bait/boater placeholders are logged as skipped by tier policy instead of starting/throttling empty repair.
- Added frontend guard so world-tier inland-water browser boot reads cache only and does not queue build-cache.
- Added server route guard so `/gfs/api/inland-water/build-cache` skips world-tier browser calls unless `explicit=1`, `admin=1`, or `force=1` is supplied.
- Fixed the cloud `frontal_shield` parse bug by replacing unsafe `int(tile.seed)` parsing with a safe hash/numeric seed helper.
- Split cache-read vs provider-fetch bbox diagnostics in frontend/server contracts:
  - `weather_cache_read_bbox`
  - `weather_fetch_bbox`
  - `jetstream_cache_read_bbox`
  - `jetstream_fetch_bbox`
- Extended the viewport diagnostic script to print/fail on scene-frame fetch bboxes and excessive scheduled tiles.

## Expected after deploy

- No `ReferenceError: tempLabelFontSize`.
- No normal boot/steady `cloud_global_full_bounds` provider path.
- No `ocean/tile-refresh scheduled=966` or `scheduled=1056` on world boot.
- World tier ocean-heavy cache-empty layers stay warming/cache-visible without live HYCOM repair.
- World tier inland-water does not auto-build during browser boot.
- Cloud feature derivation does not fail from string ids like `gfs-20-06:494712:frontal_shield`.

## Follow-up still possible

Temp labels are safe now, but if `tempLabelsAttempted=0` persists after deploy, the next task is the data join between `inland_water_temp` scene-cache companion payloads and individual lake geometry/centroids. That is not the original crash path.

# Seventh pass summary: ocean points + lightning stability

Changes:

- Fixed boater split-warm `NoneType` crash by normalizing `payload.cache` to a dict before warm metadata assignment.
- Added cache metadata to live tile-merged HYCOM ocean payloads.
- Made boater payload cache metadata robust when the source ocean payload has `cache:null`.
- Removed the remaining active inland-water temp companion `geometry=coarse` branch; it now always requests vector geometry.
- Disabled in-process GOES/GLM deferred lightning warm by default via `GFS_ENABLE_GLM_DEFERRED_WARM=false`; cached/stale lightning remains renderable.

Expected good logs:

```text
ocean/tile-refresh requested_tiles_total=4 scheduled=4 ... scene_tier=coastal
# no scene-cache-boater NoneType split warm failure
```

Expected lightning behavior:

- Fresh/stale cached flashes render.
- Empty lightning payload does not clear clouds/rain.
- GLM NetCDF warm runs only if explicitly enabled.

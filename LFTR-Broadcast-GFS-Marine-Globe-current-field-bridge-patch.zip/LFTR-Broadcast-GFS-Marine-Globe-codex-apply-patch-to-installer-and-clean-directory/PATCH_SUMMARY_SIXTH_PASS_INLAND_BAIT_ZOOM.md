# Sixth pass summary — inland bait zoom gate

This pass makes the intended inland-water behavior explicit:

- World/global tier keeps the clean vector shoreline overview: one representative lake per tile plus surface-temperature labels.
- Inland bait/thermal contour overlays are blocked at world/global tier.
- Regional/coastal/local/harbor tiers may render detailed lakes plus inland bait overlays.
- Comments, README policy, and server route policy strings now match that contract.
- A contract script checks the key frontend and backend gates.

# Third-pass scheduler + global lakes patch summary

This patch targets the two requested items:

1. Fix the backend scheduler/daemon path that can still turn a world viewport into hundreds of HYCOM provider-tile jobs.
2. Restore a visible world/global inland-water overview by adding a cheap one-lake-per-world-tile fallback when the runtime NHD tile index is missing.

## Changed files

- `server/gfs_service_parts/ocean_bait_frame.py`
  - Keeps the hard scheduler-cap code and diagnostics: `requested_tiles_total`, `scheduled`, `skipped_tiles_budget`, `partial_refresh`, `remaining_tiles`, `scene_tier`.
  - World tier defaults to max 8 ocean provider tiles.

- `server/gfs/inland/payloads.py`
  - Adds `GLOBAL_LAKE_OVERVIEW_LAKES` and fallback generation helpers.
  - If real NHD runtime tiles are missing at world tier, returns approximate major lake outlines instead of empty geometry.
  - Keeps one representative major lake per 1-degree tile.
  - Tags fallback geometry as `static_global_lake_overview_fallback_when_runtime_nhd_index_missing` so it is not confused with real NHD data.

- `scripts/check_ocean_tile_scheduler_cap_contract.sh`
  - Fails if the old uncapped `ocean/tile-refresh scheduled=` log string still exists in active code.
  - Verifies the cap helper and diagnostics are present.

- `scripts/check_no_wide_gfs_calls.sh`
  - Keeps failing active global/wide provider-fetch patterns, but permits the explicit lightweight global lake overview fallback.

- `.env.example`
  - Adds global lake overview knobs.

- `README.md`
  - Documents the world lake overview fallback.

## Runtime expectation

World boot with a huge bbox should never schedule hundreds of HYCOM tiles. The good log shape is:

```text
ocean/tile-refresh requested_tiles_total=966 scheduled=8 skipped_tiles_budget=958 partial_refresh=true scene_tier=world layer=ocean
```

World boot with missing NHD tile index should still show some major lake outlines:

```text
source=static_global_lake_overview_fallback_when_runtime_nhd_index_missing
count>0
```

Real NHD/ArcGIS tiles override the fallback whenever present.

# LFTR Broadcast / GFS Marine Globe

LFTR Broadcast / GFS Marine Globe is a Python 3 Quart web app for `/`, `/broadcast`, `/watch`, and `/gfs`. The `/gfs` view uses Google Maps Photorealistic 3D to render marine/weather intelligence layers, including locations/fish markers, clouds, rain, lightning, jetstream balloons, bait, shark intel, inland water, and boater awareness.

## Runtime architecture

The runtime path is cache-first and tile-bounded:

```text
frontend viewport
→ /gfs/api scene/cache endpoint
→ tile/cache manager
→ provider adapters only for missing/expired viewport tiles
→ validate, normalize, and reject empty/all-NaN payloads
→ promote only valid data
→ merge cached tiles
→ return renderable payload
```

Route handlers and render payload builders must not bypass cache and call NOAA/NDBC/ERDDAP/NCSS/HYCOM/RTOFS providers directly. Provider calls live in provider modules/adapters only, after bbox normalization, scene tier detection, tile split, cache check, tile budget check, and TTL check.

## Pill and layer policy

Default pills remain visually ON:

- locations
- clouds
- rain
- lightning
- jetstream
- bait
- shark-intel
- inland-water
- boater

An ON pill means cache-visible and tier-budgeted. It does not mean unlimited live provider warmup. Boot reads last-good cache immediately, preserves valid rendered visuals, schedules bounded refresh only if allowed by scene tier/TTL/tile budget, and never clears old visuals before replacement payload validates.

Empty cache placeholders such as `scene_cache_empty_*` mean cache warming or cache miss, not necessarily a crash. Empty/warming payloads must not erase existing visuals.

## Cache policy

- Last-good cache is preferred for first paint.
- Empty provider results, all-NaN grids, timeouts, and incomplete payloads are rejected from promotion.
- Stale-but-valid cache may remain visible while refresh runs.
- Tile TTLs govern refresh cadence.
- Normal boot/steady scene-frame paths must not perform global or near-global provider fetches.
- Refresh is viewport/tile-only and center-prioritized.
- Lightning flashes are short-lived TTL event particles; expired flashes fade/remove independently and never clear clouds/rain.

## Scene tier policy and tile budgets

Scene tier is derived from the visible bbox span/area.

| Tier | Behavior | Ocean refresh budget | Weather refresh budget |
|---|---|---:|---:|
| world | cache/last-good only for heavy ocean layers; no bait/boater/shark live repair | 0–8 | 8–16 |
| regional | limited clouds/rain/jetstream refresh; ocean still capped | 24 | 48 |
| coastal | bait/boater/shark live refresh allowed, tile-bounded | 64 | 64 |
| local/harbor | highest detail live refresh allowed, still tile-bounded | 64 | 64 |

Wide viewports that resolve to hundreds of tiles must schedule only the budgeted subset and report diagnostics such as `requested_tiles_total`, `tiles_scheduled`, `skipped_tiles_budget`, `partial_refresh`, `remaining_tiles`, and `next_refresh_allowed_at`.

## No global/wide boot fetches

The old `cloud_global_full_bounds` near-global bbox must not appear in normal `/gfs` boot or steady scene-cache paths. Clouds/rain/lightning/jetstream use viewport tile cache, already-decoded local/server GFS subsets, or cache-only warming placeholders. Any world overview warmer must be explicit, low-frequency, capped, and separate from user scene-frame requests.

HYCOM/ocean provider policy:

- Small HYCOM tile requests are preserved.
- Memory cache hits are used first.
- Huge HYCOM bboxes are never called directly.
- Empty/all-NaN/timeout responses are not promoted.
- World boot does not schedule hundreds of HYCOM tiles.

## Layers

### Locations / fish markers

Locations render immediately and are safe to build from local/static data.

### Clouds

Clouds render from cache/decoded GFS subsets. Cloud feature derivation failures must preserve old clouds and return diagnostics naming the failed field instead of destructively rerendering. Full 721x1440 cloud derivation must respect TTL and dedupe.

### Rain

Rain keeps valid precip columns renderable even if cloud feature derivation fails. Rain updates are non-destructive and TTL-bound.

### Lightning

Lightning uses ephemeral TTL flashes only. Empty lightning means no current/proxy flashes are available; it must not trigger global weather refresh and must never clear clouds/rain.

### Jetstream

Jetstream should use cache/viewport tile data and must not inherit a global cloud bbox during boot/steady.

### Bait, shark-intel, and boater

World tier cache-empty states do not force live HYCOM repair. Coastal/local/harbor tiers may schedule capped tile refreshes. Provider attempts must log start/result diagnostics and must not promote empty or all-NaN data.

### Inland water

Lake/river geometry reads from durable cache. The read path must not launch wide builders. Geometry persists while temp/bait labels enrich. TempLabels are child overlays; label failure must not clear shoreline geometry.

Individual inland-water geometry retention is controlled by:

```bash
INLAND_WATER_CACHE_RETENTION_DAYS=60
```

## TempLabel contract

`static/js/gfs/inland-water.js` defines `getInlandTempLabelStyle(ctx = {})`, which returns:

```js
{ fontSize, textColor, background, borderColor, shadow, altitude }
```

Temp labels render only for finite temperatures. Accepted input fields are `temp_f`, `temperature_f`, `water_temp_f`, `surface_temp_f`, `tempC`, `temp_c`, `temperature_c`, `water_temp_c`, and `surface_temp_c`. Fahrenheit displays as `72°F`; Celsius converts to Fahrenheit. Missing/null temperatures are skipped, never rendered as `NaN°F`.

TempLabel marker positions require finite lat/lng/altitude. Invalid positions are rejected and counted in diagnostics. Day mode uses dark text on a light translucent background; night mode uses light text on a dark translucent background. Suggested font sizes are world 10px, regional 11px, coastal 12px, and local/harbor 14px.


### Global lake overview fallback

World zoom may render a lightweight major-lake overview when the durable NHD runtime tile index is missing. This fallback is intentionally cheap: it keeps at most one representative major lake per 1-degree world tile, uses approximate overview-only outlines, and waits for the `inland_water_temp` companion layer to attach GFS/NCSS surface-temperature labels. Real NHD/ArcGIS runtime tiles always take precedence when present, and regional/local zoom still relies on real runtime tiles for detail.

Key knobs:

```bash
LFTR_GLOBAL_LAKE_OVERVIEW_ENABLED=1
LFTR_GLOBAL_LAKE_OVERVIEW_VERTICES=40
LFTR_GLOBAL_LAKE_OVERVIEW_MAX_LAKES=96
LFTR_GLOBAL_LAKE_OVERVIEW_MIN_AREA_KM2=18
```

## Install and run

Install entrypoints delegate to the deploy scripts:

```bash
bash broadcast.sh
bash install.sh
bash deploy/install.sh
```

The systemd service should run through:

```bash
scripts/run_broadcast_service.sh
```

Common service commands:

```bash
sudo systemctl daemon-reload
sudo systemctl restart broadcast.service
sudo systemctl status broadcast.service --no-pager
journalctl -u broadcast.service -n 200 --no-pager
```

## Diagnostics and validation

Static checks:

```bash
python3 -m py_compile $(find server -name '*.py' -print)
node --check static/js/gfs/*.js static/js/gfs/layers/*.js
bash -n scripts/*.sh deploy/*.sh deploy/lib/*.sh broadcast.sh install.sh
bash scripts/check_no_wide_gfs_calls.sh
bash scripts/check_inland_temp_label_contract.sh
```

Live diagnostics, with the server running:

```bash
bash scripts/diag_viewport_tile_cache_render_contract.sh http://127.0.0.1:8000 '-126,28,-114,40'
bash scripts/diag_bait_boater_end_to_end.sh http://127.0.0.1:8000 '-126,28,-114,40'
```

If the server is not running, live diagnostics fail clearly while static syntax/contract checks should still pass.

## Troubleshooting

- `scene_cache_empty_*` means cache warming/empty, not necessarily a server crash.
- `cloud_global_full_bounds` should not appear in normal boot/steady diagnostics.
- HYCOM timeouts should not poison cache.
- `TempLabel ReferenceError` is fixed by using `getInlandTempLabelStyle` and guarded temp parsing.
- Empty lightning means no recent/proxy flashes are available.
- Cloud feature derivation failures should preserve old clouds and explain the failed field.

## Environment knobs

Important cache/tile/TTL settings:

```bash
GFS_WEATHER_TTL_SECONDS=900
GFS_CURRENT_TTL_SECONDS=900
GFS_CLOUD_DATA_TTL_SECONDS=600
GFS_RAIN_TTL_SECONDS=600
GFS_SST_TTL_SECONDS=1800
GFS_BAIT_TTL_SECONDS=900
GFS_BOATS_TTL_SECONDS=300
GFS_JETSTREAM_TTL_SECONDS=900
GFS_WORLD_OCEAN_REFRESH_MAX_TILES=8
GFS_REGIONAL_OCEAN_REFRESH_MAX_TILES=24
GFS_COASTAL_OCEAN_REFRESH_MAX_TILES=64
GFS_HARBOR_OCEAN_REFRESH_MAX_TILES=64
GFS_WORLD_WEATHER_REFRESH_MAX_TILES=16
GFS_REGIONAL_WEATHER_REFRESH_MAX_TILES=48
GFS_COASTAL_WEATHER_REFRESH_MAX_TILES=64
GFS_HARBOR_WEATHER_REFRESH_MAX_TILES=64
GFS_TILE_WARM_BUILD_LIMIT=8
GFS_ALWAYS_ON_MAX_TILES=16
GFS_GLM_FLASH_TTL_SECONDS=600
GFS_LIGHTNING_FADE_OUT_MS=2200
GFS_ENABLE_GLM_DEFERRED_WARM=false
INLAND_WATER_CACHE_RETENTION_DAYS=60
```


## Second-pass runtime guardrails

The June 2026 second-pass runtime patch keeps every default pill ON while preventing world-zoom boot from behaving like an unlimited live provider warmup.

Key rules:

- Wide HYCOM/RTOFS requests are split into provider-safe tiles and then hard-capped by scene tier.
- World tier ocean-heavy layers (`bait`, `boater`, `shark-intel`, `ocean/current`) are cache-visible only; empty placeholders do not trigger live repair.
- World tier inland-water browser boot reads durable runtime cache only. `/gfs/api/inland-water/build-cache` skips world-tier browser calls unless `explicit=1`, `admin=1`, or `force=1` is supplied.
- Cache-read bboxes are reported separately from provider-fetch bboxes. Large world weather/jetstream cache reads should appear under `weather_cache_read_bbox` / `jetstream_cache_read_bbox`; provider fetch bboxes should be `null` when provider fetch is disallowed.
- Cloud feature ids are strings. Code must not call `int()` on ids like `gfs-20-06:494712:frontal_shield`; use stable hashes/seeds instead.

Expected world boot diagnostics:

```text
requested_tiles_total=966 scheduled_tiles=8 skipped_tiles_budget=958 partial_refresh=true
```

or the ocean-heavy layer should be skipped by tier policy with `scheduled_tiles=0`.

### Inland-water overview/detail replacement

World/global zoom uses a real-vector inland-water overview: one representative NHD lake outline per 1-degree tile with surface-temperature labels when available. Inland waterways no longer use a separate simplified geometry mode, and the static/placeholder rounded-lake fallback is disabled. Runtime NHD/detail payloads may arrive later, but the frontend treats world-tier inland-water as a single active overview scene and prunes stale overview/detail DOM nodes so both versions do not remain on the map together. Zoomed-in tiers replace the overview with detailed lake geometry and can show additional lakes.

Validation:

```bash
bash scripts/check_inland_overview_replace_contract.sh
```


## Inland water overview and bait zoom policy

Inland-water is intentionally split into two visual modes:

- **World/global overview:** real NHD vector shoreline only, one representative lake per 1° tile, with surface-temperature labels when available. No simplified/placeholder geometry is used, and inland bait/thermal contours are not rendered at this tier.
- **Detail zoom:** regional, coastal, local, and harbor tiers may replace the overview with detailed lake geometry and render inland bait/thermal contour overlays. The renderer prunes the previous overview scene before drawing the detail scene, so overview and detail should not stack.

The server contract fields are `overview_only` and `inland_bait_render_allowed`. World payloads must return `overview_only: true` and `inland_bait_render_allowed: false`; detail-tier payloads may return `overview_only: false` and `inland_bait_render_allowed: true`.


## Seventh-pass notes: ocean points / lightning stability

- Coastal HYCOM tile scheduling should remain capped and log requested/scheduled tile counts.
- Boater split-warm payloads must normalize `cache` metadata to a dict before assignment so `cache: null` cannot cause `'NoneType' object does not support item assignment`.
- Tile-merged HYCOM ocean payloads include cache metadata even when live and valid.
- Inland-water temp companion always requests `geometry=vector`; no server-side simplified/placeholder fallback should remain in active scene paths.
- Lightning remains cache-visible, but in-process GOES/GLM NetCDF deferred warm is disabled by default with `GFS_ENABLE_GLM_DEFERRED_WARM=false` to avoid HDF/NetCDF crashes in Hypercorn.

# HYCOM provider notes

The authoritative runtime/provider policy now lives in the root `README.md`.

HYCOM must be called only through provider adapters after bbox normalization, scene-tier detection, tile splitting, cache/TTL checks, and tile-budget checks. Normal `/gfs` boot and steady scene-frame paths must not issue large HYCOM viewport requests.

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OCEAN="$ROOT/server/gfs_service_parts/ocean_bait_frame.py"
SCENE="$ROOT/server/gfs_service_parts/lightning_cache_media.py"
ROUTES="$ROOT/server/gfs/routes.py"
fail(){ echo "FAIL: $*" >&2; exit 1; }

python3 -m py_compile "$OCEAN" "$SCENE" "$ROUTES" >/dev/null

grep -q 'def current_field_payload' "$OCEAN" || fail "missing current_field_payload service bridge"
grep -q 'def _find_boater_scene_cache_ocean_points' "$OCEAN" || fail "missing boater scene-cache bridge scanner"
grep -q 'scene_cache_boater_ocean_points_bridge' "$OCEAN" || fail "missing required bridge source"
grep -q 'boater.oceanAnalysisPoints.points' "$OCEAN" || fail "must prefer boater.oceanAnalysisPoints.points"
grep -q 'boater.oceanPoints.points' "$OCEAN" || fail "must accept boater.oceanPoints.points"
grep -q 'bridge_from_boater_scene_cache' "$OCEAN" || fail "missing bridge diagnostic flag"
grep -q 'bridged_point_count' "$OCEAN" || fail "missing bridged_point_count diagnostic"
grep -q 'boater_scene_cache_key' "$OCEAN" || fail "missing boater_scene_cache_key diagnostic"
grep -q 'direct_ocean_points_cache_key' "$OCEAN" || fail "missing direct_ocean_points_cache_key diagnostic"
grep -q 'fallback_warm_used' "$OCEAN" || fail "missing fallback_warm_used diagnostic"
grep -q '_promote_boater_scene_ocean_points_to_direct_cache' "$OCEAN" || fail "missing direct ocean-points promotion helper"
grep -q '_promote_boater_scene_ocean_points_to_direct_cache(out, bbox, visible_bbox)' "$SCENE" || fail "boater scene-cache write must promote to direct ocean-points cache"
grep -q 'current_field_payload' "$ROUTES" || fail "/gfs/api/field route must call current_field_payload"
grep -q '_attach_boater_bridge_to_ocean_consumer_payload(out, boater_bridge, role="bait")' "$SCENE" || fail "bait builder must consume boater oceanAnalysisPoints bridge"
grep -q '_attach_boater_bridge_to_ocean_consumer_payload(out, boater_bridge, role="shark-intel")' "$SCENE" || fail "shark-intel builder must consume boater oceanAnalysisPoints bridge"

python3 - <<'PY'
from pathlib import Path
src = Path('server/gfs_service_parts/ocean_bait_frame.py').read_text()
start = src.index('    def current_field_payload')
end = src.index('    def ocean_points_payload', start)
body = src[start:end]
assert body.index('_find_boater_scene_cache_ocean_points') < body.index('self.ocean_points_payload'), 'bridge must happen before legacy ocean_points_payload warmer'
assert '"source": "scene_cache_boater_ocean_points_bridge"' in body or 'source="scene_cache_boater_ocean_points_bridge"' in body
for field in ['"current_points": points', '"ocean_points": points', '"points": points']:
    assert field in src, f'missing {field}'
assert '"fallback_warm_used": False' in src
print('PASS current-field boater scene-cache bridge static contract')
PY

echo "OK: current field bridge contract passes"

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$ROOT/static/js/gfs/main.js"
INLAND="$ROOT/static/js/gfs/inland-water.js"
ROUTES="$ROOT/server/gfs/routes.py"
fail=0
check_contains() {
  local file="$1" pattern="$2" msg="$3"
  if ! grep -qE "$pattern" "$file"; then
    echo "FAIL: $msg" >&2
    fail=1
  else
    echo "OK: $msg"
  fi
}
check_absent() {
  local file="$1" pattern="$2" msg="$3"
  if grep -qE "$pattern" "$file"; then
    echo "FAIL: $msg" >&2
    fail=1
  else
    echo "OK: $msg"
  fi
}
check_contains "$MAIN" "INLAND_DETAIL_TIERS.*harbor.*local.*coastal.*regional|INLAND_DETAIL_TIERS.*regional" "frontend detail tiers include zoomed inland bait tiers"
check_contains "$MAIN" "baitAllowed: isInlandDetailTier\(tier\)" "frontend baitAllowed comes from detail tier"
check_contains "$MAIN" "overviewOnly: !isInlandDetailTier\(tier\)" "frontend overviewOnly is inverse of detail tier"
check_contains "$INLAND" "payload\?\.inland_bait_render_allowed === true" "renderer obeys inland_bait_render_allowed true"
check_contains "$INLAND" "payload\?\.overview_only === true.*return false|overview_only === true\) return false" "renderer blocks bait on overview_only"
check_contains "$ROUTES" "def _inland_detail_allowed_for_tier" "backend has detail tier helper"
check_contains "$ROUTES" "inland_bait_render_allowed.*_inland_detail_allowed_for_tier" "backend annotates inland_bait_render_allowed by tier"
check_contains "$ROUTES" "overview_only.*not _inland_detail_allowed_for_tier" "backend annotates overview_only by tier"
check_absent "$MAIN" "geometry=coarse|geometry:\s*'coarse'|geometry:\s*\"coarse\"" "frontend does not request coarse inland geometry"
check_absent "$ROUTES" "geometry\s*=\s*[\'\"]coarse[\'\"]" "backend does not force coarse inland geometry"
exit "$fail"

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$ROOT/static/js/gfs/main.js"
ROUTES="$ROOT/server/gfs/routes.py"
PAYLOADS="$ROOT/server/gfs/inland/payloads.py"
fail(){ echo "[FAIL] $*" >&2; exit 1; }

grep -q "function inlandWaterGeometryForTier" "$MAIN" || fail "missing inlandWaterGeometryForTier"
grep -q "return 'vector';" "$MAIN" || fail "frontend must request vector inland-water geometry only"
! grep -q 'geometry = "coarse"' "$ROUTES" || fail "routes.py still forces geometry=coarse"
! grep -q 'NHDPLUS_GEOMETRY_MODE.*coarse' "$ROUTES" || fail "routes.py can still launch coarse NHD builds"
grep -q 'legacy_simplified_mode_removed' "$PAYLOADS" || fail "payloads must mark legacy simplified requests as removed"
grep -q 'geometry_mode = "vector"' "$PAYLOADS" || fail "payloads must normalize inland-water geometry to vector"
python3 -m py_compile "$ROUTES" "$PAYLOADS" >/dev/null
if command -v node >/dev/null 2>&1; then node --check "$MAIN" >/dev/null; else echo "[WARN] node not found; skipped JS syntax check"; fi
echo "[OK] inland-water simplified geometry branch removed from active app paths"

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JS="$ROOT/static/js/gfs/inland-water.js"
PY="$ROOT/server/gfs/inland/payloads.py"

fail(){ echo "[FAIL] $*" >&2; exit 1; }

grep -q "selectInlandOverviewPolygons" "$JS" || fail "missing client overview one-lake-per-tile selector"
grep -q "pruneExistingInlandRender" "$JS" || fail "missing stale inland render prune"
grep -q "single_active_inland_water_scene_no_overview_detail_overlap" "$JS" || fail "missing overview/detail no-overlap policy diagnostic"
grep -q "overview_one_lake_per_tile" "$JS" || fail "missing overview render mode tag"
grep -q "detail_all_accepted_lakes" "$JS" || fail "missing zoomed detail render mode tag"
grep -q "data-inland-render-token" "$JS" || fail "missing render token tagging"
grep -q '"overview_only": _lod_tier(scene_tier, lod) == "world"' "$PY" || fail "server runtime world payload must mark overview_only"
grep -q '"inland_bait_render_allowed": _lod_tier(scene_tier, lod) != "world"' "$PY" || fail "server runtime world payload must gate inland bait"
if command -v node >/dev/null 2>&1; then node --check "$JS" >/dev/null; else echo "[WARN] node not found; skipped JS syntax check"; fi
python3 -m py_compile "$PY"
echo "[OK] inland overview/detail replacement contract enforced"

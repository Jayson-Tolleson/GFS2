#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PAYLOADS="$ROOT/server/gfs/inland/payloads.py"
BUILDER="$ROOT/scripts/build_nhdplus_hr_tiles.py"
MAIN="$ROOT/static/js/gfs/main.js"
LIGHTNING_MEDIA="$ROOT/server/gfs_service_parts/lightning_cache_media.py"
fail(){ echo "[FAIL] $*" >&2; exit 1; }

# Active inland-water runtime must be vector-only.
grep -q 'geometry_mode = "vector"' "$PAYLOADS" || fail "payloads must force geometry_mode vector"
grep -q 'static_placeholder_fallback_disabled' "$PAYLOADS" || fail "payloads must advertise disabled static placeholder fallback"
grep -q 'real_vector_required' "$PAYLOADS" || fail "payloads must advertise real-vector-only mode"
grep -q 'static_major_lake_placeholder_fallback_disabled_real_vector_only' "$PAYLOADS" || fail "static major-lake placeholder fallback must be disabled"
grep -q 'def _legacy_low_detail_artifact' "$PAYLOADS" || fail "missing old low-detail artifact rejection helper"

# The old literal inland-water active request pattern must not exist.
! grep -RIn 'geometry=("vector" if detail_allowed else "coarse")' "$ROOT/server/gfs" "$ROOT/server/gfs_service_parts" >/tmp/inland_bad_pattern.$$ 2>/dev/null || { cat /tmp/inland_bad_pattern.$$; rm -f /tmp/inland_bad_pattern.$$; fail "active backend can still request geometry=coarse"; }
rm -f /tmp/inland_bad_pattern.$$
! grep -RInE 'geometry=("vector" if detail_allowed else|geometry[[:space:]]*=[[:space:]]*["'"'"']coarse["'"'"'])' "$ROOT/server/gfs" "$ROOT/server/gfs_service_parts" "$ROOT/static/js/gfs/main.js" >/tmp/inland_bad_geometry.$$ 2>/dev/null || { cat /tmp/inland_bad_geometry.$$; rm -f /tmp/inland_bad_geometry.$$; fail "active inland geometry path is not vector-only"; }
rm -f /tmp/inland_bad_geometry.$$

# Builder must preserve raw vector vertices even if an old environment variable requests a legacy mode.
grep -q 'legacy_simplified_requested_ignored' "$BUILDER" || fail "builder must ignore legacy simplified geometry mode"
grep -q 'raw_vertices_preserved.*True' "$BUILDER" || fail "builder must preserve raw vertices"
! grep -q 'thin_path(src_path' "$BUILDER" || fail "builder still thins source path"

grep -q "return 'vector';" "$MAIN" || fail "frontend must request vector geometry"
python3 -m py_compile "$PAYLOADS" "$BUILDER" "$LIGHTNING_MEDIA" >/dev/null
if command -v node >/dev/null 2>&1; then node --check "$MAIN" >/dev/null; else echo "[WARN] node not found; skipped JS syntax check"; fi

echo "[OK] inland-water real-vector-only contract: no static placeholders, no old simplified tiles, vector overview only"

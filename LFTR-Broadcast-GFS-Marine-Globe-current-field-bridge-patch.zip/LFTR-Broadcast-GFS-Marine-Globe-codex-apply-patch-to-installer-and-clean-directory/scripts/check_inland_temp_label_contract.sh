#!/usr/bin/env bash
set -euo pipefail
FILE="${1:-static/js/gfs/inland-water.js}"
if [[ ! -f "$FILE" ]]; then
  echo "FAIL missing $FILE" >&2
  exit 1
fi
node --check "$FILE"
if ! grep -q 'function getInlandTempLabelStyle' "$FILE"; then
  echo "FAIL getInlandTempLabelStyle helper missing" >&2
  exit 1
fi
if grep -Eq 'tempLabelFontSize\s*\(' "$FILE"; then
  echo "FAIL undeclared tempLabelFontSize call remains" >&2
  exit 1
fi
if grep -Eq 'tempLabelAltitude\s*\(' "$FILE"; then
  echo "FAIL undeclared tempLabelAltitude call remains" >&2
  exit 1
fi
if ! grep -q 'readInlandTempF' "$FILE"; then
  echo "FAIL temp field guard helper missing" >&2
  exit 1
fi
if ! grep -Eq 'tempC|temp_c|temperature_c|water_temp_c' "$FILE"; then
  echo "FAIL Celsius temp fallback not visible" >&2
  exit 1
fi
if ! grep -q 'isFiniteInlandPosition' "$FILE"; then
  echo "FAIL invalid coordinate/altitude guard missing" >&2
  exit 1
fi
if ! grep -q 'tempLabelsSkippedNoTemp' "$FILE"; then
  echo "FAIL temp label diagnostics missing" >&2
  exit 1
fi
echo "PASS inland temp label contract"

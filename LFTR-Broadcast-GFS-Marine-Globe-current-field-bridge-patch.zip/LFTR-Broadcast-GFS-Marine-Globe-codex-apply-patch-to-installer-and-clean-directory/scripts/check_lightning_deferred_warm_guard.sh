#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILE="$ROOT/server/gfs_service_parts/lightning_cache_media.py"
fail(){ echo "FAIL: $*" >&2; exit 1; }

grep -q 'GFS_ENABLE_GLM_DEFERRED_WARM' "$FILE" || fail "GLM deferred warm must be opt-in"
grep -q 'cache_only_glm_deferred_warm_disabled' "$FILE" || fail "lightning cache shell must expose disabled deferred warm mode"
grep -q 'geometry="vector"' "$FILE" || fail "inland temp companion must request vector geometry"
! grep -q 'geometry=("vector" if detail_allowed else "coarse")' "$FILE" || fail "inland temp companion still has coarse branch"

echo "OK: lightning deferred warm guard and inland vector geometry contract pass"

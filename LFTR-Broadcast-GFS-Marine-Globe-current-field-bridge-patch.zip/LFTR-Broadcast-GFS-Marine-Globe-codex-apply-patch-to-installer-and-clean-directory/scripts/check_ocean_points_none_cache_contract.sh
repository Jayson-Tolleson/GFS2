#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILE="$ROOT/server/gfs_service_parts/ocean_bait_frame.py"
fail(){ echo "FAIL: $*" >&2; exit 1; }

grep -q 'cache_meta = payload.get("cache")' "$FILE" || fail "split warm must read cache_meta"
grep -q 'if not isinstance(cache_meta, dict)' "$FILE" || fail "split warm must normalize None cache to dict"
! grep -q 'payload.setdefault("cache", {})\["warmed_by"\]' "$FILE" || fail "unsafe payload.setdefault cache assignment remains"
grep -q '"mode": "live_tile_merged"' "$FILE" || fail "tile merged ocean payload must include cache metadata"
grep -q 'boater_live_from_ocean_payload_no_cache_meta' "$FILE" || fail "boater payload must guard missing/null ocean cache"

echo "OK: ocean points/boater split warm cache None contract passes"

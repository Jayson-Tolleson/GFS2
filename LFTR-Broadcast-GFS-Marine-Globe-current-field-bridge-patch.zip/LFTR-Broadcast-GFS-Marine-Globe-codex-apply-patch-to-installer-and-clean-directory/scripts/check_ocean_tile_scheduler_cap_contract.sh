#!/usr/bin/env bash
set -euo pipefail
printf 'Checking ocean tile scheduler cap contract...\n'
fail=0
if rg -n --glob '!docs/archive/**' --glob '!*.md' --glob '!*.txt' --glob '!scripts/check_ocean_tile_scheduler_cap_contract.sh' 'ocean/tile-refresh scheduled=' server scripts static/js/gfs >/tmp/lftr_ocean_old_tile_log.txt 2>/dev/null; then
  echo 'FAIL old uncapped ocean/tile-refresh scheduled= log string still exists:'
  cat /tmp/lftr_ocean_old_tile_log.txt
  fail=1
else
  echo 'PASS no old uncapped scheduled= tile-refresh log string'
fi
for pattern in '_cap_ocean_provider_tiles' 'requested_tiles_total=%s scheduled=%s' 'skipped_tiles_budget' 'partial_refresh'; do
  if rg -n "$pattern" server/gfs_service_parts/ocean_bait_frame.py >/dev/null; then
    echo "PASS found $pattern"
  else
    echo "FAIL missing $pattern in ocean_bait_frame.py"
    fail=1
  fi
done
python3 - <<'PY'
from pathlib import Path
src = Path('server/gfs_service_parts/ocean_bait_frame.py').read_text()
assert 'defaults = {"world": 8, "regional": 24, "coastal": 64, "local": 64, "harbor": 64}' in src
assert 'requested_tiles_total' in src and 'skipped_tiles_budget' in src and 'partial_refresh' in src
assert 'scheduled=966' not in src and 'scheduled=1056' not in src
print('PASS static world/regional/coastal cap assertions')
PY
if [[ "$fail" -ne 0 ]]; then
  echo 'FAIL ocean tile scheduler cap contract failed.'
  exit 1
fi
echo 'PASS ocean tile scheduler cap contract.'
